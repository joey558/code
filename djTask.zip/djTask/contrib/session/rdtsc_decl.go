package session

func Cputicks() (t uint64)

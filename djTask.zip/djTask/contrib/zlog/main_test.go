package zlog

import (
	"fmt"
	"testing"
	"time"
)

func Test_Search(t *testing.T) {
	start := time.Now().AddDate(0, 0, -1).Unix()
	end := time.Now().Unix()
	c, err := Search("10086", "trader", start, end, 0)
	if err != nil {
		fmt.Println(err)
	}
	fmt.Println(c)
}

func Test_Push(t *testing.T) {

	New([]string{"tcp://23.99.118.176:1883"}, "23.99.118.176:3100")

	m := map[string]interface{}{
		"cid":   "可识别ID",
		"flags": "adminLogin",
		"level": "INFO",
		"user":  "park",
		"msg":   "用户登录",
		"ip":    "127.0.0.1",
	}
	err := Push(m)
	if err != nil {
		fmt.Printf("zlog 数据保存失败 err:%s", err.Error())
	}

}

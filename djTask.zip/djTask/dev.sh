#! /bin/bash

DIR=$(dirname $(readlink -f $0))
PROJECT="djTask"
BRANCH="dev"
ETCDS="34.92.193.98:2379,34.92.58.208:2379"
TASK_CFG_PATH="/dj/dev/task/bob.json"
TRADE_CFG_PATH="/dj/dev/admin/admin.json"

git fetch
git checkout $BRANCH
git pull
git submodule init
git submodule update
go build -o $PROJECT

pkill $PROJECT
#mkdir log 2>/dev/null
#chmod +x $PROJECT
nohup ${DIR}/$PROJECT $ETCDS $TASK_CFG_PATH confirm > /data/logs/djTask/confirm.log 2>&1 &
nohup ${DIR}/$PROJECT $ETCDS $TASK_CFG_PATH settle > /data/logs/djTask/settle.log 2>&1 &
nohup ${DIR}/$PROJECT $ETCDS $TASK_CFG_PATH credit > /data/logs/djTask/credit.log 2>&1 &
nohup ${DIR}/$PROJECT $ETCDS $TRADE_CFG_PATH handicap > /data/logs/djTask/handicap.log 2>&1 &
nohup ${DIR}/$PROJECT $ETCDS $TRADE_CFG_PATH autoOdd > /data/logs/djTask/autoOdd.log 2>&1 &
nohup ${DIR}/$PROJECT $ETCDS $TRADE_CFG_PATH monitor > /data/logs/djTask/monitor.log 2>&1 &
nohup ${DIR}/$PROJECT $ETCDS $TRADE_CFG_PATH riskLimit > /data/logs/djTask/riskLimit.log 2>&1 &

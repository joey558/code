package schema

type MarketSuspendedReq struct {
	MatchID  string `json:"match_id"`
	MarketID string `json:"market_id"`
}

type MarketSuspendedRsp struct {
	Ok bool `json:"ok"`
}
package calc

import (
	"database/sql"
	"fmt"
	g "github.com/doug-martin/goqu/v9"
	_ "github.com/doug-martin/goqu/v9/dialect/mysql"
	"github.com/doug-martin/goqu/v9/exp"
	"github.com/jmoiron/sqlx"
	"reflect"
)

var (
	dialect = g.Dialect("mysql")
)

type Conn struct {
	Db *sqlx.DB
	Tx *sql.Tx
}

type QueryArg struct {
	Db      *sqlx.DB                // db connection
	Table   string                  // table
	Fields  []interface{}           // query fields
	Ex      []exp.Expression        // where conditions
	Order   []exp.OrderedExpression // order conditions
	GroupBy []interface{}           // group by fields
	Offset  uint                    // offset
	Limit   uint                    // limit
}

/**
 * @Description: 根据model结构获取db查询字段
 * @Author: maxic
 * @Date: 2020/12/25
 * @LastEditTime: 2020/12/25
 * @LastEditors: maxic
 **/
func EnumFields(obj interface{}) []interface{} {

	rt := reflect.TypeOf(obj)
	if rt.Kind() != reflect.Struct {
		return nil
	}

	var fields []interface{}
	for i := 0; i < rt.NumField(); i++ {
		f := rt.Field(i)
		if field := f.Tag.Get("db"); field != "" && field != "-" {
			fields = append(fields, field)
		}
	}

	return fields
}

/**
 * @Description: 插入记录
 * @Author: maxic
 * @Date: 2020/12/25
 * @LastEditTime: 2020/12/25
 * @LastEditors: maxic
 **/
func Insert(db Conn, table string, rows ...interface{}) (sql.Result, error) {

	if db.Db == nil && db.Tx == nil {
		return nil, fmt.Errorf("no conn")
	}
	query, _, _ := dialect.Insert(table).Rows(rows...).ToSQL()
	Println(query)

	var (
		res sql.Result
		err error
	)

	if db.Tx != nil {
		res, err = db.Tx.Exec(query)
	} else {
		res, err = db.Db.Exec(query)
	}
	if err != nil {
		Printf("insert into %s err: %s\n", table, err.Error())
	}

	return res, err
}

/**
 * @Description: 更新记录
 * @Author: maxic
 * @Date: 2020/12/25
 * @LastEditTime: 2020/12/25
 * @LastEditors: maxic
 **/
func Update(db Conn, table string, record g.Record, ex ...g.Expression) (sql.Result, error) {

	if db.Db == nil && db.Tx == nil {
		return nil, fmt.Errorf("no conn")
	}
	query, _, _ := dialect.Update(table).Set(record).Where(ex...).ToSQL()
	Println(query)

	var (
		res sql.Result
		err error
	)

	if db.Tx != nil {
		res, err = db.Tx.Exec(query)
	} else {
		res, err = db.Db.Exec(query)
	}
	if err != nil {
		Printf("update %s err: %s\n", table, err.Error())
	}

	return res, err
}

/**
 * @Description: 删除记录
 * @Author: maxic
 * @Date: 2020/12/25
 * @LastEditTime: 2020/12/25
 * @LastEditors: maxic
 **/
func Delete(db Conn, table string, ex ...exp.Expression) (sql.Result, error) {

	if db.Db == nil && db.Tx == nil {
		return nil, fmt.Errorf("no conn")
	}
	query, _, _ := dialect.Delete(table).Where(ex...).ToSQL()
	Println(query)

	var (
		res sql.Result
		err error
	)

	if db.Tx != nil {
		res, err = db.Tx.Exec(query)
	} else {
		res, err = db.Db.Exec(query)
	}
	if err != nil {
		Printf("delete from %s err: %s\n", table, err.Error())
	}

	return res, err
}

/**
 * @Description: 查询单条记录
 * @Author: maxic
 * @Date: 2020/12/25
 * @LastEditTime: 2020/12/25
 * @LastEditors: maxic
 **/
func SelectOne(data interface{}, db *sqlx.DB, table string, fields []interface{}, ex ...exp.Expression) error {

	query, _, _ := dialect.Select(fields...).From(table).Where(ex...).Limit(1).ToSQL()
	Println(query)
	err := db.Get(data, query)
	if err != nil {
		Printf("get %s err: %s\n", table, err.Error())
	}

	return err
}

/**
 * @Description: 查询多条记录
 * @Author: maxic
 * @Date: 2020/12/25
 * @LastEditTime: 2020/12/25
 * @LastEditors: maxic
 **/
func SelectAll(data interface{}, args QueryArg) error {

	if args.Db == nil {
		return fmt.Errorf("invalid db")
	}
	if args.Table == "" {
		return fmt.Errorf("invalid table")
	}
	if len(args.Fields) == 0 {
		return fmt.Errorf("invalid fields")
	}

	ds := dialect.Select(args.Fields...).From(args.Table)

	if len(args.Ex) > 0 {
		ds = ds.Where(args.Ex...)
	}

	if len(args.GroupBy) > 0 {
		ds = ds.GroupBy(args.GroupBy...)
	}

	if len(args.Order) > 0 {
		ds = ds.Order(args.Order...)
	}

	if args.Offset > 0 {
		ds = ds.Offset(args.Offset)
	}

	if args.Limit > 0 {
		ds = ds.Limit(args.Limit)
	}

	query, _, _ := ds.ToSQL()
	Println(query)

	err := args.Db.Select(data, query)
	if err != nil {
		Printf("select %s err: %s\n", args.Table, err.Error())
	}

	return err
}

/**
 * @Description: 查询表记录数
 * @Author: maxic
 * @Date: 2020/12/25
 * @LastEditTime: 2020/12/25
 * @LastEditors: maxic
 **/
func Count(db *sqlx.DB, table string, ex ...exp.Expression) (int, error) {

	var count int
	query, _, _ := dialect.Select(g.COUNT(1)).From(table).Where(ex...).ToSQL()
	Println(query)
	err := db.Get(&count, query)
	if err != nil {
		Printf("count %s err: %s\n", table, err.Error())
	}

	return count, err
}

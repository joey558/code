package calc

import (
	"fmt"
	"strconv"
	"strings"
	"time"

	"github.com/scylladb/go-set"

	"github.com/go-redis/redis/v7"
	"github.com/scylladb/go-set/strset"
	"github.com/valyala/fastjson"
)

/**
* @Description: 设置赛事/盘口缓存
* @Author: maxic
* @Date: 2020/8/19
* @LastEditTime: 2020/8/19
* @LastEditors: maxic
**/
func MatchCacheSet(pipe redis.Pipeliner, matchId, path string, data interface{}, updateIndex bool) {

	var value interface{}
	var msg interface{}
	switch data.(type) {
	case float32:
		value = fmt.Sprintf("%0.3f", data.(float32))
		msg = value
	case float64:
		value = fmt.Sprintf("%0.3f", data.(float64))
		msg = value
	case string:
		value = `"` + data.(string) + `"`
		msg = value
	case []byte:
		value = data
		msg = string(data.([]byte))
	default:
		value = data
		msg = value
	}

	key := fmt.Sprintf(RedisGameView, matchId)
	err := pipe.Do("JSON.SET", key, path, value).Err()
	if err != nil {
		Println("[ JSON.SET", key, path, msg, "] fail:", err.Error())
	} else {
		Println("[ JSON.SET", key, path, msg, "]")
	}

	if updateIndex {
		key := fmt.Sprintf(RedisGameIndex, matchId)
		err = pipe.Do("JSON.SET", key, path, value).Err()
		if err != nil {
			Println("[ JSON.SET", key, path, msg, "] fail:", err.Error())
		} else {
			Println("[ JSON.SET", key, path, msg, "]")
		}
	}
}

/**
* @Description: 冠军赛事获取
* @Author: daxie
* @Date: 2021/4/1 15:23
* @LastEditTime: 2021/4/1 15:23
* @LastEditors: daxie
 */
func MatchChampCacheGet(pool *redis.Client, mchIds []string) (map[string]interface{}, error) {

	res := make(map[string]interface{})
	cmds := make(map[string]*redis.Cmd)
	pipe := pool.Pipeline()
	for _, v := range mchIds {
		key := fmt.Sprintf(RedisGameView, v)
		cmds[v] = pipe.Do("JSON.GET", key, "NOESCAPE", ".")
	}

	_, err := pipe.Exec()
	_ = pipe.Close()
	if err != nil {
		return res, err
	}

	for mchID, cmd := range cmds {

		val, err := cmd.Result()
		if err != nil {
			continue
		}

		if val != nil {
			res[mchID] = val.(string)
		}
	}

	return res, nil
}

/**
 * @Description: 赛事zset维护
 * @Author: maxic
 * @Date: 2020/8/19
 * @LastEditTime: 2020/8/19
 * @LastEditors: maxic
 **/
func MatchZSetUpdate(pipe redis.Pipeliner, match MatchBrief) {

	keyLive := fmt.Sprintf(RedisGameLive, match.GameID)
	keyEarly := fmt.Sprintf(RedisGameEarly, match.GameID)
	keyComplex := fmt.Sprintf(RedisGameComplex, match.GameID)
	keyResult := fmt.Sprintf(redisGameResult, match.GameID)
	keyAnchor := fmt.Sprintf(redisGameAnchor, match.GameID)
	keyChamp := fmt.Sprintf(redisGameChamp, match.GameID)

	// 删除旧key
	pipe.ZRem(keyLive, match.ID)
	pipe.ZRem(keyEarly, match.ID)
	pipe.ZRem(keyComplex, match.ID)
	pipe.ZRem(keyResult, match.ID)
	pipe.ZRem(keyAnchor, match.ID)
	pipe.ZRem(keyChamp, match.ID)

	pipe.ZRem(RedisGameLiveAll, match.ID)
	pipe.ZRem(RedisGameEarlyAll, match.ID)
	pipe.ZRem(RedisGameComplexAll, match.ID)
	pipe.ZRem(RedisGameResultAll, match.ID)
	pipe.ZRem(RedisGameAnchorAll, match.ID)
	pipe.ZRem(RedisGameChampAll, match.ID)

	// 指定时间范围
	rangeEarly := GameNavTimeRangeGet(NavFlagEarly)
	rangeLive := GameNavTimeRangeGet(NavFlagLive)
	rangeComplex := GameNavTimeRangeGet(NavFlagComplex)
	rangeResult := GameNavTimeRangeGet(NavFlagResult)
	rangeChamp := GameNavTimeRangeGet(NavFlagChamp)

	record := &redis.Z{
		Score:  float64(match.StartTime),
		Member: match.ID,
	}

	fnBetween := func(time int64, ranges [2]int64) bool {
		if time >= ranges[0] && time <= ranges[1] {
			return true
		}
		return false
	}

	fnIn := func(status int, ranges []int) bool {
		for _, r := range ranges {
			if status == r {
				return true
			}
		}
		return false
	}

	// 赛事状态: 待录入-1 待审核-2 已驳回-3 待开盘-4 已开盘-5 已关盘-6 已结算-7 待取消-8 比赛取消-9
	// 赛前（非滚球中）
	if (fnBetween(match.StartTime, rangeEarly) && match.IsLive == 1) && match.Category != MatchCategoryChampion && match.Status == 5 && match.Visible == 1 && match.MktCount > 0 {
		pipe.ZAdd(keyEarly, record)
		pipe.ZAdd(RedisGameEarlyAll, record)
	}
	// 滚球
	if fnBetween(match.StartTime, rangeLive) && match.Status == 5 && match.Visible == 1 && match.LiveSupport == 1 && match.MktCount > 0 {
		pipe.ZAdd(keyLive, record)
		pipe.ZAdd(RedisGameLiveAll, record)
	}
	// 串关
	if fnBetween(match.StartTime, rangeComplex) && match.Status == 5 && match.Visible == 1 && match.IsPassOff >= 1 && match.MktCount > 0 {
		pipe.ZAdd(keyComplex, record)
		pipe.ZAdd(RedisGameComplexAll, record)
	}
	// 赛果
	if fnBetween(match.StartTime, rangeResult) && fnIn(match.Status, []int{6, 7, 9}) && match.Category != MatchCategoryChampion && match.Visible == 1 && match.MktCount > 0 {
		if match.Status == 6 {
			if match.SettledMktCount != 0 {
				pipe.ZAdd(keyResult, record)
				pipe.ZAdd(RedisGameResultAll, record)
			}
		} else {
			pipe.ZAdd(keyResult, record)
			pipe.ZAdd(RedisGameResultAll, record)
		}
	}
	// 主播盘
	if match.Category == MatchCategoryAnchor && match.Status == 5 && match.Visible == 1 && match.MktCount > 0 {
		pipe.ZAdd(keyAnchor, record)
		pipe.ZAdd(RedisGameAnchorAll, record)
	}
	// 冠军盘
	if fnBetween(match.StartTime, rangeChamp) && match.Category == MatchCategoryChampion && fnIn(match.Status, []int{5, 6, 7, 9}) && match.Visible == 1 && match.MktCount > 0 {
		if match.Status == MatchStatusSettle || match.Status == MatchStatusCancel { // 已结算 和已取消的 丢入zset最底部
			record.Score = float64(match.StartTime + int64(100000000))
		}
		pipe.ZAdd(keyChamp, record)
		pipe.ZAdd(RedisGameChampAll, record)
	}
}

/**
 * @Description: 删除赛事缓存
 * @Author: maxic
 * @Date: 2020/8/20
 * @LastEditTime: 2020/8/20
 * @LastEditors: maxic
 **/
func MatchCacheDel(pipe redis.Pipeliner, gameId, matchId, tourId string) {

	// 删除缓存对应分类
	keyLive := fmt.Sprintf(RedisGameLive, gameId)
	keyEarly := fmt.Sprintf(RedisGameEarly, gameId)
	keyComplex := fmt.Sprintf(RedisGameComplex, gameId)
	keyResult := fmt.Sprintf(redisGameResult, gameId)
	keyAnchor := fmt.Sprintf(redisGameAnchor, gameId)
	keyChamp := fmt.Sprintf(redisGameChamp, gameId)
	keyTourMatch := fmt.Sprintf(RedisGameTourMatch, gameId, tourId)           //前台游戏联赛赛事列表 gtour:<gameId>:<tourId>
	keyTourChampMatch := fmt.Sprintf(RedisGameTourChampMatch, gameId, tourId) //前台游戏联赛冠军赛事列表 gtourChamp:<gameId>:<tourId>
	pipe.ZRem(keyLive, matchId)
	pipe.ZRem(keyEarly, matchId)
	pipe.ZRem(keyComplex, matchId)
	pipe.ZRem(keyResult, matchId)
	pipe.ZRem(keyAnchor, matchId)
	pipe.ZRem(keyChamp, matchId)
	pipe.ZRem(keyTourMatch, matchId)
	pipe.ZRem(keyTourChampMatch, matchId)
	// 删除缓存数据
	keys := []string{
		fmt.Sprintf(RedisGameView, matchId),
		fmt.Sprintf(RedisGameIndex, matchId),
	}
	pipe.Del(keys...)
}

/**
 * @Description: 删除盘口缓存
 * @Author: maxic
 * @Date: 2020/8/18
 * @LastEditTime: 2020/8/18
 * @LastEditors: maxic
 **/
func MarketCacheDel(pipe redis.Pipeliner, matchId, marketId string, updateIndex bool) {

	key := fmt.Sprintf(RedisGameView, matchId)
	path := fmt.Sprintf(JPathMarket, marketId)
	pipe.Do("JSON.DEL", key, path)

	if updateIndex {
		key = fmt.Sprintf(RedisGameIndex, matchId)
		path = fmt.Sprintf(JPathMarket, marketId)
		pipe.Do("JSON.DEL", key, path)
	}
}

func parseMatch(v *fastjson.Value, matches map[string]MatchData) {

	m := MatchData{}

	m.Bo = v.GetInt("bo")
	m.Visible = v.GetInt("visible")
	m.Status = v.GetInt("status")
	m.IsLive = v.GetInt("is_live")
	m.Category = v.GetInt("category")
	m.Suspended = v.GetInt("suspended")
	m.StartTime = v.GetInt64("start_time")
	m.CloseTime = v.GetInt64("close_time")
	m.EndTime = v.GetInt64("end_time")
	m.MatchLevel = v.GetInt("match_level")
	m.IsPassOff = v.GetInt("is_pass_off")
	m.LiveSupport = v.GetInt("live_support")
	m.BetDelayTime = v.GetInt("bet_delay_time")
	m.Rec = v.GetInt("rec")
	m.MbMchPrizeLimit = v.GetInt("mb_mch_prize_limit")
	m.RndComplexPrizeLimit = v.GetInt("rnd_comp_prize_limit")
	m.RndComplexMchPrizeLimit = v.GetInt("rnd_comp_mch_prize_limit")
	m.RndCompOddDscnt = v.GetFloat64("rnd_comp_odd_dscnt")
	m.ID = string(v.GetStringBytes("id"))
	m.GameID = string(v.GetStringBytes("game_id"))
	m.TeamID = string(v.GetStringBytes("team_id"))
	m.MatchTeam = string(v.GetStringBytes("match_team"))
	m.MatchCnTeam = string(v.GetStringBytes("match_cn_team"))
	m.MatchEnTeam = string(v.GetStringBytes("match_en_team"))
	m.Score = string(v.GetStringBytes("score"))
	m.UserVideoURL = string(v.GetStringBytes("user_video_url"))
	m.AdminVideoURL = string(v.GetStringBytes("admin_video_url"))
	m.TournamentID = string(v.GetStringBytes("tournament_id"))
	m.TournamentShortName = string(v.GetStringBytes("tournament_short_name"))
	m.TournamentCnName = string(v.GetStringBytes("tournament_cn_name"))
	m.VideoType = v.GetInt("video_type")
	m.VideoLabel = v.GetInt("video_label")
	m.CreditLevel = v.GetInt("credit_level")
	m.MixPrizeLimit = v.GetInt("mix_mch_prize_limit")
	m.MixOddDscnt = v.GetFloat64("mix_odd_dscnt")
	matches[m.ID] = m
}

func parseMarket(value *fastjson.Value, markets map[string]MarketData, odds map[string]OddData) {

	o := value.GetObject("markets")
	o.Visit(func(k []byte, v *fastjson.Value) {

		_ = k
		m := MarketData{
			ID:                string(v.GetStringBytes("id")),
			MatchID:           string(v.GetStringBytes("match_id")),
			OddTypeID:         string(v.GetStringBytes("odd_type_id")),
			CnName:            string(v.GetStringBytes("cn_name")),
			EnName:            string(v.GetStringBytes("en_name")),
			Remark:            string(v.GetStringBytes("remark")),
			SubMktID:          string(v.GetStringBytes("sub_mkt_id")),
			SubOddID:          string(v.GetStringBytes("sub_odd_id")),
			Round:             v.GetInt("round"),
			IsDefault:         v.GetInt("is_default"),
			OptionType:        v.GetInt("option_type"),
			SortCode:          v.GetInt("sort_code"),
			CompSubNum:        v.GetInt("comp_sub_num"),
			Status:            v.GetInt("status"),
			Suspended:         v.GetInt("suspended"),
			Visible:           v.GetInt("visible"),
			PrizeLimit:        v.GetInt("prize_limit"),
			MbMktPrizeLimit:   v.GetInt("mb_mkt_prize_limit"),
			WarningProfit:     v.GetInt("warning_profit"),
			StopProfit:        v.GetInt("stop_profit"),
			PrizeStaticProfit: v.GetInt("prize_static_profit"),
			Tag:               string(v.GetStringBytes("tag")),
			TagCode:           v.GetInt("tag_code"),
			IsPassOff:         v.GetInt("is_pass_off"),
			MchCompPrizeLimit: v.GetInt("mch_comp_prize_limit"),
			SuspendedType:     v.GetInt("suspended_type"),
			VisibleType:       v.GetInt("visible_type"),
		}

		markets[m.ID] = m

		odd := v.GetObject("odds")
		odd.Visit(func(kk []byte, vv *fastjson.Value) {

			_ = kk

			d := OddData{
				ID:        string(vv.GetStringBytes("id")),
				IsWinner:  vv.GetInt("visible"),
				MatchID:   string(v.GetStringBytes("match_id")),
				MarketID:  string(vv.GetStringBytes("market_id")),
				Name:      string(vv.GetStringBytes("name")),
				EnName:    string(vv.GetStringBytes("en_name")),
				Odd:       string(vv.GetStringBytes("odd")),
				SortID:    vv.GetInt("sort_id"),
				Visible:   vv.GetInt("visible"),
				Suspended: vv.GetInt("suspended"),
			}

			odds[d.ID] = d
		})
	})

}

func HandicapMatchInfo(pool *redis.Client, matchID []string) (map[string]MatchData, error) {

	matches := map[string]MatchData{}

	var cmds []*redis.Cmd
	pipe := pool.Pipeline()
	for _, v := range matchID {
		key := fmt.Sprintf(RedisGameView, v)
		cmds = append(cmds, pipe.Do("JSON.GET", key, "NOESCAPE", "."))
	}

	_, _ = pipe.Exec()

	for _, cmd := range cmds {

		val, err := cmd.Result()
		if err != nil {
			continue
		}

		if val == nil {
			continue
		}

		var p fastjson.Parser
		v, err := p.Parse(val.(string))
		if err != nil {
			continue
		}

		parseMatch(v, matches)
	}

	return matches, nil
}

func HandicapMarketInfo(pool *redis.Client, matchID, marketID string) (MarketData, []OddData, error) {

	var (
		market MarketData
		odds   []OddData
		p      fastjson.Parser
	)
	key := fmt.Sprintf(RedisGameView, matchID)
	res, err := pool.Do("JSON.GET", key, "NOESCAPE", ".markets.$"+marketID).Text()
	if err != nil {
		return market, nil, err
	}
	v, err := p.Parse(res)
	if err != nil {
		return market, nil, err
	}
	obj, err := v.Object()
	if err != nil {
		return market, nil, err
	}

	round, _ := obj.Get("round").Int()
	isDefault, _ := obj.Get("is_default").Int()
	optionType, _ := obj.Get("option_type").Int()
	sortCode, _ := obj.Get("sort_code").Int()
	compSubNum := 0
	if obj.Get("comp_sub_num") != nil {
		compSubNum, _ = obj.Get("comp_sub_num").Int()
	}
	status, _ := obj.Get("status").Int()
	suspended, _ := obj.Get("suspended").Int()
	visible, _ := obj.Get("visible").Int()
	prizeLimit, _ := obj.Get("prize_limit").Int()
	mktLimit, _ := obj.Get("mb_mkt_prize_limit").Int()
	przStaticProf, _ := obj.Get("prize_static_profit").Int()
	suspendedType := 0
	if obj.Get("suspended_type") != nil {
		suspendedType, _ = obj.Get("suspended_type").Int()
	}
	visibleType := 0
	if obj.Get("visible_type") != nil {
		visibleType, _ = obj.Get("visible_type").Int()
	}

	subMktID, subOddID := "", ""
	if obj.Get("sub_mkt_id") != nil {
		subMktID = obj.Get("sub_mkt_id").String()
	}
	if obj.Get("sub_odd_id") != nil {
		subOddID = obj.Get("sub_odd_id").String()
	}
	market = MarketData{
		ID:                obj.Get("id").String(),
		MatchID:           obj.Get("match_id").String(),
		OddTypeID:         obj.Get("odd_type_id").String(),
		CnName:            obj.Get("cn_name").String(),
		EnName:            obj.Get("en_name").String(),
		SubMktID:          subMktID,
		SubOddID:          subOddID,
		Round:             round,
		IsDefault:         isDefault,
		OptionType:        optionType,
		SortCode:          sortCode,
		CompSubNum:        compSubNum,
		Status:            status,
		Suspended:         suspended,
		Visible:           visible,
		PrizeLimit:        prizeLimit,
		MbMktPrizeLimit:   mktLimit,
		PrizeStaticProfit: przStaticProf,
		SuspendedType:     suspendedType,
		VisibleType:       visibleType,
	}

	odd := obj.Get("odds").GetObject()
	odd.Visit(func(kk []byte, vv *fastjson.Value) {

		_ = kk
		odds = append(odds, OddData{
			ID:        string(vv.GetStringBytes("id")),
			IsWinner:  vv.GetInt("visible"),
			MatchID:   string(v.GetStringBytes("match_id")),
			MarketID:  string(vv.GetStringBytes("market_id")),
			Name:      string(vv.GetStringBytes("name")),
			Odd:       string(vv.GetStringBytes("odd")),
			SortID:    vv.GetInt("sort_id"),
			Visible:   vv.GetInt("visible"),
			Suspended: vv.GetInt("suspended"),
		})
	})

	return market, odds, nil
}

func HandicapInfo(pool *redis.Client, matchID []string) (HandicapData, error) {

	hd := HandicapData{}
	hd.Matches = map[string]MatchData{}
	hd.Markets = map[string]MarketData{}
	hd.Odds = map[string]OddData{}

	var cmds []*redis.Cmd
	pipe := pool.Pipeline()
	for _, v := range matchID {
		key := fmt.Sprintf(RedisGameView, v)
		cmds = append(cmds, pipe.Do("JSON.GET", key, "NOESCAPE", "."))
	}

	_, _ = pipe.Exec()

	for _, cmd := range cmds {

		val, err := cmd.Result()
		if err != nil {
			continue
		}

		if val == nil {
			continue
		}

		var p fastjson.Parser
		v, err := p.Parse(val.(string))
		if err != nil {
			continue
		}

		parseMatch(v, hd.Matches)
		parseMarket(v, hd.Markets, hd.Odds)
	}

	return hd, nil
}

/**
 * @Description: 游戏导航赛事数(通过赛事id获取游戏id, 再过滤)
 * @Author: xp
 * @Date: 2021/7/23 10:00
 * @LastEditTime: 2021/7/23 10:00
 * @LastEditors: xp
 */
func filterMatchByGameId(pipe redis.Pipeliner, matchIds []string, filterSet *strset.Set) ([]string, error) {

	if matchIds == nil || len(matchIds) == 0 || filterSet.Size() == 0 {
		return matchIds, nil
	}

	cmds := make(map[string]*redis.Cmd)
	for _, mchId := range matchIds {
		key := fmt.Sprintf(RedisGameIndex, mchId)
		cmds[mchId] = pipe.Do("JSON.GET", key, ".game_id")
	}
	_, err := pipe.Exec()
	if err != nil && err != redis.Nil {
		return matchIds, err
	}

	result := []string{}
	for mchId, cmd := range cmds {
		gameId, err := cmd.Text()
		if err != nil {
			continue
		}

		gameId = strings.ReplaceAll(gameId, "\"", "")
		if gameId != "" && !filterSet.Has(gameId) {
			result = append(result, mchId)
		}
	}

	return result, nil
}

/**
 * @Description: 获取用户前端index主页数据
 * @Author: maxic
 * @Date: 2020/8/15
 * @LastEditTime: 2020/8/15
 * @LastEditors: maxic
 **/
func GameIndexGet(pool *redis.Client, gameIds string, flag, day int, pageSize int64, now time.Time, merchantID uint64) (interface{}, error) {

	begin := time.Now()
	defer func() {
		cost := time.Since(begin)
		if cost.Seconds() > 3 {
			fmt.Println("[GameIndexGet] slow query. cost:", cost, ", args:", gameIds, flag, day, pageSize, now)
		}
	}()

	var keys []string
	min, max, limit, reverse := gameIndexGetRange(flag, day, now)

	if gameIds == "0" { //取全部游戏
		switch flag {
		case 2: // 2:赛前
			keys = append(keys, RedisGameEarlyAll)
		case 3: // 3:滚盘
			keys = append(keys, RedisGameLiveAll)
		case 4: // 4:串关
			keys = append(keys, RedisGameComplexAll)
		case 5: // 5:赛果
			keys = append(keys, RedisGameResultAll)
		case 6: // 6:筛选（所有: 早盘+赛果）
			keys = append(keys, RedisGameEarlyAll, RedisGameResultAll)
		case 7: // 主播盘
			keys = append(keys, RedisGameAnchorAll)
		case 8: // 冠军盘
			keys = append(keys, RedisGameChampAll)
		}
	} else {
		ids := strings.Split(gameIds, ",")
		for _, v := range ids {
			switch flag {
			case 2: // 2:赛前
				keys = append(keys, fmt.Sprintf(RedisGameEarly, v))
			case 3: // 3:滚盘
				keys = append(keys, fmt.Sprintf(RedisGameLive, v))
			case 4: // 4:串关
				complexKey := fmt.Sprintf(RedisGameComplex, v)
				keys = append(keys, complexKey)
			case 5: // 5:赛果
				keys = append(keys, fmt.Sprintf(redisGameResult, v))
			case 6: // 6:筛选（所有: 早盘+赛果）
				keys = append(keys, fmt.Sprintf(RedisGameEarly, v), fmt.Sprintf(redisGameResult, v))
			case 7: // 主播盘
				keys = append(keys, fmt.Sprintf(redisGameAnchor, v))
			case 8: // 冠军盘
				keys = append(keys, fmt.Sprintf(redisGameChamp, v))
			}
		}
	}

	zRangeBy := redis.ZRangeBy{
		Min: min,
		Max: max,
	}

	if limit {
		zRangeBy = redis.ZRangeBy{
			Min:    min,
			Max:    max,
			Offset: 0,
			Count:  pageSize,
		}
	}

	var (
		res      []interface{}
		cmds     []*redis.Cmd
		matchIds []string
		err      error
	)

	mpKeys := map[string]int{}
	for _, v := range keys {

		var res []string
		if reverse {
			res, err = pool.ZRevRangeByScore(v, &zRangeBy).Result()
		} else {
			res, err = pool.ZRangeByScore(v, &zRangeBy).Result()
		}

		if err != nil {
			fmt.Println("[GameIndexGet]", err)
			return "", err
		}
		for _, vv := range res {
			if _, ok := mpKeys[vv]; !ok {
				matchIds = append(matchIds, vv)
				mpKeys[vv] = 1
			}
		}
	}

	pipe := pool.Pipeline()

	for _, matchId := range matchIds {
		key := fmt.Sprintf(RedisGameIndex, matchId)
		if flag == 8 { // 冠军盘
			key = fmt.Sprintf(RedisGameView, matchId)
		}
		cmds = append(cmds, pipe.Do("JSON.GET", key, "NOESCAPE", "."))
	}

	pipe.Exec()

	for _, cmd := range cmds {

		val, err := cmd.Result()
		if err != nil {
			continue
		}

		if val != nil {
			res = append(res, val.(string))
		}
	}

	return res, nil
}

func gameIndexGetRange(flag, day int, now time.Time) (string, string, bool, bool) {

	var (
		limit   bool
		reverse bool
	)
	y, m, d := now.Date()
	today := time.Date(y, m, d, 0, 0, 0, 0, now.Location())
	tomorrow := today.AddDate(0, 0, 1)
	min, max := "-inf", "+inf"

	switch flag {
	case 1: // 1:今日
		min = "0"
		max = fmt.Sprintf("%d", tomorrow.Add(time.Hour).Unix()-1) // 有可能存在滚球跨天的情况所以这里需要加一个小时
	case 2, 4: // 2:赛前 4:串关
		// 赛前 - 次日至30天内,如果day=999(其他日期)，则展示15-30天内的赛事
		min = "0"
		maxDay := 1
		if day == 999 {
			day = 15
			maxDay = 16
		}

		date := today.AddDate(0, 0, day)
		if day > 0 {
			min = fmt.Sprintf("%d", date.Unix())
		}
		max = fmt.Sprintf("%d", date.AddDate(0, 0, maxDay).Unix()-1)
		if flag == 2 { // 赛前分页，串关因为有滚球赛事，所以一次性返回，让前分页端和排序
			limit = true
		}
	case 3: // 3:滚盘
		// 滚球 - 今日至30天内
		min = "0"
		max = fmt.Sprintf("%d", tomorrow.AddDate(0, 0, 30).Unix()-1)
	case 5: // 5:赛果
		// 赛果 - 7天内至今日
		date := tomorrow.AddDate(0, 0, -day)
		min = fmt.Sprintf("%d", date.AddDate(0, 0, -1).Unix())
		max = fmt.Sprintf("%d", date.Unix()-1)
		limit = true
		reverse = true
	case 8: // 8：冠军盘
		limit = true
	}

	return min, max, limit, reverse
}

/**
* @Description: 根据matchID获取赛事index rejson
* @Author: brandon
* @Date: 2020/8/17 8:00 下午
* @LastEditTime: 2020/8/17 8:00 下午
* @LastEditors: brandon
 */
func MatchIndexGet(pool *redis.Client, mchIds []string, merchantID uint64) ([]interface{}, error) {

	var res []interface{}
	var cmds []*redis.Cmd
	pipe := pool.Pipeline()

	filterSet, err := GetMerchantFilterGameSet(pool, merchantID)
	if err != nil {
		return nil, err
	}

	mchIds, err = filterMatchByGameId(pipe, mchIds, filterSet)
	if err != nil {
		return nil, err
	}

	for _, v := range mchIds {
		key := fmt.Sprintf(RedisGameIndex, v)
		cmds = append(cmds, pipe.Do("JSON.GET", key, "NOESCAPE", "."))
	}

	pipe.Exec()

	for _, cmd := range cmds {

		val, err := cmd.Result()
		if err != nil {
			continue
		}

		if val != nil {
			res = append(res, val.(string))
		}
	}

	return res, nil
}

/**
 * @Description: 获取用户前端view赛事详情数据
 * @Author: maxic
 * @Date: 2020/8/15
 * @LastEditTime: 2020/8/15
 * @LastEditors: maxic
 **/
func GameViewGet(pool *redis.Client, matchId string, merchantID uint64) (interface{}, error) {

	filterSet, err := GetMerchantFilterGameSet(pool, merchantID)
	if err != nil {
		return "", err
	}

	if filterSet.Size() > 0 {
		// 通过match_id获取game_id
		key := fmt.Sprintf(RedisGameView, matchId)
		gameId, err := pool.Do("JSON.GET", key, ".game_id").Text()
		if err != nil {
			return "", err
		}

		// 判断game_id是否被过滤
		gameId = strings.ReplaceAll(gameId, "\"", "")
		if gameId != "" && filterSet.Has(gameId) {
			return "", nil
		}
	}

	key := fmt.Sprintf(RedisGameView, matchId)
	return pool.Do("JSON.GET", key, "NOESCAPE", ".markets").Result()
}

/**
 * @Description: 设置游戏前端联赛缓存（开始比赛、显示比赛）
 * @Author: maxic
 * @Date: 2021/1/30
 * @LastEditTime: 2021/1/30
 * @LastEditors: maxic
 **/
func GameTourCacheSet(pipe redis.Pipeliner, gameId, tourId, matchId string, startTime int64, isChamp bool) {

	key := fmt.Sprintf(RedisGameTour, gameId)
	pipe.SAdd(key, tourId)
	key = fmt.Sprintf(RedisGameTourMatch, gameId, tourId)
	if isChamp {
		key = fmt.Sprintf(RedisGameTourChampMatch, gameId, tourId)
	}
	pipe.ZRem(key, matchId)
	pipe.ZAdd(key, &redis.Z{
		Score:  float64(startTime),
		Member: matchId,
	})
}

/**
 * @Description: 删除游戏前端联赛缓存（结束比赛、取消比赛、隐藏比赛）
 * @Author: maxic
 * @Date: 2021/1/30
 * @LastEditTime: 2021/1/30
 * @LastEditors: maxic
 **/
func GameTourCacheDel(pipe redis.Pipeliner, gameId, tourId, matchId string, isChamp bool) {

	key := fmt.Sprintf(RedisGameTourMatch, gameId, tourId)
	if isChamp {
		key = fmt.Sprintf(RedisGameTourChampMatch, gameId, tourId)
	}
	pipe.ZRem(key, matchId)
}

/**
 * @Description: 清空游戏前端联赛缓存（初始化前调用）
 * @Author: maxic
 * @Date: 2021/1/30
 * @LastEditTime: 2021/1/30
 * @LastEditors: maxic
 **/
func GameTourCacheClear(pool *redis.Client, gameId string) error {

	key := fmt.Sprintf(RedisGameTour, gameId)
	tours, err := pool.SMembers(key).Result()
	if err != nil {
		fmt.Println("[ SMembers ", key, "] err:", err)
		return err
	}

	pipe := pool.Pipeline()
	defer pipe.Close()

	for _, tour := range tours {
		key = fmt.Sprintf(RedisGameTourMatch, gameId, tour)
		pipe.Unlink(key)
	}

	key = fmt.Sprintf(RedisGameTour, gameId)
	pipe.Unlink(key)

	_, err = pipe.Exec()
	if err != nil {
		fmt.Println("GameTourCacheClear pipe.Exec err:", err)
		return err
	}

	return nil
}

/**
 * @Description: 获取联赛列表
 * @Author: maxic
 * @Date: 2021/1/30
 * @LastEditTime: 2021/1/30
 * @LastEditors: maxic
 **/
func GameTourCacheGet(pool *redis.Client, gameId, tourId string, merchantID uint64) (interface{}, error) {

	filterSet, err := GetMerchantFilterGameSet(pool, merchantID)
	if err != nil {
		return nil, err
	}
	// 游戏被过滤，直接返回空数组
	if filterSet.Has(gameId) {
		return map[string][]string{}, nil
	}

	var tours []string
	if tourId != "" {
		tours = append(tours, tourId)
	} else {
		key := fmt.Sprintf(RedisGameTour, gameId)
		tours, err = pool.SMembers(key).Result()
		if err != nil {
			fmt.Println("GameTourGet pool.ZRange err:", err)
			return nil, err
		}
	}

	loc, _ := time.LoadLocation("Asia/Shanghai")
	now := time.Now()
	entTime := time.Date(now.Year(), now.Month(), now.Day()+31, 0, 0, 0, 0, loc).Unix()
	zRangeBy := &redis.ZRangeBy{
		Min: "0",
		Max: fmt.Sprintf("%d", entTime),
	}

	cmds := map[string]*redis.StringSliceCmd{}
	champCmds := map[string]*redis.StringSliceCmd{}
	pipe := pool.Pipeline()
	for _, tour := range tours {
		// 获取联赛非冠军赛事列表
		key := fmt.Sprintf(RedisGameTourMatch, gameId, tour)
		cmds[tour] = pipe.ZRangeByScore(key, zRangeBy)
		// 获取联赛冠军赛列表
		champKey := fmt.Sprintf(RedisGameTourChampMatch, gameId, tour)
		champCmds[tour] = pipe.ZRange(champKey, 0, -1)
	}

	_, err = pipe.Exec()
	if err != nil {
		fmt.Println("GameTourGet pipe.Exec err:", err)
		return nil, err
	}

	gameTour := map[string][]string{}
	for tmtId, cmd := range cmds {
		matches, _ := cmd.Result()
		if tourId == tmtId {
			gameTour[tourId] = matches
		} else {
			if len(matches) > 0 {
				gameTour[tmtId] = matches
			}
		}
	}
	//  冠军赛事处理
	for tmtId, cmd := range champCmds {
		matches, _ := cmd.Result()
		if item, ok := gameTour[tmtId]; ok {
			item = append(item, matches...)
			gameTour[tmtId] = item
		} else {
			if len(matches) > 0 {
				gameTour[tmtId] = matches
			}
		}
	}

	return gameTour, nil
}

/**
* @Description: 获取商户过滤的游戏列表
* @Author: xp
* @Date: 2021/7/22
* @LastEditTime: 2021/7/22
* @LastEditors: xp
 */
func GetMerchantFilterGameSet(pool *redis.Client, merchantId uint64) (*strset.Set, error) {

	result := set.NewStringSet()
	if merchantId <= 0 {
		return result, nil
	}

	key := fmt.Sprintf(RedisMerchantFilterGame, merchantId)
	list, err := pool.SMembers(key).Result()
	if err != nil {
		return result, err
	}

	for _, gameId := range list {
		result.Add(gameId)
	}

	return result, nil
}

/**
* @Description: 获取所有商户过滤的游戏列表
* @Author: xp
* @Date: 2021/7/22
* @LastEditTime: 2021/7/22
* @LastEditors: xp
 */
func GetMerchantFilterGameMap(pool *redis.Client) (map[uint64]*strset.Set, error) {

	result := map[uint64]*strset.Set{}

	redisKey := strings.ReplaceAll(RedisMerchantFilterGame, "%d", "*")
	var (
		keys   []string
		err    error
		cursor uint64
	)

	for {
		var arr []string
		arr, cursor, err = pool.Scan(cursor, redisKey, 2000).Result()
		if err != nil {
			return result, err
		}

		for _, key := range arr {
			keys = append(keys, key)
		}

		if cursor == 0 {
			break
		}
	}

	// 批量获取商户对应的game_id
	pipe := pool.TxPipeline()
	defer pipe.Close()

	cmdMap := make(map[string]*redis.StringSliceCmd)
	for _, key := range keys {
		cmdMap[key] = pipe.SMembers(key)
	}
	_, err = pipe.Exec()
	if err != nil {
		return result, nil
	}

	for key, item := range cmdMap {
		arr, err := item.Result()
		if err != nil {
			return result, err
		}

		// 从key中截取merchantId
		key = strings.ReplaceAll(key, "merchant_filter_game:", "")
		merchantId, err := strconv.ParseUint(key, 10, 64)
		if err != nil {
			return result, err
		}

		for _, gameId := range arr {
			if gameIdSet, ok := result[merchantId]; !ok {
				gameIdSet = set.NewStringSet()
				gameIdSet.Add(gameId)
				result[merchantId] = gameIdSet
			} else {
				gameIdSet.Add(gameId)
			}
		}
	}

	return result, nil
}

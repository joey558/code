# djTask

后台任务服务。 包含模块：注单自动确认、操盘任务、撤单和结算、自动变赔、盘口监控、赛事自动隐藏

# 启动及初始化命令

启动滚球注单自动确认服务(商户)： ./djTask `<etcds>` `<cfgPath>` confirm  

启动操盘任务和撤单/结算服务(商户)： ./djTask `<etcds>` `<cfgPath>` settle  

启动信用网中心钱包接口超时异步处理任务和总控修改代理限额模式服务(商户)： ./djTask `<etcds>` `<cfgPath>` credit

启动自动变赔服务(总控)： ./djTask `<etcds>` `<cfgPath>` autoOdd  

启动盘口监控服务(总控)： ./djTask `<etcds>` `<cfgPath>` monitor  

启动赛事自动隐藏服务(总控)： ./djTask `<etcds>` `<cfgPath>` handicap  

# 注意事项
1. 所有商户的操盘动作、结算、撤单任务都是共用总控的beanstalk服务， 通过前缀(trade_,settle_,cancel_)加商户ID区分

2. 服务运行时间久了之后，目前会出现beanstalk 任务卡住的情况，无法正常删除已处理的job, 导致注单自动确认、操盘动作和结算无法正常使用。 目前还没有定位到问题，出现这种情况只能重启对应商户的djTask相关服务才能恢复

# Beanstalk任务监控
http://dj-prod-beanstalkd.emkcp.com:9993/public
package wallet

import (
	"fmt"
	mqtt "github.com/eclipse/paho.mqtt.golang"
)

/**
 * @Description: mqtt推送用户当前余额
 * @Author: wesley
 * @Date: 2020/6/14 14:31
 * @LastEditTime: 2020/6/14 14:31
 * @LastEditors: wesley
 */
func mqttPushBalance(cli mqtt.Client, uid uint64, memberAccount string,balance string) error {

	payload := fmt.Sprintf(mqttBalanceFormat,uid,memberAccount,balance)
	key := fmt.Sprintf("/member/balance/%d", uid)

	if token := cli.Publish(key, 1, false, payload); token.Wait() && token.Error() != nil {
		return token.Error()
	}

	return nil
}

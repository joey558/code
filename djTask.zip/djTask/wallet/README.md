# wallet

钱包服务

调用方法:

1.调用GetWallet 获取当前会员余额对象

2.调用OperateWallet

3.调用AddTransaction 插入账变

4.如果更新余额 调用UpdateBalanceInRedis 更新redis

说明:如果扣款，自行实现锁账户和调用BalanceIsEnough 获取当前会员余额是否充足




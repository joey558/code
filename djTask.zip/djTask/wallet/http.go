package wallet

import (
	"errors"
	"github.com/valyala/fasthttp"
	"net/http"
	"time"
)

type RespModel struct {
	Status string `json:"status"`
	Data   string `json:"data"`
}
type RespModelList struct {
	Status string            `json:"status"`
	Data   map[string]string `json:"data"`
}
type BetConfirmRespModel struct {
	Status    string `json:"status"`
	Data      string `json:"data"`
	Time      string `json:"time"`
	Signature string `json:"signature"`
}

var (
	defaultTimeout = 30 * time.Second
)

var fc = &fasthttp.Client{}

func httpDoTimeout(requestBody []byte, method string, requestURI string, headers map[string]string, timeout time.Duration) ([]byte, int, error) {

	req := fasthttp.AcquireRequest()
	resp := fasthttp.AcquireResponse()

	defer func() {
		fasthttp.ReleaseResponse(resp)
		fasthttp.ReleaseRequest(req)
	}()

	req.SetRequestURI(requestURI)
	req.Header.SetMethod(method)

	switch method {
	case "POST":
		req.SetBody(requestBody)
	}

	if headers != nil {
		for k, v := range headers {
			req.Header.Set(k, v)
		}
	}

	// time.Second * 30
	err := fc.DoTimeout(req, resp, timeout)

	return resp.Body(), resp.StatusCode(), err
}

func httpGetHelper(url, param string) (RespModel, error) {
	resp := RespModel{}
	url = url + "?" + param

	data, status, err := httpDoTimeout(nil, fasthttp.MethodGet, url, nil, XywHttpTimeout)
	if err != nil {
		return resp, err
	}

	if status != http.StatusOK {
		return resp, errors.New("未正确获取信息")
	}

	err = JsonUnmarshal(data, &resp)
	if err != nil {
		return resp, err
	}

	return resp, nil
}

func HttpPostHelper(url string, req []byte) (RespModel, error) {

	resp := RespModel{}

	headers := map[string]string{
		"Content-Type": "application/x-www-form-urlencoded",
	}

	data, status, err := httpDoTimeout(req, fasthttp.MethodPost, url, headers, XywHttpTimeout)
	if err != nil {
		return resp, err
	}
	if status != http.StatusOK {
		return resp, errors.New("未正确获取信息")
	}

	err = JsonUnmarshal(data, &resp)
	if err != nil {
		return resp, err
	}

	return resp, nil
}

func httpBetConfirmHelper(url string, req []byte) (BetConfirmRespModel, error) {

	resp := BetConfirmRespModel{}

	headers := map[string]string{
		"Content-Type": "application/x-www-form-urlencoded",
	}

	data, status, err := httpDoTimeout(req, fasthttp.MethodPost, url, headers, XywHttpTimeout)
	if err != nil {
		return resp, err
	}
	if status != http.StatusOK {
		return resp, errors.New("未正确获取信息")
	}

	err = JsonUnmarshal(data, &resp)
	if err != nil {
		return resp, err
	}

	return resp, nil
}

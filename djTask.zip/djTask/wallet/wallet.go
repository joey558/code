package wallet

import (
	"database/sql"
	"errors"
	"fmt"
	g "github.com/doug-martin/goqu/v9"
	_ "github.com/doug-martin/goqu/v9/dialect/mysql"
	mqtt "github.com/eclipse/paho.mqtt.golang"
	"github.com/go-redis/redis/v7"
	"github.com/jmoiron/sqlx"
	"github.com/shopspring/decimal"
	"github.com/valyala/fastrand"
	"strconv"
	"time"
)

//金流: 操作钱包余额类型
var balanceFundTypes = map[int]int{
	TransIn:             AddAmount,
	TransBetPrize:       AddAmount,
	TransBetCancel:      AddAmount,
	TransBetRefuse:      AddAmount,
	TransOut:            SubAmount,
	TransBet:            SubAmount,
	TransBetUndo:        AddAmount,
	TransBetPrizeDeduct: SubAmount,
}

var (
	dialect = g.Dialect("mysql")
)

//读取余额
func GetBalanceDBX(db *sqlx.DB, memberID uint64) (string, error) {

	var mb MemberBalance
	ex := g.Ex{
		"uid": memberID,
	}
	query, _, _ := dialect.From("tbl_member_balance").Select("uid", "balance").Where(ex).Limit(1).ToSQL()
	fmt.Println(query)
	err := db.Get(&mb, query)
	if err != nil {
		return "0", fmt.Errorf("member:%d query wallet failed:%s", memberID, err.Error())
	}

	return mb.Balance, nil
}

//读取redis余额数据
func GetBalanceRedis(pool *redis.Client, memberID uint64) (string, error) {

	redisKey := fmt.Sprintf(RedisKeyMemberWallet, memberID)
	balance, err := pool.Get(redisKey).Result()
	if err != nil || err == redis.Nil {
		return "0", err
	}

	fb, err := decimal.NewFromString(balance)
	if err != nil {
		return "0", err
	}

	return fb.Truncate(2).String(), nil
}

//批量读取redis余额数据
func GetBatchBalanceRedis(pool *redis.Client, uids []string) (map[string]string, error) {

	var keys []string
	for _, v := range uids {
		keys = append(keys, fmt.Sprintf("W:%s", v))
	}

	balances, err := pool.MGet(keys...).Result()
	if err != nil {
		return nil, err
	}

	res := map[string]string{}
	for i, uid := range uids {

		balance := "0"
		if cb, ok := balances[i].(string); ok {
			balance = cb
		}
		fb, err := decimal.NewFromString(balance)
		if err != nil {
			return nil, err
		}

		res[uid] = fb.Truncate(2).String()
	}

	return res, nil
}

//检查余额是否充足
func BalanceIsEnoughX(db *sqlx.DB, memberID uint64, amount decimal.Decimal) (decimal.Decimal, bool) {

	mb := MemberBalance{}
	ex := g.Ex{
		"uid": memberID,
	}
	balance := decimal.NewFromInt(0)
	query, _, _ := dialect.From("tbl_member_balance").Select("uid", "balance").Where(ex).Limit(1).ToSQL()
	fmt.Println(query)
	err := db.Get(&mb, query)
	if err != nil {
		return balance, false
	}

	balance, err = decimal.NewFromString(mb.Balance)
	if err != nil {
		return balance, false
	}

	if balance.Sub(amount).IsNegative() {
		return balance, false
	}

	return balance, true
}

//操作钱包 传入金额,无论加减钱都传正值
func TransferX(db *sqlx.DB, pool *redis.Client, cli mqtt.Client, param map[string]interface{}, amount decimal.Decimal, tradeType int) error {

	var (
		ok                    bool
		orderNo               string //订单号
		memberID              uint64 //会员id
		memberAccount         string //会员账号
		merchantID            uint64 //商户id
		merchantAccount       string //商户账号
		parentMerchantId      uint64 //父商户id
		parentMerchantAccount string //父商户账号
		topMerchantId         uint64 //顶层商户ID
		topMerchantAccount    string //顶层商户账户名
		sortLevel             string //商户排序层级
		deph                  uint64 //商户层深
		orderType             uint8  //注单类型
		tester                uint8  //是否测试
	)

	if orderNo, ok = param["order_no"].(string); !ok {
		return errors.New("order_no参数错误")
	}

	if memberID, ok = param["member_id"].(uint64); !ok {
		return errors.New("member_id参数错误")
	}
	if memberAccount, ok = param["member_account"].(string); !ok {
		return errors.New("member_account参数错误")
	}
	if merchantID, ok = param["merchant_id"].(uint64); !ok {
		return errors.New("merchant_id参数错误")
	}
	if merchantAccount, ok = param["merchant_account"].(string); !ok {
		return errors.New("merchant_account参数错误")
	}
	if parentMerchantId, ok = param["parent_merchant_id"].(uint64); !ok {
		return errors.New("parent_merchant_id参数错误")
	}
	if parentMerchantAccount, ok = param["parent_merchant_account"].(string); !ok {
		return errors.New("parent_merchant_account参数错误")
	}
	if topMerchantId, ok = param["top_merchant_id"].(uint64); !ok {
		return errors.New("top_merchant_id参数错误")
	}
	if topMerchantAccount, ok = param["top_merchant_account"].(string); !ok {
		return errors.New("top_merchant_account参数错误")
	}
	if sortLevel, ok = param["sort_level"].(string); !ok {
		return errors.New("sort_level参数错误")
	}
	if deph, ok = param["deph"].(uint64); !ok {
		return errors.New("deph参数错误")
	}
	if orderType, ok = param["order_type"].(uint8); !ok {
		return errors.New("order_type参数错误")
	}
	if tester, ok = param["tester"].(uint8); !ok {
		return errors.New("tester参数错误")
	}

	if tradeType > TransBetPrizeDeduct {
		return errors.New("tradeType参数错误")
	}

	current, err := GetBalanceDBX(db, memberID)
	if err != nil {
		return err
	}

	balance, err := decimal.NewFromString(current)
	if err != nil {
		return err
	}

	dbConn, err := db.Begin()
	if err != nil {
		return err
	}

	var balanceAfter decimal.Decimal
	amountType := balanceFundTypes[tradeType]
	operate := "+"
	if amountType == AddAmount {
		balanceAfter = balance.Add(amount)
	} else {
		balanceAfter = balance.Sub(amount)
		operate = "-"
	}
	ex := g.Ex{
		"uid": memberID,
	}
	record := g.Record{
		"balance": g.L(fmt.Sprintf("balance%s%s", operate, amount.String())),
	}
	query, _, _ := dialect.Update("tbl_member_balance").Set(record).Where(ex).ToSQL()
	fmt.Println(query)
	result, err := dbConn.Exec(query)
	if err != nil {
		_ = dbConn.Rollback()
		return err
	}

	if r, _ := result.RowsAffected(); r == 0 {
		_ = dbConn.Rollback()
		return fmt.Errorf("member:%d operateAmount:%s update balance failed", memberID, amount)
	}

	transID := GenId()
	trans := Transaction{
		BalanceBefore:         balance.String(),
		ID:                    transID,
		OrderNo:               orderNo,
		MemberID:              memberID,
		MemberAccount:         memberAccount,
		MerchantID:            merchantID,
		MerchantAccount:       merchantAccount,
		ParentMerchantID:      parentMerchantId,
		ParentMerchantAccount: parentMerchantAccount,
		TopMerchantId:         topMerchantId,
		TopMerchantAccount:    topMerchantAccount,
		SortLevel:             sortLevel,
		Deph:                  deph,
		TradeType:             uint8(tradeType),
		Amount:                amount.String(),
		CreatedTime:           time.Now().UnixNano() / 1e6,
		Tester:                tester,
		BalanceAfter:          balanceAfter.String(),
	}

	//增加账变
	query, _, _ = dialect.Insert("tbl_member_transaction").Rows(trans).ToSQL()
	fmt.Println(query)
	_, err = dbConn.Exec(query)
	if err != nil {
		_ = dbConn.Rollback()
		return err
	}

	// 正式账号
	if tester == 0 {
		switch tradeType {
		case TransBetPrizeDeduct: //撤销派彩
			betOrderID, err := strconv.ParseUint(orderNo, 10, 64)
			if err != nil {
				return errors.New("order_no error")
			}
			// 账变后余额为负
			if balanceAfter.LessThan(zeroAmount) {
				badDebt := BadDebtRecord{
					ID:                    GenId(),
					BetOrderID:            betOrderID,
					MemberID:              memberID,
					MemberAccount:         memberAccount,
					MerchantID:            merchantID,
					MerchantAccount:       merchantAccount,
					ParentMerchantID:      parentMerchantId,
					ParentMerchantAccount: parentMerchantAccount,
					TopMerchantId:         topMerchantId,
					TopMerchantAccount:    topMerchantAccount,
					SortLevel:             sortLevel,
					Deph:                  deph,
					BeforeAmount:          balance.String(),
					AfterAmount:           balanceAfter.String(),
					ReceivableAmount:      amount.String(),
					OrderType:             orderType,
					Ty:                    1, //坏账
					CreatedTime:           time.Now().UnixNano() / 1e6,
				}

				// 账变前余额为负
				if balance.LessThan(zeroAmount) {
					// 坏账未收回金额为撤销金额
					badDebt.UncollectedAmount = amount.String()
					// 已收金额为0
					badDebt.ReceivedAmount = "0"
				} else {
					// 坏账未收回金额为账变后余额取反
					Uncollected := zeroAmount.Sub(balanceAfter)
					badDebt.UncollectedAmount = Uncollected.String()
					// 已收金额为账变前余额
					badDebt.ReceivedAmount = balance.String()
				}

				//增加坏账记录
				query, _, _ = dialect.Insert("tbl_bad_debt_record").Rows(badDebt).ToSQL()
				fmt.Println(query)
				_, err = dbConn.Exec(query)
				if err != nil {
					_ = dbConn.Rollback()
					return err
				}
			}
		case TransBetCancel, TransBetPrize: //撤销回退本金，派彩
			betOrderID, err := strconv.ParseUint(orderNo, 10, 64)
			if err != nil {
				return errors.New("order_no error")
			}
			if balance.LessThan(zeroAmount) {
				badDebt := BadDebtRecord{
					ID:                    GenId(),
					BetOrderID:            betOrderID,
					MemberID:              memberID,
					MemberAccount:         memberAccount,
					MerchantID:            merchantID,
					MerchantAccount:       merchantAccount,
					ParentMerchantID:      parentMerchantId,
					ParentMerchantAccount: parentMerchantAccount,
					TopMerchantId:         topMerchantId,
					TopMerchantAccount:    topMerchantAccount,
					SortLevel:             sortLevel,
					Deph:                  deph,
					BeforeAmount:          balance.String(),
					AfterAmount:           balanceAfter.String(),
					ReceivableAmount:      zeroAmount.String(), //回退本金，派彩，此时为还回部分坏账金额，应回收金额不增加
					OrderType:             orderType,
					Ty:                    2, //扣回
					CreatedTime:           time.Now().UnixNano() / 1e6,
				}

				// 账变后余额大于0
				if balanceAfter.GreaterThanOrEqual(zeroAmount) {
					// 坏账未收回金额为账变前余额
					badDebt.UncollectedAmount = balance.String()
					// 坏账收回金额为账变前余额取反
					received := zeroAmount.Sub(balance)
					badDebt.ReceivedAmount = received.String()
				} else {
					// 坏账未收回金额为账变金额取反
					badDebt.UncollectedAmount = "-" + amount.String()
					// 坏账收回金额为账变金额
					badDebt.ReceivedAmount = amount.String()
				}

				//增加扣回记录
				query, _, _ = dialect.Insert("tbl_bad_debt_record").Rows(badDebt).ToSQL()
				fmt.Println(query)
				_, err = dbConn.Exec(query)
				if err != nil {
					_ = dbConn.Rollback()
					return err
				}
			}
		case TransIn: //资金转入
			if balance.LessThan(zeroAmount) {

				impact := ImpactRecord{
					ID:                    GenId(),
					TransactionID:         transID,
					MemberID:              memberID,
					MemberAccount:         memberAccount,
					MerchantID:            merchantID,
					MerchantAccount:       merchantAccount,
					ParentMerchantID:      parentMerchantId,
					ParentMerchantAccount: parentMerchantAccount,
					TopMerchantId:         topMerchantId,
					TopMerchantAccount:    topMerchantAccount,
					SortLevel:             sortLevel,
					Deph:                  deph,
					BeforeAmount:          balance.String(),
					AfterAmount:           balanceAfter.String(),
					CreatedTime:           time.Now().UnixNano() / 1e6,
				}

				// 转入后余额大于等于0
				if balanceAfter.GreaterThanOrEqual(zeroAmount) {
					//冲正金额为转入前余额取反
					impactAmount := zeroAmount.Sub(balance)
					impact.ImpactAmount = impactAmount.String()
				} else {
					// 冲正金额为转入金额
					impact.ImpactAmount = amount.String()
				}

				//增加冲正记录
				query, _, _ = dialect.Insert("tbl_impact_record").Rows(impact).ToSQL()
				fmt.Println(query)
				_, err = dbConn.Exec(query)
				if err != nil {
					_ = dbConn.Rollback()
					return err
				}
			}
		}
	}

	pipe := pool.TxPipeline()
	redisKey := fmt.Sprintf(RedisKeyMemberWallet, memberID)
	pipe.Set(redisKey, balanceAfter.String(), -1)

	err = dbConn.Commit()
	if err != nil {
		return err
	}

	_, _ = pipe.Exec()
	_ = pipe.Close()
	// 余额推送
	_ = mqttPushBalance(cli, memberID, memberAccount, balanceAfter.String())

	return nil
}

//操作钱包 传入金额,无论加减钱都传正值
func TxTransferX(dbConn *sql.Tx, pipe redis.Pipeliner, cli mqtt.Client, param map[string]interface{}, balance, amount decimal.Decimal, tradeType int) error {

	var (
		ok                    bool
		orderNo               string //注单id
		memberID              uint64 //会员id
		memberAccount         string //会员账号
		merchantID            uint64 //商户id
		merchantAccount       string //商户账号
		parentMerchantId      uint64 //父商户id
		parentMerchantAccount string //父商户账号
		topMerchantId         uint64 //顶层商户ID
		topMerchantAccount    string //顶层商户账户名
		sortLevel             string //商户排序层级
		deph                  uint64 //商户层深
		tester                uint8  //是否测试
	)

	if orderNo, ok = param["order_no"].(string); !ok {
		return errors.New("order_no参数错误")
	}
	if memberID, ok = param["member_id"].(uint64); !ok {
		return errors.New("member_id参数错误")
	}
	if memberAccount, ok = param["member_account"].(string); !ok {
		return errors.New("member_account参数错误")
	}
	if merchantID, ok = param["merchant_id"].(uint64); !ok {
		return errors.New("merchant_id参数错误")
	}
	if merchantAccount, ok = param["merchant_account"].(string); !ok {
		return errors.New("merchant_account参数错误")
	}
	if parentMerchantId, ok = param["parent_merchant_id"].(uint64); !ok {
		return errors.New("parent_merchant_id参数错误")
	}
	if parentMerchantAccount, ok = param["parent_merchant_account"].(string); !ok {
		return errors.New("parent_merchant_account参数错误")
	}
	if topMerchantId, ok = param["top_merchant_id"].(uint64); !ok {
		return errors.New("top_merchant_id参数错误")
	}
	if topMerchantAccount, ok = param["top_merchant_account"].(string); !ok {
		return errors.New("top_merchant_account参数错误")
	}
	if sortLevel, ok = param["sort_level"].(string); !ok {
		return errors.New("sort_level参数错误")
	}
	if deph, ok = param["deph"].(uint64); !ok {
		return errors.New("deph参数错误")
	}
	if tester, ok = param["tester"].(uint8); !ok {
		return errors.New("tester参数错误")
	}

	if tradeType > TransBetPrizeDeduct {
		return errors.New("tradeType参数错误")
	}

	var balanceAfter decimal.Decimal
	amountType := balanceFundTypes[tradeType]
	operate := "+"
	if amountType == AddAmount {
		balanceAfter = balance.Add(amount)
	} else {
		balanceAfter = balance.Sub(amount)
		operate = "-"
	}
	ex := g.Ex{
		"uid": memberID,
	}
	record := g.Record{
		"balance": g.L(fmt.Sprintf("balance%s%s", operate, amount.String())),
	}

	query, _, _ := dialect.Update("tbl_member_balance").Set(record).Where(ex).ToSQL()
	fmt.Println(query)
	result, err := dbConn.Exec(query)
	if err != nil {
		return err
	}

	if r, _ := result.RowsAffected(); r == 0 {
		return fmt.Errorf("member:%d operateAmount:%s update balance failed", memberID, amount)
	}

	transID := GenId()
	trans := Transaction{
		BalanceBefore:         balance.String(),
		ID:                    transID,
		OrderNo:               orderNo,
		MemberID:              memberID,
		MemberAccount:         memberAccount,
		MerchantID:            merchantID,
		MerchantAccount:       merchantAccount,
		ParentMerchantID:      parentMerchantId,
		ParentMerchantAccount: parentMerchantAccount,
		TopMerchantId:         topMerchantId,
		TopMerchantAccount:    topMerchantAccount,
		SortLevel:             sortLevel,
		Deph:                  deph,
		TradeType:             uint8(tradeType),
		Amount:                amount.String(),
		CreatedTime:           time.Now().UnixNano() / 1e6,
		Tester:                tester,
		BalanceAfter:          balanceAfter.String(),
	}

	//增加账变
	query, _, _ = dialect.Insert("tbl_member_transaction").Rows(trans).ToSQL()
	fmt.Println(query)
	_, err = dbConn.Exec(query)
	if err != nil {
		return err
	}

	redisKey := fmt.Sprintf(RedisKeyMemberWallet, memberID)
	pipe.Set(redisKey, balanceAfter.String(), -1)

	// 余额推送
	_ = mqttPushBalance(cli, memberID, memberAccount, balanceAfter.String())

	return nil
}

func GenId() uint64 {

	str := fmt.Sprintf("%d%d", Cputicks(), fastrand.Uint32n(9))
	val, err := strconv.ParseUint(str, 10, 64)
	if err != nil {
		return 0
	}

	return val
}
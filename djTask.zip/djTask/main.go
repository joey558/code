package main

import (
	"djTask/modules/confirm"
	"djTask/modules/credit"
	"djTask/modules/handicap"
	"djTask/modules/mktMonitor"
	autoOdd "djTask/modules/oddsChanged"
	"djTask/modules/riskLimit"
	"djTask/modules/settle"
	"fmt"
	"github.com/docker/docker/pkg/reexec"
	_ "go.uber.org/automaxprocs"
	"os"
	"os/exec"
	"strings"
)

type fn func([]string, string)

var cb = map[string]fn{
	"settle":    settle.Parse,
	"confirm":   confirm.Parse,
	"handicap":  handicap.Parse,
	"autoOdd":   autoOdd.Parse,
	"monitor":   mktMonitor.Parse,
	"credit":    credit.Parse,
	"riskLimit": riskLimit.Parse,
}

const (
	childProcessName = "djTask_child"
)

func init() {
	fmt.Printf("init, os.Args = %+v\n", os.Args)
	reexec.Register(childProcessName, childProcess)
	if reexec.Init() {
		os.Exit(0)
	}
}

func childProcess() {
	fmt.Printf("childProcess, os.Args = %+v\n", os.Args)
	usage := func() {
		fmt.Printf("%s <etcds> <cfgPath> [settle|confirm|risk|handicap|autoOdd|monitor|credit]\n", os.Args[0])
	}
	argc := len(os.Args)
	if argc != 4 {
		usage()
		os.Exit(2)
	}
	endpoints := strings.Split(os.Args[1], ",")
	if val, ok := cb[os.Args[3]]; ok {
		val(endpoints, os.Args[2])
	} else {
		usage()
		os.Exit(2)
	}
}

func main() {
	fmt.Printf("main, os.Args = %+v\n", os.Args)
	for {
		args := []string{childProcessName}
		for _, arg := range os.Args[1:] {
			args = append(args, arg)
		}
		cmd := reexec.Command(args...)
		cmd.Stdin = os.Stdin
		cmd.Stdout = os.Stdout
		cmd.Stderr = os.Stderr
		if err := cmd.Start(); err != nil {
			fmt.Printf("failed to run command: %s\n", err)
		}
		if err := cmd.Wait(); err != nil {
			fmt.Printf("failed to wait command: %s\n", err)
			if e, ok := err.(*exec.ExitError); ok {
				if e.ExitCode() == 2 {
					break
				}
			}
		}
	}
	fmt.Println("exit")
}

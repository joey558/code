package common

import "github.com/valyala/gorpc"

func InitRPC(addr string) *gorpc.Client {

	c := gorpc.NewTCPClient(addr)
	c.Start()

	return c
}

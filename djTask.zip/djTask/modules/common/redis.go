package common

import (
	"djTask/calc"
	"djTask/helper"
	"djTask/wallet"
	"fmt"
	"github.com/go-redis/redis/v7"
	"time"
)

const (
	// 自动变赔redis stream
	RedisStreamAutoOdd = "autoOdd"
	// 自动变赔各投注项累计赔付额
	RedisKeyOddAccumulation = "oddAccumulation"
	//联赛名称
	RedisTourName = "tmtInfo:%s"
	// c端中心钱包token与OB电竞会员ID关联映射
	RedisKeySToken = "stoken:%d"
	RedisKeyMember = "u:%d:%s" // 会员缓存
	// 冠军赛 战队缓存
	RedisMatchChampTeam = "mchChampTeam:%s"
)

func InitRedis(dsn []string, psd, name string, db int) *redis.Client {

	// var ctx = context.Background()
	rdb := redis.NewFailoverClient(&redis.FailoverOptions{
		MasterName:    name,
		SentinelAddrs: dsn,
		Password:      psd, // no password set
		DB:            db,  // use default DB
		DialTimeout:   10 * time.Second,
		ReadTimeout:   30 * time.Second,
		WriteTimeout:  30 * time.Second,
		PoolSize:      10,
		PoolTimeout:   30 * time.Second,
		MaxRetries:    2,
		IdleTimeout:   5 * time.Minute,
	})

	pong, err := rdb.Ping().Result()
	if err != nil {
		panic(err)
	}
	fmt.Println(pong, err)

	return rdb
}

// 公用哈希获取
func RedisHMGet(cli *redis.Client, keyName string, fileds []string) (map[string]string, error) {

	total := len(fileds)
	data := map[string]string{}
	value, err := cli.HMGet(keyName, fileds...).Result()
	if err != nil {
		return data, err
	}

	for i := 0; i < total; i++ {
		// 取出interface{}类型数据，转换时类型断言
		if v, ok := value[i].(string); ok {
			data[fileds[i]] = v
		} else {
			data[fileds[i]] = ""
		}
	}

	return data, nil
}

/**
 * @Description: 获取单个游戏名
 * @Author: maxic
 * @Date: 2020/10/14
 * @LastEditTime: 2021/9/28 14:50
 * @LastEditors: robin
 **/
func RedisGameNameGet(cli *redis.Client, gameId string) string {

	key := fmt.Sprintf(calc.RedisGameNav, gameId)
	gameName, err := RedisHMGet(cli, key, []string{"short_name"})
	if err != nil {
		return ""
	}
	return gameName["short_name"]
}

/**
 * @Description: 获取单个联赛名称
 * @Author: maxic
 * @Date: 2020/10/15
 * @LastEditTime: 2021/9/29 19:10
 * @LastEditors: robin
 **/
func GetTournamentNameGet(cli *redis.Client, tourId string) string {

	key := fmt.Sprintf(RedisTourName, tourId)
	tourName, err := RedisHMGet(cli, key, []string{"short_name"})
	if err != nil {
		return ""
	}
	return tourName["short_name"]
}

/**
 * @Description: 操盘动作发送stream消息
 * @Author: maxic
 * @Date: 2020/7/8
 * @LastEditTime: 2020/7/8
 * @LastEditors: maxic
 **/
func RedisSendTradeStream(cli *redis.Client, matchID, marketIds, extraInf, flag string) error {

	content := fmt.Sprintf("match_id=%s&market_id=%s&flag=%s", matchID, marketIds, flag)
	if len(extraInf) > 0 {
		content += extraInf
	}
	message := map[string]interface{}{
		"data": content,
	}
	args := &redis.XAddArgs{
		Stream:       RedisStreamTrade,
		MaxLenApprox: 50000,
		Values:       message,
	}
	return cli.XAdd(args).Err()
}

func RedisGetSToken(cli *redis.Client, uid uint64) string {

	sToken, err := cli.Get(fmt.Sprintf(RedisKeySToken, uid)).Result()
	if err != nil {
		return ""
	}

	return sToken
}

func RedisGetMember(cli *redis.Client, merchantId uint64, username string) (wallet.Member, error) {

	u := wallet.Member{}
	key := fmt.Sprintf(RedisKeyMember, merchantId, username)
	m, err := cli.Get(key).Result()
	if err == redis.Nil {
		return u, nil
	}
	if err != nil {
		return u, err
	}

	err = helper.JsonUnmarshalFromString(m, &u)

	return u, err
}

package common

import (
	"djTask/calc"
	"djTask/contrib/apollo"
)

type MerchantCfg struct {
	PoolSize int  `json:"pool_size"`
	Tenancy  bool `json:"tenancy"`
	Db       struct {
		Addr        string `json:"addr"`
		MaxIdleConn int    `json:"max_idle_conn"`
		MaxOpenConn int    `json:"max_open_conn"`
		MaxIdleTime int    `json:"max_idle_time"`
	} `json:"db"`
	TradeRedis struct {
		Addr     []string `json:"addr"`
		Password string   `json:"password"`
		Sentinel string   `json:"sentinel"`
	} `json:"trade_redis"`
	MerchantRedis struct {
		Addr     []string `json:"addr"`
		Password string   `json:"password"`
		Sentinel string   `json:"sentinel"`
		Db       int      `json:"db"`
	} `json:"merchant_redis"`
	Beanstalk   string   `json:"beanstalk"`
	ZkBeanstalk string   `json:"zk_beanstalk"`
	Mqtt        []string `json:"mqtt"`
	Zlog        struct {
		Brokers []string `json:"brokers"`
		URI     string   `json:"uri"`
	} `json:"zlog"`
	RocketMQ     []string
	Merchant     MerchantConf        `json:"merchant"`
	Credit       CreditCfg           `json:"credit"`
	ForeCastInfo calc.ForeCastConfig `json:"forecast_info"`
}

type TraderCfg struct {
	Trader struct {
		Addr string `json:"addr"`
	} `json:"trader"`
	Handicap struct {
		HTTP string `json:"http"`
	} `json:"handicap"`
	TraderDb struct {
		Db          string `json:"db"`
		MaxIdleConn int    `json:"max_idle_conn"`
		MaxOpenConn int    `json:"max_open_conn"`
	} `json:"trader_db"`
	RedisMaster struct {
		Addr     []string `json:"addr"`
		Password string   `json:"password"`
		Sentinel string   `json:"sentinel"`
	} `json:"redis_master"`
	Mqtt      []string `json:"mqtt"`
	Beanstalk string   `json:"beanstalk"`
	Zlog      struct {
		Brokers []string `json:"brokers"`
		URI     string   `json:"uri"`
	} `json:"zlog"`
	Oss struct {
		Endpoint string `json:"endpoint"`
		URL      string `json:"url"`
	} `json:"oss"`
	Fts struct {
		Addr string `json:"addr"`
	} `json:"fts"`
	Emqx      string         `json:"emqx"`
	Merchants []MerchantConf `json:"merchants"`
}

type MerchantConf struct {
	ID      uint64 `json:"id"`
	Account string `json:"account"`
}

type CreditCfg struct {
	Support           int               `json:"support"`             // 是否支持信用盘 0-不支持，1-支持
	SecretKey         string            `json:"secret_key"`          // 信用网商户秘钥
	CentralWalletHost string            `json:"central_wallet_host"` // 中心钱包接口地址
	Timeout           int               `json:"timeout"`             // 中心钱包接口超时时间
	RetryNum          int               `json:"retry_num"`           // 中心钱包接口重试次数
	Games             map[string]uint64 `json:"games"`               // 游戏map
}

func ParseCfg(v interface{}, endpoints []string, path string) {
	apollo.New(endpoints)
	if err := apollo.Parse(path, v); err != nil {
		panic(err)
	}
	apollo.Close()
}

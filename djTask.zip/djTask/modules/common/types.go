package common

import (
	g "github.com/doug-martin/goqu/v9"
	"github.com/shopspring/decimal"
)

var (
	OneDeci       = decimal.NewFromInt32(1)          // 1
	HundredDeci   = decimal.NewFromFloat32(100)      // 100
	MinOddDeci    = decimal.NewFromFloat32(1.001)    // 最低赔率值
	MaxOddDeci    = decimal.NewFromFloat32(9999.999) // 最高赔率值
	MaxTwoOddDeci = decimal.NewFromInt32(23)         // 两项盘最高赔率值
	Dialect       = g.Dialect("mysql")
)

// 注单状态
const (
	OrderStatusWaitConfirm = 1 // 待确认
	OrderStatusRefused     = 2 // 已拒绝
	OrderStatusWaitSettle  = 3 // 等待结算
	OrderStatusCancelled   = 4 // 已取消
	OrderStatusWin         = 5 // 已中奖
	OrderStatusLose        = 6 // 未中奖
	OrderStatusUndo        = 7 // 撤销
)

// 子单状态
const (
	OrderDetailStatusWaitSettle = 1 // 等待结算
	OrderDetailStatusCancelled  = 2 // 已取消
	OrderDetailStatusWin        = 3 // 已中奖
	OrderDetailStatusLose       = 4 // 未中奖
	OrderDetailStatusUndo       = 5 // 撤销
)

// 注单类型
const (
	OrderTypeSingle     = 1 //单注
	OrderTypeComplex    = 2 //串注
	OrderTypeRndComplex = 3 //单局串注
	OrderTypeMix        = 4 //复合玩法
)

// 取消类型
const (
	CancelTypeSettled   = 1 //取消已结算注单
	CancelTypeUnSettled = 2 //取消未结算注单
)

const (
	ConfirmTypeAuto          = 1 // 自动确认
	ConfirmTypeManualPrepare = 2 // 手动待确认
	ConfirmTypeManualAffirm  = 3 // 手动确认
	ConfirmTypeManualRefused = 4 // 手动拒绝
)

// 风险注单标识
const (
	RiskOrderFlagGen    = 1 // 风险注单生成
	RiskOrderFlagAccept = 2 // 风险注单接受
	RiskOrderFlagRefuse = 3 // 风险注单拒绝
)

// 盘口状态
const (
	MarketStatusWaitInput      = 1  // 待录入
	MarketStatusInputFinished  = 2  // 已录入
	MarketStatusInputReject    = 3  // 录入驳回
	MarketStatusPending        = 4  // 待审核
	MarketStatusWaitOpen       = 5  // 待开盘
	MarketStatusOpen           = 6  // 已开盘
	MarketStatusClose          = 7  // 已关盘
	MarketStatusWaitSettle     = 8  // 待结算
	MarketStatusSettled        = 9  // 已结算
	MarketStatusResultRejected = 10 // 赛果驳回
	MarketStatusWaitCancel     = 11 // 待取消
	MarketStatusCancelled      = 12 // 已取消
)

const (
	UserTypeNormal = 0 // 普通会员
	UserTypeTest   = 1 // 测试会员
	UserTypeCredit = 2 // 信用会员
)

const (
	MixMarketRuleInclude  = 0 // 复合盘口匹配规则-包含其中一个子盘口
	MixMarketRuleComplete = 1 // 复合玩法匹配规则-完整匹配所有子盘口
)

const (
	//会员注单状态变更
	mqttOrderStatusFormat = `{"uid":"%d","order_id":"%d","bet_status":"%d","theory_prize":"%s","odd":"%s","reason":"%d"}`
	//会员注单子单状态变更
	mqttOrderDetailStatusFormat = `{"uid":"%d","order_id":"%d","id":"%d","status":"%d","odd":"%s","reason":"%d"}`
	//盘口停止变赔通知
	mqttMarketAutoOddStop = `{"match_id":"%s","market_id":"%s","status":0,"msg":"%s"}`
	//盘口风险注单状态更新(接受/拒绝)
	//flag 1 风险注单生成 num 风险注单数目
	//flag 2 风险注单接受
	//flag 3 风险注单拒绝
	mqttMarketRiskOrderStatus = `{"match_id":"%s","market_id":"%s","flag":"%d","num":"%d"}`
	//盘口单注注单投注成功后推送更新盘口注单统计数据通知
	mqttMarketOrderBet = `{"match_id":"%s","market_id":"%s"}`
)

const (
	topicMemberOrderStatus       = "/member/bet/status/%d"        // 会员注单状态变更
	topicMemberOrderDetailStatus = "/member/bet_detail/status/%d" // 会员串注子单状态变更
	topicMatchActionVisible      = "/match/action/visible"        // 比赛(显示/隐藏)
	TopicMatchStatUpdate         = "/match/stat/update"           // 赛事计数更新
	TopicGameTourUpdate          = "/match/gameTour/update"       // 游戏联赛更新
	topicMarketOddsUpdate        = "/market/odds/update"          // 盘口变赔
	topicMarketAutoOddStop       = "/market/action/autoOdd"       // 盘口停赔
	topicMarketRiskOrderStatus   = "/market/risk_order/status/%s" // 盘口风险注单状态更新(接受/拒绝)
	topicMarketOrderBet          = "/market/order/bet/%s"         // 盘口注单统计更新通知
	topicMarketActionSuspended   = "/market/action/suspended"     // 盘口(暂停/取消暂停)
	topicMarketStatisticUpdate   = "/market/statistic/update"     // 盘口统计数量更新
	topicOddActionSuspended      = "/odd/action/suspended"        // 投注项暂停
	topicMatchRiskUpdate         = "/match/risk/update"           // 赛事风控设置更新
	topicMarketPrizeLimitUpdate  = "/market/prizeLimit/update"    // 盘口限红变更
)

const (
	RedisMarketMonitorRecord    = "monitor_info:%s"    // monitor_info:<market_id>
	RedisMarketOddMonitorRecord = "monitor_info:%s:%s" // monitor_info:<market_id>:<odd_id>
	RedisStreamMonitor          = "monitor"
	RedisStreamTrade            = "trade"
	RedisRiskWinLimit           = "riskWinLimit" // 限红比例
)

const (
	OptionTypeWinLose          = 1  // 输赢
	OptionTypeHandicap         = 2  // 让分
	OptionTypeOverUnder        = 3  // 大小
	OptionTypePloy             = 4  // 趣味
	OptionTypeCorrectScore     = 5  // 波胆
	OptionType1X2              = 6  // 胜平负
	OptionTypeOddEven          = 7  // 单双
	OptionTypeYesNo            = 8  // 是否
	OptionTypeComplex          = 9  // 复合
	OptionTypeSingleChampion   = 10 // 猜冠军（单项结算）
	OptionTypeMultipleChampion = 11 // 猜冠军（多项结算）
	OptionTypeMix              = 12 // 复合玩法
)

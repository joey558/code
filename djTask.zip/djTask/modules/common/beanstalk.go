package common

import (
	"djTask/helper"
	"fmt"
	"log"
	"net/url"
	"os"
	"strconv"
	"strings"
	"time"

	"github.com/beanstalkd/go-beanstalk"
	"github.com/panjf2000/ants/v2"
	cpool "github.com/silenceper/pool"
)

//tube list
const (
	BeanstalkSettleTube        = "settle_%s"           // 盘口结算
	BeanstalkMarketMonitorTube = "market_monitor"      // 盘口预警监控
	BeanstalkAutoOddTube       = "auto_odd"            // 自动变赔
	BeanstalkTradeTube         = "trade_%s"            // 操盘任务队列
	BeanstalkCancelTube        = "cancel_%s"           // 撤单任务队列
	BeanStalkBetOrderConfirm   = "bet_confirm_%s"      // 滚盘注单确认
	BeanStalkMatchAutoHide     = "match_auto_hide"     // 非滚盘赛事自动隐藏
	BeanStalkCreditTimeout     = "credit_timeout_%s"   // 信用钱包接口超时任务队列
	BeanStalkAgentLimitMode    = "agent_limit_mode_%s" // 总控后台修改代理限额模式
	BeanStalkMatchRiskLimit    = "match_risk_limit"    // 限红比例 返还率缩减
)

type BeansFunc func(h *BeansHandler, msg BeansMessage) bool

type BeansHandler struct {
	Name          string             // handler name
	BeansPool     cpool.Pool         // beanstalk pool
	BeansTubeName string             // beanstalk tube name
	BeansReserve  time.Duration      // beanstalk reserve time
	FnPoolSize    int                // handle func pool size
	Fn            BeansFunc          // handle func
	fnPool        *ants.PoolWithFunc // handle func pool
}

func (h *BeansHandler) Watch() {
	var err error
	h.fnPool, err = ants.NewPoolWithFunc(h.FnPoolSize, func(payload interface{}) {
		if m, ok := payload.(BeansMessage); ok {
			if h.Fn(h, m) {
				if err := m.Conn.Delete(m.MID); err != nil {
					AddLog(LogError, h.Name, m.ID, err.Error())
				}
			}
		}
	})
	if err != nil {
		AddLog(LogError, h.Name, 0, "NewPoolWithFunc:", err.Error())
		return
	}

	consume := func() {
		v, err := h.BeansPool.Get()
		if err != nil {
			AddLog(LogError, h.Name, 0, "[%s] beanstalk Get: %s", h.BeansTubeName, err.Error())
			return
		}

		defer func(h *BeansHandler) {
			if err = h.BeansPool.Put(v); err != nil {
				AddLog(LogError, h.Name, 0, "[%s] beanstalk Put: %s", h.BeansTubeName, err.Error())
			}
		}(h)

		if conn, ok := v.(*beanstalk.Conn); ok {
			c := beanstalk.NewTubeSet(conn, h.BeansTubeName)
			mid, data, err := c.Reserve(h.BeansReserve)
			fmt.Println(data)
			id := fmt.Sprintf("%x-%d-%d", &conn, mid, helper.Cputicks()) // uniq id, for duplicated-consume tracing.
			if err != nil {
				if !strings.Contains(err.Error(), "reserve-with-timeout:") {
					AddLog(LogError, h.Name, id, "[%s] beanstalk Reserve: %s", h.BeansTubeName, err.Error())
				}
				return
			}

			m, err := url.ParseQuery(string(data))
			fmt.Println(m)
			if err != nil {
				AddLog(LogError, h.Name, id, "[%s] %s: %s", h.BeansTubeName, err.Error(), string(data))
				if err = conn.Delete(mid); err != nil {
					AddLog(LogError, h.Name, id, "[%s] beanstalk Delete: %s", h.BeansTubeName, err.Error())
				}
				return
			}

			AddLog(LogInfo, h.Name, id, "[%s] invoke: %s", h.BeansTubeName, string(data))
			msg := BeansMessage{
				ID:   id,
				Conn: conn,
				MID:  mid,
				Msg:  m,
			}
			fmt.Println(msg)
			if err = h.fnPool.Invoke(msg); err != nil {
				AddLog(LogError, h.Name, mid, "[%s] fnPool.Invoke: %s", h.BeansTubeName, err.Error())
			}
		}
	}

	lastPeekId := uint64(0)
	monitor := func() {
		v, err := h.BeansPool.Get()
		if err != nil {
			AddLog(LogError, h.Name, 0, "[%s] beanstalk Get: %s", h.BeansTubeName, err.Error())
			return
		}

		defer func(h *BeansHandler) {
			if err = h.BeansPool.Put(v); err != nil {
				AddLog(LogError, h.Name, 0, "[%s] beanstalk Put: %s", h.BeansTubeName, err.Error())
			}
		}(h)

		if conn, ok := v.(*beanstalk.Conn); ok {
			tube := beanstalk.Tube{
				Conn: conn,
				Name: h.BeansTubeName,
			}
			if peekId, peekBody, _ := tube.PeekReady(); peekId > 0 {
				if peekId == lastPeekId && lastPeekId > 0 {
					stat, _ := conn.StatsJob(peekId)
					AddLog(LogError, h.Name, peekId, "[%s] next ready job: %s, stats: %+v", h.BeansTubeName, string(peekBody), stat)
					if age, _ := strconv.Atoi(stat["age"]); age >= 120 { // 2min任务没有消费，认定为队列阻塞
						AddLog(LogError, h.Name, peekId, "[%s] job time out. age: %d", h.BeansTubeName, age)
						os.Exit(0) // exit and restart child process here
					}
				}
				lastPeekId = peekId
			}
			v, err := h.BeansPool.Get()
			if err != nil {
				AddLog(LogError, h.Name, 0, "[%s] beanstalk Get: %s", h.BeansTubeName, err.Error(), v)
			}
			fmt.Println(v)
			fmt.Println(h.BeansTubeName)
			fmt.Println(h.Name)
			AddLog(LogInfo, h.Name, 0, "[%s] ok", h.BeansTubeName)
		}
	}

	go func() {
		for {
			select {
			case <-time.Tick(time.Minute):
				monitor()
			}
		}
	}()
	for {
		consume()
	}
}

func (h *BeansHandler) Release() {
	if h.fnPool != nil {
		h.fnPool.Release()
	}
}

type BeansMessage struct {
	ID   string          // uniq id
	Conn *beanstalk.Conn // beanstalk conn
	MID  uint64          // msg id
	Msg  url.Values      // msg data
}

type BeansTask struct {
	Tube    string        //tube 名称
	Message string        //job body
	Delay   time.Duration //延迟ready的秒数
	TTR     time.Duration //允许worker执行的最大秒数
	PRI     uint32        //优先级
}

func InitBeanstalk(beanstalkConn string, initialCap, maxIdle, maxCap int) cpool.Pool {

	factory := func() (interface{}, error) { return beanstalk.Dial("tcp", beanstalkConn) }
	closed := func(v interface{}) error { return v.(*beanstalk.Conn).Close() }
	poolConfig := &cpool.Config{
		InitialCap:  initialCap, // 资源池初始连接数
		MaxIdle:     maxIdle,    // 最大空闲连接数
		MaxCap:      maxCap,     // 最大并发连接数
		Factory:     factory,
		Close:       closed,
		IdleTimeout: 15 * time.Second,
	}

	beanPool, err := cpool.NewChannelPool(poolConfig)
	if err != nil {
		log.Fatalln(err)
	}
	return beanPool
}

func BeansAddTask(pool cpool.Pool, data BeansTask) error {

	v, err := pool.Get()
	if err != nil {
		return err
	}

	if conn, ok := v.(*beanstalk.Conn); ok {

		tube := &beanstalk.Tube{Conn: conn, Name: data.Tube}
		_, err = tube.Put([]byte(data.Message), data.PRI, data.Delay, data.TTR)
		if err != nil {
			return err
		}
	}

	//将连接放回连接池中
	return pool.Put(v)
}

/**
 * @Description: 盘口预警监控任务
 * @Author: maxic
 * @Date: 2020/11/5
 * @LastEditTime: 2020/11/5
 * @LastEditors: maxic
 **/
func BeansTaskMarketMonitor(pool cpool.Pool, matchId, marketId, oddId string) error {

	message := fmt.Sprintf("match_id=%s&market_id=%s&odd_id=%s", matchId, marketId, oddId)
	fmt.Printf("BeansTaskMarketMonitor: %s, %s", BeanstalkMarketMonitorTube, message)

	data := BeansTask{
		Tube:    BeanstalkMarketMonitorTube,
		Message: message,
		Delay:   0,
		PRI:     1,
		TTR:     10 * time.Second,
	}

	return BeansAddTask(pool, data)
}

/*
 * @Description: 添加延时任务-限红比例,返还率缩减
 * @Author: robin
 * @Date: 2021/8/8 14:33
 * @LastEditTime: 2021/8/17 19:48
 * @LastEditors: robin
 */
// 限红比例,返还率缩减 延时队列写入
func PutDelayQueueRiskLimit(pool cpool.Pool, matchId string, id int, startTime int64) error {

	levelTime := []int{1, 3, 7}
	index := id - 1
	delayTime := time.Unix(startTime, 0).AddDate(0, 0, -levelTime[index]).Unix() - time.Now().Unix()
	message := fmt.Sprintf("matchId=%s&id=%d&startTime=%d", matchId, id, startTime)
	fmt.Println("--------------", BeanStalkMatchRiskLimit, "|", message, "|", delayTime, "--------------")

	data := BeansTask{
		Tube:    BeanStalkMatchRiskLimit,
		Message: message,
		Delay:   time.Duration(delayTime) * time.Second,
		PRI:     1,
		TTR:     10 * time.Second,
	}

	return BeansAddTask(pool, data)
}

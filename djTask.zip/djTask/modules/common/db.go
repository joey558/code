package common

import (
	"database/sql"
	_ "github.com/go-sql-driver/mysql"
	"github.com/jmoiron/sqlx"
	"log"
	"time"
)

func InitDB(dsn string, maxIdleConn, maxOpenConn int) *sql.DB {

	db, err := sql.Open("mysql", dsn)
	if err != nil {
		log.Fatalln(err)
		return db
	}

	db.SetMaxOpenConns(maxOpenConn)
	db.SetMaxIdleConns(maxIdleConn)
	db.SetConnMaxLifetime(time.Second * 30)
	db.SetConnMaxIdleTime(time.Minute * 30)
	err = db.Ping()
	if err != nil {
		log.Fatalln(err)
	}

	return db
}

func InitDBX(dsn string, maxIdleConn, maxOpenConn int) *sqlx.DB {

	db, err := sqlx.Connect("mysql", dsn)
	if err != nil {
		log.Fatalf("initDB failed: %s", err.Error())
	}

	db.SetMaxOpenConns(maxOpenConn)
	db.SetMaxIdleConns(maxIdleConn)
	db.SetConnMaxLifetime(time.Second * 30)
	err = db.Ping()
	if err != nil {
		log.Fatalf("initDB failed: %s", err.Error())
	}

	return db
}

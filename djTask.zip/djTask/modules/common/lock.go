package common

import (
	"fmt"
	"github.com/go-redis/redis/v7"
	"sync"
	"time"
)

var (
	stats map[string]bool // map[key]stat
	mtx   sync.Mutex
)

type Lock interface {
	Lock() error
	Unlock()
}

type LocalLock struct {
	Key string
}

func (l *LocalLock) Lock() error {
	var err error
	mtx.Lock()
	if _, ok := stats[l.Key]; ok {
		err = fmt.Errorf("[%s] lock fail", l.Key)
	} else {
		if stats == nil {
			stats = make(map[string]bool)
		}
		stats[l.Key] = true
	}
	mtx.Unlock()
	return err
}

func (l *LocalLock) Unlock() {
	mtx.Lock()
	delete(stats, l.Key)
	mtx.Unlock()
}

type RedisLock struct {
	Pool    *redis.Client
	Key     string
	Timeout time.Duration
}

func (l *RedisLock) Lock() error {
	key := fmt.Sprintf("rlock:%s", l.Key)
	ok, err := l.Pool.SetNX(key, "1", l.Timeout).Result()
	if err != nil {
		return fmt.Errorf("[%s] lock fail: %s", key, err.Error())
	}
	if !ok {
		return fmt.Errorf("[%s] lock fail", key)
	}
	return nil
}

func (l *RedisLock) Unlock() {
	key := fmt.Sprintf("rlock:%s", l.Key)
	l.Pool.Unlink(key)
}

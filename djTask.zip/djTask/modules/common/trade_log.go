package common

import (
	"djTask/calc"
	mqtt "github.com/eclipse/paho.mqtt.golang"
	"github.com/go-redis/redis/v7"
)

/**
 * @Description: 发布赛事日志
 * @Author: maxic
 * @Date: 2020/10/15
 * @LastEditTime: 2021/4/15 16:51
 * @LastEditors: robin
 **/
func XPubMatch(emqx mqtt.Client, cli *redis.Client, gameId, tourId, Teams, matchId, menu, action, result string) error {

	r := []rune(result)
	if len(r) > 1024 { // max length 1024
		result = string(r[0:1021]) + "..."
	}

	td := calc.TDMatch{
		TS:                  "now",
		User:                "【auto】",
		Group:               "",
		IP:                  "",
		Menu:                menu,
		Action:              action,
		GameID:              gameId,
		GameShortName:       RedisGameNameGet(cli, gameId),
		TournamentId:        tourId,
		TournamentShortName: GetTournamentNameGet(cli, tourId),
		Teams:               Teams,
		MatchID:             matchId,
		Result:              result,
	}

	return calc.XPub(emqx, td)
}

/**
 * @Description: 发布盘口日志
 * @Author: maxic
 * @Date: 2020/10/15
 * @LastEditTime: 2021/4/15 16:51
 * @LastEditors: robin
 **/
func XPubMarket(emqx mqtt.Client, cli *redis.Client, gameId, tourId, Teams, matchId, marketId, marketName string, round int16, menu, action, result string, category int8) error {

	r := []rune(result)
	if len(r) > 1024 { // max length 1024
		result = string(r[0:1021]) + "..."
	}

	td := calc.TDMarket{
		TS:                  "now",
		User:                "【auto】",
		Group:               "",
		IP:                  "",
		Menu:                menu,
		Action:              action,
		GameID:              gameId,
		GameShortName:       RedisGameNameGet(cli, gameId),
		TournamentId:        tourId,
		TournamentShortName: GetTournamentNameGet(cli, tourId),
		Teams:               Teams,
		MatchID:             matchId,
		MarketID:            marketId,
		MarketEnName:        marketName,
		Round:               round,
		Result:              result,
		Category:            category,
	}

	return calc.XPub(emqx, td)
}

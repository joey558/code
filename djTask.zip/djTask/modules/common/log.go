package common

import (
	"djTask/contrib/zlog"
	"fmt"
	"runtime"
	"time"
)

type LogLevel string

const (
	LogInfo  LogLevel = "INFO"
	LogError LogLevel = "ERROR"
)

/**
 * @Description: 打印日志
 * @Author: maxic
 * @Date: 2020/8/4
 * @LastEditTime: 2020/8/4
 * @LastEditors: maxic
 **/
func AddLog(level LogLevel, flag string, cid interface{}, format string, v ...interface{}) {

	_, file, line, _ := runtime.Caller(1)
	loc := fmt.Sprintf("%s:%d", file, line)
	msg := fmt.Sprintf(format, v...)

	fmt.Println(time.Now().Format("2006-01-02 15:04:05.000"), "|", level, "|", loc, "|", cid, "|", msg)

	if level == LogInfo {
		zlog.Info(nil, flag, loc, msg, cid, 0)
	} else {
		zlog.Error(nil, flag, loc, msg, cid, 0)
	}
}

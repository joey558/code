package common

import (
	"context"
	"fmt"
	"github.com/apache/rocketmq-client-go/v2"
	"github.com/apache/rocketmq-client-go/v2/primitive"
	"github.com/apache/rocketmq-client-go/v2/producer"
)

//生产消息
func RocketMqProducer(rocketMQ []string, msgs []*primitive.Message) error {

	mq, err := rocketmq.NewProducer(
		producer.WithNameServer(rocketMQ),
		producer.WithRetry(5),
	)

	if err != nil {
		return fmt.Errorf("rmq start producer error: %s", err.Error())
	}

	_ = mq.Start()

	for _, msg := range msgs {
		res, err := mq.SendSync(context.Background(), msg)
		if err != nil {
			return fmt.Errorf("rmq message:[%+v] send error: %s", msg, err.Error())
		}

		fmt.Printf("rmq send message succeed, result = %s\n", res.String())
	}

	return nil
}

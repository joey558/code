package common

import (
	"djTask/calc"
	"fmt"
	"log"
	"time"

	"djTask/helper"

	mqtt "github.com/eclipse/paho.mqtt.golang"
)

// 赔率更新推送结构
type OddUpdateNotify struct {
	MarketId   string `json:"market_id"`
	MatchId    string `json:"match_id"`
	ID         string `json:"id"`
	Odd        string `json:"odd"`
	ReturnRate string `json:"return_rate"`
}

// 赛事风控参数更新推送
type MatchUpdateRiskNotify struct {
	MatchID              string  `json:"match_id"`                 // 赛事id
	RateLimit            int     `json:"rate_limit"`               // 限红比例
	RateReduce           float64 `json:"rate_reduce"`              // 返还率缩减
	MbMchPrizeLimit      int     `json:"mb_mch_prize_limit"`       // 会员赛事赔付
	MixMchPrizeLimit     int     `json:"mix_mch_prize_limit"`      // 复合玩法赛事赔付
	RndCompPrizeLimit    int     `json:"rnd_comp_prize_limit"`     // 单局串关单注赔付
	RndCompMchPrizeLimit int     `json:"rnd_comp_mch_prize_limit"` // 单局串关赛事赔付
	RndCompOddDscnt      float64 `json:"rnd_comp_odd_dscnt"`       // 单局串关赔率折扣
}

// 盘口风控参数更新推送
type MarketPrizeLimitUpdateNotify struct {
	MarketId          string  `json:"market_id"`
	MatchId           string  `json:"match_id"`
	ReturnRate        float64 `json:"return_rate"`         // 返还率
	DefaultReturnRate float64 `json:"default_return_rate"` // 默认值-返还率
	PrizeStaticProfit int     `json:"prize_static_profit"` // 单注限红
	PrizeLimit        int     `json:"prize_limit"`         // 单注赔付
	MbMktPrizeLimit   int     `json:"mb_mkt_prize_limit"`  // 会员盘口赔付
	WarningProfit     int     `json:"warning_profit"`
	StopProfit        int     `json:"stop_profit"`
	Reason            int     `json:"reason"` // 用于-盘口返还率缩减-未生效
}

/**
 * @Description: 初始化mqtt
 * @Author: wesley
 * @Date: 2020/6/15 13:35
 * @LastEditTime: 2020/6/15 13:35
 * @LastEditors: wesley
 */
func InitMqttService(mqttCfg []string) mqtt.Client {

	clientOptions := mqtt.NewClientOptions().
		SetClientID(fmt.Sprintf("%d", helper.Cputicks())).
		SetCleanSession(false).
		SetAutoReconnect(true).
		SetKeepAlive(120 * time.Second).
		SetPingTimeout(10 * time.Second).
		SetWriteTimeout(10 * time.Second).
		SetMaxReconnectInterval(10 * time.Second)

	for _, v := range mqttCfg {
		clientOptions.AddBroker(v)
	}

	client := mqtt.NewClient(clientOptions)
	if conn := client.Connect(); conn.WaitTimeout(time.Duration(10)*time.Second) && conn.Wait() && conn.Error() != nil {
		log.Fatalf("token: %s", conn.Error())
	}
	return client
}

// 注单状态推送
func MqttPushOrderStatus(cli mqtt.Client, uid, orderID uint64, betStatus int, theoryPrize, odd string, reason int) error {

	payload := fmt.Sprintf(mqttOrderStatusFormat, uid, orderID, betStatus, theoryPrize, odd, reason)
	key := fmt.Sprintf(topicMemberOrderStatus, uid)

	//fmt.Println("----------", key, "|", payload, "-------------")
	return calc.MQTTNotify(cli, key, payload)
}

// 注单详情状态推送
func MqttPushOrderDetailStatus(cli mqtt.Client, uid, orderID, id uint64, betStatus int, odd string, reason int) error {

	payload := fmt.Sprintf(mqttOrderDetailStatusFormat, uid, orderID, id, betStatus, odd, reason)
	key := fmt.Sprintf(topicMemberOrderDetailStatus, uid)
	return calc.MQTTNotify(cli, key, payload)
}

// 盘口风险注单生成/接受/拒绝状态推送
func MqttPushRiskOrderStatus(cli mqtt.Client, matchID, marketID string, flag, num int) error {

	payload := fmt.Sprintf(mqttMarketRiskOrderStatus, matchID, marketID, flag, num)
	key := fmt.Sprintf(topicMarketRiskOrderStatus, matchID)
	return calc.MQTTNotify(cli, key, payload)
}

// 盘口单注注单自动确认成功后推送更新盘口注单统计数据通知
func MqttPushMarketOrderBet(cli mqtt.Client, matchID, marketID string) error {

	payload := fmt.Sprintf(mqttMarketOrderBet, matchID, marketID)
	key := fmt.Sprintf(topicMarketOrderBet, matchID)

	return calc.MQTTNotify(cli, key, payload)
}

// 比赛状态(显示/隐藏)
func MqttPushMatchVisibleUpdate(cli mqtt.Client, matchIDs []string, visible int) error {

	var data []map[string]interface{}
	for _, id := range matchIDs {
		data = append(data, map[string]interface{}{
			"match_id": id,
			"visible":  visible,
		})
	}
	return calc.MQTTNotify(cli, topicMatchActionVisible, data)
}

/**
 * @Description: 赔率更新推送
 * @Author: maxic
 * @Date: 2020/8/3
 * @LastEditTime: 2020/8/3
 * @LastEditors: maxic
 **/
func MqttPushOddUpdate(cli mqtt.Client, odds []OddUpdateNotify) error {

	return calc.MQTTNotify(cli, topicMarketOddsUpdate, odds)
}

/**
 * @Description: 发送停止自动变赔通知
 * @Author: maxic
 * @Date: 2020/8/5
 * @LastEditTime: 2020/8/5
 * @LastEditors: maxic
 **/
func MqttPushAutoOddStop(cli mqtt.Client, matchId, marketId, msg string) error {

	payload := fmt.Sprintf(mqttMarketAutoOddStop, matchId, marketId, msg)
	return calc.MQTTNotify(cli, topicMarketAutoOddStop, payload)
}

// 盘口状态(暂停/取消暂停)
func MqttNotifyMarketSuspended(cli mqtt.Client, marketIds, autoMixMarketIds []string, suspended int, matchId string) error {

	var data []map[string]interface{}
	for _, id := range marketIds {
		data = append(data, map[string]interface{}{
			"match_id":  matchId,
			"market_id": id,
			"suspended": suspended,
			"type":      1,
		})
	}

	for _, id := range autoMixMarketIds {
		data = append(data, map[string]interface{}{
			"match_id":  matchId,
			"market_id": id,
			"suspended": suspended,
			"type":      0,
		})
	}
	return calc.MQTTNotify(cli, topicMarketActionSuspended, data)
}

/**
 * @Description: 盘口计数变更通知
 * @Author: maxic
 * @Date: 2020/7/10
 * @LastEditTime: 2020/7/10
 * @LastEditors: maxic
 **/
func MqttNotifyMarketCountsUpdate(cli mqtt.Client, matchID string, counts interface{}) error {

	data := map[string]interface{}{
		"match_id": matchID,
		"counts":   counts,
	}
	return calc.MQTTNotify(cli, topicMarketStatisticUpdate, data)
}

// 投注项状态(暂停/取消暂停)
func MqttNotifyOddSuspended(cli mqtt.Client, matchId, marketID, oddID string, suspended int) error {

	return calc.MQTTNotify(cli, topicOddActionSuspended, map[string]interface{}{
		"match_id":  matchId,
		"market_id": marketID,
		"odd_id":    oddID,
		"suspended": suspended,
	})
}

// 赛事风控变更
func MqttNotifyMatchRiskUpdate(cli mqtt.Client, item MatchUpdateRiskNotify) error {
	return calc.MQTTNotify(cli, topicMatchRiskUpdate, item)
}

/*
 * @Description: 盘口赔率更新
 * @Author: robin
 * @Date: 2021/8/12 16:27
 * @LastEditTime: 2021/8/12 16:27
 * @LastEditors: robin
 */
func MqttNotifyOddUpdate(cli mqtt.Client, odd []OddUpdateNotify) error {
	return calc.MQTTNotify(cli, topicMarketOddsUpdate, odd)
}

/*
 * @Description: 盘口限红更新
 * @Author: robin
 * @Date: 2021/8/12 16:31
 * @LastEditTime: 2021/8/12 16:31
 * @LastEditors: robin
 */
func MqttNotifyPrizeLimitUpdate(cli mqtt.Client, item []MarketPrizeLimitUpdateNotify) error {
	return calc.MQTTNotify(cli, topicMarketPrizeLimitUpdate, item)
}

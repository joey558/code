package credit

import (
	"database/sql"
	"djTask/mRejson"
	"djTask/modules/common"
	"fmt"
	g "github.com/doug-martin/goqu/v9"
	"strconv"
	"time"
)

func agentLimitModeUpdate(h *common.BeansHandler, msg common.BeansMessage) bool {

	sID := msg.Msg.Get("id")
	id, err := strconv.ParseUint(sID, 10, 64)
	if err != nil {
		common.AddLog(common.LogError, h.Name, msg.ID, "agent id[%s] error, finished", sID)
		return true
	}

	sLimitMode := msg.Msg.Get("limit_mode")
	limitMode, err := strconv.Atoi(sLimitMode)
	if err != nil {
		common.AddLog(common.LogError, h.Name, msg.ID, "limit_mode:[%s] error, finished", sLimitMode)
		return true
	}

	agent, err := AgentFindOne(g.Ex{"id": id})
	if err != nil {
		if err == sql.ErrNoRows {
			return true
		}
		common.AddLog(common.LogError, h.Name, msg.ID, "agent info find fail, error:%s", err.Error())
		return false
	}

	if agent.LimitMode == limitMode {
		common.AddLog(common.LogError, h.Name, msg.ID, "agent[%] no need update limit_mode:[%d]. finished", sID, limitMode)
		return true
	}

	deph, err := TransToDepth(agent.SortLevel)
	if err != nil {
		return true
	}

	ex := []g.Expression{
		g.C("sort_level").Gte(agent.SortLevel),
		g.C("sort_level").Lt(TransToSortLevel(deph + 1)),
	}

	agentList, err := AgentFindAll(ex...)
	if err != nil {
		common.AddLog(common.LogError, h.Name, msg.ID, "agent list find fail, error:%s", err.Error())
		return false
	}

	record := g.Record{
		"limit_mode":  limitMode,
		"update_time": time.Now().Unix(),
	}

	for _, v := range agentList {
		if v.LimitMode == limitMode {
			continue
		}

		dbTx, err := db.Begin()
		if err != nil {
			return false
		}

		query, _, _ := dialect.Update("tbl_credit_agent").Set(record).Where(g.Ex{"id": v.ID}).ToSQL()
		fmt.Println(query)
		_, err = dbTx.Exec(query)
		if err != nil {
			common.AddLog(common.LogError, h.Name, msg.ID, "agent update limit_mode exec sql fail, error:%s", err.Error())
			_ = dbTx.Rollback()
			return false
		}

		pipe := pool.TxPipeline()
		mRejson.SetAgent(pipe, v.ID, v.ParentID, "limit_mode", limitMode)
		_, err = pipe.Exec()
		if err != nil {
			common.AddLog(common.LogError, h.Name, msg.ID, "agent update limit_mode exec pipe fail, error:%s", err.Error())
			_ = dbTx.Rollback()
			return false
		}

		_ = dbTx.Commit()
	}

	return true
}
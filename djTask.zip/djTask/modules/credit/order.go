package credit

import (
	g "github.com/doug-martin/goqu/v9"
)

// 注单数据
type simpleBetData struct {
	ID                    uint64 `db:"id" json:"id"`                                              //注单ID
	MemberID              uint64 `db:"member_id" json:"member_id"`                                //会员ID
	MemberAccount         string `db:"member_account" json:"member_account"`                      //会员账号
	MerchantID            uint64 `db:"merchant_id" json:"merchant_id"`                            //商户ID
	MerchantAccount       string `db:"merchant_account" json:"merchant_account"`                  //商户账号
	ParentMerchantID      uint64 `db:"parent_merchant_id" json:"parent_merchant_id"`              //父商户ID
	ParentMerchantAccount string `db:"parent_merchant_account" json:"parent_merchant_account"`    //父商户账号
	TopMerchantId         uint64 `db:"top_merchant_id" json:"top_merchant_id"`                    //顶层商户ID
	TopMerchantAccount    string `db:"top_merchant_account" json:"top_merchant_account"`          //顶层商户名称
	SortLevel             string `db:"sort_level" json:"sort_level" rule:"chn" name:"sort_level"` //商户排序层级
	Deph                  uint64 `db:"deph" json:"deph" rule:"chn" name:"deph"`                   //商户层深
	Tester                uint8  `db:"tester" json:"tester"`                                      //是否测试账户
	OrderType             uint8  `db:"order_type" json:"order_type"`                              //注单类型 1普通注单 2串关注单
	ParleyType            int    `db:"parley_type" json:"parley_type"`                            //串关类型 1普通注单 2:2串1  3:3串1 4:4串1 5:5串1 6:6串1 7:7串1 8:8串1
	GameID                string `db:"game_id" json:"game_id"`                                    //游戏ID
	TournamentID          string `db:"tournament_id" json:"tournament_id"`                        //联赛ID
	MatchID               string `db:"match_id" json:"match_id"`                                  //比赛ID
	MatchType             int    `db:"match_type" json:"match_type"`                              //赛事类型 1-正常 2-冠军  3-大逃杀
	MarketID              string `db:"market_id" json:"market_id"`                                //盘口ID
	MarketCnName          string `db:"market_cn_name" json:"market_cn_name"`                      //盘口中文名称
	TeamNames             string `db:"team_names" json:"team_names"`                              //队伍名称
	TeamID                string `db:"team_id" json:"team_id"`                                    //战队id
	OddID                 string `db:"odd_id" json:"odd_id"`                                      //投注项ID
	OrgOddID              string `db:"org_odd_id" json:"org_odd_id"`                              //玩法ID
	OddName               string `db:"odd_name" json:"odd_name"`                                  //投注项名称
	Odd                   string `db:"odd" json:"odd"`                                            //赔率
	Round                 int    `db:"round" json:"round"`                                        //第几局
	BetIP                 uint32 `db:"bet_ip" json:"bet_ip"`                                      //投注IP
	Device                uint32 `db:"device" json:"device"`                                      //设备 [1-PC  2-H5  3-Android  4-IOS]
	BetAmount             string `db:"bet_amount" json:"bet_amount"`                              //注单金额
	TheoryPrize           string `db:"theory_prize" json:"theory_prize"`                          //预期派彩金额
	WinAmount             string `db:"win_amount" json:"win_amount"`                              //派彩金额
	BetStatus             int    `db:"bet_status" json:"bet_status"`                              //注单状态 1-待确认 2-已拒绝 3-待结算 4-已取消 5-已中奖 6-未中奖 7-已撤销
	IsLive                int    `db:"is_live" json:"is_live"`                                    //赛事阶段 1-初盘 2-滚盘
	ConfirmType           int    `db:"confirm_type" json:"confirm_type"`                          //确认方式 1-自动确认 2-手动待确认 3-手动确认 4-手动拒绝
	BetTime               int64  `db:"bet_time" json:"bet_time"`                                  //投注时间
	SettleCount           uint64 `db:"settle_count" json:"settle_count"`                          //结算次数
	SettleTime            int64  `db:"settle_time" json:"settle_time"`                            //结算时间
	MatchStartTime        int64  `db:"match_start_time" json:"match_start_time"`                  //赛事开始时间
	Reason                int    `db:"reason" json:"reason"`                                      //撤销理由
	OddDiscount           string `db:"odd_discount" json:"odd_discount"`                          //赔率折扣
	AgentID               uint64 `db:"agent_id" json:"agent_id"`                                  //直属代理ID
	AgentAccount          string `db:"agent_account" json:"agent_account"`                        //直属代理账号
}

//串关注单详情
type complexBetData struct {
	ID             uint64 `db:"id"  json:"id"`
	OrderID        uint64 `db:"order_id"  json:"order_id"`
	GameID         string `db:"game_id"  json:"game_id"`
	GameName       string `db:"-" json:"game_name"`
	TournamentID   string `db:"tournament_id"  json:"tournament_id"`
	TournamentName string `db:"-" json:"tournament_name"`
	MatchID        string `db:"match_id"  json:"match_id"`
	MatchType      int    `db:"match_type"  json:"match_type"`
	MarketID       uint64 `db:"market_id"  json:"market_id"`
	MarketCnName   string `db:"market_cn_name"  json:"market_cn_name"`
	TeamNames      string `db:"team_names"  json:"team_names"`
	TeamID         string `db:"team_id"  json:"team_id"`
	OddID          string `db:"odd_id"  json:"odd_id"`
	OrgOddID       string `db:"org_odd_id"  json:"org_odd_id"`
	OddName        string `db:"odd_name"  json:"odd_name"`
	Odd            string `db:"odd"  json:"odd"`
	Round          int    `db:"round"  json:"round"`
	MatchStartTime int64  `db:"match_start_time"  json:"match_start_time"`
	SettleTime     int64  `db:"settle_time"  json:"settle_time"`
	SettleCount    uint64 `db:"settle_count"  json:"settle_count"`
	Status         int    `db:"status"  json:"status"`
	IsLive         int    `db:"is_live"  json:"is_live"`
	Reason         int    `db:"reason"  json:"reason"`
}

/**
 * @Description: 根据条件查询一条注单记录
 * @Author: wesley
 * @Date: 2020/7/6 16:14
 * @LastEditTime: 2020/7/6 16:14
 * @LastEditors: wesley
 */
func simpleBetFindOne(ex g.Ex) (simpleBetData, error) {

	var data simpleBetData

	query, _, _ := dialect.From("tbl_bet_order").Select(simpleBetColumns...).Where(ex).Limit(1).ToSQL()
	err := db.Get(&data, query)

	return data, err
}
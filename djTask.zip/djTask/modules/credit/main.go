package credit

import (
	"djTask/calc"
	"djTask/contrib/zlog"
	"djTask/modules/common"
	"djTask/wallet"
	"fmt"
	g "github.com/doug-martin/goqu/v9"
	mqtt "github.com/eclipse/paho.mqtt.golang"
	"github.com/go-redis/redis/v7"
	"github.com/jmoiron/sqlx"
	cpool "github.com/silenceper/pool"
	"time"
)

var (
	conf    common.MerchantCfg
	bPool   cpool.Pool
	zkbPool cpool.Pool
	db      *sqlx.DB
	cli     mqtt.Client
	pool    *redis.Client
)

var (
	dialect           = g.Dialect("mysql")
	simpleBetColumns  = calc.EnumFields(simpleBetData{})
	complexBetColumns = calc.EnumFields(complexBetData{})
	colCreditAgent    = calc.EnumFields(CreditAgent{})
)

const (
	mqttBalanceFormat = `{"uid":"%d","account":"%s","balance":"%s"}`
)


func Parse(endpoints []string, path string) {

	common.ParseCfg(&conf, endpoints, path)

	// 初始化mqtt推送
	cli = common.InitMqttService(conf.Mqtt)
	// 初始化延时队列
	bPool = common.InitBeanstalk(conf.Beanstalk, 50, 50, 100)
	// 初始化redis
	pool = common.InitRedis(conf.MerchantRedis.Addr, conf.MerchantRedis.Password, conf.MerchantRedis.Sentinel, 0)
	// 初始化db
	db = common.InitDBX(conf.Db.Addr, conf.Db.MaxIdleConn, conf.Db.MaxOpenConn)
	// 初始化zlog
	zlog.New(conf.Zlog.Brokers, conf.Zlog.URI)
	// 设置信用网中心钱包host地址
	wallet.XywSecretKey = conf.Credit.SecretKey
	wallet.XywHost = conf.Credit.CentralWalletHost
	wallet.XywHttpTimeout = time.Duration(conf.Credit.Timeout) * time.Second
	wallet.XywRetryNum = conf.Credit.RetryNum

	defer func() {
		_ = db.Close()
		_ = pool.Close()
	}()

	run()
}

func run() {
	go func() {
		handler := &common.BeansHandler{
			Name:          "agentLimitMode",
			BeansPool:     bPool,
			BeansTubeName: fmt.Sprintf(common.BeanStalkAgentLimitMode, conf.Merchant.Account),
			BeansReserve:  2 * time.Minute,
			FnPoolSize:    conf.PoolSize,
			Fn:            agentLimitModeUpdate,
		}
		handler.Watch()
		handler.Release()
	}()

	func() {
		handler := &common.BeansHandler{
			Name:          "creditTimeout",
			BeansPool:     bPool,
			BeansTubeName: fmt.Sprintf(common.BeanStalkCreditTimeout, conf.Merchant.Account),
			BeansReserve:  2 * time.Minute,
			FnPoolSize:    conf.PoolSize,
			Fn:            balanceTimeout,
		}
		handler.Watch()
		handler.Release()
	}()
}

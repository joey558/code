package credit

import (
	"fmt"
	g "github.com/doug-martin/goqu/v9"
	"strconv"
	"strings"
)

// 信用代理
type CreditAgent struct {
	ID              uint64 `db:"id" json:"id" rule:"none" name:"id"`                                                                            // 代理ID
	Account         string `db:"account" json:"account" rule:"chn" min:"2" max:"128" msg:"illegal account[2-128]" name:"account"`               // 代理账号
	CID             string `db:"cid" json:"cid" rule:"chn" name:"cid"`                                                                          // C端代理id
	TopID           uint64 `db:"top_id" rule:"none" json:"top_id"`                                                                              // 顶层代理id
	TopAccount      string `db:"top_account" rule:"none" json:"top_account"`                                                                    // 顶层代理账号
	ParentID        uint64 `db:"parent_id" rule:"none" json:"parent_id"`                                                                        // 上级代理ID
	ParentAccount   string `db:"parent_account" json:"parent_account" rule:"none" name:"parent_account"`                                        // 上级代理账号
	SortLevel       string `db:"sort_level" rule:"none" json:"sort_level"`                                                                      // 代理排序层级
	Deph            uint64 `db:"deph" rule:"none" json:"deph"`                                                                                  // 代理层深
	MerchantID      uint64 `db:"merchant_id" rule:"none" json:"merchant_id"`                                                                    // 商户ID
	MerchantAccount string `db:"merchant_account" rule:"none" json:"merchant_account"`                                                          // 商户账号
	InitialQuota    string `db:"initial_quota" json:"initial_quota" rule:"amount" msg:"illegal initial_quota" name:"initial_quota"`             // 初始可用额度
	UsedQuota       string `db:"used_quota" json:"used_quota" rule:"none" name:"used_quota"`                                                    // 已消费额度
	LimitMode       int    `db:"limit_mode" json:"limit_mode" rule:"digit" default:"0" max:"1" msg:"illegal limit_mode[0-1]" name:"limit_mode"` // 限额模式(1：标准，0：信用)
	Status          uint8  `db:"status" json:"status" rule:"digit" default:"0" max:"1" msg:"illegal status[0-1]" name:"status"`                 // 代理状态(1：开启，0：关闭)
	CreateTime      uint32 `db:"create_time" json:"create_time" rule:"none" name:"create_time"`                                                 // 创建时间
	UpdateTime      uint32 `db:"update_time" json:"update_time" rule:"none" name:"update_time"`                                                 // 更新时间
}

/**
 * @Description: 将代理SortLevel转为Depth
 * @Author: awen
 * @Date: 2021/05/31 17:12
 * @LastEditTime: 2021/05/31 17:12
 * @LastEditors: awen
 **/
func TransToDepth(sortLevel string) (uint64, error) {

	if len(sortLevel) < 5 {
		return 0, nil
	}

	depth, err := strconv.ParseUint(sortLevel, 10, 64)
	if err != nil {
		return 0, fmt.Errorf("invalid sort_level")
	}

	return depth, nil
}

/**
 * @Description: 获取单个代理
 * @Author: awen
 * @Date: 2021/05/19
 * @LastEditTime: 2021/05/19
 * @LastEditors: awen
 */
func AgentFindOne(ex g.Ex) (CreditAgent, error) {

	var data CreditAgent
	query, _, _ := dialect.From("tbl_credit_agent").Select(colCreditAgent...).Where(ex).Limit(1).ToSQL()
	err := db.Get(&data, query)
	return data, err
}

/**
 * @Description: 获取所有代理
 * @Author: awen
 * @Date: 2021/05/28
 * @LastEditTime: 2021/05/28
 * @LastEditors: awen
 */
func AgentFindAll(ex ...g.Expression) ([]CreditAgent, error) {

	var data []CreditAgent
	query, _, _ := dialect.From("tbl_credit_agent").Select(colCreditAgent...).Where(ex...).ToSQL()
	err := db.Select(&data, query)
	return data, err
}

/**
 * @Description: 将商户Depth转为SortLevel
 * @Author: maxic
 * @Date: 2020/11/30
 * @LastEditTime: 2020/11/30
 * @LastEditors: maxic
 **/
func TransToSortLevel(depth uint64) string {

	sortLevel := fmt.Sprintf("%d", depth)
	prefix := strings.Repeat("0", 5-len(sortLevel)%5)
	return prefix + sortLevel
}
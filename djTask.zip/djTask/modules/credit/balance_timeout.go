package credit

import (
	"database/sql"
	"djTask/contrib/validator"
	"djTask/mRejson"
	"djTask/modules/common"
	"djTask/wallet"
	"fmt"
	g "github.com/doug-martin/goqu/v9"
	mqtt "github.com/eclipse/paho.mqtt.golang"
	"github.com/shopspring/decimal"
	"strconv"
	"time"
)

func balanceTimeout(h *common.BeansHandler, msg common.BeansMessage) bool {

	id := msg.Msg.Get("id")
	if !validator.CheckStringDigit(id) {
		common.AddLog(common.LogError, h.Name, msg.ID, "order id:%s error, finished", id)
		return true
	}

	var (
		transType int
		err       error
		record    g.Record
		ex        g.Ex
	)
	transTypeStr := msg.Msg.Get("trans_type")

	if transType, err = strconv.Atoi(transTypeStr); err != nil {
		common.AddLog(common.LogError, h.Name, msg.ID, "trans_type:%s error, finished", transTypeStr)
		return true
	}

	result, err := wallet.GetBalanceResult(id, transType)
	if err != nil {
		common.AddLog(common.LogError, h.Name, msg.ID, "GetBalanceResult error:%s", err.Error())
		return false
	}

	switch transType {
	case wallet.TransBet:
		ex = g.Ex{"id": id}
		order, err := simpleBetFindOne(ex)
		if err != nil {
			if err == sql.ErrNoRows {
				return true
			}
			common.AddLog(common.LogError, h.Name, msg.ID, "simpleBetFindOne order[%s] error:%s", id, err.Error())
			return false
		}

		amount, err := decimal.NewFromString(order.BetAmount)
		if err != nil {
			return false
		}

		if result { //扣款成功，插入投注账变
			balanceStr, err := wallet.GetCreditBalance(order.MemberAccount)
			if err != nil {
				common.AddLog(common.LogError, h.Name, msg.ID, "GetCreditBalance order[%s] member[%s] error:%s", id, order.MemberAccount, err.Error())
				return false
			}

			balance, err := decimal.NewFromString(balanceStr)
			if err != nil {
				return false
			}

			balanceAfter := balance.Sub(amount)
			trans := wallet.Transaction{
				ID:                    wallet.GenId(),
				OrderNo:               fmt.Sprintf("%d", order.ID),
				MemberID:              order.MemberID,
				MemberAccount:         order.MemberAccount,
				MerchantID:            order.MerchantID,
				MerchantAccount:       order.MerchantAccount,
				ParentMerchantID:      order.ParentMerchantID,
				ParentMerchantAccount: order.ParentMerchantAccount,
				TopMerchantId:         order.TopMerchantId,
				TopMerchantAccount:    order.TopMerchantAccount,
				SortLevel:             order.SortLevel,
				Deph:                  order.Deph,
				CreatedTime:           time.Now().UnixNano() / 1e6,
				Tester:                order.Tester,
				AgentID:               order.AgentID,
				AgentAccount:          order.AgentAccount,
				Amount:                amount.String(),
				BalanceBefore:         balance.String(),
				BalanceAfter:          balanceAfter.String(),
				TradeType:             uint8(transType),
			}

			//增加账变
			query, _, _ := dialect.Insert("tbl_member_transaction").Rows(trans).ToSQL()
			fmt.Println(query)
			_, err = db.Exec(query)
			if err != nil {
				common.AddLog(common.LogError, h.Name, msg.ID, "insert transaction order[%s] error:%s", id, err.Error())
				return false
			}

			// 余额推送
			_ = mqttPushBalance(cli, trans.MemberID, trans.MemberAccount, trans.BalanceAfter)
		} else { // 扣款失败，取消注单
			//更新注单状态
			tm := time.Now().Unix()
			record = g.Record{
				"bet_status":  common.OrderStatusCancelled,
				"reason":      250,
				"settle_time": tm,
				"update_time": tm,
				"win_amount":  "0",
			}
			ex["bet_status"] = g.Op{"neq": common.OrderStatusCancelled}
			query, _, _ := dialect.Update("tbl_bet_order").Set(record).Where(ex).ToSQL()
			fmt.Println(query)
			res, err := db.Exec(query)
			if err != nil {
				common.AddLog(common.LogError, h.Name, msg.ID, "update order[%s] status error:%s", id, err.Error())
				return false
			}

			if n, _ := res.RowsAffected(); n == 0 {
				return true
			}
		}
	case wallet.TransBetFail:
		// 已加款，则删除任务
		if result {
			return true
		}

		username := msg.Msg.Get("username")
		if !validator.CheckStringAlnum(username) {
			common.AddLog(common.LogError, h.Name, msg.ID, "username :%s error, finished", username)
			return true
		}

		sToken := msg.Msg.Get("stoken")

		amount, err := decimal.NewFromString(msg.Msg.Get("amount"))
		if err != nil {
			common.AddLog(common.LogError, h.Name, msg.ID, "amount :%s error, finished", msg.Msg.Get("amount"))
			return true
		}

		_, ok, failMsg := wallet.CreditBalanceAddDeduction(username, sToken, id, amount, wallet.TransBetFail)
		if !ok {
			common.AddLog(common.LogError, h.Name, msg.ID, "order[%s] BetFail operate fail!  error:%s", id, failMsg)
			return false
		}
	}
	return true
}

func sTokenMerchSecretKeyGet(merchantID, memberID uint64) (string, string, error) {

	sToken := common.RedisGetSToken(pool, memberID)
	merch, err := mRejson.Get(pool, merchantID)
	if err != nil {
		return "", "", err
	}

	return sToken, merch.SecretKey, nil
}

/**
 * @Description: mqtt推送用户当前余额
 * @Author: wesley
 * @Date: 2020/6/14 14:31
 * @LastEditTime: 2020/6/14 14:31
 * @LastEditors: wesley
 */
func mqttPushBalance(cli mqtt.Client, uid uint64, memberAccount string, balance string) error {

	payload := fmt.Sprintf(mqttBalanceFormat, uid, memberAccount, balance)
	key := fmt.Sprintf("/member/balance/%d", uid)

	if token := cli.Publish(key, 1, false, payload); token.Wait() && token.Error() != nil {
		return token.Error()
	}

	return nil
}

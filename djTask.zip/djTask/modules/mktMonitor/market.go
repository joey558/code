package mktMonitor

import (
	"database/sql"
	"djTask/calc"
	"djTask/modules/common"
	"fmt"
	g "github.com/doug-martin/goqu/v9"
	"github.com/go-redis/redis/v7"
	"github.com/scylladb/go-set/strset"
	"time"
)

var (
	colMarketData   = calc.EnumFields(calc.MarketData{})
	colMarketMixSub = calc.EnumFields(MarketMixSub{})
)


// 盘口列表数据统计
type CalcMarketCountsStat struct {
	TotalCounts     int `json:"total_counts"`      // 全部
	CanBetCounts    int `json:"can_bet_counts"`    // 可投注盘口数
	WaitOpenCounts  int `json:"wait_open_counts"`  // 待开盘数
	SuspendCounts   int `json:"suspend_counts"`    // 暂停盘口数
	HiddenCounts    int `json:"hidden_counts"`     // 隐藏盘口数
	WaitInputCounts int `json:"wait_input_counts"` // 待录入盘口数
	EnteredCounts   int `json:"entered_counts"`    // 已录入盘口数
	AllCounts       int `json:"all_counts"`        // 总盘口数
	CancelCount     int `json:"cancel_count"`      // 取消盘口数
	Settlement      int `json:"settlement"`        // 已结算订单
	WaitSettlement  int `json:"wait_settlement"`   // 待结算
}

type MarketMixSub struct {
	ID          string `json:"id"  db:"id"`
	MatchID     string `json:"match_id" db:"match_id"`
	Round       int    `json:"round" db:"round"`
	MixMarketID string `json:"mix_market_id" db:"mix_market_id"`
	SubMarketID string `json:"sub_market_id" db:"sub_market_id"`
	Count       int    `json:"count" db:"count"`
}

/**
 * @Description: 盘口列表数据统计
 * @Author: wesley
 * @Date: 2020/10/23
 * @LastEditTime: 2020/10/23
 * @LastEditors: wesley
 **/
func marketCountCalc(markets map[string]calc.MarketData) (CalcMarketCountsStat, string) {

	var (
		counts     CalcMarketCountsStat
		defaultMkt string
	)

	counts.TotalCounts = len(markets)
	for _, market := range markets {

		if market.Status == common.MarketStatusWaitOpen { // 待开盘
			counts.WaitOpenCounts++
		} else if market.Status == common.MarketStatusOpen && market.Visible == 1 && market.Suspended == 0 {
			counts.CanBetCounts++ // 可投注 (开盘且可见且未暂停)
		}
		if market.Suspended == 1 { // 暂停
			counts.SuspendCounts++
		}
		if market.Visible == 0 { // 隐藏
			counts.HiddenCounts++
		}
		if market.Status == common.MarketStatusResultRejected || market.Status == common.MarketStatusClose {
			counts.WaitInputCounts++ // 待录入盘口（已关盘 赛果驳回）
		}
		if market.Status == common.MarketStatusWaitSettle || market.Status == common.MarketStatusWaitCancel ||
			market.Status == common.MarketStatusSettled || market.Status == common.MarketStatusCancelled {
			counts.EnteredCounts++ // 已录入盘口（待结算 待取消 已结算 已取消）
		}
		if market.Status != common.MarketStatusWaitInput && market.Status != common.MarketStatusInputReject &&
			market.Status != common.MarketStatusPending {
			counts.AllCounts++ // 全部（所有赛事审核通过盘口）
		}
		if market.Status == common.MarketStatusCancelled && market.Remark != "取消理由:无赛果" {
			counts.CancelCount++ // 已取消（已取消且无赛果）
		}
		if market.Status == common.MarketStatusWaitSettle {
			counts.WaitSettlement++ // 待结算盘口（待结算）
		}
		if market.Status == common.MarketStatusSettled || market.Status == common.MarketStatusCancelled {
			counts.Settlement++ // 已结算盘口（已结算 已取消）
		}

		if len(defaultMkt) == 0 && market.IsDefault == 1 {
			defaultMkt = market.ID
		}
	}

	return counts, defaultMkt
}

/**
 * @Description: 获取默认盘口
 * @Author: awen
 * @Date: 2021/06/26
 * @LastEditTime: 2021/10/26
 * @LastEditors: awen
 **/
func getDefaultMarketID(markets map[string]calc.MarketData) string {

	defaultMkt := ""
	for _, v := range markets {
		if v.IsDefault == 1 {
			defaultMkt = v.ID
		}
	}

	return defaultMkt
}

/**
 * @Description: 盘口暂停
 * @Author: maxic
 * @Date: 2020/10/23
 * @LastEditTime: 2020/10/23
 * @LastEditors: maxic
 **/
func marketSuspend(tx *sql.Tx, match calc.MatchData, market calc.MarketData, markets map[string]calc.MarketData) (CalcMarketCountsStat, []string, error) {

	// 更新盘口状态
	record := g.Record{
		"suspended":      1,
		"suspended_type": 1, // 盘口超限触发的暂停算是手动暂停
		"update_by_id":   0,
		"update_by_name": "【auto】",
		"update_time":    time.Now().Unix(),
	}

	market.Suspended = 1
	markets[market.ID] = market

	var (
		counts       CalcMarketCountsStat
		err          error
		defaultMktID string
		mixIds       []string
	)

	if market.OptionType == common.OptionTypeWinLose && market.Round > 0 {
		mixMarkets, err := getMixMarkets(common.MixMarketRuleInclude, "suspended", 0, []string{market.ID})
		if err != nil {
			return counts, mixIds, err
		}

		if len(mixMarkets) > 0 {
			for _, mix := range mixMarkets {
				// 复合盘口未暂停的需要暂停
				if mix.Suspended == 0 {
					mixIds = append(mixIds, mix.ID)
					mix.Suspended = 1
					markets[mix.ID] = mix
				}
			}
		}
	}

	counts, defaultMktID = marketCountCalc(markets)
	err = marketUpdate(tx, match.ID, defaultMktID, record, g.Ex{"id": market.ID})
	if err != nil {
		return counts, mixIds, err
	}

	if len(mixIds) > 0 {
		// 更新管理复合盘口状态
		mixRecord := g.Record{
			"suspended":      1,
			"suspended_type": 0, // 子盘口停盘导致的关联复合盘口停盘，暂停类型为自动
			"update_by_id":   0,
			"update_by_name": "【auto】",
			"update_time":    time.Now().Unix(),
		}

		err := marketUpdate(tx, match.ID, defaultMktID, mixRecord, g.Ex{"id": mixIds})
		if err != nil {
			return counts, mixIds, err
		}
	}

	return counts, mixIds, nil
}

/**
 * @Description: 从数据库获取盘口列表
 * @Author: wesley
 * @Date: 2020/6/22 13:20
 * @LastEditTime: 2020/6/22 13:20
 * @LastEditors: wesley
 */
func MarketListDB(ex g.Ex) ([]calc.MarketData, error) {

	var data []calc.MarketData
	query, _, _ := g.Dialect("mysql").From("tbl_markets").Select(colMarketData...).Where(ex).ToSQL()
	err := db.Select(&data, query)

	return data, err
}

/**
* @Description: 根据子盘口获取管理复合盘口
* @Author: awen
* @Date: 2021/08/15
* @LastEditTime: 2021/08/15
* @LastEditors: awen
 */
func getMixMarkets(rule int, field string, val int, subIds []string) ([]calc.MarketData, error) {

	var (
		data []calc.MarketData
		ok   bool
	)

	//获取子盘口关联的复合玩法盘口
	mktMixSubs, err := MarketMixSubFindAll(g.Ex{"sub_market_id": subIds})
	if err != nil {
		return data, err
	}

	if len(mktMixSubs) == 0 {
		return data, err
	}

	mktIds := strset.New()
	for _, v := range mktMixSubs {
		mktIds.Add(v.MixMarketID)
	}

	mpMixSubIds := map[string][]string{}
	if rule == common.MixMarketRuleComplete {
		//获取复合条件的复合玩法盘口的所有子盘口
		mixSubAll, err := MarketMixSubFindAll(g.Ex{"mix_market_id": mktIds.List()})
		if err != nil {
			return data, err
		}

		for _, v := range mixSubAll {
			mktIds.Add(v.SubMarketID)
			mpMixSubIds[v.MixMarketID] = append(mpMixSubIds[v.MixMarketID], v.SubMarketID)
		}
	}

	mixMarkets, err := MarketListDB(g.Ex{"id": mktIds.List()})
	if err != nil {
		return mixMarkets, err
	}

	if rule == common.MixMarketRuleInclude {
		return mixMarkets, nil
	}

	mpSubId := map[string]int8{}
	for _, subId := range subIds {
		mpSubId[subId] = 1
	}

	mpSubMkt := map[string]calc.MarketData{}
	for _, mkt := range mixMarkets {
		mpSubMkt[mkt.ID] = mkt
	}

	for mixId, subMktIds := range mpMixSubIds {
		// 符合条件的子盘口数据
		subCount := 0
		for _, subId := range subMktIds {
			if _, ok = mpSubMkt[subId]; ok {
				if mpSubId[subId] == 1 {
					subCount++
					continue
				}
				switch field {
				case "status":
					if mpSubMkt[subId].Status == val {
						subCount++
					}
				case "suspended":
					if mpSubMkt[subId].Suspended == val {
						subCount++
					}
				case "visible":
					if mpSubMkt[subId].Visible == val {
						subCount++
					}
				default:
					break
				}
			}
		}
		if mpSubMkt[mixId].CompSubNum == subCount {
			data = append(data, mpSubMkt[mixId])
		}
	}

	return data, nil
}

/**
 * @Description: 获取所有子盘口与复合盘口的关联
 * @Author: awen
 * @Date: 2021-06-21
 * @LastEditTime: 2021-06-21
 * @LastEditors: awen
 **/
func MarketMixSubFindAll(ex g.Ex) ([]MarketMixSub, error) {

	var data []MarketMixSub
	query, _, _ := g.Dialect("mysql").From("tbl_market_mix_sub").Select(colMarketMixSub...).Where(ex).ToSQL()
	err := db.Select(&data, query)
	if err != nil {
		return data, err
	}

	return data, nil
}

/**
 * @Description: 投注项暂停
 * @Author: awen
 * @Date: 2021-06-21
 * @LastEditTime: 2021-06-21
 * @LastEditors: awen
 **/
func oddSuspend(tx *sql.Tx, matchID, marketID, oddID string, markets map[string]calc.MarketData) error {

	// 更新盘口状态
	record := g.Record{
		"suspended": 1,
	}

	query, _, _ := common.Dialect.Update("tbl_odds").Set(record).Where(g.Ex{"id": oddID}).ToSQL()
	fmt.Println(query)
	_, err := tx.Exec(query)
	if err != nil {
		return err
	}

	defaultMktID := getDefaultMarketID(markets)
	// 更新盘口缓存
	path := fmt.Sprintf(calc.JPathOddField, marketID, oddID, "suspended")
	pipe := traderRedis.Pipeline()
	calc.MatchCacheSet(pipe, matchID, path, 1, marketID == defaultMktID)
	_, err = pipe.Exec()
	if err != nil {
		return err
	}

	return nil
}

/**
* @Description: 盘口更新
* @Author: brandon
* @Date: 2020/6/20 8:27 下午
* @LastEditTime: 2020/6/20 8:27 下午
* @LastEditors: brandon
 */
func marketUpdate(tx *sql.Tx, matchID, defaultMktID string, record g.Record, ex g.Ex) error {

	// 更新盘口数据库
	query, _, _ := common.Dialect.Update("tbl_markets").Set(record).Where(ex).ToSQL()
	fmt.Println(query)
	_, err := tx.Exec(query)
	if err != nil {
		return err
	}

	// 更新盘口缓存
	pipe := traderRedis.Pipeline()
	MarketCacheUpdate(pipe, matchID, record, ex, defaultMktID)
	_, err = pipe.Exec()
	_ = pipe.Close()
	if err != nil {
		return err
	}

	return nil
}

/**
 * @Description: 发送盘口mqtt通知
 * @Author: maxic
 * @Date: 2020/10/23
 * @LastEditTime: 2020/10/23
 * @LastEditors: maxic
 **/
func monitorNotify(matchID, marketID string, mixMarketIds []string, counts CalcMarketCountsStat) error {

	// mqtt通知盘口状态变更
	err := common.MqttNotifyMarketSuspended(cli, []string{marketID}, mixMarketIds, 1, matchID)
	if err != nil {
		return err
	}

	return common.MqttNotifyMarketCountsUpdate(cli, matchID, counts)
}

/**
 * @Description: 更新盘口缓存字段
 * @Author: maxic
 * @Date: 2020/8/15
 * @LastEditTime: 2020/8/15
 * @LastEditors: maxic
 **/
func MarketCacheUpdate(pipe redis.Pipeliner, matchId string, record g.Record, ex g.Ex, defaultMarketId string) {

	cacheFields := map[string]bool{
		"is_default":         true,
		"option_type":        true,
		"sort_code":          true,
		"status":             true,
		"suspended":          true,
		"visible":            true,
		"prize_limit":        true,
		"mb_mkt_prize_limit": true,
		"mb_mch_prize_limit": true,
		"warning_profit":     true,
		"stop_profit":        true,
		"remark":             true,
		"suspended_type":     true,
		"visible_type":       true,
	}
	fn := func(id, defaultId string) {
		for k, v := range record {
			if cacheFields[k] {
				path := fmt.Sprintf(calc.JPathMarketField, id, k)
				calc.MatchCacheSet(pipe, matchId, path, v, id == defaultMarketId)
			}
		}
	}
	if id, ok := ex["id"]; ok {
		switch id.(type) {
		case string:
			fn(id.(string), defaultMarketId)
		case []string:
			for _, v := range id.([]string) {
				fn(v, defaultMarketId)
			}
		}
	}
}

/**
 * @Description: 更新盘口投注项缓存字段
 * @Author: maxic
 * @Date: 2020/8/15
 * @LastEditTime: 2020/8/15
 * @LastEditors: maxic
 **/
func MarketCacheOddUpdate(pipe redis.Pipeliner, matchId, marketId string, record g.Record, ex g.Ex, defaultMarketId string) {

	cacheFields := map[string]bool{
		"odd":       true,
		"is_winner": true,
		"sort_id":   true,
		"visible":   true,
		"suspended": true,
		"name":      true,
		"en_name":   true,
	}
	fn := func(id, defaultId string) {
		for k, v := range record {
			if cacheFields[k] {
				path := fmt.Sprintf(calc.JPathOddField, marketId, id, k)
				calc.MatchCacheSet(pipe, matchId, path, v, marketId == defaultMarketId)
			}
		}
	}
	if id, ok := ex["id"]; ok {
		switch id.(type) {
		case string:
			fn(id.(string), defaultMarketId)
		case []string:
			for _, v := range id.([]string) {
				fn(v, defaultMarketId)
			}
		}
	}
}
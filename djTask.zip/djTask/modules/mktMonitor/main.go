package mktMonitor

import (
	"djTask/contrib/zlog"
	"djTask/modules/common"
	mqtt "github.com/eclipse/paho.mqtt.golang"
	"github.com/go-redis/redis/v7"
	"github.com/jmoiron/sqlx"
	"github.com/panjf2000/ants/v2"
	cpool "github.com/silenceper/pool"
	"time"
)

var (
	conf        common.TraderCfg
	bPool       cpool.Pool
	pool        *ants.PoolWithFunc
	db          *sqlx.DB
	traderRedis *redis.Client
	cli         mqtt.Client
	emqxCli     mqtt.Client
)

func Parse(endpoints []string, path string) {

	common.ParseCfg(&conf, endpoints, path)

	// 初始化数据库
	db = common.InitDBX(conf.TraderDb.Db, conf.TraderDb.MaxIdleConn, conf.TraderDb.MaxOpenConn)
	// 初始化总控redis
	traderRedis = common.InitRedis(conf.RedisMaster.Addr, conf.RedisMaster.Password, conf.RedisMaster.Sentinel, 0)
	// 初始MQTT
	cli = common.InitMqttService(conf.Mqtt)
	// 初始操盘日志mqtt
	emqxCli = common.InitMqttService([]string{conf.Emqx})
	// 初始化延时队列
	bPool = common.InitBeanstalk(conf.Beanstalk, 50, 50, 100)
	// 初始化zlog
	zlog.New(conf.Zlog.Brokers, conf.Zlog.URI)

	defer func() {
		_ = db.Close()
		_ = traderRedis.Close()
	}()

	run()
}

func run() {
	pool, _ = ants.NewPoolWithFunc(1000, func(payload interface{}) {
		if task, ok := payload.(MarketMonitorTask); ok {
			handle(task)
		}
	})
	defer pool.Release()

	handler := &common.BeansHandler{
		Name:          "mktMonitor",
		BeansPool:     bPool,
		BeansTubeName: common.BeanstalkMarketMonitorTube,
		BeansReserve:  2 * time.Minute,
		FnPoolSize:    1000,
		Fn:            beansHandle,
	}
	handler.Watch()
	handler.Release()
}

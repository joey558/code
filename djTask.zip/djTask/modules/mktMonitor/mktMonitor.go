package mktMonitor

import (
	"database/sql"
	"djTask/calc"
	"djTask/contrib/validator"
	"djTask/helper"
	"djTask/modules/common"
	"fmt"
	g "github.com/doug-martin/goqu/v9"
	"github.com/go-redis/redis/v7"
	"github.com/shopspring/decimal"
	"math"
	"strconv"
	"sync"
	"time"
)

// 盘口监控记录结构体
type MarketMonitor struct {
	ID           string `json:"id" db:"id"`
	GameId       string `json:"game_id" db:"game_id"`               // 游戏id
	TournamentId string `json:"tournament_id" db:"tournament_id"`   // 联赛id
	MatchId      string `json:"match_id" db:"match_id"`             // 赛事id
	MarketId     string `json:"market_id" db:"market_id"`           // 盘口id
	OddId        string `json:"odd_id" db:"odd_id"`                 // 投注项id
	Type         int    `json:"type" db:"type"`                     // 记录类型 0-暂停记录 1-预警记录
	Status       int    `json:"status" db:"status"`                 // 预警记录警报状态 0-预警 1-超限
	UpdateById   uint64 `json:"update_by_id" db:"update_by_id"`     // 修改人ID
	UpdateByName string `json:"update_by_name" db:"update_by_name"` // 修改人名称
	UpdateTime   int64  `json:"update_time" db:"update_time"`       // 修改时间
}

/**
 * @Description: 设置盘口监控记录缓存
 * @Author: maxic
 * @Date: 2020/10/23
 * @LastEditTime: 2020/10/23
 * @LastEditors: maxic
 **/
func marketMonitorSetCache(marketId, oddId string, typ, status int) error {

	var err error
	key := fmt.Sprintf(common.RedisMarketMonitorRecord, marketId)
	if oddId != "0" {
		key = fmt.Sprintf(common.RedisMarketOddMonitorRecord, marketId, oddId)
	}
	filed := fmt.Sprintf("%d", typ)
	if status >= 0 { // set
		_, err = traderRedis.HSet(key, filed, status).Result()
	} else { // delete
		_, err = traderRedis.HDel(key, filed).Result()
	}

	return err
}

/**
 * @Description: 新增盘口监控记录
 * @Author: maxic
 * @Date: 2020/10/23
 * @LastEditTime: 2020/10/23
 * @LastEditors: maxic
 **/
func marketMonitorInsert(tx *sql.Tx, data MarketMonitor) error {

	query, _, _ := g.Dialect("mysql").Insert("tbl_market_monitor").Rows(data).ToSQL()
	fmt.Println(query)
	_, err := tx.Exec(query)
	if err != nil {
		return err
	}

	return marketMonitorSetCache(data.MarketId, data.OddId, data.Type, data.Status)
}

/**
 * @Description: 更新盘口监控记录
 * @Author: maxic
 * @Date: 2020/10/23
 * @LastEditTime: 2020/10/23
 * @LastEditors: maxic
 **/
func marketMonitorUpdate(tx *sql.Tx, record g.Record, ex g.Ex) error {

	query, _, _ := g.Dialect("mysql").Update("tbl_market_monitor").Set(record).Where(ex).Limit(1).ToSQL()
	fmt.Println(query)
	_, err := tx.Exec(query)
	if err != nil {
		return err
	}

	return marketMonitorSetCache(ex["market_id"].(string), ex["odd_id"].(string), ex["type"].(int), record["status"].(int))
}

/**
 * @Description: 删除盘口监控记录
 * @Author: maxic
 * @Date: 2020/10/23
 * @LastEditTime: 2020/10/23
 * @LastEditors: maxic
 **/
func marketMonitorDelete(tx *sql.Tx, ex g.Ex) error {

	query, _, _ := g.Dialect("mysql").Delete("tbl_market_monitor").Where(ex).Limit(1).ToSQL()
	fmt.Println(query)
	_, err := tx.Exec(query)
	if err != nil {
		return err
	}
	return marketMonitorSetCache(ex["market_id"].(string), ex["odd_id"].(string), ex["type"].(int), -1)
}

/**
 * @Description: 获取盘口或冠军盘投注项监控记录状态
 * @Author: wesley
 * @Date: 2020/10/8 14:52
 * @LastEditTime: 2020/10/8 14:52
 * @LastEditors: wesley
 */
func marketMonitorStatusGet(marketID, oddID string, typ int) (int, error) {

	key := fmt.Sprintf(common.RedisMarketMonitorRecord, marketID)
	if oddID != "0" {
		key = fmt.Sprintf(common.RedisMarketOddMonitorRecord, marketID, oddID)
	}
	filed := fmt.Sprintf("%d", typ)
	res, err := traderRedis.HGet(key, filed).Result()
	if err == redis.Nil {
		return -1, nil
	}
	if err != nil {
		return -1, err
	}
	status, err := strconv.Atoi(res)
	if err != nil {
		return -1, err
	}
	return status, nil
}

type MarketMonitorTask struct {
	Handler   *common.BeansHandler
	MatchId   string
	MarketId  string
	OddId     string
	Tid       string
	TimeStamp int64
}

var (
	mtxTask   sync.Mutex
	mtxStamps sync.Mutex
	tasks     = map[string]bool{}  // map[task]working_stat
	stamps    = map[string]int64{} // map[task]timestamp
)

func lockTask(task MarketMonitorTask) bool {
	ret := true
	mtxTask.Lock()
	key := fmt.Sprintf("%s:%s:%s", task.MatchId, task.MarketId, task.OddId)
	if _, ok := tasks[key]; ok {
		ret = false
	} else {
		tasks[key] = true
	}
	mtxTask.Unlock()
	return ret
}

func unlockTask(task MarketMonitorTask) {
	mtxTask.Lock()
	key := fmt.Sprintf("%s:%s:%s", task.MatchId, task.MarketId, task.OddId)
	delete(tasks, key)
	mtxTask.Unlock()
}

func getTaskStamp(task MarketMonitorTask) int64 {
	stamp := int64(0)
	mtxStamps.Lock()
	key := fmt.Sprintf("%s:%s:%s", task.MatchId, task.MarketId, task.OddId)
	if s, ok := stamps[key]; ok {
		stamp = s
	}
	mtxStamps.Unlock()
	return stamp
}

func invokeTask(task MarketMonitorTask) {
	if stamp := getTaskStamp(task); stamp > 0 && task.TimeStamp <= stamp {
		//common.AddLog(common.LogInfo, task.Handler.Name, task.Tid, "discard expired task: %+v, new stamp: %d", task, stamp)
		return
	}

	mtxStamps.Lock()
	key := fmt.Sprintf("%s:%s:%s", task.MatchId, task.MarketId, task.OddId)
	stamps[key] = task.TimeStamp
	mtxStamps.Unlock()

	pool.Invoke(task)
	//common.AddLog(common.LogInfo, task.Handler.Name, task.Tid, "invoke task: %+v", task)
}

func divorceTask(task MarketMonitorTask) {
	mtxStamps.Lock()
	key := fmt.Sprintf("%s:%s:%s", task.MatchId, task.MarketId, task.OddId)
	delete(stamps, key)
	mtxStamps.Unlock()
}

/**
 * @Description: 盘口监控beanstalk消息处理函数
 * @Author: maxic
 * @Date: 2020/10/23
 * @LastEditTime: 2020/10/23
 * @LastEditors: maxic
 **/
func beansHandle(h *common.BeansHandler, m common.BeansMessage) bool {

	//传输内容 match_id=%v&market_id=%v
	matchId := m.Msg.Get("match_id")
	marketId := m.Msg.Get("market_id")
	oddId := m.Msg.Get("odd_id")
	orderId := m.Msg.Get("order_id")

	common.AddLog(common.LogInfo, h.Name, m.ID,
		"=== handle market monitor... match_id:%s, market_id:%s, odd_id:%s order_id:%s ===", matchId, marketId, oddId, orderId)

	if !validator.CheckStringDigit(matchId) {
		common.AddLog(common.LogError, h.Name, m.ID, "match_id invalid")
		return true
	}
	if !validator.CheckStringDigit(marketId) {
		common.AddLog(common.LogError, h.Name, m.ID, "market_id invalid")
		return true
	}

	invokeTask(MarketMonitorTask{
		Handler:   h,
		MatchId:   matchId,
		MarketId:  marketId,
		OddId:     oddId,
		Tid:       m.ID,
		TimeStamp: time.Now().UnixNano(),
	})
	return true
}

/**
 * @Description: 盘口监控记录处理函数
 * @Author: maxic
 * @Date: 2020/10/23
 * @LastEditTime: 2020/10/23
 * @LastEditors: maxic
 **/
func handle(task MarketMonitorTask) {
	if stamp := getTaskStamp(task); stamp > 0 && task.TimeStamp < stamp {
		//common.AddLog(common.LogInfo, h.Name, task.Tid, "task expired: %+v, new stamp: %d", task, stamp)
		return
	}

	if !process(task) {
		invokeTask(task)
	} else {
		divorceTask(task)
	}
}

/**
 * @Description: 盘口监控记录实际处理函数
 * @Author: maxic
 * @Date: 2020/10/23
 * @LastEditTime: 2020/10/23
 * @LastEditors: maxic
 **/
func process(task MarketMonitorTask) bool {

	//if !lockTask(task) {
	//	return false
	//}
	//defer unlockTask(task)

	key := fmt.Sprintf("%s:%s:%s", common.BeanstalkMarketMonitorTube, task.MatchId, task.MarketId)
	lock := common.RedisLock{Pool: traderRedis, Key: key, Timeout: 5 * time.Second}
	if err := lock.Lock(); err != nil {
		common.AddLog(common.LogError, task.Handler.Name, task.Tid, err.Error())
		return false
	}
	defer lock.Unlock()

	common.AddLog(common.LogInfo, task.Handler.Name, task.Tid, "process market monitor... task:%+v", task)

	//获取盘口信息
	data, err := calc.HandicapInfo(traderRedis, []string{task.MatchId})
	if err != nil {
		common.AddLog(common.LogError, task.Handler.Name, task.Tid, "get match match from redis error: %s", err.Error())
		return false
	}

	//先判断缓存中是否存在要处理的盘口
	match, ok := data.Matches[task.MatchId]
	if !ok {
		common.AddLog(common.LogError, task.Handler.Name, task.Tid, "match not found in handicap cache")
		return false
	}
	market, ok := data.Markets[task.MarketId]
	if !ok {
		common.AddLog(common.LogError, task.Handler.Name, task.Tid, "market not found in handicap cache")
		return false
	}
	if market.WarningProfit == 0 || market.StopProfit == 0 {
		common.AddLog(common.LogError, task.Handler.Name, task.Tid,
			"market set no monitor values[%d|%d], skip...", market.WarningProfit, market.StopProfit)
		return false
	}

	//从缓存中获取盘口盈亏数据
	mktProf, err := calc.MarketProfitCalc(traderRedis, task.MatchId, task.MarketId)
	if err != nil {
		common.AddLog(common.LogError, task.Handler.Name, task.Tid, "get market profits from redis error: %s", err.Error())
		return false
	}

	var odd calc.OddData
	//冠军盘猜冠军和趣味玩法只暂定对应的投注项
	championFlag := 0
	if match.Category == 2 {
		if market.OptionType == common.OptionTypePloy || //趣味
			market.OptionType == common.OptionTypeSingleChampion || //猜冠军单项结算
			market.OptionType == common.OptionTypeMultipleChampion { //猜冠军多项结算
			championFlag = 1
			if odd, ok = data.Odds[task.OddId]; !ok {
				common.AddLog(common.LogError, task.Handler.Name, task.Tid, "odd[%s] not found in handicap cache", task.OddId)
				return false
			}
		}
	}

	if championFlag == 0 {
		task.OddId = "0"
	}

	//判断超限状态
	status := -1
	for oId, oddProf := range mktProf.Odds {
		if championFlag == 1 && oId != task.OddId {
			continue
		}
		profit := decimal.NewFromFloat(mktProf.RealityBetAmount + mktProf.FloatBetAmount -
			oddProf.RealityTheoryPrize - oddProf.FloatTheoryPrize)
		if profit.Neg().GreaterThanOrEqual(decimal.NewFromInt(int64(market.StopProfit))) {
			// 浮动盈亏大于等于停盘值
			status = int(math.Max(float64(status), float64(calc.MarketMonitorStatusStop)))
		} else if profit.Neg().GreaterThanOrEqual(decimal.NewFromInt(int64(market.WarningProfit))) {
			// 浮动盈亏大于等于预警值
			status = int(math.Max(float64(status), float64(calc.MarketMonitorStatusWarning)))
		}
	}
	common.AddLog(common.LogInfo, task.Handler.Name, task.Tid, "market float profits: %+v, profit setting: %d|%d, status: %d",
		mktProf, market.WarningProfit, market.StopProfit, status)

	//获取盘口当前监控状态
	oldStatus, err := marketMonitorStatusGet(task.MarketId, task.OddId, calc.MarketMonitorTypeMonitor)
	if err != nil {
		common.AddLog(common.LogError, task.Handler.Name, task.Tid, "get market monitor status error: %s", err.Error())
		return false
	}
	common.AddLog(common.LogInfo, task.Handler.Name, task.Tid, "market old monitor status: %d", oldStatus)

	// 更新操作
	tx, err := db.Begin()
	if err != nil {
		common.AddLog(common.LogError, task.Handler.Name, task.Tid, "begin tx error: %s", err.Error())
		return false
	}

	var (
		counts CalcMarketCountsStat
		mixIds []string
	)
	record := MarketMonitor{
		ID:           fmt.Sprintf("%d", helper.Cputicks()),
		GameId:       match.GameID,
		TournamentId: match.TournamentID,
		MatchId:      task.MatchId,
		MarketId:     task.MarketId,
		OddId:        task.OddId,
		Type:         calc.MarketMonitorTypeMonitor,
		Status:       status,
		UpdateById:   0,
		UpdateByName: "【auto】",
		UpdateTime:   time.Now().Unix(),
	}
	suspend := false
	if oldStatus < 0 { //记录不存在
		//当前为预警或超限状态，则新增
		if status >= 0 {
			suspend = status == calc.MarketMonitorStatusStop
			if err = marketMonitorInsert(tx, record); err != nil {
				_ = tx.Rollback()
				common.AddLog(common.LogError, task.Handler.Name, task.Tid, "insert market monitor record error: %s", err.Error())
				return false
			}
			common.AddLog(common.LogInfo, task.Handler.Name, task.Tid, "insert market monitor record: %+v", record)
		}

	} else { //记录已存在
		switch status {
		case calc.MarketMonitorStatusWarning: // 当前为预警状态
			// 不处理
			_ = tx.Commit()
			common.AddLog(common.LogInfo, task.Handler.Name, task.Tid, "already in monitor status[%d], current[%d], skip...", oldStatus, status)
			return true

		case calc.MarketMonitorStatusStop: // 当前为超限状态
			suspend = true

			if oldStatus == calc.MarketMonitorStatusStop {
				// 旧状态已经是超限状态，后续需检测盘口是否暂停
				common.AddLog(common.LogInfo, task.Handler.Name, task.Tid, "already in monitor status[%d], current[%d]", oldStatus, status)
			} else {
				// 当前已经是预警状态，升级为超限状态并暂停盘口
				err = marketMonitorUpdate(tx,
					g.Record{
						"status":         record.Status,
						"update_by_id":   record.UpdateById,
						"update_by_name": record.UpdateByName,
						"update_time":    time.Now().Unix(),
					},
					g.Ex{
						"market_id": record.MarketId,
						"odd_id":    record.OddId,
						"type":      calc.MarketMonitorTypeMonitor,
					},
				)
				if err != nil {
					_ = tx.Rollback()
					common.AddLog(common.LogError, task.Handler.Name, task.Tid, "upgrade status to stop error: %s", err.Error())
					return false
				}

				common.AddLog(common.LogInfo, task.Handler.Name, task.Tid, "upgrade status to stop")
			}

		default: // 当前为未预警或超限状态
			if oldStatus == calc.MarketMonitorStatusStop {
				// 旧状态已经是超限状态，不处理
				_ = tx.Commit()
				common.AddLog(common.LogInfo, task.Handler.Name, task.Tid, "no need to delete monitor record in status stop, skip...")
				return true
			} else {
				// 当前已经是预警状态，移除记录
				delEx := g.Ex{
					"market_id": record.MarketId,
					"odd_id":    "0",
					"type":      calc.MarketMonitorTypeMonitor,
				}
				if championFlag == 1 {
					delEx["odd_id"] = record.OddId
				}
				err = marketMonitorDelete(tx, delEx)
				if err != nil {
					_ = tx.Rollback()
					common.AddLog(common.LogError, task.Handler.Name, task.Tid, "delete monitor record error: %s", err.Error())
					return false
				}

				common.AddLog(common.LogInfo, task.Handler.Name, task.Tid, "delete monitor record")
			}
		}
	}

	if !suspend {
		// 不用暂停盘口，直接提交
		if err = tx.Commit(); err != nil {
			common.AddLog(common.LogError, task.Handler.Name, task.Tid, "commit tx error: %s", err.Error())
		}
		return true

	} else {
		// 判断盘口和投注项是否已暂停
		if (championFlag == 0 && market.Suspended == 1 && market.SuspendedType == 1) || (championFlag == 1 && odd.Suspended == 1) {
			_ = tx.Commit()
			common.AddLog(common.LogInfo, task.Handler.Name, task.Tid, "market already suspended")
			return true
		}

		if championFlag == 0 {
			// 暂停盘口
			if counts, mixIds, err = marketSuspend(tx, match, market, data.Markets); err != nil {
				_ = tx.Rollback()
				common.AddLog(common.LogError, task.Handler.Name, task.Tid, "suspend market error: %s", err.Error())
				return false
			}
		} else {
			// 暂停投注项
			if err = oddSuspend(tx, task.MatchId, task.MarketId, task.OddId, data.Markets); err != nil {
				_ = tx.Rollback()
				common.AddLog(common.LogError, task.Handler.Name, task.Tid, "suspend odd error: %s", err.Error())
				return false
			}
		}
		

		// 新增盘口暂停记录
		oldStatus, err := marketMonitorStatusGet(task.MarketId, task.OddId, calc.MarketMonitorTypeSuspend)
		if oldStatus < 0 { // 记录不存在
			record.ID = fmt.Sprintf("%d", helper.Cputicks()+1)
			record.Type = calc.MarketMonitorTypeSuspend
			record.Status = 0
			if err = marketMonitorInsert(tx, record); err != nil {
				_ = tx.Rollback()
				common.AddLog(common.LogError, task.Handler.Name, task.Tid, "insert market suspend record error: %s", err.Error())
				return false
			}
			common.AddLog(common.LogInfo, task.Handler.Name, task.Tid, "insert market suspend record: %+v", record)
		}

		// 提交事务
		if err = tx.Commit(); err != nil {
			common.AddLog(common.LogError, task.Handler.Name, task.Tid, "commit tx error: %s", err.Error())
			return false
		}

		if championFlag == 0 {
			// 盘口暂停, 推送redis stream
			extraInfo := fmt.Sprintf("&delay_time=%d", match.BetDelayTime)
			err = beansPutTradeTask(match.ID, market.ID, extraInfo, "1")
			//err = common.RedisSendTradeStream(traderRedis, match.ID, market.ID, extraInfo, "1")
			if err != nil {
				common.AddLog(common.LogError, task.Handler.Name, task.Tid, "send market suspend trade stream error: %s", err.Error())
			}

			// mqtt通知盘口状态变更
			err = monitorNotify(match.ID, market.ID, mixIds, counts)
			if err != nil {
				common.AddLog(common.LogError, task.Handler.Name, task.Tid, "mqtt notify error: %s", err.Error())
			}
		} else {
			err = common.MqttNotifyOddSuspended(cli, task.MatchId, task.MarketId, task.OddId, 1)
			if err != nil {
				common.AddLog(common.LogError, task.Handler.Name, task.Tid, "mqtt notify error: %s", err.Error())
			}
		}


		_ = common.XPubMarket(emqxCli, traderRedis, match.GameID, match.TournamentID, match.MatchTeam, match.ID,
			market.ID, market.CnName, int16(market.Round),
			"操盘管理-赛事主页", "盘口暂停", "盘口预警超限自动暂停", int8(match.Category))
	}

	return true
}

/**
 * @Description:追加操盘任务，盘口监控触发停盘后，暂停盘口
 * @Author: awen
 * @Date: 2020/10/24 21:40
 * @LastEditTime: 2020/10/24 21:40
 * @LastEditors: awen
 */
func beansPutTradeTask(matchID, marketIds, extraInf, flag string) error {

	message := fmt.Sprintf("match_id=%s&market_id=%s&flag=%s", matchID, marketIds, flag)
	if len(extraInf) > 0 {
		message += extraInf
	}

	for _, m := range conf.Merchants {

		data := common.BeansTask{
			Tube:    fmt.Sprintf(common.BeanstalkTradeTube, m.Account),
			Message: message,
			Delay:   0,
			PRI:     1,
			TTR:     60 * time.Second,
		}

		if err := common.BeansAddTask(bPool, data); err != nil {
			return fmt.Errorf("merchant_id: %d account:%s beanstalk put trade err:%s", m.ID, m.Account, err.Error())
		}
	}

	return nil
}

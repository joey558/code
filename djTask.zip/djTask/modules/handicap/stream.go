package handicap

import (
	"fmt"
	"github.com/go-redis/redis/v7"
)

/**
 * @Description: 操盘动作发送stream消息
 * @Author: maxic
 * @Date: 2020/7/8
 * @LastEditTime: 2020/7/8
 * @LastEditors: maxic
 **/
func RedisSendTradeStream(matchID, marketIds, flag string) error {

	content := fmt.Sprintf("match_id=%s&market_id=%s&flag=%s", matchID, marketIds, flag)
	message := map[string]interface{}{
		"data": content,
	}
	args := &redis.XAddArgs{
		Stream:       redisStreamTrade,
		MaxLenApprox: 50000,
		Values:       message,
	}

	return pool.XAdd(args).Err()
}


package handicap

import (
	"fmt"
	g "github.com/doug-martin/goqu/v9"
)

/**
 * @Description: 从数据库获取盘口列表
 * @Author: wesley
 * @Date: 2020/6/22 13:20
 * @LastEditTime: 2020/6/22 13:20
 * @LastEditors: wesley
 */
func MarketListDB(ex g.Ex) ([]MarketData, error) {

	var data []MarketData
	query, _, _ := g.Dialect("mysql").From("tbl_markets").Select("id").Where(ex).ToSQL()
	fmt.Println(query)
	err := db.Select(&data, query)

	return data, err
}

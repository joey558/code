package handicap

import (
	"djTask/calc"
	"djTask/contrib/validator"
	"djTask/contrib/zlog"
	"djTask/modules/common"
	"time"

	g "github.com/doug-martin/goqu/v9"
	mqtt "github.com/eclipse/paho.mqtt.golang"
	"github.com/go-redis/redis/v7"
	"github.com/jmoiron/sqlx"
	cpool "github.com/silenceper/pool"
)

var (
	conf    common.TraderCfg
	bPool   cpool.Pool
	db      *sqlx.DB
	pool    *redis.Client
	cli     mqtt.Client
	emqxCli mqtt.Client
)

const (
	MatchHide = "2" //赛事自动隐藏
)

// bean tasks
var bTasks = map[string]common.BeansFunc{
	MatchHide: matchHide, //赛事隐藏
}

func Parse(endpoints []string, path string) {

	common.ParseCfg(&conf, endpoints, path)

	// 初始化延时队列
	bPool = common.InitBeanstalk(conf.Beanstalk, 5, 5, 10)
	// 初始化操盘消息推送mqtt
	cli = common.InitMqttService(conf.Mqtt)
	// 初始操盘日志mqtt
	emqxCli = common.InitMqttService([]string{conf.Emqx})
	// 初始化db
	db = common.InitDBX(conf.TraderDb.Db, conf.TraderDb.MaxIdleConn, conf.TraderDb.MaxOpenConn)
	// 初始化总控redis
	pool = common.InitRedis(conf.RedisMaster.Addr, conf.RedisMaster.Password, conf.RedisMaster.Sentinel, 0)
	// 初始化zlog
	zlog.New(conf.Zlog.Brokers, conf.Zlog.URI)

	defer func() {
		_ = db.Close()
		_ = pool.Close()
	}()

	run()
}

func run() {

	handler := &common.BeansHandler{
		Name:          "autoHide",
		BeansPool:     bPool,
		BeansTubeName: common.BeanStalkMatchAutoHide,
		BeansReserve:  2 * time.Minute,
		FnPoolSize:    1000,
		Fn:            process,
	}
	handler.Watch()
	handler.Release()
}

// beanstalk task process
func process(h *common.BeansHandler, msg common.BeansMessage) bool {

	if task, ok := bTasks[msg.Msg.Get("flag")]; ok {
		return task(h, msg)
	}
	common.AddLog(common.LogError, h.Name, msg.ID, "flag not in the task list")
	return true
}

func matchHide(h *common.BeansHandler, m common.BeansMessage) bool {

	matchID := m.Msg.Get("match_id")
	if !validator.CheckStringDigit(matchID) {
		common.AddLog(common.LogError, h.Name, m.ID, "match_id: %s not digital", matchID)
		return true
	}

	matches, err := calc.HandicapMatchInfo(pool, []string{matchID})
	if err != nil {
		common.AddLog(common.LogError, h.Name, m.ID, "match_id: %s get match info from cache error :%s", matchID, err.Error())
		return false
	}

	var (
		match calc.MatchData
		ok    bool
	)
	if match, ok = matches[matchID]; !ok {
		common.AddLog(common.LogError, h.Name, m.ID, "match_id: %s not in the cache", matchID)
		return true
	}

	// 如果比赛已隐藏，则跳过
	if match.Visible == 0 {
		common.AddLog(common.LogInfo, h.Name, m.ID, "match[%s] already hidden", matchID)
		return true
	}

	// 如果比赛不在开盘状态 跳过
	if match.Status != MatchStatusOpened {
		common.AddLog(common.LogInfo, h.Name, m.ID, "match[%s] is not in status opened, skip", matchID)
		return true
	}

	// 如果比赛支持滚球 跳过
	if match.LiveSupport == 1 {
		common.AddLog(common.LogInfo, h.Name, m.ID, "match[%s] live_support:%d, skip", matchID, match.LiveSupport)
		return true
	}

	// 如果当前赛事未到开盘时间(冠军盘多加 关闭时间)，不自动隐藏赛事
	// 允许1s的误差，http://dj-jira.mkcp.online:8080/browse/PROD-219
	now := time.Now()
	nowVal := now.Unix() + 1
	bNotAutoHide := match.StartTime > nowVal
	if match.Category == MatchCategoryChampion {
		// 冠军盘 如果当前赛事未到开盘时间(和关盘时间)，不自动隐藏赛事
		bNotAutoHide = match.StartTime > nowVal && match.CloseTime > nowVal
	}
	if bNotAutoHide {
		common.AddLog(common.LogInfo, h.Name, m.ID, "skip match auto hide. match_id:%s, start_time:%d, close_time:%d",
			matchID, match.StartTime, match.CloseTime)
		return true
	}

	record := g.Record{
		"update_by_id":   "0",
		"update_by_name": "【auto】",
		"update_time":    now.Unix(),
		"visible":        0,
	}

	node := calc.MatchBrief{
		ID:          matchID,
		GameID:      match.GameID,
		StartTime:   match.StartTime,
		Status:      match.Status,
		Visible:     0,
		LiveSupport: match.LiveSupport,
		IsPassOff:   match.IsPassOff,
		IsLive:      match.IsLive,
	}

	ex := g.Ex{"id": matchID}
	err = matchUpdate(record, ex, node)
	if err != nil {
		common.AddLog(common.LogError, h.Name, m.ID, err.Error())
		return false
	}

	markets, err := MarketListDB(g.Ex{"match_id": matchID})
	if err != nil {
		common.AddLog(common.LogError, h.Name, m.ID, err.Error())
		return true
	}

	var ids string
	for _, market := range markets {
		ids += market.ID + ","
	}
	err = RedisSendTradeStream(matchID, ids, "1")
	if err != nil {
		common.AddLog(common.LogError, h.Name, m.ID, err.Error())
		return true
	}

	// 更新联赛缓存
	err = gameTourCacheUpdate(match.GameID, match.TournamentID, match.ID, false, match.Category == MatchCategoryChampion)
	if err != nil {
		common.AddLog(common.LogError, h.Name, m.ID, err.Error())
		return true
	}

	// 更新赛事计数
	err = gameNavCountStat(match.GameID)
	if err != nil {
		common.AddLog(common.LogError, h.Name, m.ID, err.Error())
		return true
	}

	err = common.MqttPushMatchVisibleUpdate(cli, []string{matchID}, 0)
	if err != nil {
		common.AddLog(common.LogError, h.Name, m.ID, err.Error())
		return true
	}

	_ = common.XPubMatch(emqxCli, pool, match.GameID, match.TournamentID, match.MatchTeam, match.ID,
		"操盘管理-赛事主页", "赛事显示/隐藏", "自动隐藏")

	return true
}

func gameTourCacheUpdate(gameId, tourId, matchId string, flag, isChamp bool) error {

	pipe := pool.TxPipeline()
	defer pipe.Close()

	if !flag {
		calc.GameTourCacheDel(pipe, gameId, tourId, matchId, isChamp)
	}

	_, err := pipe.Exec()
	if err != nil {
		return err
	}

	tours, err := calc.GameTourCacheGet(pool, gameId, tourId, 0)
	if err != nil {
		return err
	}

	// 获取过滤当前游戏的商户
	filterList := []uint64{}
	filterGameMap, err := calc.GetMerchantFilterGameMap(pool)
	if err != nil {
		return err
	}
	for merchantId, gameSet := range filterGameMap {
		if gameSet.Has(gameId) {
			filterList = append(filterList, merchantId)
		}
	}
	res := map[string]interface{}{
		"game_id":         gameId,
		"tours":           tours,
		"merchant_filter": filterList,
	}
	return calc.MQTTNotify(cli, common.TopicGameTourUpdate, res)
}

func gameNavCountStat(gameId string) error {

	// 从redis中获取所有商户过滤的游戏
	filterGameMap, err := calc.GetMerchantFilterGameMap(pool)
	if err != nil {
		return err
	}

	// 首先统计没有过滤游戏的商户
	dataAll := calc.MatchCountStatData{}
	dataAll.MerchantId = 0
	dataAll.GameId = gameId
	dataAll.Stats, err = calc.GameNavMatchCountStat(pool, gameId)
	if err != nil {
		return err
	}
	dataAll.StatsAll, err = calc.GameNavMatchCountGet(pool, nil, 0)
	if err != nil {
		return err
	}

	var result []calc.MatchCountStatData
	result = append(result, dataAll)

	// 最后统计有游戏过滤的商户
	for merchantID, gameIdSet := range filterGameMap {
		data := calc.MatchCountStatData{}
		data.MerchantId = merchantID
		data.GameId = gameId

		// 判断游戏是否被过滤
		// 如果被过滤，数量都是0
		// 如果没有被过滤，数量和dataAll.Stats一样
		if !gameIdSet.Has(gameId) {
			data.Stats = dataAll.Stats
		}

		// 统计商户总数量
		data.StatsAll, err = calc.GameNavMatchCountGet(pool, nil, merchantID)
		if err != nil {
			return err
		}

		result = append(result, data)
	}

	return calc.MQTTNotify(cli, common.TopicMatchStatUpdate, result)
}

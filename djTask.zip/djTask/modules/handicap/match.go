package handicap

import (
	"database/sql"
	"djTask/calc"
	"fmt"
	g "github.com/doug-martin/goqu/v9"
	_ "github.com/doug-martin/goqu/v9/dialect/mysql"
	"github.com/go-redis/redis/v7"
)

/**
 * @Description: 获取赛事数量
 * @Author: wesley
 * @Date: 2020/6/27 20:36
 * @LastEditTime: 2020/6/27 20:36
 * @LastEditors: wesley
 */
func MatchCounts(ex g.Ex) (int64, error) {

	var count int64
	query, _, _ := g.Dialect("mysql").From("tbl_matches").Select(g.COUNT("id")).Where(ex).ToSQL()
	fmt.Println(query)
	err := db.Get(&count, query)

	return count, err
}

/**
* @Description: 查询一条记录
* @Author:
* @Date: 2020/6/21 5:42 下午
* @LastEditTime: 2020/6/21 5:42 下午
* @LastEditors: brandon
 */
func matchFindOne(ex g.Ex) (MatchData, error) {

	data := MatchData{}
	dialect := g.Dialect("mysql")
	query, _, _ := dialect.From("tbl_matches").Where(ex).Select("id", "game_id", "live_support").Limit(1).ToSQL()
	fmt.Println(query)
	err := db.Get(&data, query)
	if err == sql.ErrNoRows {
		return data, nil
	}

	return data, err
}

/**
* @Description: 更新赛事
* @Author: brandon
* @Date: 2020/6/20 8:27 下午
* @LastEditTime: 2020/6/20 8:27 下午
* @LastEditors: brandon
 */
func matchUpdate(record g.Record, ex g.Ex, node calc.MatchBrief) error {

	pipe := pool.TxPipeline()
	defer pipe.Close()

	tx, err := db.Begin()
	if err != nil {
		return err
	}

	query, _, _ := g.Dialect("mysql").Update("tbl_matches").Set(record).Where(ex).ToSQL()
	_, err = tx.Exec(query)
	if err != nil {
		tx.Rollback()
		return err
	}

	matchCacheUpdate(pipe, record, ex)
	calc.MatchZSetUpdate(pipe, node)
	_, err = pipe.Exec()
	if err != nil {
		tx.Rollback()
		return err
	}

	return tx.Commit()
}

/**
 * @Description: 更新赛事缓存字段
 * @Author: maxic
 * @Date: 2020/8/15
 * @LastEditTime: 2020/8/15
 * @LastEditors: maxic
 **/
func matchCacheUpdate(pipe redis.Pipeliner, record g.Record, ex g.Ex) {

	cacheFields := map[string]bool{
		"is_live":               true,
		"is_pass_off":           true,
		"live_support":          true,
		"match_level":           true,
		"match_team":            true,
		"rec":                   true,
		"score":                 true,
		"start_time":            true,
		"end_time":              true,
		"bet_delay_time":        true,
		"status":                true,
		"suspended":             true,
		"team_id":               true,
		"tournament_id":         true,
		"tournament_short_name": true,
		"user_video_url":        true,
		"visible":               true,
	}

	fn := func(id string) {
		for k, v := range record {
			if cacheFields[k] {
				path := fmt.Sprintf(calc.JPathMatchField, k)
				calc.MatchCacheSet(pipe, id, path, v, true)
			}
		}
	}
	if id, ok := ex["id"]; ok {
		switch id.(type) {
		case string:
			fn(id.(string))
		case []string:
			for _, v := range id.([]string) {
				fn(v)
			}
		}
	}
}

package handicap

const (
	MatchStatusEntered    = 1 // 已录入
	MatchStatusPending    = 2 // 待审核
	MatchStatusReject     = 3 // 驳回
	MatchStatusWaitOpen   = 4 // 待开盘
	MatchStatusOpened     = 5 // 开盘
	MatchStatusClosed     = 6 // 关盘
	MatchStatusSettle     = 7 // 结算
	MatchStatusWaitCancel = 8 // 待取消
	MatchStatusCancel     = 9 // 取消
)

// 赛事类型 正常-1 冠军-2 大逃杀-3 篮球-4 主播盘-5 足球-6
const (
	MatchCategoryNormal     = 1
	MatchCategoryChampion   = 2
	MatchCategoryEscape     = 3
	MatchCategoryBasketball = 4
	MatchCategoryAnchor     = 5
	MatchCategoryFootball   = 6
)

const (
	redisStreamTrade = "trade"
)

// Match 赛事结构体
type MatchData struct {
	ID          string `json:"id" db:"id" rule:"none" name:"id"`
	GameID      string `json:"game_id" db:"game_id" rule:"digit" min:"1" msg:"game_id error" name:"game_id"`
	LiveSupport int    `json:"live_support" db:"live_support" rule:"none" name:"live_support"`
}

// 盘口列表数据
type MarketData struct {
	ID string `json:"id" db:"id"`
}

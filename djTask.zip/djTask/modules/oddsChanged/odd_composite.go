package oddsChanged

import (
	"database/sql"
	"djTask/modules/common"
	"fmt"
	g "github.com/doug-martin/goqu/v9"
	"github.com/shopspring/decimal"
)

func OddCompositeSubCompIDFindAll(ex g.Ex) ([]string, error) {

	var compIDs []string
	query, _, _ := common.Dialect.From("tbl_odd_composite_sub").Select(g.DISTINCT("odd_composite_id")).Where(ex).ToSQL()
	err := db.Select(&compIDs, query)
	if err != nil {
		return compIDs, err
	}

	return compIDs, nil
}

/**
* @Description: 查询赛事等级复合玩法返还率(改造提醒：赛事中新增字段，避免每次查数据库)
* @Author:awen
* @Date: 2021/08/21 6:15 下午
* @LastEditTime:  2021/08/21 6:15 下午
* @LastEditors: awen
 */
func mixIddDscntFind(ex g.Ex) (decimal.Decimal, error) {

	var mixIddDscnt float64
	query, _, _ := common.Dialect.Select("mix_odd_dscnt").From("tbl_match_level").Where(ex).Limit(1).ToSQL()
	fmt.Println(query)
	err := db.Get(&mixIddDscnt, query)
	if err != nil {
		return decimal.Zero, err
	}

	if err == sql.ErrNoRows {
		return common.OneDeci, nil
	}

	return decimal.NewFromFloat(mixIddDscnt).Div(common.HundredDeci), err
}
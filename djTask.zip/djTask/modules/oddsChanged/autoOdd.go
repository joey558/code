package oddsChanged

import (
	"djTask/calc"
	"djTask/contrib/validator"
	"djTask/helper"
	"djTask/modules/common"
	"errors"
	"fmt"
	g "github.com/doug-martin/goqu/v9"
	"github.com/go-redis/redis/v7"
	"github.com/shopspring/decimal"
	"math"
	"sort"
	"strconv"
	"strings"
	"time"
)

// 自动变赔参数
type AutoOddArg struct {
	Coefficient           decimal.Decimal // 变赔系数
	Step                  decimal.Decimal // 变赔幅度
	PrizeDiff             decimal.Decimal // 赔付差异值
	JumpTimes             int64           // 跳盘倍数
	UnilateralCoefficient decimal.Decimal // 单边变赔系数
	UnilateralStep        decimal.Decimal // 单边变赔幅度
}

// 盘口限红参数
type MarketArg struct {
	AutoOddEnabled int64           `db:"auto_odd"`    // 是否启用自动变赔
	ReturnRate     decimal.Decimal `db:"return_rate"` // 返还率
	PrizeLimit     int64           `db:"prize_limit"` // 单注限红
	StopValue      int64           // 停盘值	TODO 二期做
}

// 赔率选项统计
type OddStat struct {
	MarketID string          // 盘口id
	OddId    string          `db:"id"`  // 赔率选项id
	Odds     decimal.Decimal `db:"odd"` // 赔率
	PreOdd   string          // 变赔前的赔率
	WinRate  decimal.Decimal // 胜率
	Profit   decimal.Decimal // 理论盈亏（假设某选项获胜时平台的理论盈亏）
	Name     string          `db:"name"` //选项中文名称
}

type MatchTeams struct {
	TeamID     string `json:"team_id"`
	TeamEnName string `json:"team_en_name"`
	TeamCnName string `json:"team_cn_name"`
	SortID     int    `json:"sort_id" `
}

func handle(b *common.BeansHandler, m common.BeansMessage) bool {

	h := AutoOddTask{}
	if !h.Parse(b, m) {
		return true
	}

	ch, ok := tasks.Load(h.marketId)
	if !ok {
		ch = make(chan AutoOddTask)
		tasks.Store(h.marketId, ch)
	}
	ch.(chan AutoOddTask) <- h

	return true
}

type AutoOddTask struct {
	id           string
	name         string
	matchId      string
	marketId     string
	oddId        string
	betAmount    decimal.Decimal
	isDefault    int
	isUnilateral int
}

func (h *AutoOddTask) Parse(b *common.BeansHandler, m common.BeansMessage) bool {
	h.name = b.Name
	h.id = m.ID

	// 参数校验 match_id=136228385694995&market_id=136338517783690&odd_id=136338518027839&bet_amount=10
	common.AddLog(common.LogInfo, h.name, h.id, "=== order: %+v ===", m)

	// 测试账号不变赔
	tester := m.Msg.Get("tester")
	if tester != "0" {
		common.AddLog(common.LogInfo, h.name, h.id, "skip auto odd: tester[%s]", tester)
		return false
	}
	matchId := m.Msg.Get("match_id")
	if !validator.CheckStringDigit(matchId) {
		common.AddLog(common.LogError, h.name, h.id, "match id error")
		return false
	}
	marketId := m.Msg.Get("market_id")
	if !validator.CheckStringDigit(marketId) {
		common.AddLog(common.LogError, h.name, h.id, "market id error")
		return false
	}
	oddId := m.Msg.Get("odd_id")
	if !validator.CheckStringDigit(oddId) {
		common.AddLog(common.LogError, h.name, h.id, "odd id error")
		return false
	}
	isDefault := m.Msg.Get("is_default")
	if !validator.CheckStringDigit(isDefault) {
		common.AddLog(common.LogError, h.name, h.id, "isDefault error")
		return false
	}
	isDefaultMarket, _ := strconv.Atoi(isDefault)

	betAmount := m.Msg.Get("bet_amount")
	fbetAmount, err := decimal.NewFromString(betAmount)
	if err != nil {
		common.AddLog(common.LogError, h.name, h.id, "bet amount error")
		return false
	}

	optionType := m.Msg.Get("option_type")
	if !validator.CheckStringDigit(optionType) {
		common.AddLog(common.LogError, h.name, h.id, "option type error")
		return false
	}
	iOptionType, _ := strconv.Atoi(optionType)

	h.matchId = matchId
	h.marketId = marketId
	h.oddId = oddId
	h.betAmount = fbetAmount
	h.isDefault = isDefaultMarket
	// 玩法类型为猜冠军（单项结算）或 猜冠军（多项结算） 是为单边变赔
	if iOptionType == common.OptionTypeSingleChampion || iOptionType == common.OptionTypeMultipleChampion {
		h.isUnilateral = 1
	}

	return true
}

/**
 * @Description: 自动变赔处理
 * @Author: maxic
 * @Date: 2020/8/2
 * @LastEditTime: 2020/8/2
 * @LastEditors: maxic
 **/
func (h *AutoOddTask) Handle() bool {

	s := time.Now()
	defer func() {
		common.AddLog(common.LogInfo, h.name, h.id, "cost: %v", time.Since(s))
	}()

	// 获取变赔参数
	args, err := h.getAutoOddArg()
	if err != nil {
		common.AddLog(common.LogError, h.name, h.id, "get auto odd args fail: %s", err.Error())
		return true
	}
	common.AddLog(common.LogInfo, h.name, h.id, "args: %+v", args)

	// 获取赔率项累计赔付额
	accumulation, err := h.getAccumulation(h.oddId)
	if err != nil {
		common.AddLog(common.LogError, h.name, h.id, "get accumulation fail: %s, oddId: %s", err.Error(), h.oddId)
		return true
	}
	common.AddLog(common.LogInfo, h.name, h.id, "accumulation: %+v", accumulation)

	// 获取盘口单注限红，返还率
	mktArgs, err := h.getMarketArg(h.marketId)
	if err != nil {
		common.AddLog(common.LogError, h.name, h.id, "get market risk args fail: %s", err.Error())
		return true
	}
	if mktArgs.AutoOddEnabled == 0 {
		common.AddLog(common.LogInfo, h.name, h.id, "market[%s] auto odd is disabled", h.marketId)
		return true
	}
	common.AddLog(common.LogInfo, h.name, h.id, "mktArgs: %+v", mktArgs)

	// 获取各赔率项累计理论盈亏
	oddStats, err := h.getOddStats()
	if err != nil {
		common.AddLog(common.LogError, h.name, h.id, "get profit stat fail: %s", err.Error())
		return true
	}

	for i, val := range oddStats {
		oddStats[i].MarketID = h.marketId
		oddStats[i].PreOdd = val.Odds.StringFixed(3)
	}

	var curOdd *OddStat
	for i := range oddStats {
		// 计算各选项的胜率
		if h.isUnilateral != 1 {
			// 原胜率 = 盘口返还率/赔率
			oddStats[i].WinRate = mktArgs.ReturnRate.Div(oddStats[i].Odds)
		}
		if oddStats[i].OddId == h.oddId {
			curOdd = &oddStats[i]
		}
	}

	if curOdd == nil {
		common.AddLog(common.LogError, h.name, h.id, "data error")
		return true
	}
	common.AddLog(common.LogInfo, h.name, h.id, "oddStats: %+v", oddStats)

	// 累计赔付额
	// TODO 执行变赔逻辑时时，已有注单情况下，如何统计累计赔付额？（场景：最初未开启自动变赔，后面又开启了；或者程序中断再恢复）
	//if accumulation.IsZero() {
	//	accumulation = curOdd.Profit.Neg() // 累计赔付额=平台盈利取反
	//}
	payment := curOdd.Odds.Sub(common.OneDeci).Mul(h.betAmount) // 本次赔付额 = (赔率-1)*投注额
	accumulation = accumulation.Add(payment)

	// 变赔阀值 = 变赔系数*盘口当前限红
	var threshold decimal.Decimal
	if h.isUnilateral == 1 {
		threshold = args.UnilateralCoefficient.Mul(decimal.NewFromInt(mktArgs.PrizeLimit))
	} else {
		threshold = args.Coefficient.Mul(decimal.NewFromInt(mktArgs.PrizeLimit))
	}

	common.AddLog(common.LogInfo, h.name, h.id, "payment: %v, accumulation: %v|%v", payment, accumulation, threshold)

	// 累计赔付额 > 变赔系数*盘口当前限红(变赔阀值)，才开始变赔
	if accumulation.LessThanOrEqual(threshold) {
		common.AddLog(common.LogInfo, h.name, h.id, "skip auto odd")

		// 更新累计赔付额
		err = h.setAccumulation(map[string]interface{}{
			h.oddId: accumulation.StringFixed(3),
		})
		if err != nil {
			common.AddLog(common.LogError, h.name, h.id, "set accumulation fail: %s", err.Error())
		}

		return true
	}

	// 单边变赔与投注项胜率无关,变赔变赔不影响其他投注项的赔率
	if h.isUnilateral == 1 {

		// 变赔次数 = int(累计赔付额/(变赔系数*盘口当前限红))
		count := accumulation.Div(args.UnilateralCoefficient.Mul(decimal.NewFromInt(mktArgs.PrizeLimit))).IntPart()
		// 累计赔付额 = 累计赔付额 -  变赔次数*变赔系数*盘口当前限红(变赔阀值)
		accumulation = accumulation.Sub(decimal.NewFromInt(count).Mul(threshold))
		// 新赔率 = 投注项原赔率 * ( 1 - 变赔幅度 ) ^ 变赔次数
		for i := 0; i < int(count); i++ {
			curOdd.Odds = curOdd.Odds.Mul(common.OneDeci.Sub(args.UnilateralStep))
		}

		common.AddLog(common.LogInfo, h.name, h.id, "count:%d,  accumulation:%s, curOdd.Odds:%s",
			count, accumulation.String(), curOdd.Odds.String())
	} else {
		// 计算盈亏差值
		maxProfit := decimal.Zero
		minProfit := decimal.NewFromFloat(math.MaxFloat64)
		for _, profit := range oddStats {
			if profit.Profit.GreaterThan(maxProfit) {
				maxProfit = profit.Profit
			}
			if profit.Profit.LessThan(minProfit) {
				minProfit = profit.Profit
			}
		}
		delta := maxProfit.Sub(minProfit)
		diffLine := args.PrizeDiff.Mul(decimal.NewFromInt(mktArgs.PrizeLimit))
		common.AddLog(common.LogInfo, h.name, h.id, "maxProfit: %+v. minProfit: %+v, delta: %v, diffLine: %v", maxProfit, minProfit, delta, diffLine)

		// 胜率变化幅度
		var winRateStep decimal.Decimal
		if delta.LessThan(diffLine) {
			// 盈亏差值 < 赔付差异值*盘口当前限红， 胜率变化幅度=基础幅度
			winRateStep = args.Step
		} else {
			// 盈亏差值 >= 赔付差异值*盘口当前限红， 胜率变化幅度=基础幅度*跳盘倍数
			winRateStep = args.Step.Mul(decimal.NewFromInt(args.JumpTimes))
		}

		common.AddLog(common.LogInfo, h.name, h.id, "winRateStep: %+v", winRateStep)

		// 变赔次数 = int(累计赔付额/(变赔系数*盘口当前限红))
		count := accumulation.Div(args.Coefficient.Mul(decimal.NewFromInt(mktArgs.PrizeLimit))).IntPart()
		// 胜率差异 = 变赔次数*胜率变化幅度
		winRateDelta := decimal.NewFromInt(count).Mul(winRateStep)
		// 新胜率 = 原胜率 + 胜率差异
		curOdd.WinRate = curOdd.WinRate.Add(winRateDelta)
		// 累计赔付额 = 累计赔付额 -  变赔次数*变赔系数*盘口当前限红(变赔阀值)
		accumulation = accumulation.Sub(decimal.NewFromInt(count).Mul(threshold))
		// 新赔率 = 返还率/新胜率
		curOdd.Odds = mktArgs.ReturnRate.Div(curOdd.WinRate)

		common.AddLog(common.LogInfo, h.name, h.id, "count:%v, winRateDelta:%v, curOdd.WinRate:%v, accumulation:%v, curOdd.Odds:%v",
			count, winRateDelta, curOdd.WinRate, accumulation, curOdd.Odds)

		// 计算其他选项的新赔率
		sumWinRate := decimal.Zero
		for _, odd := range oddStats {
			if odd.OddId == h.oddId {
				continue
			}
			sumWinRate = sumWinRate.Add(odd.WinRate)
		}
		for i := range oddStats {
			if oddStats[i].OddId == h.oddId {
				continue
			}
			// 其他选项新胜率 = 其他选项新胜率 - 胜率差异*胜率占比
			oddStats[i].WinRate = oddStats[i].WinRate.Sub(winRateDelta.Mul(oddStats[i].WinRate.Div(sumWinRate)))
			// 新赔率 = 返还率/新胜率
			oddStats[i].Odds = mktArgs.ReturnRate.Div(oddStats[i].WinRate)
		}
		common.AddLog(common.LogInfo, h.name, h.id, "oddStats: %+v", oddStats)
	}

	// 停止变赔条件：
	// 1.操盘手关闭自动变赔（前端开关）；
	// 2.操盘手将某个投注项隐藏；（重新开启自动变赔后需要根据未隐藏的投注项变赔）（前端开关）
	// 3.变赔后有投注项赔率小于赔率下限或大于赔率上限；（下限为1.001，上限为23）
	// 4.盘口任意选项浮动盈亏的亏损金额超过停盘值；
	stop := false // 是否停止变赔
	stopMsg := "" // 停止原因
	for _, odd := range oddStats {
		if h.isUnilateral == 1 && odd.OddId != h.oddId {
			continue
		}

		if h.isUnilateral == 1 {
			if odd.Odds.LessThan(decimal.NewFromFloat(1.001)) || odd.Odds.GreaterThan(decimal.NewFromFloat(9999.999)) {
				stop = true
				stopMsg = fmt.Sprintf("赔率超出赔率上限或下限[1.001, 9999.999]")
				common.AddLog(common.LogInfo, h.name, h.id, "stop auto odd. %+v odds out of range [1.001, 9999.999]", odd)
				break
			}
		} else {
			if odd.Odds.LessThan(decimal.NewFromFloat(1.001)) || odd.Odds.GreaterThan(decimal.NewFromInt(23)) {
				stop = true
				stopMsg = fmt.Sprintf("赔率超出赔率上限或下限[1.001, 23]")
				common.AddLog(common.LogInfo, h.name, h.id, "stop auto odd. %+v odds out of range [1.001, 23]", odd)
				break
			}
		}

		if mktArgs.StopValue > 0 && odd.Profit.Neg().GreaterThan(decimal.NewFromInt(mktArgs.StopValue)) {
			stop = true
			stopMsg = fmt.Sprintf("浮动盈亏超过停盘值")
			common.AddLog(common.LogInfo, h.name, h.id, "stop auto odd. %+v reached stop value: %+v", odd, mktArgs.StopValue)
			break
		}
	}

	// 停止变赔
	// 1.自动变赔停止后，需要将累计赔付额清零；
	// 2.自动变赔停止后，将前端页面自动变赔的开关改为“停用”；
	if stop {
		// 累计赔付额清零
		accumulations := map[string]interface{}{}
		for _, odd := range oddStats {
			accumulations[odd.OddId] = "0"
		}
		err = h.setAccumulation(accumulations)
		if err != nil {
			common.AddLog(common.LogError, h.name, h.id, "reset accumulation fail: %s", err.Error())
		}
		// 关闭盘口自动变赔开关
		err = h.disableMarketArg(h.marketId)
		if err != nil {
			common.AddLog(common.LogError, h.name, h.id, "disable market arg fail: %s", err.Error())
		}
		// 发送MQTT通知给前端
		err = common.MqttPushAutoOddStop(cli, h.matchId, h.marketId, stopMsg)
		if err != nil {
			common.AddLog(common.LogError, h.name, h.id, "push mqtt auto odd stop fail: %s", err.Error())
		}

		return true
	}

	//获取盘口信息
	data, err := calc.HandicapInfo(traderRedis, []string{h.matchId})
	if err != nil {
		common.AddLog(common.LogError, h.name, h.id, "get match match from redis error: %s", err.Error())
		return true
	}
	match, ok := data.Matches[h.matchId]
	if !ok {
		common.AddLog(common.LogError, h.name, h.id, "match not found in handicap cache")
		return true
	}
	market, ok := data.Markets[h.marketId]
	if !ok {
		common.AddLog(common.LogError, h.name, h.id, "market not found in handicap cache")
		return true
	}

	if market.OptionType == common.OptionTypeWinLose && market.Round > 0 {

		// 设置复合玩法子盘口变赔后的新赔率
		mpNewOddStat := map[string]string{}
		for _, v := range oddStats {
			mpNewOddStat[v.OddId] = v.Odds.StringFixed(3)
		}
		mpMktOdd := map[string][]calc.OddData{}
		for _, odd := range data.Odds {
			if _, ok = mpNewOddStat[odd.ID]; ok {
				odd.Odd = mpNewOddStat[odd.ID]
				data.Odds[odd.ID] = odd
			}
			if mkt, ok := data.Markets[odd.MarketID]; ok && mkt.OptionType == common.OptionTypeMix && mkt.Round == market.Round {
				mpMktOdd[odd.MarketID] = append(mpMktOdd[odd.MarketID], odd)
			}
		}

		if len(mpMktOdd) >= 0 {
			mixIddDscnt, err := mixIddDscntFind(g.Ex{"level": match.MatchLevel})
			if err != nil {
				common.AddLog(common.LogError, h.name, h.id, "get mix idd discount fail: %s", err.Error())
				return true
			}

			for k, v := range data.Markets {
				// 排除非当前局数的复合玩法的盘口
				if _, ok = mpMktOdd[k]; !ok {
					continue
				}

				mixMktFlag := 0
				subMktIds := strings.Split(v.SubMktID, ",")
				for _, mktId := range subMktIds {
					if mktId == market.ID {
						mixMktFlag = 1
						break
					}
				}

				if mixMktFlag == 0 {
					continue
				}

				subOddIds := strings.Split(v.SubOddID, ",")
				mpMktSubOdds := map[string][]calc.OddData{}
				for _, oddIdStr := range subOddIds {
					oddIds := strings.Split(oddIdStr, "|")
					if len(oddIds) == 0 {
						continue
					}
					for _, oddId := range oddIds {
						for _, mktId := range subMktIds {
							if data.Odds[oddId].MarketID == mktId {
								mpMktSubOdds[mktId] = append(mpMktSubOdds[mktId], data.Odds[oddId])
							}
						}
					}
				}

				// 计算复合盘口赔率
				T1OddVal, T2OddVal := common.OneDeci, common.OneDeci
				for _, mktSubOdds := range mpMktSubOdds {
					// 排序
					sort.Slice(mktSubOdds, func(i, j int) bool {
						return mktSubOdds[j].SortID > mktSubOdds[i].SortID
					})
					o1, _ := decimal.NewFromString(mktSubOdds[0].Odd)
					o2, _ := decimal.NewFromString(mktSubOdds[1].Odd)
					T1OddVal = T1OddVal.Mul(o1.Sub(common.OneDeci).Mul(mixIddDscnt).Add(common.OneDeci))
					T2OddVal = T2OddVal.Mul(o2.Sub(common.OneDeci).Mul(mixIddDscnt).Add(common.OneDeci))
				}

				mixMktOdds := mpMktOdd[k]
				// 排序
				sort.Slice(mixMktOdds, func(i, j int) bool {
					return mixMktOdds[j].SortID > mixMktOdds[i].SortID
				})

				oddStats = append(oddStats, OddStat{
					MarketID: k,
					OddId:    mixMktOdds[0].ID,
					PreOdd:   mixMktOdds[0].Odd,
					Odds:     T1OddVal,
					Name:     mixMktOdds[0].Name,
				})
				oddStats = append(oddStats, OddStat{
					MarketID: k,
					OddId:    mixMktOdds[1].ID,
					PreOdd:   mixMktOdds[1].Odd,
					Odds:     T2OddVal,
					Name:     mixMktOdds[1].Name,
				})
			}
		}
	}

	// 更新赔率
	err = h.setOdds(h.matchId, h.marketId, h.isDefault, oddStats)
	if err != nil {
		common.AddLog(common.LogError, h.name, h.id, "set odd fail: %s", err.Error())
		return true
	}

	// 更新累计赔付额
	err = h.setAccumulation(map[string]interface{}{
		h.oddId: accumulation.StringFixed(3),
	})
	if err != nil {
		common.AddLog(common.LogError, h.name, h.id, "set accumulation fail: %s", err.Error())
		return true
	}

	var tmNames []string
	if match.Category == calc.MatchCategoryChampion {
		matchTeams, err := MatchChampTeamsGet(match.ID)
		if err != nil {
			common.AddLog(common.LogError, h.name, h.id, "mchChampTeam not found in mchChampTeam cache")
			return true
		}

		for _, team := range matchTeams {
			tmNames = append(tmNames, team.TeamCnName)
		}
	} else {
		tmNames = strings.Split(match.MatchCnTeam, ",")
	}

	// 发送MQTT推送
	msg := ""
	var notifies []common.OddUpdateNotify
	for i, odd := range oddStats {
		notifies = append(notifies, common.OddUpdateNotify{
			MarketId:   odd.MarketID,
			MatchId:    h.matchId,
			ID:         odd.OddId,
			Odd:        odd.Odds.StringFixed(3),
			ReturnRate: mktArgs.ReturnRate.StringFixed(1),
		})

		oddName := odd.Name
		if strings.Contains(odd.Name, "@T") {
			if len(tmNames) >= 2 {
				if strings.Contains(odd.Name, "@T1") {
					oddName = strings.ReplaceAll(odd.Name, "@T1", tmNames[0])
				} else if strings.Contains(odd.Name, "@T2") {
					oddName = strings.ReplaceAll(odd.Name, "@T2", tmNames[1])
				} else {
					s := strings.ReplaceAll(odd.Name, "@T", "")
					j, _ := strconv.Atoi(s)
					if j >= 1 && j-1 < len(tmNames) {
						oddName = tmNames[j-1]
					}
				}
			}
		}
		msg += fmt.Sprintf("【选项名称】:%v 【赔率】:%s -> %s\n", oddName, oddStats[i].PreOdd, odd.Odds.StringFixed(3))
	}
	err = common.MqttPushOddUpdate(cli, notifies)
	if err != nil {
		common.AddLog(common.LogError, h.name, h.id, "push mqtt fail: %s", err.Error())
		return true
	}

	_ = common.XPubMarket(emqxCli, traderRedis, match.GameID, match.TournamentID, match.MatchTeam, match.ID, market.ID,
		market.CnName, int16(market.Round), "赛事管理-赛事主页", "自动变赔",
		fmt.Sprintf("%s 【返还率】:%s", msg, mktArgs.ReturnRate.StringFixed(1)), int8(match.Category))
	return true
}

/**
 * @Description: 获取变赔参数
 * @Author: maxic
 * @Date: 2020/8/3
 * @LastEditTime: 2020/8/3
 * @LastEditors: maxic
 **/
func (h *AutoOddTask) getAutoOddArg() (AutoOddArg, error) {

	var args AutoOddArg

	key := "setting"
	fields := []string{
		"odd_update_coefficient",            // 变赔系数
		"odd_update_step",                   // 变赔幅度
		"odd_prize_diff",                    // 赔付差异值
		"odd_mkt_multi",                     // 跳盘倍数
		"unilateral_odd_update_coefficient", // 单边变赔系数
		"unilateral_odd_update_step",        // 单边变赔幅度
	}
	data, err := common.RedisHMGet(traderRedis, key, fields)
	if err != nil {
		return args, err
	}

	for k, v := range data {
		switch k {
		case "odd_update_coefficient":
			args.Coefficient, _ = decimal.NewFromString(v)
		case "odd_update_step":
			args.Step, _ = decimal.NewFromString(v)
		case "odd_prize_diff":
			args.PrizeDiff, _ = decimal.NewFromString(v)
		case "odd_mkt_multi":
			args.JumpTimes, _ = strconv.ParseInt(v, 10, 64)
		case "unilateral_odd_update_coefficient":
			args.UnilateralCoefficient, _ = decimal.NewFromString(v)
		case "unilateral_odd_update_step":
			args.UnilateralStep, _ = decimal.NewFromString(v)
		}
	}
	args.UnilateralStep = args.UnilateralStep.Div(decimal.NewFromInt(100))
	return args, nil
}

/**
 * @Description: 获取盘口风控参数
 * @Author: maxic
 * @Date: 2020/8/2
 * @LastEditTime: 2020/8/2
 * @LastEditors: maxic
 **/
func (h *AutoOddTask) getMarketArg(marketId string) (MarketArg, error) {

	var data MarketArg
	dialect := g.Dialect("mysql")
	ex := g.Ex{"id": marketId}
	query, _, _ := dialect.Select("auto_odd", "return_rate", "prize_limit").From("tbl_markets").Where(ex).Limit(1).ToSQL()
	common.AddLog(common.LogInfo, h.name, h.id, query)
	err := db.Get(&data, query)
	return data, err
}

/**
 * @Description: 更新盘口
 * @Author: maxic
 * @Date: 2020/8/6
 * @LastEditTime: 2020/8/6
 * @LastEditors: maxic
 **/
func (h *AutoOddTask) disableMarketArg(marketId string) error {

	record := g.Record{"auto_odd": 0}
	ex := g.Ex{"id": marketId}
	query, _, _ := g.Dialect("mysql").Update("tbl_markets").Set(record).Where(ex).ToSQL()
	common.AddLog(common.LogInfo, h.name, h.id, query)

	_, err := db.Exec(query)
	return err
}

/**
 * @Description: 获取赔率项累计赔付额
 * @Author: maxic
 * @Date: 2020/8/3
 * @LastEditTime: 2020/8/3
 * @LastEditors: maxic
 **/
func (h *AutoOddTask) getAccumulation(oddId string) (decimal.Decimal, error) {

	var accumulation decimal.Decimal
	data, err := traderRedis.HGet(common.RedisKeyOddAccumulation, oddId).Result()
	if err != nil && err != redis.Nil {
		return accumulation, err
	}
	accumulation, _ = decimal.NewFromString(data)
	return accumulation, nil
}

/**
 * @Description: 设置赔率项累计赔付额
 * @Author: maxic
 * @Date: 2020/8/3
 * @LastEditTime: 2020/8/3
 * @LastEditors: maxic
 **/
func (h *AutoOddTask) setAccumulation(accumulations map[string]interface{}) error {
	return traderRedis.HMSet(common.RedisKeyOddAccumulation, accumulations).Err()
}

/**
 * @Description: 获取指定某一盘口某一赔率选项获胜时，该盘口下所有选项的理论盈亏
 * @Author: maxic
 * @Date: 2020/8/2
 * @LastEditTime: 2020/8/2
 * @LastEditors: maxic
 **/
func (h *AutoOddTask) getOddStats() ([]OddStat, error) {

	var (
		data []OddStat
		ex   g.Ex
	)

	dialect := g.Dialect("mysql")
	//if h.isUnilateral == 1 {
	//	// 获取单个赔率选项（id，赔率）
	//	ex = g.Ex{
	//		"id":      h.oddId,
	//		"visible": 1,
	//	}
	//} else {
	//	// 获取盘口下所有赔率选项（id，赔率）
	//	ex = g.Ex{
	//		"market_id": h.marketId,
	//		"visible":   1,
	//	}
	//}
	// 获取盘口下所有赔率选项（id，赔率）
	ex = g.Ex{
		"market_id": h.marketId,
		"visible":   1,
	}
	query, _, _ := dialect.Select("id", "odd", "name").From("tbl_odds").Where(ex).ToSQL()
	common.AddLog(common.LogInfo, h.name, h.id, query)
	err := db.Select(&data, query)
	if err != nil {
		return data, err
	}

	marketStat, err := calc.MarketProfitCalc(traderRedis, h.matchId, h.marketId)
	if err != nil {
		return data, err
	}

	fnFind := func(odds []OddStat, id string) *OddStat {
		for i := range odds {
			odd := &odds[i]
			if odd.OddId == id {
				return odd
			}
		}
		return nil
	}

	for id, oddStat := range marketStat.Odds {
		if ref := fnFind(data, id); ref != nil {
			ref.Profit = decimal.NewFromFloat(marketStat.RealityBetAmount - oddStat.RealityTheoryPrize)
		}
	}

	return data, nil
}

/**
 * @Description: 设置赔率
 * @Author: maxic
 * @Date: 2020/8/3
 * @LastEditTime: 2020/8/3
 * @LastEditors: maxic
 **/
func (h *AutoOddTask) setOdds(matchId, marketId string, isDefault int, oddStats []OddStat) error {

	var (
		record  g.Record
		ex      g.Ex
		path    string
		mktRate int
		err     error
	)
	pipe := traderRedis.TxPipeline()
	defer pipe.Close()

	tx, err := db.Begin()
	if err != nil {
		return err
	}

	dialect := g.Dialect("mysql")

	totalOddsRate := decimal.NewFromInt(0)
	for _, odd := range oddStats {
		if h.isUnilateral == 1 {
			totalOddsRate = totalOddsRate.Add(common.OneDeci.Div(odd.Odds))
			if odd.OddId != h.oddId {
				continue
			}
		}
		record = g.Record{"odd": odd.Odds.StringFixed(3)}
		ex = g.Ex{"id": odd.OddId}
		query, _, _ := dialect.Update("tbl_odds").Set(record).Where(ex).ToSQL()
		common.AddLog(common.LogInfo, h.name, h.id, query)
		_, err = tx.Exec(query)
		if err != nil {
			_ = tx.Rollback()
			return err
		}

		if odd.MarketID != "" {
			marketId = odd.MarketID
		}
		path = fmt.Sprintf(calc.JPathOddField, marketId, odd.OddId, "odd")
		calc.MatchCacheSet(pipe, matchId, path, odd.Odds.StringFixed(3), isDefault == 1)
	}

	// 单边变赔后更新盘口返回率
	if h.isUnilateral == 1 {
		if totalOddsRate.IsZero() {
			_ = tx.Rollback()
			return errors.New("totalOddsRate is zero")
		}

		mktRate, err = strconv.Atoi(common.OneDeci.Div(totalOddsRate).Mul(decimal.NewFromInt(100)).StringFixed(0))
		if err != nil {
			_ = tx.Rollback()
			return err
		}

		record = g.Record{"return_rate": mktRate}
		ex = g.Ex{"id": h.marketId}
		query, _, _ := dialect.Update("tbl_markets").Set(record).Where(ex).ToSQL()
		common.AddLog(common.LogInfo, h.name, h.id, query)
		_, err = tx.Exec(query)
		if err != nil {
			_ = tx.Rollback()
			return err
		}

		path = fmt.Sprintf(calc.JPathMarketField, marketId, "return_rate")
		calc.MatchCacheSet(pipe, matchId, path, mktRate, isDefault == 1)
	}

	_, err = pipe.Exec()
	if err != nil {
		_ = tx.Rollback()
		return err
	}

	return tx.Commit()
}

/*
* @Description: 获取冠军赛事战队列表
* @Author: jinxi
* @Date: 2021/7/14 13:21
* @LastEditTime: 2021/7/14 13:21
* @LastEditors: jinxi
 */
func MatchChampTeamsGet(matchID string) ([]MatchTeams, error) {

	var data []MatchTeams
	key := fmt.Sprintf(common.RedisMatchChampTeam, matchID)
	result, err := traderRedis.SMembers(key).Result()
	if err != nil {
		return data, err
	}

	for _, res := range result {
		team := MatchTeams{}
		err = helper.JsonUnmarshal([]byte(res), &team)
		if err != nil {
			return data, err
		}

		data = append(data, team)
	}

	// 排序
	sort.Slice(data, func(i, j int) bool {
		return data[j].SortID > data[i].SortID
	})

	return data, nil
}

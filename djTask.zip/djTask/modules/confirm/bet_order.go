package confirm

import (
	"djTask/calc"
	"djTask/contrib/validator"
	"djTask/modules/common"
	"strconv"
	"time"

	g "github.com/doug-martin/goqu/v9"
	_ "github.com/doug-martin/goqu/v9/dialect/mysql"
)

func betOrderConfirm(h *common.BeansHandler, msg common.BeansMessage) bool {

	memberID := msg.Msg.Get("uid")
	if !validator.CheckStringDigit(memberID) {
		common.AddLog(common.LogError, h.Name, msg.ID, "member_id:%s error, finished", memberID)
		return true
	}
	uid, err := strconv.ParseUint(memberID, 10, 64)
	if err != nil {
		common.AddLog(common.LogError, h.Name, msg.ID, "member_id:%s error: %s, finished", memberID, err.Error())
		return true
	}

	matchID := msg.Msg.Get("match_id")
	if !validator.CheckStringDigit(matchID) {
		common.AddLog(common.LogError, h.Name, msg.ID, "match_id:%s error, finished", matchID)
		return true
	}
	marketID := msg.Msg.Get("market_id")
	if !validator.CheckStringDigit(marketID) {
		common.AddLog(common.LogError, h.Name, msg.ID, "market_id:%s error, finished", marketID)
		return true
	}
	betOrderID := msg.Msg.Get("order_id")
	if !validator.CheckStringDigit(betOrderID) {
		common.AddLog(common.LogError, h.Name, msg.ID, "order_id:%s error, finished", betOrderID)
		return true
	}
	orderId, err := strconv.ParseUint(betOrderID, 10, 64)
	if err != nil {
		common.AddLog(common.LogError, h.Name, msg.ID, "order_id:%s error: %s, finished", betOrderID, err.Error())
		return true
	}

	oddID := msg.Msg.Get("odd_id")
	if !validator.CheckStringDigit(marketID) {
		common.AddLog(common.LogError, h.Name, msg.ID, "odd_id:%s error, finished", oddID)
		return true
	}
	betAmount := msg.Msg.Get("bet_amount")
	if _, err := strconv.ParseFloat(betAmount, 64); err != nil {
		common.AddLog(common.LogError, h.Name, msg.ID, "bet_amount:%s error, finished", betAmount)
		return true
	}
	theoryPrize := msg.Msg.Get("theory_prize")
	if _, err := strconv.ParseFloat(theoryPrize, 64); err != nil {
		common.AddLog(common.LogError, h.Name, msg.ID, "theory_prize:%s error, finished", theoryPrize)
		return true
	}
	tester := msg.Msg.Get("tester")
	if _, err := strconv.ParseUint(tester, 10, 8); err != nil {
		common.AddLog(common.LogError, h.Name, msg.ID, "tester:%s error, finished", tester)
		return true
	}
	odd := msg.Msg.Get("odd")
	if _, err := strconv.ParseFloat(odd, 64); err != nil {
		common.AddLog(common.LogError, h.Name, msg.ID, "odd:%s error, finished", odd)
		return true
	}

	mktInfo, _, err := calc.HandicapMarketInfo(traderRedis, matchID, marketID)
	if err != nil {
		common.AddLog(common.LogError, h.Name, msg.ID, err.Error())
		return false
	}

	//盘口已暂停
	if mktInfo.Suspended == 1 && tester == "0" {
		common.AddLog(common.LogError, h.Name, msg.ID, "market suspended already, finished")
		return true
	}

	record := g.Record{
		"bet_status":  common.OrderStatusWaitSettle,
		"update_time": time.Now().Unix(),
	}

	ex := g.Ex{
		"id":           betOrderID,
		"bet_status":   common.OrderStatusWaitConfirm,
		"confirm_type": common.ConfirmTypeAuto,
	}

	dialect := g.Dialect("mysql")
	query, _, _ := dialect.Update("tbl_bet_order").Set(record).Where(ex).ToSQL()
	result, err := db.Exec(query)
	if err != nil {
		common.AddLog(common.LogError, h.Name, msg.ID, err.Error())
		return false
	}

	if r, _ := result.RowsAffected(); r == 0 {
		common.AddLog(common.LogError, h.Name, msg.ID, "order:[%s] no need confirm, finished. sql:[%s]", betOrderID, query)
		return true
	}

	if tester == "0" {
		c := calc.Confirm{
			MatchID:     matchID,
			MarketID:    marketID,
			OddID:       oddID,
			BetAmount:   betAmount,
			TheoryPrize: theoryPrize,
			Odd:         odd,
		}
		//浮动注单自动确认更新赛事注单统计数据
		pipe := traderRedis.TxPipeline()
		defer pipe.Close()

		calc.OrderConfirm(pipe, c)

		// 更新Forecast 数据
		calc.FCOrderConfirm(pipe, mktInfo, c)

		_, err = pipe.Exec()
		if err != nil {
			common.AddLog(common.LogError, h.Name, msg.ID, "data: [%+v] order confirm failed, err: %s", c, err.Error())
			return true
		}

		// 推送操盘盘口注单变更
		_ = common.MqttPushMarketOrderBet(cli, matchID, marketID)
	}

	// 推送会员注单状态变更
	_ = common.MqttPushOrderStatus(cli, uid, orderId, common.OrderStatusWaitSettle, "0", "0", 0)

	return true
}

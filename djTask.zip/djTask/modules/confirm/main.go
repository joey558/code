package confirm

import (
	"djTask/calc"
	"djTask/contrib/zlog"
	"djTask/modules/common"
	"fmt"
	"time"

	mqtt "github.com/eclipse/paho.mqtt.golang"
	"github.com/go-redis/redis/v7"
	"github.com/jmoiron/sqlx"
	cpool "github.com/silenceper/pool"
)

var (
	conf        common.MerchantCfg
	bPool       cpool.Pool
	db          *sqlx.DB
	cli         mqtt.Client
	traderRedis *redis.Client
)

func Parse(endpoints []string, path string) {

	common.ParseCfg(&conf, endpoints, path)

	// 初始化mqtt推送
	cli = common.InitMqttService(conf.Mqtt)
	// 初始化延时队列
	bPool = common.InitBeanstalk(conf.Beanstalk, 50, 50, 100)
	// 初始化总控redis
	traderRedis = common.InitRedis(conf.TradeRedis.Addr, conf.TradeRedis.Password, conf.TradeRedis.Sentinel, 0)
	// 初始化db
	db = common.InitDBX(conf.Db.Addr, conf.Db.MaxIdleConn, conf.Db.MaxOpenConn)
	// 初始化zlog
	zlog.New(conf.Zlog.Brokers, conf.Zlog.URI)

	// 初始化ForeCast配置
	calc.InitForeCastConfig(conf.ForeCastInfo)

	defer func() {
		_ = db.Close()
		traderRedis.Close()
		bPool.Release()
	}()

	run()
}

func run() {
	handler := &common.BeansHandler{
		Name:          "orderConfirm",
		BeansPool:     bPool,
		BeansTubeName: fmt.Sprintf(common.BeanStalkBetOrderConfirm, conf.Merchant.Account),
		BeansReserve:  2 * time.Minute,
		FnPoolSize:    conf.PoolSize,
		Fn:            betOrderConfirm,
	}
	handler.Watch()
	handler.Release()
}

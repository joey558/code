package settle

import (
	"djTask/calc"
	"djTask/contrib/zlog"
	"djTask/helper"
	"djTask/modules/common"
	"djTask/wallet"
	"fmt"
	"time"

	"github.com/bsm/redislock"
	g "github.com/doug-martin/goqu/v9"
	"github.com/shopspring/decimal"
)

//串关注单详情
type complexBetData struct {
	ID             uint64 `db:"id"  json:"id"`
	OrderID        uint64 `db:"order_id"  json:"order_id"`
	GameID         string `db:"game_id"  json:"game_id"`
	GameName       string `db:"-" json:"game_name"`
	TournamentID   string `db:"tournament_id"  json:"tournament_id"`
	TournamentName string `db:"-" json:"tournament_name"`
	MatchID        string `db:"match_id"  json:"match_id"`
	MatchType      int    `db:"match_type"  json:"match_type"`
	MarketID       uint64 `db:"market_id"  json:"market_id"`
	MarketCnName   string `db:"market_cn_name"  json:"market_cn_name"`
	TeamNames      string `db:"team_names"  json:"team_names"`
	TeamID         string `db:"team_id"  json:"team_id"`
	OddID          string `db:"odd_id"  json:"odd_id"`
	OrgOddID       string `db:"org_odd_id"  json:"org_odd_id"`
	OddName        string `db:"odd_name"  json:"odd_name"`
	Odd            string `db:"odd"  json:"odd"`
	Round          int    `db:"round"  json:"round"`
	MatchStartTime int64  `db:"match_start_time"  json:"match_start_time"`
	SettleTime     int64  `db:"settle_time"  json:"settle_time"`
	SettleCount    uint64 `db:"settle_count"  json:"settle_count"`
	Status         int    `db:"status"  json:"status"`
	IsLive         int    `db:"is_live"  json:"is_live"`
	Reason         int    `db:"reason"  json:"reason"`
}

//串关子注单统计
type complexBetStat struct {
	Total    int                        //总记录数
	Canceled int                        //总取消数
	Lost     int                        //总不中奖
	UnSettle int                        //待结算数
	Odds     map[uint64]decimal.Decimal //赔率
}

/**
 * @Description: 根据条件查询多条注单记录
 * @Author: wesley
 * @Date: 2020/7/6 16:14
 * @LastEditTime: 2020/7/6 16:14
 * @LastEditors: wesley
 */
func complexBetFindAll(ex g.Ex) ([]complexBetData, error) {

	var data []complexBetData

	query, _, _ := dialect.From("tbl_order_detail").Select(complexBetColumns...).Where(ex).ToSQL()
	fmt.Println(query)
	err := dbx.Select(&data, query)

	return data, err
}

//统计子注单结算情况
func complexBetCalcStat(orderId uint64) (complexBetStat, error) {

	stat := complexBetStat{}

	comps, err := complexBetFindAll(g.Ex{"order_id": orderId})
	if err != nil {
		return stat, err
	}

	odds := map[uint64]decimal.Decimal{}
	for _, comp := range comps {
		switch comp.Status {
		case common.OrderDetailStatusWaitSettle:
			stat.UnSettle++
		case common.OrderDetailStatusCancelled, common.OrderDetailStatusUndo:
			stat.Canceled++
		case common.OrderDetailStatusLose:
			stat.Lost++
		}
		odd, _ := decimal.NewFromString(comp.Odd)
		odds[comp.ID] = odd
	}

	stat.Total = len(comps)
	stat.Odds = odds

	return stat, nil
}

/**
* @Description: 串注注单结算（一单）
* @Author: brandon
* @Date: 2020/7/8 7:58 下午
* @LastEditTime: 2020/7/8 7:58 下午
* @LastEditors: brandon
 */
func complexSettleOne(comp complexBetData, notify *NotifyComplexBody, oddIDs []string, settleCount uint64) (bool, error) {

	// 子单获取主单信息
	betOrder, err := simpleBetFindOne(g.Ex{"id": comp.OrderID})
	if err != nil {
		return false, err
	}

	if betOrder.ID == 0 {
		return false, fmt.Errorf("order_detail:[%d] missing parent order", comp.ID)
	}

	key := fmt.Sprintf("lock_%d", betOrder.MemberID)
	lock, err := locker.Obtain(key, 60*time.Second, nil)
	if err == redislock.ErrNotObtained {
		return false, fmt.Errorf("key: %s could not obtain lock", key)
	} else if err != nil {
		return false, fmt.Errorf("obtain lock failed, err: %s", err.Error())
	}
	defer lock.Release()

	tm := time.Now().Unix()
	v := g.Record{
		"settle_time":  tm,
		"update_time":  tm,
		"settle_count": settleCount,
	}

	//赔率id相等表示已中奖，否则未中奖
	detailStatus := common.OrderDetailStatusWin
	if !isWinnerOddID(oddIDs, comp.OddID) {
		detailStatus = common.OrderDetailStatusLose
	}

	v["status"] = detailStatus
	comp.Status = detailStatus
	comp.SettleCount = settleCount
	comp.SettleTime = tm
	// 更新子单状态
	query, _, _ := dialect.Update("tbl_order_detail").Set(v).Where(g.Ex{"id": comp.ID, "status": common.OrderDetailStatusWaitSettle}).ToSQL()
	fmt.Println(query)
	res, err := dbx.Exec(query)
	if err != nil {
		return false, err
	}
	if n, _ := res.RowsAffected(); n == 0 {
		zlog.Info(nil, "orderSettle", "", fmt.Sprintf("order_detail:[%d] update to settled failed, maybe status invalid!", comp.ID), 0, 0)
		return false, nil
	}

	// 统计串注子单
	complexStat, err := complexBetCalcStat(comp.OrderID)
	if err != nil {
		return false, err
	}

	var notifySimple bool
	// 得到主单是否结算完成，如果主单结算已经完成，结算仅更新子单状态
	if betOrder.BetStatus == common.OrderStatusWaitSettle {

		masterV := g.Record{
			"update_time":  tm,
			"settle_time":  tm,
			"settle_count": settleCount,
			"bet_status":   common.OrderStatusLose,
		}
		// 信用盘注单结算时更新会员当前所属代理
		if betOrder.Tester == common.UserTypeCredit {
			u, err := common.RedisGetMember(merchantRedis, betOrder.MerchantID, betOrder.MemberAccount)
			if err != nil {
				return false, err
			}
			masterV["agent_id"] = u.AgentID
			masterV["agent_account"] = u.AgentAccount
			betOrder.AgentID = u.AgentID
			betOrder.AgentAccount = u.AgentAccount
		}
		masterEx := g.Ex{
			"id":         comp.OrderID,
			"bet_status": common.OrderStatusWaitSettle,
		}

		if complexStat.Lost > 0 {
			//更新父单不中奖
			query, _, _ := dialect.Update("tbl_bet_order").Set(masterV).Where(masterEx).ToSQL()
			fmt.Println(query)
			res, err := dbx.Exec(query)
			if err != nil {
				return false, err
			}
			if n, _ := res.RowsAffected(); n == 0 {
				zlog.Info(nil, "orderSettle", "", fmt.Sprintf("order:[%d] update to lose failed, maybe status invalid", comp.OrderID), comp.MarketID, 0)
				return false, nil
			}

			notifySimple = true
			betOrder.SettleTime = tm
			betOrder.SettleCount = settleCount
			betOrder.BetStatus = common.OrderStatusLose

		} else if complexStat.UnSettle == 0 {

			//此处表示已经中奖
			amount, err := decimal.NewFromString(betOrder.TheoryPrize)
			if err != nil {
				return false, err
			}

			masterV["bet_status"] = common.OrderStatusWin
			masterV["win_amount"] = betOrder.TheoryPrize
			query, _, _ := dialect.Update("tbl_bet_order").Set(masterV).Where(masterEx).ToSQL()
			fmt.Println(query)
			res, err := dbx.Exec(query)
			if err != nil {
				return false, err
			}

			if n, _ := res.RowsAffected(); n == 0 {
				zlog.Info(nil, "orderSettle", "", fmt.Sprintf("order:[%d] update to win failed, maybe status invalid", comp.OrderID), comp.MarketID, 0)
				return false, nil
			}

			err = settleTransfer(betOrder, amount, wallet.TransBetPrize)
			if err != nil {
				// 信用网串注注单派彩失败，回滚子单和注单的状态
				if betOrder.Tester == common.UserTypeCredit {
					rollbackV := g.Record{
						"status":       common.OrderDetailStatusWaitSettle,
						"settle_count": settleCount - 1,
					}
					// 回滚子单状态
					query, _, _ := dialect.Update("tbl_order_detail").Set(rollbackV).Where(g.Ex{"id": comp.ID, "status": common.OrderDetailStatusWin}).ToSQL()
					fmt.Println(query)
					_, rollbackErr := dbx.Exec(query)
					if rollbackErr != nil {
						zlog.Error(nil, "orderSettle", "", fmt.Sprintf("credit order[%d] sent awards fail, reset order detail[%d] status fail! error:%s", comp.OrderID, comp.ID, rollbackErr.Error()), comp.ID, 0)
						return false, nil
					}

					// 回滚主单状态
					rollbackMasterV := g.Record{
						"bet_status":   common.OrderStatusWaitSettle,
						"settle_count": settleCount - 1,
						"win_amount":   "0",
					}

					query, _, _ = dialect.Update("tbl_bet_order").Set(rollbackMasterV).Where(g.Ex{"id": comp.OrderID, "bet_status": common.OrderStatusWin}).ToSQL()
					fmt.Println(query)
					_, rollbackErr = dbx.Exec(query)
					if rollbackErr != nil {
						zlog.Error(nil, "orderSettle", "", fmt.Sprintf("credit order[%d] sent awards fail, reset master order status fail! detail[%d] error:%s", comp.OrderID, comp.ID, rollbackErr.Error()), comp.OrderID, 0)
						return false, nil
					}
				}
				return false, err
			}

			betOrder.BetStatus = common.OrderStatusWin
			betOrder.WinAmount = betOrder.TheoryPrize
			betOrder.SettleTime = tm
			notifySimple = true
		}
	}

	NotifyBuildComplexBody(betOrder, comp, notify, notifySimple)
	return true, nil
}

/**
* @Description: 串注撤销（一个子单）
* @Author: brandon
* @Date: 2020/7/8 9:31 下午
* @LastEditTime: 2020/7/8 9:31 下午
* @LastEditors: brandon
 */
func complexCancelOne(comp complexBetData, notify *NotifyComplexBody, flag int, cancelCalc map[string]calc.OddOrderCancelCalc) error {

	//获取父注单信息
	betOrder, err := simpleBetFindOne(g.Ex{"id": comp.OrderID})
	if err != nil {
		return err
	}

	if betOrder.ID == 0 {
		fmt.Printf("detail:[%d] missing parent order\n", comp.ID)
		return nil
	}

	//撤单前主单的预派彩金额
	oldPrize, err := decimal.NewFromString(betOrder.TheoryPrize)
	if err != nil {
		return err
	}
	//撤单单数， 所有子单全部撤销时为1，否则为0
	cancelCount := 0
	//撤单金额， 所有子单全部撤销时为投注金额，否则为0
	cancelAmount := decimal.Zero

	// 信用盘注单结算时更新会员当前所属代理
	if betOrder.Tester == common.UserTypeCredit {
		u, err := common.RedisGetMember(merchantRedis, betOrder.MerchantID, betOrder.MemberAccount)
		if err != nil {
			return err
		}
		betOrder.AgentID = u.AgentID
		betOrder.AgentAccount = u.AgentAccount
	}

	tm := time.Now().Unix()
	//1.修改子注单状态为撤销
	v := g.Record{
		"odd":         "1",
		"update_time": tm,
		"settle_time": tm,
		"reason":      comp.Reason,
	}

	// 取消未结算注单
	status := common.OrderDetailStatusCancelled
	// 取消已结算注单
	if flag == common.CancelTypeSettled {
		status = common.OrderDetailStatusUndo
	}

	v["status"] = status
	ex := g.Ex{
		"id":     comp.ID,
		"status": comp.Status,
	}
	//更新子单状态
	query, _, _ := dialect.Update("tbl_order_detail").Set(v).Where(ex).ToSQL()
	fmt.Println(query)
	_, err = dbx.Exec(query)
	if err != nil {
		return err
	}

	comp.Status = status
	comp.Odd = "1"
	comp.SettleTime = tm
	// 统计串注子单
	complexStat, err := complexBetCalcStat(comp.OrderID)
	if err != nil {
		return err
	}

	amount, _ := decimal.NewFromString(betOrder.BetAmount)
	if betOrder.BetStatus == common.OrderStatusWin {
		oldPrize, err := decimal.NewFromString(betOrder.WinAmount)
		if err != nil {
			return err
		}

		err = settleTransfer(betOrder, oldPrize, wallet.TransBetPrizeDeduct)
		if err != nil {
			return err
		}
	}

	var (
		prize decimal.Decimal
		odds  decimal.Decimal
	)
	//撤单后仍旧中奖，重新计算奖金
	if betOrder.OrderType == common.OrderTypeComplex {
		prize, odds = complexCalcPrize(amount, complexStat.Odds)
	} else if betOrder.OrderType == common.OrderTypeRndComplex {
		prize, odds, err = rndComplexCalcPrize(amount, complexStat.Odds, betOrder.OddDiscount)
		if err != nil {
			return err
		}
	} else if betOrder.OrderType == common.OrderTypeMix {
		prize, odds, err = complexComposite(amount, complexStat.Odds, betOrder.OddDiscount)
		if err != nil {
			return err
		}
	}

	prize, err = decimal.NewFromString(helper.TrimStr(prize))
	if err != nil {
		return err
	}

	// 串关注单主单更新字段
	masterRecord := g.Record{
		"update_time":  tm,
		"odd":          odds.String(),
		"theory_prize": prize.String(),
	}
	// 信用盘注单结算时更新会员当前所属代理
	if betOrder.Tester == common.UserTypeCredit {
		masterRecord["agent_id"] = betOrder.AgentID
		masterRecord["agent_account"] = betOrder.AgentAccount
	}

	if prize.Sign() != 1 { //奖金<=0
		return fmt.Errorf("order:[%d] cal prize is less zero", comp.OrderID)
	}

	betOrder.Odd = odds.String()
	betOrder.TheoryPrize = prize.String()
	betStatus := betOrder.BetStatus

	if complexStat.Canceled == complexStat.Total { // 所有子单取消

		masterRecord["odd"] = "1"
		masterRecord["win_amount"] = 0
		masterRecord["settle_time"] = tm
		masterRecord["theory_prize"] = "0"

		if flag == common.CancelTypeSettled {
			betStatus = common.OrderStatusUndo
		} else {
			betStatus = common.OrderStatusCancelled
		}

		err = settleTransfer(betOrder, amount, wallet.TransBetCancel)
		if err != nil {
			return err
		}
		betOrder.Odd = "1"
		betOrder.TheoryPrize = "0"
		betOrder.WinAmount = "0"
		betOrder.SettleTime = tm
		cancelAmount = amount
		cancelCount = 1
		// 子单全部撤销，主单原预派彩金额需要加上注单本金
		oldPrize = oldPrize.Add(amount)
	} else if complexStat.UnSettle > 0 {
		// 即使子单未全结算,串注只要有一条注单是输,总注单状态就变成输
		if complexStat.Lost > 0 {
			betOrder.SettleTime = tm
			betStatus = common.OrderStatusLose
			masterRecord["settle_time"] = tm
		} else {
			masterRecord["settle_time"] = 0
			betOrder.SettleTime = 0
			betStatus = common.OrderStatusWaitSettle
		}

	} else if complexStat.Lost > 0 {

		betOrder.SettleTime = tm
		betStatus = common.OrderStatusLose
		masterRecord["settle_time"] = tm

	} else if complexStat.Lost == 0 {

		masterRecord["win_amount"] = prize.String()
		masterRecord["settle_time"] = tm
		betOrder.WinAmount = prize.String()
		betOrder.SettleTime = tm
		betStatus = common.OrderStatusWin
		err = settleTransfer(betOrder, prize, wallet.TransBetPrize)
		if err != nil {
			return err
		}
	}

	masterRecord["bet_status"] = betStatus
	betOrder.BetStatus = betStatus
	//修改父注单状态
	masterEx := g.Ex{
		"id": comp.OrderID,
		"bet_status": []int{
			common.OrderStatusWaitConfirm,
			common.OrderStatusWaitSettle,
			common.OrderStatusWin,
			common.OrderStatusLose,
		},
	}

	query, _, _ = dialect.Update("tbl_bet_order").Set(masterRecord).Where(masterEx).ToSQL()
	fmt.Println(query)
	res, err := dbx.Exec(query)
	if err != nil {
		return err
	}
	if n, _ := res.RowsAffected(); n == 0 {
		return fmt.Errorf("order:%d update to cancel failed, maybe status invalid", comp.OrderID)
	}

	if betOrder.OrderType == common.OrderTypeMix && betOrder.Tester == 0 {
		var (
			oddCancelCalc calc.OddOrderCancelCalc
			ok            bool
		)

		if oddCancelCalc, ok = cancelCalc[betOrder.OddID]; !ok {
			oddCancelCalc = calc.OddOrderCancelCalc{
				MatchID:            betOrder.MatchID,
				MarketID:           betOrder.MarketID,
				FloatCount:         0,
				FloatAmount:        decimal.Zero,
				FloatTheoryPrize:   decimal.Zero,
				RealityCount:       cancelCount,
				RealityAmount:      cancelAmount,
				RealityTheoryPrize: oldPrize.Sub(prize),
			}
		} else {
			oddCancelCalc.RealityCount = oddCancelCalc.RealityCount + cancelCount
			oddCancelCalc.RealityAmount = oddCancelCalc.RealityAmount.Add(cancelAmount)
			//复合玩法注单，子单撤销，盈亏数据更新：  复合盘口投注项原实际预派彩金额-(复合玩法注单撤单前预派彩金额-撤单后的预派彩金额)
			oddCancelCalc.RealityTheoryPrize = oddCancelCalc.RealityTheoryPrize.Add(oldPrize.Sub(prize))
		}

		cancelCalc[betOrder.OddID] = oddCancelCalc
	}

	NotifyBuildComplexBody(betOrder, comp, notify, true)
	return nil
}

/**
 * @Description: 子单统计数量
 * @Author: wesley
 * @Date: 2020/7/6 16:14
 * @LastEditTime: 2020/7/6 16:14
 * @LastEditors: wesley
 */
func complexBetCount(ex g.Ex) (int, error) {

	var count int
	query, _, _ := g.Dialect("mysql").From("tbl_order_detail").Select(g.COUNT("id")).Where(ex).ToSQL()
	fmt.Println(query)
	err := dbx.Get(&count, query)
	return count, err
}

//计算串注奖金
func complexCalcPrize(amount decimal.Decimal, data map[uint64]decimal.Decimal) (decimal.Decimal, decimal.Decimal) {

	odds := decimalOne
	for _, odd := range data {
		odds = odds.Mul(odd)
	}

	return amount.Mul(odds), odds
}

//计算局内串注奖金
func rndComplexCalcPrize(amount decimal.Decimal, data map[uint64]decimal.Decimal, oddDiscount string) (decimal.Decimal, decimal.Decimal, error) {

	odds := decimalOne
	// 局内串关返还率
	discnt, _ := decimal.NewFromString(oddDiscount)
	// 实际串关赔率 = ((投注项1赔率-1)*局内串关返还率+1) * ((投注项2赔率-1)*局内串关返还率+1)…… ((投注项N赔率-1)*局内串关返还率+1)
	for _, odd := range data {
		odds = odds.Mul(odd.Sub(decimalOne).Mul(discnt).Add(decimalOne))
	}

	odds = odds.Round(6)
	val, err := traderRedis.HGet("setting", "round_complex_max_odd").Int64()
	if err != nil {
		return decimal.Zero, decimal.Zero, err
	}

	maxOdd := decimal.NewFromInt(val)
	if odds.GreaterThan(maxOdd) {
		odds = maxOdd
	}

	return amount.Mul(odds), odds, nil
}

//计算复合玩法奖金
func complexComposite(amount decimal.Decimal, data map[uint64]decimal.Decimal, oddDiscount string) (decimal.Decimal, decimal.Decimal, error) {
	odds := decimalOne
	// 复合玩法返还率
	discnt, _ := decimal.NewFromString(oddDiscount)
	// 实际串关赔率 = ((投注项1赔率-1)*复合玩法返还率+1) * ((投注项2赔率-1)*复合玩法返还率+1)…… ((投注项N赔率-1)*复合玩法返还率+1)
	for _, odd := range data {
		odds = odds.Mul(odd.Sub(decimalOne).Mul(discnt).Add(decimalOne))
	}

	return amount.Mul(odds), odds, nil
}

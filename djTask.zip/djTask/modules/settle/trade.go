package settle

import (
	"djTask/calc"
	"djTask/contrib/validator"
	"djTask/modules/common"
	"djTask/wallet"
	"strconv"
	"strings"
	"time"

	g "github.com/doug-martin/goqu/v9"
	"github.com/scylladb/go-set/strset"
	"github.com/shopspring/decimal"
)

const (
	flagMatchOpen        = "0"
	flagGenRiskOrder     = "1" //盘口暂停
	flagCancelMarket     = "2" //盘口取消
	flagReceiveSimple    = "3" //风险注单接收
	flagRefuseSimple     = "4" //风险注单拒绝
	flagStuckOrderAccept = "5" //盘口卡单接受
)

var tradeFns = map[string]common.BeansFunc{
	flagMatchOpen:        tradeRiskOrderGen,
	flagGenRiskOrder:     tradeRiskOrderGen,
	flagCancelMarket:     tradeCancelMarket,
	flagReceiveSimple:    tradeRiskOrderAccept,
	flagRefuseSimple:     tradeRiskOrderRefuse,
	flagStuckOrderAccept: tradeStuckOrderAccept,
}

type TimeoutAcceptMsg struct {
	handler  *common.BeansHandler
	Id       uint64
	MatchID  string
	MarketID string
	Delay    int
}

// 自动确认卡单注单查询结构体
type StuckOrder struct {
	ID          uint64 `db:"id"`           // 注单ID
	Uid         uint64 `db:"member_id"`    // 会员ID
	MatchID     string `db:"match_id"`     // 赛事ID
	MarketID    string `db:"market_id"`    // 盘口ID
	OddID       string `db:"odd_id"`       // 投注项ID
	Odd         string `db:"odd"`          // 投注项赔率
	BetAmount   string `db:"bet_amount"`   // 投注金额
	TheoryPrize string `db:"theory_prize"` // 预期派彩金额
	Tester      int    `db:"tester"`       // 是否为测试账号
	OddTypeID   string `db:"org_odd_id"`   // 玩法ID
	IsLive      int    `db:"is_live"`      // 1-赛前 2-滚球
	Round       int    `db:"round"`        // 注单局数
}

// 盘口状态变更
func tradeHandle(h *common.BeansHandler, m common.BeansMessage) bool {

	//market_id=1&flag=1  1盘口暂停 2盘口取消 3盘口风险注单接收 4盘口风险注单拒绝
	flag := m.Msg.Get("flag")
	if fn, ok := tradeFns[flag]; ok {
		return fn(h, m)
	}
	common.AddLog(common.LogError, h.Name, m.ID, "invalid flag: %s", flag)
	return true
}

/**
 * @Description: 生成风险注单
 * @Author: wesley
 * @Date: 2020/7/8 14:11
 * @LastEditTime: 2020/7/8 14:11
 * @LastEditors: wesley
 */
func tradeRiskOrderGen(h *common.BeansHandler, m common.BeansMessage) bool {

	matchID := m.Msg.Get("match_id")
	if !validator.CheckStringDigit(matchID) {
		common.AddLog(common.LogError, "riskOrderGen", m.ID, "match: [%s] err, cant gen risk order", matchID)
		return true
	}
	sMktIDs := m.Msg.Get("market_id")
	if !validator.CheckStringCommaDigit(sMktIDs) {
		common.AddLog(common.LogError, "riskOrderGen", m.ID, "market: [%s] err, cant gen risk order", sMktIDs)
		return true
	}
	delay, err := strconv.Atoi(m.Msg.Get("delay_time"))
	if err != nil {
		common.AddLog(common.LogError, "riskOrderGen", m.ID, "market: [%s] cant gen risk order,because the delay_time err: %s", sMktIDs, err.Error())
		return true
	}

	marketIDs := strings.Split(sMktIDs, ",")
	nowTime := time.Now().Unix()
	var (
		n       int64  // 执行成功条数
		execSql string // update语句
	)
	record := g.Record{
		"confirm_type": common.ConfirmTypeManualPrepare,
		"update_time":  nowTime,
	}

	ex := g.Ex{
		"bet_status":   common.OrderStatusWaitConfirm,
		"confirm_type": common.ConfirmTypeAuto,
	}

	dialect := g.Dialect("mysql")
	pipe := traderRedis.TxPipeline()
	defer pipe.Close()
	for _, mktID := range marketIDs {

		ex["market_id"] = mktID
		execSql, _, _ = dialect.Update("tbl_bet_order").Set(record).Where(ex).ToSQL()

		res, err := dbx.Exec(execSql)
		if err != nil {
			common.AddLog(common.LogError, "riskOrderGen", m.ID, err.Error())
			continue
		}

		if n, _ = res.RowsAffected(); n == 0 {
			common.AddLog(common.LogInfo, "riskOrderGen", m.ID, "market risk order are zero, SQL: %s", execSql)
			continue
		}

		calc.RiskOrderGen(pipe, matchID, mktID, int(n))
		_, err = pipe.Exec()
		if err != nil {
			common.AddLog(common.LogError, "riskOrderGen", m.ID, "update order stat for gen risk order err: %s", err.Error())
			continue
		}
		// 生成风险注单更新盘口风险注单数和推送刷新通知mqtt
		_ = common.MqttPushRiskOrderStatus(cli, matchID, mktID, common.RiskOrderFlagGen, int(n))
	}

	//风险注单超时自动确认
	for _, marketID := range marketIDs {
		marketID := marketID
		go func() {
			time.Sleep(time.Second * (time.Duration(delay)))
			riskOrderAccept(matchID, marketID, m.MID)
		}()
	}
	return true
}

//风险单注注单接受
func tradeRiskOrderAccept(h *common.BeansHandler, m common.BeansMessage) bool {

	//获取所有待处理的注单id
	matchID := m.Msg.Get("match_id")
	if !validator.CheckStringDigit(matchID) {
		common.AddLog(common.LogError, "riskOrderAccept", m.ID, "match: [%s] err, cant accept", matchID)
		return true
	}
	marketID := m.Msg.Get("market_id")
	if !validator.CheckStringDigit(marketID) {
		common.AddLog(common.LogError, "riskOrderAccept", m.ID, "market: [%s] err, cant accept", marketID)
		return true
	}

	riskOrderAccept(matchID, marketID, m.MID)
	return true
}

//风险单注注单拒绝注单
func tradeRiskOrderRefuse(h *common.BeansHandler, m common.BeansMessage) bool {

	matchID := m.Msg.Get("match_id")
	if !validator.CheckStringDigit(matchID) {
		common.AddLog(common.LogError, "riskOrderRefuse", m.ID, "match: [%s] err, cant refuse", matchID)
		return true
	}

	marketID := m.Msg.Get("market_id")
	if !validator.CheckStringDigit(marketID) {
		common.AddLog(common.LogError, "riskOrderRefuse", m.ID, "market: [%s] err, cant refuse", marketID)
		return true
	}
	mktID, err := strconv.ParseUint(marketID, 10, 64)
	if err != nil {
		common.AddLog(common.LogError, "riskOrderRefuse", m.ID, "marketID: [%s] err", marketID)
		return true
	}

	ex := g.Ex{
		"market_id":    marketID,
		"bet_status":   common.OrderStatusWaitConfirm,
		"confirm_type": common.ConfirmTypeManualPrepare,
		"order_type":   1,
	}

	var orders []simpleBetData
	dialect := g.Dialect("mysql")

	query, _, _ := dialect.Select(simpleBetColumns...).From("tbl_bet_order").Where(ex).ToSQL()
	err = dbx.Select(&orders, query)
	if err != nil {
		common.AddLog(common.LogError, "riskOrderRefuse", m.ID, "refuse risk order error: %s", err.Error())
		return true
	}

	if len(orders) == 0 {
		common.AddLog(common.LogInfo, "riskOrderRefuse", m.ID, "no data waiting refuse, sql:"+query)
		return true
	}

	var (
		n        int64             // sql执行成功条数
		ok       bool              // key是否存在
		execSql  string            // 注单表更新sql语句
		oddCalc  calc.TradeOddCalc // 拒绝成功，注单投注项注单统计
		notifies []simpleBetData
	)
	tm := time.Now().Unix()
	record := g.Record{
		"bet_status":   common.OrderStatusRefused,
		"confirm_type": common.ConfirmTypeManualRefused,
		"settle_count": 1,
		"update_time":  tm,
		"settle_time":  tm,
	}

	updateEx := g.Ex{
		"bet_status":   common.OrderStatusWaitConfirm,
		"confirm_type": common.ConfirmTypeManualPrepare,
	}

	// 盘口拒绝风险注单统计
	mktRefuseStatistics := calc.OrderRefuseCalc{
		BetCount:  0,
		BetAmount: decimal.Zero,
		Odds:      map[string]calc.TradeOddCalc{},
	}

	tourIds := strset.New()
	gameIds := strset.New()
	for _, v := range orders {
		updateEx["id"] = v.ID
		tx, err := dbx.Begin()
		if err != nil {
			common.AddLog(common.LogError, "riskOrderRefuse", m.ID, "order[%d] refuse fail, open transaction error:%s", v.ID, err.Error())
			continue
		}

		execSql, _, _ = dialect.Update("tbl_bet_order").Set(record).Where(updateEx).ToSQL()
		res, err := tx.Exec(execSql)
		if err != nil {
			_ = tx.Rollback()
			common.AddLog(common.LogError, "riskOrderRefuse", m.ID, "refuse risk order error: %s", err.Error())
			continue
		}

		if n, _ = res.RowsAffected(); n == 0 {
			_ = tx.Rollback()
			common.AddLog(common.LogInfo, "riskOrderRefuse", m.ID, "market refuse risk order are zero, SQL: %s", execSql)
			continue
		}

		bet, _ := decimal.NewFromString(v.BetAmount)
		//拒绝注单退款
		err = settleTransfer(v, bet, wallet.TransBetRefuse)
		if err != nil {
			_ = tx.Rollback()
			common.AddLog(common.LogError, "riskOrderRefuse", m.ID, "order_id:%d add trans failed for refuse err:%s", v.ID, err.Error())
			continue
		}

		err = tx.Commit()
		if err != nil {
			common.AddLog(common.LogInfo, "riskOrderRefuse", m.ID, "market refuse risk order commit transaction error: %s", err.Error())
			continue
		}

		tourIds.Add(v.TournamentID)
		gameIds.Add(v.GameID)

		notify := v
		notify.BetStatus = common.OrderStatusRefused
		notify.SettleTime = tm
		notify.ConfirmType = common.ConfirmTypeManualRefused
		notify.SettleCount = 1
		notifies = append(notifies, notify)

		mktRefuseStatistics.BetCount++
		// 非正式会员注单只更新风险注单数，不更新盘口和投注项盈亏金额
		if v.Tester != common.UserTypeNormal {
			continue
		}
		mktRefuseStatistics.BetAmount = mktRefuseStatistics.BetAmount.Add(bet)
		theoryPrize, _ := decimal.NewFromString(v.TheoryPrize)

		// 盘口投注项统计数据不存在, 盘口和投注项浮动注单统计直接减去当前注单
		if oddCalc, ok = mktRefuseStatistics.Odds[v.OddID]; !ok {
			mktRefuseStatistics.Odds[v.OddID] = calc.TradeOddCalc{
				BetCount:    1,
				BetAmount:   bet,
				TheoryPrize: theoryPrize,
			}
		} else { // 盘口投注项统计数据已存在，则在之前的数据上累加
			oddCalc.BetCount++
			oddCalc.BetAmount = oddCalc.BetAmount.Add(bet)
			oddCalc.TheoryPrize = oddCalc.TheoryPrize.Add(theoryPrize)
			mktRefuseStatistics.Odds[v.OddID] = oddCalc
		}
	}

	if mktRefuseStatistics.BetCount > 0 {
		// 风险注单手动拒绝更新赛事注单统计数据
		pipe := traderRedis.TxPipeline()
		calc.MarketRiskOrderRefuse(pipe, matchID, marketID, mktRefuseStatistics)

		// 风险注单手动拒绝更新ForeCast注单统计数据
		calc.FCMarketRiskOrderRefuse(pipe, matchID, marketID, mktRefuseStatistics)

		_, err = pipe.Exec()
		defer pipe.Close()
		if err != nil {
			common.AddLog(common.LogError, "riskOrderRefuse", m.ID, err.Error())
			return true
		}

		// 风险注单拒绝引起浮动盈亏变化，需要监控盘口预警状态
		err = common.BeansTaskMarketMonitor(zkbPool, matchID, marketID, "0")
		if err != nil {
			common.AddLog(common.LogError, "riskOrderRefuse", m.ID, "add monitor task failed")
		}

		// 风险注单拒绝推送
		_ = common.MqttPushRiskOrderStatus(cli, matchID, marketID, common.RiskOrderFlagRefuse, 0)
	}

	//notify
	if len(notifies) > 0 {
		NotifySimple(notifies, tourIds.List(), gameIds.List(), mktID)
	}
	return true
}

// 自动确认卡单手动确认
func tradeStuckOrderAccept(h *common.BeansHandler, m common.BeansMessage) bool {

	marketID := m.Msg.Get("market_id")
	if !validator.CheckStringDigit(marketID) {
		common.AddLog(common.LogError, "stuckOrderAccept", m.ID, "market: [%s] stuck acccpt err, cant accept", marketID)
		return true
	}

	ex := g.Ex{
		"market_id":    marketID,
		"bet_status":   common.OrderStatusWaitConfirm,
		"confirm_type": common.ConfirmTypeAuto,
	}

	var betOrders []StuckOrder
	// 查询盘口所有未确认的注单
	dialect := g.Dialect("mysql")
	query, _, _ := dialect.Select(stuckOrderColumns...).From("tbl_bet_order").Where(ex).ToSQL()
	err := dbx.Select(&betOrders, query)
	if err != nil {
		common.AddLog(common.LogError, "stuckOrderAccept", m.ID, "stuck accept order error: %s", err.Error())
		return true
	}

	if len(betOrders) == 0 {
		common.AddLog(common.LogInfo, "stuckOrderAccept", m.ID, "no data waiting stuck accept, sql:"+query)
		return true
	}

	var (
		n       int64  // sql执行成功条数
		execSql string // 注单表更新sql语句
	)
	nowTime := time.Now().Unix()
	record := g.Record{
		"bet_status":  common.OrderStatusWaitSettle,
		"update_time": nowTime,
	}

	calcParam := calc.OrderAcceptCalc{
		MarketID: marketID,
		IsStuck:  1,
		Odds:     map[string]calc.TradeOddCalc{},
	}

	for _, v := range betOrders {

		execSql, _, _ = dialect.Update("tbl_bet_order").Set(record).Where(g.Ex{"id": v.ID, "bet_status": common.OrderStatusWaitConfirm}).ToSQL()
		res, err := dbx.Exec(execSql)
		if err != nil {
			common.AddLog(common.LogError, "stuckOrderAccept", m.ID, "stuck accept market order error: %s", err.Error())
			continue
		}

		if n, _ = res.RowsAffected(); n == 0 {
			common.AddLog(common.LogInfo, "stuckOrderAccept", m.ID, "stuck accept market order are zero, SQL: %s", execSql)
			continue
		}

		// 正式会员注单手动接受后才更新浮动盈亏统计
		if v.Tester == common.UserTypeNormal {
			// 组装卡单接受注单统计参数
			calcParam = OrderAcceptCalcParam(v, calcParam)
		}

		// 推送会员注单状态变更
		_ = common.MqttPushOrderStatus(cli, v.Uid, v.ID, common.OrderStatusWaitSettle, "0", "0", 0)
	}

	if calcParam.MatchID != "" && len(calcParam.Odds) > 0 {
		pipe := traderRedis.TxPipeline()
		defer pipe.Close()
		calc.OrderAccept(pipe, calcParam)
		calc.FCOrderAccept(pipe, calcParam)
		_, err = pipe.Exec()
		if err != nil {
			common.AddLog(common.LogError, "stuckOrderAccept", m.ID, "data: [%+v] order confirm failed, err: %s", calcParam, err.Error())
			return true
		}
		// 推送操盘盘口注单变更
		_ = common.MqttPushMarketOrderBet(cli, calcParam.MatchID, marketID)
	}
	return true
}

func OrderAcceptCalcParam(order StuckOrder, calcParam calc.OrderAcceptCalc) calc.OrderAcceptCalc {

	if calcParam.MatchID == "" {
		calcParam.MatchID = order.MatchID
	}

	betAmount, _ := decimal.NewFromString(order.BetAmount)
	theoryPrize, _ := decimal.NewFromString(order.TheoryPrize)

	calcParam.BetCount++
	calcParam.BetAmount = calcParam.BetAmount.Add(betAmount)
	var (
		ok      bool              // 投注项统计key是否存在
		oddCalc calc.TradeOddCalc // 拒绝成功，注单投注项注单统计
	)
	// 盘口投注项统计数据不存在, 盘口和投注项浮动注单统计直接减去当前注单
	if oddCalc, ok = calcParam.Odds[order.OddID]; !ok {
		calcParam.Odds[order.OddID] = calc.TradeOddCalc{
			BetCount:    1,
			BetAmount:   betAmount,
			TheoryPrize: theoryPrize,
			OddTypeID:   order.OddTypeID,
			Round:       order.Round,
			IsLive:      order.IsLive,
		}
	} else {
		oddCalc.BetCount++
		oddCalc.BetAmount = oddCalc.BetAmount.Add(betAmount)
		oddCalc.TheoryPrize = oddCalc.TheoryPrize.Add(theoryPrize)
		calcParam.Odds[order.OddID] = oddCalc
	}

	return calcParam
}

//风险注单接受
func riskOrderAccept(matchID, marketID string, id uint64) {

	ex := g.Ex{
		"market_id":    marketID,
		"bet_status":   common.OrderStatusWaitConfirm,
		"confirm_type": common.ConfirmTypeManualPrepare,
	}

	// 查询盘口所有未确认的注单
	dialect := g.Dialect("mysql")
	query, _, _ := dialect.Select(stuckOrderColumns...).From("tbl_bet_order").Where(ex).ToSQL()
	var betOrders []StuckOrder
	err := dbx.Select(&betOrders, query)
	if err != nil {
		common.AddLog(common.LogError, "riskOrderAccept", id, "accept risk order error: %s", err.Error())
		return
	}

	if len(betOrders) == 0 {
		common.AddLog(common.LogInfo, "riskOrderAccept", id, "no data waiting accept, sql:"+query)
		return
	}

	var (
		n       int64  // sql执行成功条数
		execSql string // 注单表更新sql语句
	)
	nowTime := time.Now().Unix()
	record := g.Record{
		"bet_status":   common.OrderStatusWaitSettle,
		"confirm_type": common.ConfirmTypeManualAffirm,
		"update_time":  nowTime,
	}

	calcParam := calc.OrderAcceptCalc{
		MatchID:  matchID,
		MarketID: marketID,
		Odds:     map[string]calc.TradeOddCalc{},
	}

	for _, v := range betOrders {

		execSql, _, _ = dialect.Update("tbl_bet_order").Set(record).Where(g.Ex{"id": v.ID, "bet_status": common.OrderStatusWaitConfirm}).ToSQL()
		res, err := dbx.Exec(execSql)
		if err != nil {
			common.AddLog(common.LogError, "riskOrderAccept", id, "accept market risk order error: %s", err.Error())
			continue
		}

		if n, _ = res.RowsAffected(); n == 0 {
			common.AddLog(common.LogInfo, "riskOrderAccept", id, "accept market risk order are zero, SQL: %s", execSql)
			continue
		}

		calcParam.RiskCount++
		// 测试和信用注单只更新
		if v.Tester != common.UserTypeNormal {
			continue
		}
		// 组装风险注单接受注单统计参数
		calcParam = OrderAcceptCalcParam(v, calcParam)
	}

	if calcParam.BetCount > 0 || calcParam.RiskCount > 0 {
		pipe := traderRedis.TxPipeline()
		defer pipe.Close()
		calc.OrderAccept(pipe, calcParam)

		// 风险注单，更新ForeCast数据
		calc.FCOrderAccept(pipe, calcParam)

		_, err = pipe.Exec()
		if err != nil {
			common.AddLog(common.LogError, "riskOrderAccept", id, "data: [%+v] risk order accept failed, err: %s", calcParam, err.Error())
		}

		// 推送操盘盘口注单变更
		_ = common.MqttPushMarketOrderBet(cli, calcParam.MatchID, marketID)

		// 推送状态变更
		for _, v := range betOrders {
			_ = common.MqttPushOrderStatus(cli, v.Uid, v.ID, common.OrderStatusWaitSettle, v.TheoryPrize, v.Odd, 0)
		}
	}
}

package settle

import (
	"djTask/calc"
	"djTask/contrib/zlog"
	"djTask/modules/common"
	"djTask/wallet"
	"fmt"
	"time"

	"github.com/bsm/redislock"
	g "github.com/doug-martin/goqu/v9"
	_ "github.com/doug-martin/goqu/v9/dialect/mysql"
	mqtt "github.com/eclipse/paho.mqtt.golang"
	"github.com/go-redis/redis/v7"
	"github.com/jmoiron/sqlx"
	"github.com/shopspring/decimal"
	cpool "github.com/silenceper/pool"
)

var (
	conf          common.MerchantCfg
	dbx           *sqlx.DB
	cli           mqtt.Client
	traderRedis   *redis.Client
	merchantRedis *redis.Client
	locker        *redislock.Client
	zkbPool       cpool.Pool
)

var (
	dialect           = g.Dialect("mysql")
	decimalOne        = decimal.NewFromInt32(1)
	stuckOrderColumns = calc.EnumFields(StuckOrder{})
	simpleBetColumns  = calc.EnumFields(simpleBetData{})
	complexBetColumns = calc.EnumFields(complexBetData{})
)

func Parse(endpoints []string, path string) {

	common.ParseCfg(&conf, endpoints, path)

	// 初始化数据库
	dbx = common.InitDBX(conf.Db.Addr, conf.Db.MaxIdleConn, conf.Db.MaxOpenConn)
	// 初始化延时队列
	cli = common.InitMqttService(conf.Mqtt)
	// 初始化总控redis
	traderRedis = common.InitRedis(conf.TradeRedis.Addr, conf.TradeRedis.Password, conf.TradeRedis.Sentinel, 0)
	// 初始化商户redis
	merchantRedis = common.InitRedis(conf.MerchantRedis.Addr, conf.MerchantRedis.Password, conf.MerchantRedis.Sentinel, conf.MerchantRedis.Db)
	// 初始化延时队列
	zkbPool = common.InitBeanstalk(conf.ZkBeanstalk, 50, 50, 100)
	// 初始化zlog
	zlog.New(conf.Zlog.Brokers, conf.Zlog.URI)
	//初始化locker
	locker = redislock.New(merchantRedis)
	// 设置信用网中心钱包host地址
	wallet.XywSecretKey = conf.Credit.SecretKey
	wallet.XywHost = conf.Credit.CentralWalletHost
	wallet.XywHttpTimeout = time.Duration(conf.Credit.Timeout) * time.Second
	wallet.XywRetryNum = conf.Credit.RetryNum

	// 初始化ForeCast配置
	calc.InitForeCastConfig(conf.ForeCastInfo)

	defer func() {
		_ = dbx.Close()
		_ = traderRedis.Close()
		_ = merchantRedis.Close()
	}()

	run()
}

func run() {
	// 结算队列
	go func() {
		handler := &common.BeansHandler{
			Name:          "orderSettle",
			BeansPool:     zkbPool,
			BeansTubeName: fmt.Sprintf(common.BeanstalkSettleTube, conf.Merchant.Account),
			BeansReserve:  2 * time.Minute,
			FnPoolSize:    conf.PoolSize,
			Fn:            settlesHandle,
		}
		handler.Watch()
		handler.Release()
	}()

	// 操盘队列
	go func() {
		handler := &common.BeansHandler{
			Name:          "trader",
			BeansPool:     zkbPool,
			BeansTubeName: fmt.Sprintf(common.BeanstalkTradeTube, conf.Merchant.Account),
			BeansReserve:  2 * time.Minute,
			FnPoolSize:    conf.PoolSize,
			Fn:            tradeHandle,
		}
		handler.Watch()
		handler.Release()
	}()

	// 撤单队列
	func() {
		handler := &common.BeansHandler{
			Name:          "orderCancel",
			BeansPool:     zkbPool,
			BeansTubeName: fmt.Sprintf(common.BeanstalkCancelTube, conf.Merchant.Account),
			BeansReserve:  2 * time.Minute,
			FnPoolSize:    conf.PoolSize,
			Fn:            cancelHandle,
		}
		handler.Watch()
		handler.Release()
	}()
}

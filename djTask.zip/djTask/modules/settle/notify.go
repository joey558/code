package settle

import (
	"djTask/modules/common"
)

//var (
//	notifySimpleData  = jingo.NewStructEncoder(simpleBetData{})
//	notifyComplexData = jingo.NewStructEncoder(NotifyComplexBody{})
//)

type NotifyComplexBody struct {
	ID                    uint64 `json:"id"`  //注单ID
	CID                   uint64 `json:"cid"` //注单明细ID
	MemberID              uint64 `json:"member_id"`
	MemberAccount         string `json:"member_account"`
	MerchantID            uint64 `json:"merchant_id"`
	MerchantAccount       string `json:"merchant_account"`
	ParentMerchantID      uint64 `json:"parent_merchant_id"`
	ParentMerchantAccount string `json:"parent_merchant_account"`
	Tester                uint8  `json:"tester"`
	OrderType             uint8  `json:"order_type"`
	ParleyType            int    `json:"parley_type"`
	GameID                string `json:"game_id"`
	GameName              string `json:"game_name"`
	TournamentID          string `json:"tournament_id"`
	TournamentName        string `json:"tournament_name"`
	MatchID               string `json:"match_id"`
	MatchType             int    `json:"match_type"`
	MarketID              uint64 `json:"market_id"`
	MarketCnName          string `json:"market_cn_name"`
	TeamNames             string `json:"team_names"`
	TeamID                string `json:"team_id"`
	OddID                 string `json:"odd_id"`
	OrgOddID              string `json:"org_odd_id"`
	OddName               string `json:"odd_name"`
	Odd                   string `json:"odd"`
	COdd                  string `json:"c_odd"`
	Round                 int    `json:"round"`
	BetIP                 uint32 `json:"bet_ip"`
	Device                uint32 `json:"device"`
	BetAmount             string `json:"bet_amount"`
	TheoryPrize           string `json:"theory_prize"`
	WinAmount             string `json:"win_amount"`
	BetStatus             int    `json:"bet_status"`
	Status                int    `json:"status"`
	IsLive                int    `json:"is_live"`
	ConfirmType           int    `json:"confirm_type"`
	BetTime               int64  `json:"bet_time"`
	SettleCount           uint64 `json:"settle_count"`
	SettleTime            int64  `json:"settle_time"`
	MatchStartTime        int64  `json:"match_start_time"`
	Reason                int    `json:"reason"`
	NotifySimple          bool   //结算是否完成的标识
}

//单注通知
func NotifySimple(notifies []simpleBetData, tourIds, gameIds []string, marketId uint64) {

	//获得联赛名称
	//tourNames, _ := common.RedisTourCnNameBatchGet(traderRedis, tourIds)
	//gameNames, _ := common.RedisGameNameBatchGet(traderRedis, gameIds)
	//var msgs []*primitive.Message

	for _, order := range notifies {

		//注单状态推送
		_ = common.MqttPushOrderStatus(cli, order.MemberID, order.ID, order.BetStatus, order.TheoryPrize, order.Odd, order.Reason)

	//	prefix := order.MerchantID
	//	if confTenancy {
	//		prefix = order.ParentMerchantID
	//	}
	//
	//	topic := fmt.Sprintf("%d_order", prefix)
	//	if tourName, ok1 := tourNames[order.TournamentID]; ok1 {
	//		order.TournamentName = tourName
	//	}
	//	if gameName, ok2 := gameNames[order.GameID]; ok2 {
	//		order.GameName = gameName
	//	}
	//
	//	buf := jingo.NewBufferFromPool()
	//	notifySimpleData.Marshal(&order, buf)
	//	dst := make([]byte, len(buf.Bytes))
	//	copy(dst, buf.Bytes)
	//	msgs = append(msgs, &primitive.Message{
	//		Topic: topic,
	//		Body:  dst,
	//	})
	//	buf.ReturnToPool()
	//}
	////注单推送
	//err := common.RocketMqProducer(rocketMQ, msgs)
	//if err != nil {
	//	_, file, line, _ := runtime.Caller(0)
	//	zlog.Error(nil, "orderNotify", fmt.Sprintf("%s:%d", file, line), err.Error(), marketId, 0)
	}
}

//串注通知
func NotifyComplex(notifies []NotifyComplexBody, tourIds, gameIds []string, marketId uint64) {

	//notify
	//tourNames, _ := common.RedisTourCnNameBatchGet(traderRedis, tourIds)
	//gameNames, _ := common.RedisGameNameBatchGet(traderRedis, gameIds)
	//var msgs []*primitive.Message

	for _, order := range notifies {

		_ = common.MqttPushOrderDetailStatus(cli, order.MemberID, order.ID, order.CID, order.Status, order.COdd, order.Reason)
		if order.NotifySimple {
			_ = common.MqttPushOrderStatus(cli, order.MemberID, order.ID, order.BetStatus, order.TheoryPrize, order.Odd, 0)
		}

	//	prefix := order.MerchantID
	//	if confTenancy {
	//		prefix = order.ParentMerchantID
	//	}
	//
	//	topic := fmt.Sprintf("%d_order", prefix)
	//	if tourName, ok1 := tourNames[order.TournamentID]; ok1 {
	//		order.TournamentName = tourName
	//	}
	//	if gameName, ok2 := gameNames[order.GameID]; ok2 {
	//		order.GameName = gameName
	//	}
	//
	//	buf := jingo.NewBufferFromPool()
	//	notifyComplexData.Marshal(&order, buf)
	//	dst := make([]byte, len(buf.Bytes))
	//	copy(dst, buf.Bytes)
	//	msgs = append(msgs, &primitive.Message{
	//		Topic: topic,
	//		Body:  dst,
	//	})
	//	buf.ReturnToPool()
	//}
	////注单推送
	//err := common.RocketMqProducer(rocketMQ, msgs)
	//if err != nil {
	//	_, file, line, _ := runtime.Caller(0)
	//	zlog.Error(nil, "orderNotify", fmt.Sprintf("%s:%d", file, line), err.Error(), marketId, 0)
	}
}

//构建串关通知消息
func NotifyBuildComplexBody(simple simpleBetData, comp complexBetData, notify *NotifyComplexBody, notifySimple bool) {

	notify.ID = simple.ID
	notify.CID = comp.ID
	notify.MemberID = simple.MemberID
	notify.MemberAccount = simple.MemberAccount
	notify.MerchantID = simple.MerchantID
	notify.MerchantAccount = simple.MerchantAccount
	notify.ParentMerchantID = simple.ParentMerchantID
	notify.ParentMerchantAccount = simple.ParentMerchantAccount
	notify.Tester = simple.Tester
	notify.OrderType = simple.OrderType
	notify.ParleyType = simple.ParleyType
	notify.GameID = comp.GameID
	notify.GameName = comp.GameName
	notify.TournamentID = comp.TournamentID
	notify.TournamentName = comp.TournamentName
	notify.MatchID = comp.MatchID
	notify.MatchType = comp.MatchType
	notify.MarketID = comp.MarketID
	notify.MarketCnName = comp.MarketCnName
	notify.TeamNames = comp.TeamNames
	notify.TeamID = comp.TeamID
	notify.OddID = comp.OddID
	notify.OrgOddID = comp.OrgOddID
	notify.OddName = comp.OddName
	notify.Odd = simple.Odd
	notify.COdd = comp.Odd
	notify.Round = comp.Round
	notify.BetIP = simple.BetIP
	notify.Device = simple.Device
	notify.BetAmount = simple.BetAmount
	notify.TheoryPrize = simple.TheoryPrize
	notify.WinAmount = simple.WinAmount
	notify.BetStatus = simple.BetStatus
	notify.Status = comp.Status
	notify.IsLive = comp.IsLive
	notify.ConfirmType = simple.ConfirmType
	notify.BetTime = simple.BetTime
	notify.SettleCount = simple.SettleCount
	notify.SettleTime = simple.SettleTime
	notify.MatchStartTime = comp.MatchStartTime
	notify.NotifySimple = notifySimple
	notify.Reason = comp.Reason
}

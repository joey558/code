package settle

import (
	"djTask/contrib/zlog"
	"djTask/modules/common"
	"djTask/wallet"
	"fmt"
	"github.com/bsm/redislock"
	g "github.com/doug-martin/goqu/v9"
	"github.com/shopspring/decimal"
	"time"
)

// 注单数据
type simpleBetData struct {
	ID                    uint64 `db:"id" json:"id"`                                              //注单ID
	MemberID              uint64 `db:"member_id" json:"member_id"`                                //会员ID
	MemberAccount         string `db:"member_account" json:"member_account"`                      //会员账号
	MerchantID            uint64 `db:"merchant_id" json:"merchant_id"`                            //商户ID
	MerchantAccount       string `db:"merchant_account" json:"merchant_account"`                  //商户账号
	ParentMerchantID      uint64 `db:"parent_merchant_id" json:"parent_merchant_id"`              //父商户ID
	ParentMerchantAccount string `db:"parent_merchant_account" json:"parent_merchant_account"`    //父商户账号
	TopMerchantId         uint64 `db:"top_merchant_id" json:"top_merchant_id"`                    //顶层商户ID
	TopMerchantAccount    string `db:"top_merchant_account" json:"top_merchant_account"`          //顶层商户名称
	SortLevel             string `db:"sort_level" json:"sort_level" rule:"chn" name:"sort_level"` //商户排序层级
	Deph                  uint64 `db:"deph" json:"deph" rule:"chn" name:"deph"`                   //商户层深
	Tester                uint8  `db:"tester" json:"tester"`                                      //是否测试账户
	OrderType             uint8  `db:"order_type" json:"order_type"`                              //注单类型 1普通注单 2串关注单 3局内串关 4复合玩法
	ParleyType            int    `db:"parley_type" json:"parley_type"`                            //串关类型 1普通注单 2:2串1  3:3串1 4:4串1 5:5串1 6:6串1 7:7串1 8:8串1
	GameID                string `db:"game_id" json:"game_id"`                                    //游戏ID
	TournamentID          string `db:"tournament_id" json:"tournament_id"`                        //联赛ID
	MatchID               string `db:"match_id" json:"match_id"`                                  //比赛ID
	MatchType             int    `db:"match_type" json:"match_type"`                              //赛事类型 1-正常 2-冠军  3-大逃杀
	MarketID              string `db:"market_id" json:"market_id"`                                //盘口ID
	MarketCnName          string `db:"market_cn_name" json:"market_cn_name"`                      //盘口中文名称
	TeamNames             string `db:"team_names" json:"team_names"`                              //队伍名称
	TeamID                string `db:"team_id" json:"team_id"`                                    //战队id
	OddID                 string `db:"odd_id" json:"odd_id"`                                      //投注项ID
	OrgOddID              string `db:"org_odd_id" json:"org_odd_id"`                              //玩法ID
	OddName               string `db:"odd_name" json:"odd_name"`                                  //投注项名称
	Odd                   string `db:"odd" json:"odd"`                                            //赔率
	OrgOdd                string `db:"org_odd" json:"org_odd"`                                    //原始赔率
	Round                 int    `db:"round" json:"round"`                                        //第几局
	BetIP                 uint32 `db:"bet_ip" json:"bet_ip"`                                      //投注IP
	Device                uint32 `db:"device" json:"device"`                                      //设备 [1-PC  2-H5  3-Android  4-IOS]
	BetAmount             string `db:"bet_amount" json:"bet_amount"`                              //注单金额
	TheoryPrize           string `db:"theory_prize" json:"theory_prize"`                          //预期派彩金额
	WinAmount             string `db:"win_amount" json:"win_amount"`                              //派彩金额
	BetStatus             int    `db:"bet_status" json:"bet_status"`                              //注单状态 1-待确认 2-已拒绝 3-待结算 4-已取消 5-已中奖 6-未中奖 7-已撤销
	IsLive                int    `db:"is_live" json:"is_live"`                                    //赛事阶段 1-初盘 2-滚盘
	ConfirmType           int    `db:"confirm_type" json:"confirm_type"`                          //确认方式 1-自动确认 2-手动待确认 3-手动确认 4-手动拒绝
	BetTime               int64  `db:"bet_time" json:"bet_time"`                                  //投注时间
	SettleCount           uint64 `db:"settle_count" json:"settle_count"`                          //结算次数
	SettleTime            int64  `db:"settle_time" json:"settle_time"`                            //结算时间
	MatchStartTime        int64  `db:"match_start_time" json:"match_start_time"`                  //赛事开始时间
	Reason                int    `db:"reason" json:"reason"`                                      //撤销理由
	OddDiscount           string `db:"odd_discount" json:"odd_discount"`                          //赔率折扣
	AgentID               uint64 `db:"agent_id" json:"agent_id"`                                  //直属代理ID
	AgentAccount          string `db:"agent_account" json:"agent_account"`                        //直属代理账号
}

/**
* @Description: 单注中奖结算（一单）
* @Author: brandon
* @Date: 2020/7/8 7:41 下午
* @LastEditTime: 2020/7/8 7:41 下午
* @LastEditors: brandon
 */
func simpleSettleOneWin(order simpleBetData, settleCount uint64) (simpleBetData, bool, error) {

	//初始化通知信息
	tm := time.Now().Unix()
	notify := order

	key := fmt.Sprintf("lock_%d", order.MemberID)
	lock, err := locker.Obtain(key, 60*time.Second, nil)
	if err == redislock.ErrNotObtained {
		return notify, false, fmt.Errorf("key: %s could not obtain lock", key)
	} else if err != nil {
		return notify, false, fmt.Errorf("obtain lock failed, err: %s", err.Error())
	}
	defer lock.Release()

	// 更新单注已中奖
	simpleV := g.Record{
		"bet_status":   common.OrderStatusWin,
		"settle_count": settleCount,
		"settle_time":  tm,
		"update_time":  tm,
		"win_amount":   order.TheoryPrize,
	}

	// 信用盘注单结算时更新会员当前所属代理
	if order.Tester == common.UserTypeCredit {
		u, err := common.RedisGetMember(merchantRedis, order.MerchantID, order.MemberAccount)
		if err != nil {
			return notify, false, err
		}
		simpleV["agent_id"] = u.AgentID
		simpleV["agent_account"] = u.AgentAccount
		order.AgentID = u.AgentID
		order.AgentAccount = u.AgentAccount
	}

	query, _, _ := dialect.Update("tbl_bet_order").Set(simpleV).Where(g.Ex{"id": order.ID, "bet_status": common.OrderStatusWaitSettle}).ToSQL()
	fmt.Println(query)
	res, err := dbx.Exec(query)
	if err != nil {
		return notify, false, err
	}

	if n, _ := res.RowsAffected(); n == 0 {
		zlog.Info(nil, "orderSettle", "", fmt.Sprintf("order:%d update to win failed, maybe status invalid", order.ID), order.MarketID, 0)
		return notify, false, nil
	}

	// 账变金额
	amount, err := decimal.NewFromString(order.TheoryPrize)
	// 信用注单插入账变记录，现金盘注单派彩并插入账变记录
	err = settleTransfer(order, amount, wallet.TransBetPrize)
	if err != nil {
		// 信用注单派彩失败，回滚注单状态
		if order.Tester == common.UserTypeCredit {
			zlog.Info(nil, "orderSettle", "", fmt.Sprintf("credit order:[%d] credit wallet payout fail,  error:%s", order.ID, err.Error()), order.MarketID, 0)
			resetSimpleV := g.Record{
				"bet_status":   common.OrderStatusWaitSettle,
				"settle_count": settleCount - 1,
				"win_amount":   "0",
			}
			query, _, _ = dialect.Update("tbl_bet_order").Set(resetSimpleV).Where(g.Ex{"id": order.ID, "bet_status": common.OrderStatusWin}).ToSQL()
			fmt.Println(query)
			_, rollbackErr := dbx.Exec(query)
			if rollbackErr != nil {
				zlog.Error(nil, "orderSettle", "", fmt.Sprintf("credit order[%d] sent awards fail, reset order status fail! error:%s", order.ID, rollbackErr.Error()), order.ID, 0)
				return notify, false, nil
			}
			// 信用网中心钱包派彩失败，未避免中心钱包长时间超时，导致结算复合负载超限宕机，程序不再重试结算派彩，需要操盘手重新发起结算
			return notify, false, nil
		}
		return notify, false, err
	}

	notify.BetStatus = common.OrderStatusWin
	notify.SettleCount = settleCount
	notify.SettleTime = tm
	notify.WinAmount = order.TheoryPrize

	return notify, true, nil
}

/**
* @Description: 单注未结算撤销
* @Author: brandon
* @Date: 2020/7/8 9:24 下午
* @LastEditTime: 2020/7/8 9:24 下午
* @LastEditors: brandon
 */
func simpleCancelOne(order simpleBetData, flag int) (simpleBetData, error) {

	var (
		transType   int
		betStatus   int
		rollbackErr error
	)
	// 取消已结算注单
	if flag == common.CancelTypeSettled {
		transType = wallet.TransBetUndo
		betStatus = common.OrderStatusUndo
	} else { // 取消未结算注单
		transType = wallet.TransBetCancel
		betStatus = common.OrderStatusCancelled
	}

	notify := order
	amount, err := decimal.NewFromString(order.BetAmount)
	if err != nil {
		return notify, err
	}

	//更新注单状态
	tm := time.Now().Unix()
	//修改注单状态为撤销
	simpleV := g.Record{
		"bet_status":  betStatus,
		"reason":      order.Reason,
		"settle_time": tm,
		"update_time": tm,
		"win_amount":  "0",
	}

	// 信用盘注单取消时更新会员当前所属代理
	if order.Tester == common.UserTypeCredit {
		u, err := common.RedisGetMember(merchantRedis, order.MerchantID, order.MemberAccount)
		if err != nil {
			return notify, err
		}
		simpleV["agent_id"] = u.AgentID
		simpleV["agent_account"] = u.AgentAccount
		order.AgentID = u.AgentID
		order.AgentAccount = u.AgentAccount
	}

	ex := g.Ex{
		"id": order.ID,
		"bet_status": []int{
			common.OrderStatusWaitConfirm,
			common.OrderStatusWaitSettle,
			common.OrderStatusWin,
			common.OrderStatusLose,
		},
	}

	query, _, _ := dialect.Update("tbl_bet_order").Set(simpleV).Where(ex).ToSQL()
	fmt.Println(query)
	res, err := dbx.Exec(query)
	if err != nil {
		return notify, err
	}
	if n, _ := res.RowsAffected(); n == 0 {
		return notify, fmt.Errorf("order:%d update to cancel failed, maybe status invalid", order.ID)
	}

	// 信用注单派彩失败，回滚注单状态
	fnRollback := func() error {
		if order.Tester == common.UserTypeCredit {
			rollbackV := g.Record{
				"bet_status": order.BetStatus,
			}
			if order.BetStatus == common.OrderStatusWin {
				rollbackV["win_amount"] = order.WinAmount
			}
			query, _, _ = dialect.Update("tbl_bet_order").Set(rollbackV).Where(g.Ex{"id": order.ID}).ToSQL()
			fmt.Println(query)
			_, rollbackErr = dbx.Exec(query)
			if rollbackErr != nil {
				zlog.Error(nil, "orderSettle", "", fmt.Sprintf("simple credit order[%d] sent awards fail, reset order status fail! error:%s", order.ID, rollbackErr.Error()), order.ID, 0)
				return rollbackErr
			}
		}

		return nil
	}

	//中奖扣除奖金
	if order.BetStatus == common.OrderStatusWin {

		prize, err := decimal.NewFromString(order.WinAmount)
		if err != nil {
			return notify, err
		}

		//中奖扣除奖金
		err = settleTransfer(order, prize, wallet.TransBetPrizeDeduct)
		if err != nil {
			rollbackErr = fnRollback()
			if rollbackErr != nil {
				return notify, nil
			}
			return notify, err
		}
	}

	notify.WinAmount = "0"
	notify.BetStatus = betStatus
	notify.SettleTime = tm

	//回退投注金额
	err = settleTransfer(order, amount, transType)
	if err != nil {
		rollbackErr = fnRollback()
		if rollbackErr != nil {
			return notify, nil
		}
		return notify, err
	}


	return notify, nil
}

/**
 * @Description: 根据条件查询多条注单记录
 * @Author: wesley
 * @Date: 2020/7/6 16:14
 * @LastEditTime: 2020/7/6 16:14
 * @LastEditors: wesley
 */
func simpleBetFindAll(ex g.Ex) ([]simpleBetData, error) {

	var data []simpleBetData

	query, _, _ := dialect.From("tbl_bet_order").Select(simpleBetColumns...).Where(ex).ToSQL()
	err := dbx.Select(&data, query)

	return data, err
}

/**
 * @Description: 根据条件查询一条注单记录
 * @Author: wesley
 * @Date: 2020/7/6 16:14
 * @LastEditTime: 2020/7/6 16:14
 * @LastEditors: wesley
 */
func simpleBetFindOne(ex g.Ex) (simpleBetData, error) {

	var data simpleBetData

	query, _, _ := dialect.From("tbl_bet_order").Select(simpleBetColumns...).Where(ex).Limit(1).ToSQL()
	err := dbx.Get(&data, query)

	return data, err
}

/**
 * @Description: 统计注单数
 * @Author: wesley
 * @Date: 2020/7/6 16:14
 * @LastEditTime: 2020/7/6 16:14
 * @LastEditors: wesley
 */
func simpleBetCount(ex g.Ex) (int, error) {

	var count int
	query, _, _ := g.Dialect("mysql").From("tbl_bet_order").Select(g.COUNT("id")).Where(ex).ToSQL()
	err := dbx.Get(&count, query)
	return count, err
}

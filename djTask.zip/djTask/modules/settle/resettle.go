package settle

import (
	"container/list"
	"database/sql"
	"djTask/contrib/zlog"
	"djTask/helper"
	"djTask/modules/common"
	wallet "djTask/wallet"
	"fmt"
	"github.com/bsm/redislock"
	g "github.com/doug-martin/goqu/v9"
	"github.com/scylladb/go-set/strset"
	"github.com/shopspring/decimal"
	"time"
)

/*
** 二次结算
 */

var resettleSimpleStatus = []int{
	common.OrderStatusWaitSettle,
	common.OrderStatusWin,
	common.OrderStatusLose,
}

var resettleComplexStatus = []int{
	common.OrderDetailStatusWaitSettle,
	common.OrderDetailStatusWin,
	common.OrderDetailStatusLose,
}

//单注重新结算
func resettleSimple(marketID uint64, oddIDs []string, settleCount uint64, flag, reason int) {

	//检查上次是否结算完成
	ex := g.Ex{
		"market_id":    marketID,
		"bet_status":   []int{common.OrderStatusWin, common.OrderStatusLose},
		"settle_count": g.Op{"lt": settleCount - 1},
	}
	count, err := simpleBetCount(ex)
	if err != nil {
		common.AddLog(common.LogError, "orderResettle", marketID, err.Error())
		return
	}
	if count > 0 {
		common.AddLog(common.LogInfo, "orderResettle", marketID, "simple order last settle not finished")
		return
	}

	//1 获取未中奖,已中奖,待开奖的订单记录
	ex = g.Ex{
		"market_id":    marketID,
		"settle_count": settleCount - 1,
		"bet_status":   resettleSimpleStatus,
	}
	simples, err := simpleBetFindAll(ex)
	if err != nil {
		common.AddLog(common.LogError, "orderResettle", marketID, err.Error())
		return
	}
	if len(simples) == 0 {
		common.AddLog(common.LogInfo, "orderResettle", marketID, "no simple order need resettle")
		return
	}

	var notifies []simpleBetData
	tourIds := strset.New()
	gameIds := strset.New()
	simpleList := list.New()

	//循环遍历
	for _, simple := range simples {

		tourIds.Add(simple.TournamentID)
		gameIds.Add(simple.GameID)

		notify, succeed, err := resettleSimpleOne(simple, oddIDs, settleCount, flag, reason)
		if err != nil {
			common.AddLog(common.LogError, "orderResettle", marketID, "order: %d simple resettle err: %s", simple.ID, err.Error())
			simpleList.PushBack(simple)
			continue
		}
		if succeed {
			notifies = append(notifies, notify)
		}
	}

	for simpleList.Len() != 0 {

		elem := simpleList.Front()
		simple := elem.Value.(simpleBetData)
		common.AddLog(common.LogInfo, "orderResettle", marketID, "simplex: [%+v] retrying", simple)

		//重新结算主体逻辑
		notify, succeed, err := resettleSimpleOne(simple, oddIDs, settleCount, flag, reason)
		if err != nil {
			common.AddLog(common.LogError, "orderResettle", marketID, "order: %d simple resettle err: %s", simple.ID, err.Error())
			simpleList.MoveToBack(elem)
			continue
		}

		if succeed {
			notifies = append(notifies, notify)
		}
		simpleList.Remove(elem)
	}

	//notify
	if len(notifies) > 0 {
		NotifySimple(notifies, tourIds.List(), gameIds.List(), marketID)
	}
}

//串注重新结算
func resettleComplex(marketID uint64, oddIDs []string, settleCount uint64, flag, reason int) {

	//检查上次是否结算完成
	ex := g.Ex{
		"market_id":    marketID,
		"status":       []int{common.OrderDetailStatusLose, common.OrderDetailStatusWin},
		"settle_count": g.Op{"lt": settleCount - 1},
	}
	count, err := complexBetCount(ex)
	if err != nil {
		common.AddLog(common.LogError, "orderResettle", marketID, err.Error())
		return
	}
	if count > 0 {
		common.AddLog(common.LogInfo, "orderResettle", marketID, "complex order last settle not finished")
		return
	}

	ex = g.Ex{
		"market_id":    marketID,
		"settle_count": settleCount - 1,
		"status":       resettleComplexStatus,
	}
	//1.获取盘口所有串注注单
	comps, err := complexBetFindAll(ex)
	if err != nil {
		common.AddLog(common.LogError, "orderResettle", marketID, err.Error())
		return
	}

	if len(comps) == 0 {
		common.AddLog(common.LogInfo, "orderResettle", marketID, "no complex order need resettle")
		return
	}

	var succeed bool
	var notifies []NotifyComplexBody
	tourIds := strset.New()
	gameIds := strset.New()
	compList := list.New()

	for _, comp := range comps {

		gameIds.Add(comp.GameID)
		tourIds.Add(comp.TournamentID)
		notify := &NotifyComplexBody{}

		succeed, err = resettleComplexOne(comp, notify, oddIDs, settleCount, flag, reason)
		if err != nil {
			common.AddLog(common.LogError, "orderResettle", marketID, "detail: %d complex resettle err: %s", comp.ID, err.Error())
			// 查询注单不存在，则不进行重试
			if err != sql.ErrNoRows {
				compList.PushBack(comp)
			}
			continue
		}
		if succeed {
			notifies = append(notifies, *notify)
		}
	}

	for compList.Len() != 0 {

		elem := compList.Front()
		comp := elem.Value.(complexBetData)
		notify := &NotifyComplexBody{}
		common.AddLog(common.LogInfo, "orderResettle", marketID, "complex: [%+v] retrying", comp)

		succeed, err = resettleComplexOne(comp, notify, oddIDs, settleCount, flag, reason)
		if err != nil {
			common.AddLog(common.LogError, "orderResettle", marketID, "detail: %d complex resettle err: %s", comp.ID, err.Error())
			compList.MoveToBack(elem)
			continue
		}

		if succeed {
			notifies = append(notifies, *notify)
		}
		compList.Remove(elem)
	}

	//通知调用
	if len(notifies) > 0 {
		NotifyComplex(notifies, tourIds.List(), gameIds.List(), marketID)
	}
}

//单注单条记录重新结算
func resettleSimpleOne(simple simpleBetData, winOddIds []string, settleCount uint64, flag, reason int) (simpleBetData, bool, error) {

	notify := simple
	key := fmt.Sprintf("lock_%d", simple.MemberID)
	lock, err := locker.Obtain(key, 60*time.Second, nil)
	if err == redislock.ErrNotObtained {
		return notify, false, fmt.Errorf("key: %s could not obtain lock", key)
	} else if err != nil {
		return notify, false, fmt.Errorf("obtain lock failed, err: %s", err.Error())
	}
	defer lock.Release()

	//构建notify
	ctime := time.Now().Unix()
	notify.SettleTime = ctime
	notify.SettleCount = settleCount

	bet, _ := decimal.NewFromString(simple.BetAmount)
	prize, err := decimal.NewFromString(simple.TheoryPrize)
	if err != nil {
		return notify, false, err
	}
	simpleRecord := g.Record{
		"update_time":  ctime,
		"settle_time":  ctime,
		"settle_count": settleCount,
	}
	// 信用盘注单结算时更新会员当前所属代理
	if simple.Tester == common.UserTypeCredit {
		u, err := common.RedisGetMember(merchantRedis, simple.MerchantID, simple.MemberAccount)
		if err != nil {
			return notify, false, err
		}
		simpleRecord["agent_id"] = u.AgentID
		simpleRecord["agent_account"] = u.AgentAccount
		simple.AgentID = u.AgentID
		simple.AgentAccount = u.AgentAccount
	}
	simpleEx := g.Ex{
		"id":           simple.ID,
		"settle_count": settleCount - 1,
	}

	if 2 == flag { //取消逻辑

		simpleRecord["odd"] = "1"
		simpleRecord["win_amount"] = "0"
		simpleRecord["theory_prize"] = "0"
		simpleRecord["bet_status"] = common.OrderStatusCancelled
		simpleRecord["reason"] = reason

		notify.Odd = "1"
		notify.WinAmount = "0"
		notify.TheoryPrize = "0"
		notify.BetStatus = common.OrderStatusCancelled
		notify.Reason = reason

		query, _, _ := dialect.Update("tbl_bet_order").Set(simpleRecord).Where(simpleEx).ToSQL()
		fmt.Println(query)
		res, err := dbx.Exec(query)
		if err != nil {
			return notify, false, err
		}
		if n, _ := res.RowsAffected(); n == 0 {
			zlog.Info(nil, "orderResettle", "", fmt.Sprintf("order:%d update to resettle failed, maybe status invalid", simple.ID), simple.MarketID, 0)
			return notify, false, nil
		}

		if simple.BetStatus == common.OrderStatusWin {
			//扣除派奖
			err = settleTransfer(simple, prize, wallet.TransBetPrizeDeduct)
			if err != nil {
				return notify, false, err
			}
		}
		//回退投注金额
		err = settleTransfer(simple, bet, wallet.TransBetCancel)
		if err != nil {
			return notify, false, err
		}
		return notify, true, nil
	}

	//重新结算逻辑
	var won bool
	winAmount := "0"
	status := common.OrderStatusLose
	if isWinnerOddID(winOddIds, simple.OddID) {
		won = true
		status = common.OrderStatusWin
		winAmount = simple.TheoryPrize
	}

	simpleRecord["win_amount"] = winAmount
	simpleRecord["bet_status"] = status
	notify.WinAmount = winAmount
	notify.BetStatus = status
	query, _, _ := dialect.Update("tbl_bet_order").Set(simpleRecord).Where(simpleEx).ToSQL()
	fmt.Println(query)
	res, err := dbx.Exec(query)
	if err != nil {
		return notify, false, err
	}
	if n, _ := res.RowsAffected(); n == 0 {
		zlog.Info(nil, "orderResettle", "", fmt.Sprintf("order:%d update to resttled failed, maybe status invalid", simple.ID), simple.MarketID, 0)
		return notify, false, nil
	}

	if simple.BetStatus == common.OrderStatusWin {
		//扣除派奖
		err = settleTransfer(simple, prize, wallet.TransBetPrizeDeduct)
		if err != nil {
			return notify, false, err
		}
	}
	if won {
		//设置中奖
		err = settleTransfer(simple, prize, wallet.TransBetPrize)
		if err != nil {
			return notify, false, err
		}
	}

	return notify, true, nil
}

//串注单条记录重新结算
func resettleComplexOne(comp complexBetData, notify *NotifyComplexBody, winOddIds []string, settleCount uint64, flag, reason int) (bool, error) {

	simple, err := simpleBetFindOne(g.Ex{"id": comp.OrderID})
	if err != nil {
		return false, err
	}

	key := fmt.Sprintf("lock_%d", simple.MemberID)
	lock, err := locker.Obtain(key, 60*time.Second, nil)
	if err == redislock.ErrNotObtained {
		return false, fmt.Errorf("key: %s could not obtain lock", key)
	} else if err != nil {
		return false, fmt.Errorf("obtain lock failed, err: %s", err.Error())
	}
	defer lock.Release()

	bet, _ := decimal.NewFromString(simple.BetAmount)
	oldPrize, err := decimal.NewFromString(simple.TheoryPrize)
	if err != nil {
		return false, err
	}
	deductPrize := false
	if simple.BetStatus == common.OrderStatusWin {
		deductPrize = true
	}

	ctime := time.Now().Unix()
	detailV := g.Record{
		"update_time":  ctime,
		"settle_count": settleCount,
		"settle_time":  ctime,
	}

	var detailStatus int
	//更新子单状态
	if 2 == flag {
		//2次取消
		detailV["odd"] = "1"
		detailV["status"] = common.OrderDetailStatusCancelled
		detailV["reason"] = reason
		detailStatus = common.OrderDetailStatusCancelled
		comp.Odd = "1"
		comp.Reason = reason
	} else {
		//2次结算
		detailStatus = common.OrderDetailStatusWin
		if !isWinnerOddID(winOddIds, comp.OddID) {
			detailStatus = common.OrderDetailStatusLose
		}
		detailV["status"] = detailStatus
	}

	query, _, _ := dialect.Update("tbl_order_detail").Set(detailV).Where(g.Ex{"id": comp.ID}).ToSQL()
	fmt.Println(query)
	res, err := dbx.Exec(query)
	if err != nil {
		return false, err
	}
	if n, _ := res.RowsAffected(); n == 0 {
		zlog.Info(nil, "orderResettle", "", fmt.Sprintf("order_detail: %d update to resttled failed, maybe status invalid", comp.ID), comp.MarketID, 0)
		return false, nil
	}

	comp.SettleCount = settleCount
	comp.SettleTime = ctime
	comp.Status = detailStatus
	// 统计串注子单
	complexStat, err := complexBetCalcStat(comp.OrderID)
	if err != nil {
		return false, err
	}

	//新奖金和新赔率
	var (
		prize decimal.Decimal
		odds  decimal.Decimal
	)
	if simple.OrderType == common.OrderTypeComplex {
		prize, odds = complexCalcPrize(bet, complexStat.Odds)
	} else if simple.OrderType == common.OrderTypeRndComplex {
		prize, odds, err = rndComplexCalcPrize(bet, complexStat.Odds, simple.OddDiscount)
		if err != nil {
			return false, err
		}
	} else if simple.OrderType == common.OrderTypeMix {
		prize, odds, err = complexComposite(bet, complexStat.Odds, simple.OddDiscount)
		if err != nil {
			return false, err
		}
	}

	prize, err = decimal.NewFromString(helper.TrimStr(prize))
	if err != nil {
		return false, err
	}

	masterStatus := common.OrderStatusWaitSettle
	back, resend := false, false
	simple.Odd = odds.String()
	simple.TheoryPrize = prize.String()
	masterRecord := g.Record{
		"update_time":  ctime,
		"odd":          odds.String(),
		"theory_prize": prize.String(),
	}
	// 信用盘注单结算时更新会员当前所属代理
	if simple.Tester == common.UserTypeCredit {
		u, err := common.RedisGetMember(merchantRedis, simple.MerchantID, simple.MemberAccount)
		if err != nil {
			return false, err
		}
		masterRecord["agent_id"] = u.AgentID
		masterRecord["agent_account"] = u.AgentAccount
		simple.AgentID = u.AgentID
		simple.AgentAccount = u.AgentAccount
	}

	if complexStat.Lost > 0 {

		masterRecord["settle_count"] = settleCount
		masterRecord["settle_time"] = ctime
		masterRecord["win_amount"] = "0"
		simple.SettleCount = settleCount
		simple.SettleTime = ctime
		simple.WinAmount = "0"
		masterStatus = common.OrderStatusLose

	} else {
		if complexStat.Canceled == complexStat.Total {

			masterRecord["settle_count"] = settleCount
			masterRecord["settle_time"] = ctime
			masterRecord["win_amount"] = "0"
			simple.SettleCount = settleCount
			simple.SettleTime = ctime
			simple.WinAmount = "0"
			masterStatus = common.OrderStatusCancelled
			back = true

		} else if complexStat.UnSettle == 0 {

			masterRecord["settle_count"] = settleCount
			masterRecord["settle_time"] = ctime
			masterRecord["win_amount"] = prize.String()
			simple.SettleCount = settleCount
			simple.SettleTime = ctime
			simple.WinAmount = prize.String()
			masterStatus = common.OrderStatusWin
			resend = true
		}
	}

	masterRecord["bet_status"] = masterStatus
	simple.BetStatus = masterStatus
	//更新主单状态
	query, _, _ = dialect.Update("tbl_bet_order").Set(masterRecord).Where(g.Ex{"id": comp.OrderID}).ToSQL()
	fmt.Println(query)
	res, err = dbx.Exec(query)
	if err != nil {
		return false, err
	}
	if n, _ := res.RowsAffected(); n == 0 {
		zlog.Info(nil, "orderResettle", "", fmt.Sprintf("order:%d update to resettled failed, maybe status invalid", comp.OrderID), comp.MarketID, 0)
		return false, nil
	}

	if deductPrize {
		//本身中奖，扣除派奖
		err = settleTransfer(simple, oldPrize, wallet.TransBetPrizeDeduct)
		if err != nil {
			return false, err
		}
	}

	if back {
		//取消返款
		err = settleTransfer(simple, bet, wallet.TransBetCancel)
		if err != nil {
			return false, err
		}
	}
	if resend {
		//中奖
		err = settleTransfer(simple, prize, wallet.TransBetPrize)
		if err != nil {
			return false, err
		}
	}

	NotifyBuildComplexBody(simple, comp, notify, true)
	return true, nil
}

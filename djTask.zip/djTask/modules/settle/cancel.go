package settle

import (
	"djTask/calc"
	"djTask/contrib/validator"
	"djTask/contrib/zlog"
	"djTask/helper"
	"djTask/modules/common"
	"fmt"
	"runtime"
	"strconv"
	"strings"

	g "github.com/doug-martin/goqu/v9"
	"github.com/scylladb/go-set/strset"
	"github.com/shopspring/decimal"
)

/**
 * @Description: 撤单
 * @Author: wesley
 * @Date: 2020/7/6 15:41
 * @LastEditTime: 2020/7/6 15:41
 * @LastEditors: wesley
 */
func cancelHandle(h *common.BeansHandler, m common.BeansMessage) bool {

	//数据格式ids=123,234,345&order_type=1&reason=201  order_type等于1单注等于2串注
	ids := strings.Split(m.Msg.Get("ids"), ",")
	if len(ids) == 0 {
		common.AddLog(common.LogError, h.Name, m.ID, "ids empty!!!")
		return true
	}
	fmt.Println(123)
	// 撤单理由
	reason, err := strconv.Atoi(m.Msg.Get("reason"))
	if err != nil {
		common.AddLog(common.LogError, h.Name, m.ID, err.Error())
		return true
	}

	orderType, err := strconv.Atoi(m.Msg.Get("order_type"))
	if err != nil {
		common.AddLog(common.LogError, h.Name, m.ID, err.Error())
		return true
	}
	switch orderType {
	case common.OrderTypeSingle:

		//单注撤单
		ex := g.Ex{
			"order_type": 1,
			"id":         ids,
			"bet_status": []int{common.OrderStatusWaitConfirm, common.OrderStatusWaitSettle, common.OrderStatusWin, common.OrderStatusLose},
		}
		orders, err := simpleBetFindAll(ex)
		if err != nil {
			common.AddLog(common.LogError, h.Name, m.ID, err.Error())
			return true
		}

		if len(orders) == 0 {
			common.AddLog(common.LogInfo, h.Name, m.ID, "ids:[%s] dont have orders need cancel!!!", ids)
			return true
		}

		for i := range orders {
			orders[i].Reason = reason
		}

		//单注撤单主程序
		cancelSimple(orders, common.CancelTypeSettled)

	case common.OrderTypeComplex, common.OrderTypeRndComplex, common.OrderTypeMix:

		//串注撤单
		ex := g.Ex{
			"id":     ids,
			"status": []int{common.OrderDetailStatusWaitSettle, common.OrderDetailStatusWin, common.OrderDetailStatusLose},
		}
		details, err := complexBetFindAll(ex)
		if err != nil {
			common.AddLog(common.LogError, h.Name, m.ID, err.Error())
			return true
		}

		if len(details) == 0 {
			common.AddLog(common.LogInfo, h.Name, m.ID, "ids:[%s] dont have order details need cancel!!!", ids)
			return true
		}

		for i := range details {
			details[i].Reason = reason
		}

		//串注撤单主程序
		cancelComplex(details, common.CancelTypeSettled)
	default:
		common.AddLog(common.LogError, h.Name, m.ID, "order type error")
	}

	return true
}

// 单注已结算撤销
func cancelSimple(orders []simpleBetData, flag int) {

	tourIds := strset.New()
	gameIds := strset.New()
	var (
		notifies               []simpleBetData
		oddCancelCalc          calc.OddOrderCancelCalc
		fcOddCancelCalc        calc.OddOrderCancelCalc
		mktRisk                calc.MarketRiskCalc
		ok                     bool
		betAmount, theoryPirze decimal.Decimal
	)

	cancelMarkets := map[string]string{}
	cancelMarketRisk := map[string]calc.MarketRiskCalc{}
	cancelOddOrders := map[string]calc.OddOrderCancelCalc{}
	// ForeCast 取消注单map,key由oddID_round_isLive_odd拼接而成
	fcCancelOddOrders := map[string]calc.OddOrderCancelCalc{}

	for _, order := range orders {
		// 单注撤销
		notify, err := simpleCancelOne(order, flag)
		if err != nil {
			_, file, line, _ := runtime.Caller(0)
			zlog.Error(nil, "orderCancel", fmt.Sprintf("%s:%d", file, line), err.Error(), order.MarketID, 0)
			continue
		}

		cancelMarkets[order.MarketID] = order.MatchID
		tourIds.Add(order.TournamentID)
		gameIds.Add(order.GameID)
		notifies = append(notifies, notify)

		// 撤销/取消风险注单：赛事待处理风险注单数-1， 盘口风险注单数-1
		if order.BetStatus == common.OrderStatusWaitConfirm && order.ConfirmType == common.ConfirmTypeManualPrepare {
			if mktRisk, ok = cancelMarketRisk[order.MarketID]; !ok {
				cancelMarketRisk[order.MarketID] = calc.MarketRiskCalc{
					MatchID: order.MatchID,
					RiskNum: 1,
				}
			} else {
				mktRisk.RiskNum++
				cancelMarketRisk[order.MarketID] = mktRisk
			}
		}
		if order.Tester == 0 {
			betAmount, _ = decimal.NewFromString(order.BetAmount)
			theoryPirze, _ = decimal.NewFromString(order.TheoryPrize)

			newCancelCalc := calc.OddOrderCancelCalc{
				MatchID:            order.MatchID,
				MarketID:           order.MarketID,
				FloatCount:         0,
				FloatAmount:        decimal.Zero,
				FloatTheoryPrize:   decimal.Zero,
				RealityCount:       0,
				RealityAmount:      decimal.Zero,
				RealityTheoryPrize: decimal.Zero,
				Odd:                order.Odd,
				Round:              order.Round,
				IsLive:             order.IsLive,
				OddID:              order.OddID,
			}

			if oddCancelCalc, ok = cancelOddOrders[order.OddID]; !ok {
				oddCancelCalc = newCancelCalc
			}

			fcKey := fmt.Sprintf("%s_%d_%d_%s", order.OddID, order.Round, order.IsLive, order.Odd)
			if fcOddCancelCalc, ok = fcCancelOddOrders[fcKey]; !ok {
				fcOddCancelCalc = newCancelCalc
			}

			switch order.BetStatus {
			case common.OrderStatusWaitConfirm: // 待确认
				oddCancelCalc.FloatCount++
				oddCancelCalc.FloatAmount = oddCancelCalc.FloatAmount.Add(betAmount)
				oddCancelCalc.FloatTheoryPrize = oddCancelCalc.FloatTheoryPrize.Add(theoryPirze)
			case common.OrderStatusWaitSettle, common.OrderStatusWin, common.OrderStatusLose: // 待结算，已中奖，未中奖
				oddCancelCalc.RealityCount++
				oddCancelCalc.RealityAmount = oddCancelCalc.RealityAmount.Add(betAmount)
				oddCancelCalc.RealityTheoryPrize = oddCancelCalc.RealityTheoryPrize.Add(theoryPirze)

				// ForeCast的数据
				fcOddCancelCalc.RealityCount++
				fcOddCancelCalc.RealityAmount = fcOddCancelCalc.RealityAmount.Add(betAmount)
				fcOddCancelCalc.RealityTheoryPrize = fcOddCancelCalc.RealityTheoryPrize.Add(theoryPirze)
			}

			cancelOddOrders[order.OddID] = oddCancelCalc
			fcCancelOddOrders[fcKey] = fcOddCancelCalc
		}
	}

	// 更新赛事操盘注单统计
	pipe := traderRedis.TxPipeline()
	calc.OrderCancelCalc(pipe, cancelMarketRisk, cancelOddOrders)

	// 撤消注单时 更新Forecast 数据
	calc.FCOrderCancelCalc(pipe, fcCancelOddOrders)

	_, err := pipe.Exec()
	if err != nil {
		_, file, line, _ := runtime.Caller(0)
		zlog.Error(nil, "orderCancel", fmt.Sprintf("%s:%d", file, line), err.Error(), 0, 0)
	}

	// 推送操盘盘口注单变更
	for marketID, matchID := range cancelMarkets {
		_ = common.MqttPushMarketOrderBet(cli, matchID, marketID)
	}

	// 撤销注单引起浮动盈亏变化，需要监控盘口预警状态
	for k, v := range cancelOddOrders {
		err = common.BeansTaskMarketMonitor(zkbPool, v.MatchID, v.MarketID, k)
		if err != nil {
			zlog.Info(nil, "orderCancel", "", fmt.Sprintf("add monitor task failed, error:%s", err.Error()), v.MarketID, 0)
			continue
		}
	}

	//notify
	if len(notifies) > 0 {
		NotifySimple(notifies, tourIds.List(), gameIds.List(), 0)
	}
}

//串注已结算撤销
func cancelComplex(comps []complexBetData, flag int) {

	tourIds := strset.New()
	gameIds := strset.New()
	var notifies []NotifyComplexBody
	cancelOddOrders := map[string]calc.OddOrderCancelCalc{}
	for _, comp := range comps {

		//主逻辑开始
		notify := &NotifyComplexBody{}
		err := complexCancelOne(comp, notify, flag, cancelOddOrders)
		if err != nil {
			_, file, line, _ := runtime.Caller(0)
			zlog.Error(nil, "orderCancel", fmt.Sprintf("%s:%d", file, line), err.Error(), comp.MarketID, 0)
			continue
		}

		notifies = append(notifies, *notify)
		tourIds.Add(comp.TournamentID)
		gameIds.Add(comp.GameID)
	}

	if len(cancelOddOrders) > 0 {
		// 更新赛事操盘注单统计
		pipe := traderRedis.TxPipeline()
		calc.OrderCancelCalc(pipe, nil, cancelOddOrders)
		_, err := pipe.Exec()
		if err != nil {
			_, file, line, _ := runtime.Caller(0)
			zlog.Error(nil, "orderCancel", fmt.Sprintf("%s:%d", file, line), err.Error(), 0, 0)
		}

		// 撤销注单引起浮动盈亏变化，需要监控盘口预警状态
		for k, v := range cancelOddOrders {
			err = common.BeansTaskMarketMonitor(zkbPool, v.MatchID, v.MarketID, k)
			if err != nil {
				zlog.Info(nil, "orderCancel", "", fmt.Sprintf("add monitor task failed, error:%s \n", err.Error()), v.MarketID, 0)
				continue
			}
		}
	}
	//notify
	if len(notifies) > 0 {
		NotifyComplex(notifies, tourIds.List(), gameIds.List(), 0)
	}
}

/**
 * @Description: 盘口取消
 * @Author: wesley
 * @Date: 2020/7/8 16:32
 * @LastEditTime: 2020/7/8 16:32
 * @LastEditors: wesley
 */
func tradeCancelMarket(h *common.BeansHandler, m common.BeansMessage) bool {

	marketID := m.Msg.Get("market_id")
	reason := m.Msg.Get("reason")
	if !validator.CheckStringCommaDigit(marketID) {
		common.AddLog(common.LogError, "orderCancel", 0, "market:[%s] err ", marketID)
		return true
	}
	mapReason := map[string]int{}
	if reason != "" {
		err := helper.JsonUnmarshalFromString(reason, &mapReason)
		if err != nil {
			common.AddLog(common.LogError, "orderCancel", 0, "reason:[%s] err ", reason)
			return true
		}
	}
	ids := strings.Split(marketID, ",")
	// 取消盘口单注注单
	cancelMarketSimple(ids, mapReason, 0)
	// 取消盘口串注注单
	cancelMarketComplex(ids, mapReason, 0)

	fmt.Println("cancel market finished")
	return true
}

/**
* @Description: 取消盘口单注订单
* @Author: brandon
* @Date: 2020/7/9 3:37 下午
* @LastEditTime: 2020/7/9 3:37 下午
* @LastEditors: brandon
 */
func cancelMarketSimple(marketIds []string, mapReason map[string]int, settleCount uint64) {

	ex := g.Ex{
		"market_id":    marketIds,
		"bet_status":   common.OrderStatusWaitSettle,
		"settle_count": settleCount,
	}
	//1.获取盘口所有串注注单
	simples, err := simpleBetFindAll(ex)
	if err != nil {
		common.AddLog(common.LogError, "orderCancel", 0, err.Error())
		return
	}

	if len(simples) == 0 {
		common.AddLog(common.LogInfo, "orderCancel", 0, "market:[%v] dont have simple need cancel!!!", marketIds)
		return
	}

	for i, o := range simples {
		if reason, ok := mapReason[o.MarketID]; ok {
			simples[i].Reason = reason
		}
	}

	// 取消未结算单注注单
	cancelSimple(simples, common.CancelTypeUnSettled)
}

/**
* @Description: 取消盘口串注订单
* @Author: brandon
* @Date: 2020/7/9 3:37 下午
* @LastEditTime: 2020/7/9 3:37 下午
* @LastEditors: brandon
 */
func cancelMarketComplex(marketIds []string, mapReason map[string]int, settleCount uint64) {

	ex := g.Ex{
		"market_id":    marketIds,
		"status":       common.OrderDetailStatusWaitSettle,
		"settle_count": settleCount,
	}
	//1.获取盘口所有串注注单
	complexes, err := complexBetFindAll(ex)
	if err != nil {
		common.AddLog(common.LogError, "orderCancel", 0, err.Error())
		return
	}

	if len(complexes) == 0 {
		common.AddLog(common.LogInfo, "orderCancel", 0, "market:[%v] dont have complex need cancel!!!", marketIds)
		return
	}

	for i, o := range complexes {
		if reason, ok := mapReason[fmt.Sprintf("%d", o.MarketID)]; ok {
			complexes[i].Reason = reason
		}
	}

	// 取消未结算串注注单
	cancelComplex(complexes, common.CancelTypeUnSettled)
}

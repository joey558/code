package settle

import (
	"container/list"
	"database/sql"
	"djTask/contrib/zlog"
	"djTask/modules/common"
	"djTask/wallet"
	"fmt"
	g "github.com/doug-martin/goqu/v9"
	"github.com/scylladb/go-set/strset"
	"github.com/shopspring/decimal"
	"runtime"
	"strconv"
	"strings"
	"time"
)

//结算
func settlesHandle(h *common.BeansHandler, m common.BeansMessage) bool {

	//数据格式 market_id=123&odd_id=234&settle_count=1&flag=1&reason=1  flag=1 盘口结算 2 盘口取消
	marketID, err := strconv.ParseUint(m.Msg.Get("market_id"), 10, 64)
	if err != nil {
		common.AddLog(common.LogError, h.Name, m.ID, err.Error())
		return true
	}

	flag, _ := strconv.Atoi(m.Msg.Get("flag"))
	if flag > 2 || flag < 1 {
		common.AddLog(common.LogError, h.Name, m.ID, "flag: "+m.Msg.Get("flag")+" not 1 or 2")
		return true
	}

	oddID := m.Msg.Get("odd_id")
	oddIDs := strings.Split(oddID, ",")
	if flag == 1 && len(oddIDs) == 0 {
		common.AddLog(common.LogError, h.Name, m.ID, "odd: %d is empty", oddID)
		return true
	}

	settleCount, _ := strconv.ParseUint(m.Msg.Get("settle_count"), 10, 64)
	if settleCount < 1 {
		common.AddLog(common.LogError, h.Name, m.ID, "settle count: %s not gte 1", m.Msg.Get("settle_count"))
		return true
	}
	reason, err := strconv.Atoi(m.Msg.Get("reason"))
	if err != nil {
		common.AddLog(common.LogError, h.Name, m.ID, "reason: %d  err: %s", reason, err.Error())
	}

	if settleCount == 1 {

		//结算锁机制
		key := fmt.Sprintf("%s_draw:%d", conf.Merchant.Account, marketID)
		lock := common.RedisLock{Pool: traderRedis, Key: key, Timeout: 2 * 60 * time.Second}
		if err = lock.Lock(); err != nil {
			common.AddLog(common.LogError, h.Name, m.ID, err.Error())
			return true
		}

		// 单注结算
		settleMarketSimple(marketID, oddIDs, settleCount)
		// 串注结算
		settleMarketComplex(marketID, oddIDs, settleCount)

		lock.Unlock()

	} else {

		resettleSimple(marketID, oddIDs, settleCount, flag, reason)
		resettleComplex(marketID, oddIDs, settleCount, flag, reason)
	}
	return true
}

// 判断注单投注项ID是否为获胜投注项ID
func isWinnerOddID(oddIDs []string, oddID string) bool {
	for _, item := range oddIDs {
		if item == oddID {
			return true
		}
	}
	return false
}

// 单注结算
func settleMarketSimple(marketID uint64, oddIDs []string, settleCount uint64) {

	tm := time.Now().Unix()
	ex := g.Ex{
		"market_id":    marketID,
		"order_type":   common.OrderTypeSingle,
		"bet_status":   common.OrderStatusWaitSettle,
		"settle_count": settleCount - 1,
	}

	orders, err := simpleBetFindAll(ex)
	if err != nil {
		_, file, line, _ := runtime.Caller(0)
		zlog.Error(nil, "orderSettle", fmt.Sprintf("%s:%d", file, line), err.Error(), marketID, 0)
		return
	}

	if len(orders) == 0 {
		zlog.Info(nil, "orderSettle", "", "no simple need settle", marketID, 0)
		return
	}

	var (
		notifies          []simpleBetData
		res               sql.Result
		n                 int64
	)
	tourIds := strset.New()
	gameIds := strset.New()
	simpleList := list.New()

	for _, v := range orders {

		tourIds.Add(v.TournamentID)
		gameIds.Add(v.GameID)

		if isWinnerOddID(oddIDs, v.OddID) {
			// 单注中奖结算
			notify, succeed, err := simpleSettleOneWin(v, settleCount)
			if err != nil {
				_, file, line, _ := runtime.Caller(0)
				errMsg := fmt.Sprintf("order_id: %d settle error: %s", v.ID, err.Error())
				zlog.Error(nil, "orderSettle", fmt.Sprintf("%s:%d", file, line), errMsg, marketID, 0)
				simpleList.PushBack(v)
				continue
			}
			if succeed {
				notifies = append(notifies, notify)
			}

		} else {
			// 更新单注未中奖
			simpleV := g.Record{
				"bet_status":   common.OrderStatusLose,
				"settle_count": settleCount,
				"settle_time":  tm,
				"update_time":  tm,
			}
			// 信用盘注单结算时更新会员当前所属代理
			if v.Tester == common.UserTypeCredit {
				u, err := common.RedisGetMember(merchantRedis, v.MerchantID, v.MemberAccount)
				if err != nil {
					_, file, line, _ := runtime.Caller(0)
					errMsg := fmt.Sprintf("order_id: %d settle, get credit member error: %s", v.ID, err.Error())
					zlog.Error(nil, "orderSettle", fmt.Sprintf("%s:%d", file, line), errMsg, marketID, 0)
					simpleList.PushBack(v)
					continue
				}
				simpleV["agent_id"] = u.AgentID
				simpleV["agent_account"] = u.AgentAccount
			}

			query, _, _ := dialect.Update("tbl_bet_order").Set(simpleV).Where(g.Ex{"id": v.ID, "bet_status": common.OrderStatusWaitSettle}).ToSQL()
			fmt.Println(query)
			res, err = dbx.Exec(query)
			if err != nil {
				_, file, line, _ := runtime.Caller(0)
				zlog.Error(nil, "orderSettle", fmt.Sprintf("%s:%d", file, line), err.Error(), marketID, 0)
				continue
			}

			if n, _ = res.RowsAffected(); n == 0 {
				zlog.Info(nil, "orderSettle", "", fmt.Sprintf("order:%d update to lose failed, maybe status invalid", v.ID), marketID, 0)
				continue
			}

			notify := v
			notify.BetStatus = common.OrderStatusLose
			notify.SettleCount = settleCount
			notify.SettleTime = tm
			notifies = append(notifies, notify)
		}
	}

	for simpleList.Len() != 0 {

		elem := simpleList.Front()
		order := elem.Value.(simpleBetData)
		zlog.Info(nil, "orderSettle", "", fmt.Sprintf("simplex: [%+v] retrying", order), marketID, 0)

		// 单注中奖结算
		notify, succeed, err := simpleSettleOneWin(order, settleCount)
		if err != nil {
			_, file, line, _ := runtime.Caller(0)
			errMsg := fmt.Sprintf("order_id: %d simple settle error: %s", order.ID, err.Error())
			zlog.Error(nil, "orderSettle", fmt.Sprintf("%s:%d", file, line), errMsg, marketID, 0)
			simpleList.MoveToBack(elem)
			continue
		}
		if succeed {
			notifies = append(notifies, notify)
		}
		simpleList.Remove(elem)
	}

	//notify
	if len(notifies) > 0 {
		NotifySimple(notifies, tourIds.List(), gameIds.List(), marketID)
	}
}

// 串注结算
func settleMarketComplex(marketID uint64, oddIDs []string, settleCount uint64) {

	ex := g.Ex{
		"market_id":    marketID,
		"status":       common.OrderDetailStatusWaitSettle,
		"settle_count": settleCount - 1,
	}
	//1.获取盘口所有串注注单
	complexes, err := complexBetFindAll(ex)
	if err != nil {
		_, file, line, _ := runtime.Caller(0)
		zlog.Error(nil, "orderSettle", fmt.Sprintf("%s:%d", file, line), err.Error(), marketID, 0)
		return
	}

	if len(complexes) == 0 {
		zlog.Info(nil, "orderSettle", "", "no complex need settle", marketID, 0)
		return
	}

	tourIds := strset.New()
	gameIds := strset.New()
	compList := list.New()
	var succeed bool
	var notifies []NotifyComplexBody
	//2.遍历结算
	for _, comp := range complexes {

		gameIds.Add(comp.GameID)
		tourIds.Add(comp.TournamentID)
		notify := &NotifyComplexBody{}
		//结算主体逻辑开始
		succeed, err = complexSettleOne(comp, notify, oddIDs, settleCount)
		if err != nil {
			_, file, line, _ := runtime.Caller(0)
			errMsg := fmt.Sprintf("order_id: %d complex settle error: %s", comp.OrderID, err.Error())
			zlog.Error(nil, "orderSettle", fmt.Sprintf("%s:%d", file, line), errMsg, marketID, 0)
			// 查询注单不存在，则不进行重试
			if err != sql.ErrNoRows {
				compList.PushBack(comp)
			}
			continue
		}
		if succeed {
			notifies = append(notifies, *notify)
		}
	}

	for compList.Len() != 0 {

		elem := compList.Front()
		comp := elem.Value.(complexBetData)
		notify := &NotifyComplexBody{}
		zlog.Info(nil, "orderSettle", "", fmt.Sprintf("complex: [%+v] retrying", comp), 0, 0)

		//结算主体逻辑开始
		succeed, err = complexSettleOne(comp, notify, oddIDs, settleCount)
		if err != nil {
			_, file, line, _ := runtime.Caller(0)
			errMsg := fmt.Sprintf("order_id: %d complex settle error: %s", comp.OrderID, err.Error())
			zlog.Error(nil, "orderSettle", fmt.Sprintf("%s:%d", file, line), errMsg, marketID, 0)
			compList.MoveToBack(elem)
			continue
		}

		if succeed {
			notifies = append(notifies, *notify)
		}
		compList.Remove(elem)
	}

	//notify
	if len(notifies) > 0 {
		NotifyComplex(notifies, tourIds.List(), gameIds.List(), marketID)
	}
}

func settleTransfer(data simpleBetData, amount decimal.Decimal, transType int) error {

	if data.Tester != common.UserTypeCredit {
		param := map[string]interface{}{
			"order_no":                fmt.Sprintf("%d", data.ID),
			"member_id":               data.MemberID,
			"member_account":          data.MemberAccount,
			"merchant_id":             data.MerchantID,
			"merchant_account":        data.MerchantAccount,
			"parent_merchant_id":      data.ParentMerchantID,
			"parent_merchant_account": data.ParentMerchantAccount,
			"top_merchant_id":         data.TopMerchantId,
			"top_merchant_account":    data.TopMerchantAccount,
			"sort_level":              data.SortLevel,
			"deph":                    data.Deph,
			"tester":                  data.Tester,
			"order_type":              data.OrderType,
		}

		// 写入账变
		return wallet.TransferX(dbx, merchantRedis, cli, param, amount, transType)
	} else {
		trans := wallet.Transaction{
			OrderNo:               fmt.Sprintf("%d", data.ID),
			MemberID:              data.MemberID,
			MemberAccount:         data.MemberAccount,
			MerchantID:            data.MerchantID,
			MerchantAccount:       data.MerchantAccount,
			ParentMerchantID:      data.ParentMerchantID,
			ParentMerchantAccount: data.ParentMerchantAccount,
			TopMerchantId:         data.TopMerchantId,
			TopMerchantAccount:    data.TopMerchantAccount,
			SortLevel:             data.SortLevel,
			Deph:                  data.Deph,
			CreatedTime:           time.Now().UnixNano() / 1e6,
			Tester:                data.Tester,
			AgentID:               data.AgentID,
			AgentAccount:          data.AgentAccount,
		}

		sToken := common.RedisGetSToken(merchantRedis, data.MemberID)
		// 中心钱包加款/派彩和写入账变
		return wallet.CreditTransfer(dbx, cli, trans, amount, transType, sToken)
	}

}

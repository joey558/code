package riskLimit

import (
	"fmt"

	"djTask/contrib/validator"
	"djTask/contrib/zlog"
	"djTask/modules/common"
	g "github.com/doug-martin/goqu/v9"
	mqtt "github.com/eclipse/paho.mqtt.golang"
	"github.com/go-redis/redis/v7"
	"github.com/jmoiron/sqlx"
	cpool "github.com/silenceper/pool"
	"strconv"
	"time"
)

var (
	conf  common.TraderCfg
	bPool cpool.Pool
	db    *sqlx.DB
	cli   mqtt.Client
	pool  *redis.Client
)

var (
	dialect = g.Dialect("mysql")
)

func Parse(endpoints []string, path string) {

	common.ParseCfg(&conf, endpoints, path)

	// 初始化mqtt推送
	cli = common.InitMqttService(conf.Mqtt)
	// 初始化延时队列
	bPool = common.InitBeanstalk(conf.Beanstalk, 50, 50, 100)
	// 初始化redis
	pool = common.InitRedis(conf.RedisMaster.Addr, conf.RedisMaster.Password, conf.RedisMaster.Sentinel, 0)
	// 初始化db
	db = common.InitDBX(conf.TraderDb.Db, conf.TraderDb.MaxIdleConn, conf.TraderDb.MaxOpenConn)
	// 初始化zlog
	zlog.New(conf.Zlog.Brokers, conf.Zlog.URI)

	defer func() {
		_ = db.Close()
		_ = pool.Close()
	}()

	run()
}

func run() {

	handler := &common.BeansHandler{
		Name:          "matchRiskLimit",
		BeansPool:     bPool,
		BeansTubeName: common.BeanStalkMatchRiskLimit,
		BeansReserve:  2 * time.Minute,
		FnPoolSize:    1000,
		Fn:            matchRiskLimit,
	}
	handler.Watch()
	handler.Release()
}

/*
 * @Description: 风控管理-限红比例设置(限红比例,返还率缩减)
 * @Author: robin
 * @Date: 2021/8/11 18:45
 * @LastEditTime: 2021/8/11 18:45
 * @LastEditors: robin
 */
func matchRiskLimit(h *common.BeansHandler, msg common.BeansMessage) bool {

	matchId := msg.Msg.Get("matchId")
	if !validator.CheckStringDigit(matchId) {
		common.AddLog(common.LogError, h.Name, msg.ID, "risk limit match id:%s error, finished", matchId)
		return true
	}

	ex := g.Ex{"id": matchId}
	match, err := MatchFindOne(ex)
	if err != nil {
		common.AddLog(common.LogError, h.Name, msg.ID, "CalRiskLimit can find matchID[%s]error: %s", matchId, err.Error())
		return true
	}

	startTime := msg.Msg.Get("startTime")
	if !validator.CheckStringDigit(startTime) {
		common.AddLog(common.LogError, h.Name, msg.ID, "match start time:%s error, finished", startTime)
		return true
	}

	strTime := fmt.Sprintf("%d", match.StartTime)
	if strTime != startTime {
		common.AddLog(common.LogError, h.Name, msg.ID, "match start time is error, strTime[%s] startTime[%s] finished", strTime, startTime)
		return true
	}

	riskId := msg.Msg.Get("id")
	if !validator.CheckStringDigit(riskId) {
		common.AddLog(common.LogError, h.Name, msg.ID, "risk limit id:%s error, finished", riskId)
		return true
	}

	id, err := strconv.Atoi(riskId)
	if err != nil {
		common.AddLog(common.LogError, h.Name, msg.ID, "risk limit id string conversion int error: %s", err.Error())
		return true
	}

	if id < 1 || id > 4 {
		common.AddLog(common.LogError, h.Name, msg.ID, "risk limit id:[%d] error, only value(1-4)", id)
		return true
	}

	dataRisk, err := GetRiskInfoFromRedis()
	if err != nil {
		common.AddLog(common.LogError, h.Name, msg.ID, "risk limit data from redis error: %s", err.Error())
		return true
	}

	if len(dataRisk) <= id {
		common.AddLog(common.LogError, h.Name, msg.ID, "risk limit id is not in redis buffer range, dataRis size:[%d], id:%d", len(dataRisk), id)
		return true
	}

	data := dataRisk[id]
	err = CalRiskLimit(match, id, data.RateLimit, data.RateReduce)
	if err != nil {
		common.AddLog(common.LogError, h.Name, msg.ID, "CalRiskLimit error: %s", err.Error())
	}

	return true
}

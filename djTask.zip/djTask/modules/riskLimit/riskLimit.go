package riskLimit

import (
	"database/sql"
	"djTask/calc"
	"djTask/helper"
	"djTask/modules/common"
	"fmt"
	g "github.com/doug-martin/goqu/v9"
	"github.com/go-redis/redis/v7"
	"github.com/shopspring/decimal"
	"sort"
	"strings"
)

var (
	colMatchData  = calc.EnumFields(MatchData{})
	colMarketData = calc.EnumFields(MarketData{})
	colOdd        = calc.EnumFields(Odd{})
	colMarket     = calc.EnumFields(Market{})
	OneDecimal    = decimal.NewFromInt(1)
)

// Match 赛事结构体
type MatchData struct {
	ID                   string        `json:"id" db:"id"`
	UpdateTime           int64         `json:"update_time" db:"update_time"`
	StartTime            int64         `json:"start_time" db:"start_time"`
	MatchLevel           int           `json:"match_level" db:"match_level"`
	CreditLevel          int           `json:"credit_level" db:"credit_level"` //信用联赛等级
	Status               int           `json:"status" db:"status"`
	MbMchPrizeLimit      int           `json:"mb_mch_prize_limit" db:"mb_mch_prize_limit"`             //会员赛事赔付
	MixMchPrizeLimit     int           `json:"mix_mch_prize_limit" db:"mix_mch_prize_limit"`           //复合玩法赛事赔付
	RateLimit            int           `json:"rate_limit" db:"rate_limit"`                             //限红比例
	RateReduce           float64       `json:"rate_reduce" db:"rate_reduce"`                           //返还率缩减
	DefaultMarket        DefaultMarket `json:"default_market" db:"-" `                                 //默认盘口列表
	MixOddDscnt          float64       `json:"mix_odd_dscnt" db:"mix_odd_dscnt"`                       //复合玩法返还率
	RndCompPrizeLimit    int           `json:"rnd_comp_prize_limit" db:"rnd_comp_prize_limit"`         // 单局串关单注赔付
	RndCompMchPrizeLimit int           `json:"rnd_comp_mch_prize_limit" db:"rnd_comp_mch_prize_limit"` // 单局串关赛事赔付
	RndCompOddDscnt      float64       `json:"rnd_comp_odd_dscnt" db:"rnd_comp_odd_dscnt"`             // 单局串关赔率折扣
}

// 盘口数据
type MarketData struct {
	ID                string  `json:"id" db:"id"`
	MatchID           string  `json:"match_id" db:"match_id"`
	OptionType        int8    `json:"option_type" db:"option_type"`
	ReturnRate        float64 `json:"return_rate" db:"return_rate"`
	DefaultReturnRate float64 `json:"default_return_rate" db:"default_return_rate"` // 限红之前-返还率默认值
	Status            int8    `json:"status" db:"status"`
	Odds              []Odd   `json:"odds"` // [程序使用] 投注项
	PrizeLimit        int     `json:"prize_limit" db:"prize_limit"`
	MbMktPrizeLimit   int     `json:"mb_mkt_prize_limit" db:"mb_mkt_prize_limit"`
	WarningProfit     int     `json:"warning_profit" db:"warning_profit"`
	StopProfit        int     `json:"stop_profit" db:"stop_profit"`
	Reason            int     `json:"reason" db:"reason"`
	PrizeStaticProfit int     `json:"prize_static_profit" db:"prize_static_profit"`
	SubMktID          string  `json:"sub_mkt_id" db:"sub_mkt_id"` // 复合盘口子盘口ID
}

// Market 盘口结构体
type Market struct {
	ID                string  `json:"id" db:"id"`
	MatchID           string  `json:"match_id" db:"match_id"`
	OptionType        int8    `json:"option_type" db:"option_type"`
	ReturnRate        float64 `json:"return_rate" db:"return_rate"`
	PrizeLimit        int     `json:"prize_limit" db:"prize_limit"`
	MbMktPrizeLimit   int     `json:"mb_mkt_prize_limit" db:"mb_mkt_prize_limit"`
	WarningProfit     int     `json:"warning_profit" db:"warning_profit"`
	StopProfit        int     `json:"stop_profit" db:"stop_profit"`
	PrizeStaticProfit int     `json:"prize_static_profit" db:"prize_static_profit"`
	Reason            int     `json:"reason" db:"reason"`
}

// Odd 投注项
type Odd struct {
	ID        string `json:"id" db:"id"`               // 投注项ID
	MatchID   string `json:"match_id" db:"match_id"`   // 赛事ID
	MarketID  string `json:"market_id" db:"market_id"` // 盘口ID
	Name      string `json:"name" db:"name"`           // 选项名称
	EnName    string `json:"en_name" db:"en_name"`     // 选项英文名称
	Odd       string `json:"odd" db:"odd"`             // 赔率
	OrgOdd    string `json:"org_odd" db:"org_odd"`     // 赔率
	Round     int    `json:"round" db:"round"`         // 赛事局数
	IsWinner  int    `json:"is_winner" db:"is_winner"` // 是否获胜 1-是 0-否
	SortID    int    `json:"sort_id" db:"sort_id"`     // 排序码
	Visible   int    `json:"visible" db:"visible"`     // 是否显示 1-显示 0-隐藏
	Suspended int    `json:"suspended" db:"suspended"` // 是否暂停 1-暂停 0-取消暂停
	TeamID    string `json:"team_id" db:"team_id"`     // 战队id
}

// 首页默认盘口
type DefaultMarket struct {
	Markets   []DefaultMarketData `json:"markets" db:"markets"`
	DefaultID string              `json:"default_id" db:"default_id"`
}
type DefaultMarketData struct {
	ID         string `json:"id" db:"id"`
	Name       string `json:"name" db:"name"`
	OptionType int8   `json:"option_type" db:"option_type"`
}

//更新盘口,以及赔率(限红比例,返还率缩减)
type MarketOddUpdate struct {
	OddUpdate    []OdUpdate
	RecordMarket MktUpdate
	MarketID     string
}

// 投注项更新
type OdUpdate struct {
	Record g.Record
	Ex     g.Ex
}

// 盘口更新
type MktUpdate struct {
	Record g.Record
	Ex     g.Ex
}

// 风控管理-限红比例设置(限红比例,返还率缩减)
type RiskWinLimit struct {
	ID           int     `db:"id" name:"id" rule:"none" json:"id"`                                     // ID
	Name         string  `db:"name" name:"name" rule:"none" json:"name"`                               // 阶段名
	StartTime    int     `db:"start_time" name:"start_time" rule:"none" json:"start_time"`             // 开始时间
	EndTime      int     `db:"end_time" name:"end_time" rule:"none" json:"end_time"`                   // 结束时间
	RateLimit    int     `db:"rate_limit" name:"rate_limit" rule:"none" json:"rate_limit"`             // 限红比例
	RateReduce   float64 `db:"rate_reduce" name:"rate_reduce" rule:"none" json:"rate_reduce"`          // 返还率缩减
	UpdateByID   uint64  `db:"update_by_id" name:"update_by_id" rule:"none" json:"update_by_id"`       // 更新ID
	UpdateByName string  `db:"update_by_name" name:"update_by_name" rule:"none" json:"update_by_name"` // 更新名称
	UpdateTime   int64   `db:"update_time" name:"update_time" rule:"none" json:"update_time"`          // 更新时间
}

// 投注项参数结构体
type OddParam struct {
	ID     string          `json:"id"`
	Name   string          `json:"name"`    // 选项名称
	EnName string          `json:"en_name"` // 选项英文名
	Odd    decimal.Decimal `json:"odd"`     // 赔率
	SortID int             `json:"sort_id"` // 排序码
	TeamID string          `json:"team_id"` // 战队id
}

/*
 * @Description: 获取风控管理-限红比例设置(限红比例,返还率缩减)基本信息
 * @Author: robin
 * @Date: 2021/8/11 19:18
 * @LastEditTime: 2021/8/11 19:18
 * @LastEditors: robin
 */
func GetRiskInfoFromRedis() ([]RiskWinLimit, error) {

	var data []RiskWinLimit
	key := fmt.Sprintf(common.RedisRiskWinLimit)
	bytes, err := pool.Get(key).Bytes()
	if err != nil {
		if err != redis.Nil {
			return data, err
		}
	}

	if bytes != nil {
		err = helper.JsonUnmarshal(bytes, &data)
		if err != nil {
			return data, err
		}
	}

	return data, err
}

/**
* @Description: 查询一条记录
* @Author:
* @Date: 2020/6/21 5:42 下午
* @LastEditTime: 2020/6/21 5:42 下午
* @LastEditors: brandon
 */
func MatchFindOne(ex g.Ex) (MatchData, error) {

	data := MatchData{}
	query, _, _ := dialect.From("tbl_matches").Where(ex).Select(colMatchData...).Limit(1).ToSQL()
	fmt.Println(query)
	err := db.Get(&data, query)
	if err == sql.ErrNoRows {
		return data, nil
	}

	return data, err
}

/*
 * @Description: 获取盘口列表
 * @Author: robin
 * @Date: 2021/8/11 19:57
 * @LastEditTime: 2021/8/11 19:57
 * @LastEditors: robin
 */
func MarketListDB(ex g.Ex) ([]MarketData, error) {

	var data []MarketData
	query, _, _ := dialect.From("tbl_markets").Select(colMarketData...).Where(ex).ToSQL()
	fmt.Println(query)
	err := db.Select(&data, query)

	return data, err
}

/*
 * @Description: 从mysql获取投注项列表
 * @Author: robin
 * @Date: 2021/8/11 20:15
 * @LastEditTime: 2021/8/11 20:15
 * @LastEditors: robin
 */
func OddListDB(ex g.Ex) ([]Odd, error) {

	var data []Odd
	query, _, _ := dialect.Select(colOdd...).From("tbl_odds").Where(ex).ToSQL()
	err := db.Select(&data, query)

	return data, err
}

/*
 * @Description: 更新赛事缓存字段(会员赛事赔付,复合玩法赛事赔付)
 * @Author: robin
 * @Date: 2021/10/6 23:39
 * @LastEditTime: 2021/10/6 23:39
 * @LastEditors: robin
 */
func MatchCacheUpdate(pipe redis.Pipeliner, record g.Record, ex g.Ex) {

	cacheFields := map[string]bool{
		"mb_mch_prize_limit":  true,
		"mix_mch_prize_limit": true,
	}

	fn := func(id string) {
		for k, v := range record {
			if cacheFields[k] {
				path := fmt.Sprintf(calc.JPathMatchField, k)
				calc.MatchCacheSet(pipe, id, path, v, true)
			}
		}
	}
	if id, ok := ex["id"]; ok {
		switch id.(type) {
		case string:
			fn(id.(string))
		case []string:
			for _, v := range id.([]string) {
				fn(v)
			}
		}
	}
}

/*
 * @Description: 更新盘口缓存字段(限红比例相关的字段)
 * @Author: robin
 * @Date: 2021/8/12 11:28
 * @LastEditTime: 2021/10/6 23:41
 * @LastEditors: robin
 */
func MarketCacheUpdate(pipe redis.Pipeliner, matchId string, record g.Record, ex g.Ex, defaultMarketId string) {

	cacheFields := map[string]bool{
		"prize_limit":         true,
		"mb_mkt_prize_limit":  true,
		"warning_profit":      true,
		"stop_profit":         true,
		"prize_static_profit": true,
	}
	fn := func(id, defaultId string) {
		for k, v := range record {
			if cacheFields[k] {
				path := fmt.Sprintf(calc.JPathMarketField, id, k)
				calc.MatchCacheSet(pipe, matchId, path, v, id == defaultMarketId)
			}
		}
	}
	if id, ok := ex["id"]; ok {
		switch id.(type) {
		case string:
			fn(id.(string), defaultMarketId)
		case []string:
			for _, v := range id.([]string) {
				fn(v, defaultMarketId)
			}
		}
	}
}

/*
 * @Description: 更新盘口投注项缓存字段
 * @Author: robin
 * @Date: 2021/8/12 11:29
 * @LastEditTime: 2021/8/12 11:29
 * @LastEditors: robin
 */
func MarketCacheOddUpdate(pipe redis.Pipeliner, matchId, marketId string, record g.Record, ex g.Ex, defaultMarketId string) {

	cacheFields := map[string]bool{
		"odd":       true,
		"is_winner": true,
		"sort_id":   true,
		"visible":   true,
		"suspended": true,
		"name":      true,
		"en_name":   true,
	}
	fn := func(id, defaultId string) {
		for k, v := range record {
			if cacheFields[k] {
				path := fmt.Sprintf(calc.JPathOddField, marketId, id, k)
				calc.MatchCacheSet(pipe, matchId, path, v, marketId == defaultMarketId)
			}
		}
	}
	if id, ok := ex["id"]; ok {
		switch id.(type) {
		case string:
			fn(id.(string), defaultMarketId)
		case []string:
			for _, v := range id.([]string) {
				fn(v, defaultMarketId)
			}
		}
	}
}

/*
 * @Description: 根据条件从数据库获取一个盘口数据
 * @Author: robin
 * @Date: 2021/8/11 21:23
 * @LastEditTime: 2021/8/11 21:23
 * @LastEditors: robin
 */
func MarketFindOne(ex g.Ex) (Market, error) {

	data := Market{}
	query, _, _ := dialect.Select(colMarket...).From("tbl_markets").Where(ex).Limit(1).ToSQL()
	err := db.Get(&data, query)
	if err == sql.ErrNoRows {
		return data, nil
	}

	return data, err
}

/*
 * @Description: 批量更新 指定赛事,以及赛事所有盘口的限红比例,返还率缩减等风控信息
 * @Author: robin
 * @Date: 2021/8/11 20:36
 * @LastEditTime: 2021/8/11 20:36
 * @LastEditors: robin
 */
func MatchMarketRiskLimitUpdate(matchId string, recordMatch g.Record, recordMarketOdd []MarketOddUpdate, ex g.Ex) error {

	dbConn, err := db.Begin()
	if err != nil {
		return err
	}

	// 更新数据库-赛事
	query, _, _ := dialect.Update("tbl_matches").Set(recordMatch).Where(ex).ToSQL()
	fmt.Println(query)
	_, err = dbConn.Exec(query)
	if err != nil {
		_ = dbConn.Rollback()
		return err
	}

	// 更新缓存-赛事
	pipe := pool.TxPipeline()
	defer pipe.Close()

	MatchCacheUpdate(pipe, recordMatch, ex)

	// 更新盘口,以及赔率
	for _, record := range recordMarketOdd {
		for _, re := range record.OddUpdate { //盘口赔率
			query, _, _ := dialect.Update("tbl_odds").Set(re.Record).Where(re.Ex).ToSQL()
			fmt.Println(query)
			_, err := dbConn.Exec(query)
			if err != nil {
				_ = dbConn.Rollback()
				return err
			}
		}

		query, _, _ := dialect.Update("tbl_markets").Set(record.RecordMarket.Record).Where(record.RecordMarket.Ex).ToSQL()
		fmt.Println(query)
		_, err = dbConn.Exec(query)
		if err != nil {
			_ = dbConn.Rollback()
			return err
		}

		// 获取默认盘口
		market, err := MarketFindOne(g.Ex{"match_id": matchId, "is_default": 1})
		if err != nil {
			_ = dbConn.Rollback()
			return err
		}

		//更新盘口信息
		pipe := pool.Pipeline()
		MarketCacheUpdate(pipe, matchId, record.RecordMarket.Record, record.RecordMarket.Ex, market.ID)

		// 更新盘口投注项缓存
		for _, rec := range record.OddUpdate {
			MarketCacheOddUpdate(pipe, matchId, record.MarketID, rec.Record, rec.Ex, market.ID)
		}
	}

	// 更新盘口 以及赔率
	_, err = pipe.Exec()
	if err != nil {
		_ = dbConn.Rollback()
		return err
	}

	return dbConn.Commit()

}

/*
 * @Description: 根据当前限红比例,返还率缩减进行计算赛事,盘口相关的限红,赔付
 * @Author: robin
 * @Date: 2021/8/12 16:42
 * @LastEditTime: 2021/8/12 16:42
 * @LastEditors: robin
 */
func CalRiskLimit(match MatchData, id, rateLimit int, rateReduce float64) error {

	var (
		mbMchPrizeLimit         int
		defaultMbMchPrizeLimit  int
		mixMchPrizeLimit        int
		defaultMixMchPrizeLimit int
	)
	//赛事-更新数据
	defaultMbMchPrizeLimit = match.MbMchPrizeLimit * 100 / match.RateLimit
	mbMchPrizeLimit = defaultMbMchPrizeLimit * rateLimit / 100 //会员赛事赔付
	defaultMixMchPrizeLimit = match.MixMchPrizeLimit * 100 / match.RateLimit
	mixMchPrizeLimit = defaultMixMchPrizeLimit * rateLimit / 100 //复合玩法赛事赔付

	recordMatch := g.Record{
		"rate_limit":          rateLimit,        //限红比例
		"rate_reduce":         rateReduce,       //返还率缩减
		"mb_mch_prize_limit":  mbMchPrizeLimit,  //会员赛事赔付
		"mix_mch_prize_limit": mixMchPrizeLimit, //复合玩法赛事赔付
	}

	// 所有盘口
	markets, err := MarketListDB(g.Ex{"match_id": match.ID, "status": []int{common.MarketStatusWaitOpen, common.MarketStatusOpen, common.MarketStatusClose}})
	if err != nil {
		return err
	}

	// 盘口的赔率
	oddsList, err := OddListDB(g.Ex{"match_id": match.ID})
	if err != nil {
		return err
	}

	// 复合玩法返还率(赔率折扣)
	compDiscount := decimal.NewFromFloat(match.MixOddDscnt).Div(decimal.NewFromInt(100))
	// 输赢玩法盘口的新投注项赔率数据
	mpWinLostOdds := map[string][]OddParam{}

	// 返还率和盘口赔率
	var (
		recordMarketOdd  []MarketOddUpdate
		oddNotify        []common.OddUpdateNotify
		prizeLimitNotify []common.MarketPrizeLimitUpdateNotify
	)
	for i, market := range markets {

		var (
			returnRate               float64
			reason                   int
			defaultPrizeStaticProfit int
			prizeStaticProfit        int
			defaultPrizeLimit        int
			prizeLimit               int
			defaultMbMktPrizeLimit   int
			mbMktPrizeLimit          int
			defaultWarningProfit     int
			warningProfit            int
			defaultStopProfit        int
			stopProfit               int
			record                   MarketOddUpdate
			winLostOddsTmp           []OddParam
			oddUpdateTmp             []OdUpdate
			oddNotifyTmp             []common.OddUpdateNotify
		)

		//复合盘口(更新字段为: 复合玩法单注赔付,复合玩法预警值,复合玩法停盘值,复合盘口投注项赔率)
		if market.OptionType == common.OptionTypeMix { // 复合玩法
			defaultPrizeLimit = market.PrizeLimit * 100 / match.RateLimit
			prizeLimit = defaultPrizeLimit * rateLimit / 100
			defaultWarningProfit = market.WarningProfit * 100 / match.RateLimit
			warningProfit = defaultWarningProfit * rateLimit / 100
			defaultStopProfit = market.StopProfit * 100 / match.RateLimit
			stopProfit = defaultStopProfit * rateLimit / 100

			market.PrizeLimit = prizeLimit       //复合玩法单注赔付
			market.WarningProfit = warningProfit //复合玩法预警值
			market.StopProfit = stopProfit       //复合玩法停盘值

			// 复合玩法盘口-投注项赔率单独处理
			for _, odd := range oddsList {
				if market.ID != odd.MarketID {
					continue
				}
				if market.OptionType == common.OptionTypeMix { // 复合玩法
					market.Odds = append(market.Odds, odd)
					continue
				}
			}
			markets[i] = market
			continue
		}

		if market.DefaultReturnRate > rateReduce {
			returnRate = market.DefaultReturnRate - rateReduce
		} else {
			returnRate = market.ReturnRate
			reason = 300
		}
		defaultPrizeStaticProfit = market.PrizeStaticProfit * 100 / match.RateLimit
		prizeStaticProfit = defaultPrizeStaticProfit * rateLimit / 100
		defaultPrizeLimit = market.PrizeLimit * 100 / match.RateLimit
		prizeLimit = defaultPrizeLimit * rateLimit / 100
		defaultMbMktPrizeLimit = market.MbMktPrizeLimit * 100 / match.RateLimit
		mbMktPrizeLimit = defaultMbMktPrizeLimit * rateLimit / 100
		defaultWarningProfit = market.WarningProfit * 100 / match.RateLimit
		warningProfit = defaultWarningProfit * rateLimit / 100
		defaultStopProfit = market.StopProfit * 100 / match.RateLimit
		stopProfit = defaultStopProfit * rateLimit / 100

		recordMarket := MktUpdate{
			Record: g.Record{
				"return_rate":         returnRate,
				"prize_static_profit": prizeStaticProfit,
				"prize_limit":         prizeLimit,
				"mb_mkt_prize_limit":  mbMktPrizeLimit,
				"warning_profit":      warningProfit,
				"stop_profit":         stopProfit,
				"reason":              reason,
			},
			Ex: g.Ex{"id": market.ID},
		}

		if reason != 300 && returnRate != market.ReturnRate { //返还率发生变更
			// 盘口的赔率
			for _, odd := range oddsList {
				if odd.MarketID != market.ID {
					continue
				}
				Odd, err := decimal.NewFromString(odd.Odd)
				if err != nil {
					return err
				}

				if market.ReturnRate == 0 {
					reason = 300
					break
				}

				oddRate := Odd.Mul(decimal.NewFromFloat(returnRate)).Div(decimal.NewFromFloat(market.ReturnRate)).Round(3)
				if oddRate.LessThan(common.MinOddDeci) {
					reason = 300
					break
				}

				if len(market.Odds) == 2 { // 两项盘最高赔率为23
					if oddRate.GreaterThan(common.MaxTwoOddDeci) {
						reason = 300
						break
					}
				}

				if oddRate.GreaterThan(common.MaxOddDeci) {
					reason = 300
					break
				}

				if market.OptionType == common.OptionTypeWinLose {
					winLostOddsTmp = append(winLostOddsTmp, OddParam{
						ID:     odd.ID,
						Odd:    oddRate,
						SortID: odd.SortID,
					})
				}

				oddUpdateTmp = append(oddUpdateTmp, OdUpdate{
					Record: g.Record{"odd": oddRate.StringFixed(3)},
					Ex:     g.Ex{"id": odd.ID},
				})

				oddNotifyTmp = append(oddNotifyTmp, common.OddUpdateNotify{
					ID:         odd.ID,
					MatchId:    odd.MatchID,
					MarketId:   odd.MarketID,
					Odd:        oddRate.StringFixed(3),
					ReturnRate: fmt.Sprintf("%v", returnRate),
				})
			}
		} // 返还率发生变更-end

		if reason == 300 {
			winLostOddsTmp = []OddParam{}
			oddUpdateTmp = []OdUpdate{}
			oddNotifyTmp = []common.OddUpdateNotify{}
			recordMarket.Record["return_rate"] = market.ReturnRate
			recordMarket.Record["reason"] = reason
		} else if reason == 0 {
			if market.OptionType == common.OptionTypeWinLose && (len(winLostOddsTmp) > 0) {
				mpWinLostOdds[market.ID] = append(mpWinLostOdds[market.ID], winLostOddsTmp...)
			}
		}

		if len(oddNotifyTmp) > 0 {
			oddNotify = append(oddNotify, oddNotifyTmp...)
		}

		prizeLimitNotify = append(prizeLimitNotify, common.MarketPrizeLimitUpdateNotify{
			MarketId:          market.ID,
			MatchId:           market.MatchID,
			ReturnRate:        returnRate,
			PrizeStaticProfit: prizeStaticProfit,
			PrizeLimit:        prizeLimit,
			MbMktPrizeLimit:   mbMktPrizeLimit,
			WarningProfit:     warningProfit,
			StopProfit:        stopProfit,
			Reason:            reason,
		})

		record = MarketOddUpdate{
			RecordMarket: recordMarket,
			OddUpdate:    oddUpdateTmp,
			MarketID:     market.ID,
		}

		recordMarketOdd = append(recordMarketOdd, record)

		markets[i] = market
	}

	if match.MixOddDscnt > 0 { //复合玩法 返还率 大于0
		// 复合玩法盘口赔率-更新
		for _, market := range markets {
			if market.OptionType != common.OptionTypeMix {
				continue
			}
			// 复合玩法盘口子盘口id
			subMktIDs := strings.Split(market.SubMktID, ",")
			if len(subMktIDs) < 2 {
				continue
			}

			// 计算复合盘口赔率
			T1Odd, T2Odd := OneDecimal, OneDecimal
			bUpdateOdd := false
			for _, subMktId := range subMktIDs {
				if subOdds, ok := mpWinLostOdds[subMktId]; ok {
					// 排序
					sort.Slice(subOdds, func(i, j int) bool {
						return subOdds[j].SortID > subOdds[i].SortID
					})

					if len(subOdds) < 2 {
						break
					}
					T1Odd = T1Odd.Mul(subOdds[0].Odd.Sub(OneDecimal).Mul(compDiscount).Add(OneDecimal))
					T2Odd = T2Odd.Mul(subOdds[1].Odd.Sub(OneDecimal).Mul(compDiscount).Add(OneDecimal))
					bUpdateOdd = true
				}
			}
			if !bUpdateOdd {
				continue
			}

			// 排序
			sort.Slice(market.Odds, func(i, j int) bool {
				return market.Odds[j].SortID > market.Odds[i].SortID
			})

			var (
				record       MarketOddUpdate
				oddUpdateTmp []OdUpdate
				oddNotifyTmp []common.OddUpdateNotify
			)
			// 复合玩法主队赔率
			oddUpdateTmp = append(oddUpdateTmp, OdUpdate{
				Record: g.Record{"odd": T1Odd.StringFixed(3)},
				Ex:     g.Ex{"id": market.Odds[0].ID, "market_id": market.ID, "match_id": market.MatchID},
			})
			oddNotifyTmp = append(oddNotifyTmp, common.OddUpdateNotify{
				ID:         market.Odds[0].ID,
				MatchId:    market.MatchID,
				MarketId:   market.ID,
				Odd:        T1Odd.StringFixed(3),
				ReturnRate: "100",
			})

			// 复合玩法客队赔率
			oddUpdateTmp = append(oddUpdateTmp, OdUpdate{
				Record: g.Record{"odd": T2Odd.StringFixed(3)},
				Ex:     g.Ex{"id": market.Odds[1].ID, "market_id": market.ID, "match_id": market.MatchID},
			})
			oddNotifyTmp = append(oddNotifyTmp, common.OddUpdateNotify{
				ID:         market.Odds[1].ID,
				MatchId:    market.MatchID,
				MarketId:   market.ID,
				Odd:        T2Odd.StringFixed(3),
				ReturnRate: "100",
			})

			recordMarket := MktUpdate{
				Record: g.Record{
					"prize_limit":    market.PrizeLimit,    //复合玩法单注赔付
					"warning_profit": market.WarningProfit, //复合玩法预警值
					"stop_profit":    market.StopProfit,    //复合玩法停盘值
				},
				Ex: g.Ex{"id": market.ID},
			}

			prizeLimitNotify = append(prizeLimitNotify, common.MarketPrizeLimitUpdateNotify{
				MarketId:      market.ID,
				MatchId:       market.MatchID,
				PrizeLimit:    market.PrizeLimit,
				WarningProfit: market.WarningProfit,
				StopProfit:    market.StopProfit,
			})

			record = MarketOddUpdate{
				RecordMarket: recordMarket,
				OddUpdate:    oddUpdateTmp,
				MarketID:     market.ID,
			}

			recordMarketOdd = append(recordMarketOdd, record)
		}
	}

	//更新赛事,盘口
	err = MatchMarketRiskLimitUpdate(match.ID, recordMatch, recordMarketOdd, g.Ex{"id": match.ID})
	if err != nil {
		return err
	}

	if id-1 > 0 {
		//发送延时消息任务-限红比例,返还率缩减
		err = common.PutDelayQueueRiskLimit(bPool, match.ID, id-1, match.StartTime)
		if err != nil {
			return err
		}
	}

	// 赛事风控参数修改,消息推送
	riskNotify := common.MatchUpdateRiskNotify{
		MatchID:              match.ID,
		RateLimit:            rateLimit,                  //限红比例
		RateReduce:           rateReduce,                 //返还率缩减
		MbMchPrizeLimit:      mbMchPrizeLimit,            //会员赛事赔付
		MixMchPrizeLimit:     mixMchPrizeLimit,           //复合玩法赛事赔付
		RndCompPrizeLimit:    match.RndCompPrizeLimit,    //局内串关单注赔付
		RndCompMchPrizeLimit: match.RndCompMchPrizeLimit, //局内串关赛事赔付
		RndCompOddDscnt:      match.RndCompOddDscnt,      //局内串关返还率
	}
	err = common.MqttNotifyMatchRiskUpdate(cli, riskNotify)
	if err != nil {
		return err
	}

	// 盘口投注项赔率更新,消息推送
	if len(oddNotify) > 0 {
		err = common.MqttNotifyOddUpdate(cli, oddNotify)
		if err != nil {
			return err
		}
	}
	// 盘口风控参数修改,消息推送
	if len(prizeLimitNotify) > 0 {
		err = common.MqttNotifyPrizeLimitUpdate(cli, prizeLimitNotify)
		if err != nil {
			return err
		}
	}

	return nil
}

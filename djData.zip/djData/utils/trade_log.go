package utils

import (
	"fmt"
	mqtt "github.com/eclipse/paho.mqtt.golang"
)

// 用户登录日志
type TDLogin struct {
	TS   string `json:"ts"`  // 登录时间
	User string `json:"usr"` // 用户
	IP   string `json:"ip"`  // IP
	UA   string `json:"ua"`  // UA标识
}

// 通用(如游戏，联赛，战队等非操盘)操作日志
type TDCommon struct {
	TS     string `json:"ts"`     // 操作时间
	User   string `json:"usr"`    // 用户
	IP     string `json:"ip"`     // IP
	Group  string `json:"grp"`    // 用户分组
	Menu   string `json:"menu"`   // 菜单名称(如：玩法管理,联赛管理...)
	Action string `json:"action"` // 操作项(如：新增玩法,添加风险会员,编辑商户...)
	Result string `json:"result"` // 操作结果
}

// 赛事操作日志
type TDMatch struct {
	TS                  string `json:"ts"`                    // 操作时间
	User                string `json:"usr"`                   // 用户
	IP                  string `json:"ip"`                    // IP
	Group               string `json:"grp"`                   // 用户分组
	Menu                string `json:"menu"`                  // 菜单名称(如：玩法管理,联赛管理...)
	Action              string `json:"action"`                // 操作项(如：新增玩法,添加风险会员,编辑商户...)
	GameID              string `json:"game_id"`               // 游戏ID
	GameShortName       string `json:"game_short_name"`       // 游戏简称
	TournamentId        string `json:"tournament_id"`         // 联赛ID
	TournamentShortName string `json:"tournament_short_name"` // 联赛简称
	Teams               string `json:"teams"`                 // 战队信息
	MatchID             string `json:"match_id"`              // 赛事ID
	Result              string `json:"result"`                // 操作结果
}

// 盘口操作日志
type TDMarket struct {
	TS                  string `json:"ts"`                    // 操作时间
	User                string `json:"usr"`                   // 用户
	IP                  string `json:"ip"`                    // IP
	Group               string `json:"grp"`                   // 用户分组
	Menu                string `json:"menu"`                  // 菜单名称(如：玩法管理,联赛管理...)
	Action              string `json:"action"`                // 操作项(如：新增玩法,添加风险会员,编辑商户...)
	GameID              string `json:"game_id"`               // 游戏ID
	GameShortName       string `json:"game_short_name"`       // 游戏简称
	TournamentId        string `json:"tournament_id"`         // 联赛ID
	TournamentShortName string `json:"tournament_short_name"` // 联赛简称
	Teams               string `json:"teams"`                 // 战队信息
	MatchID             string `json:"match_id"`              // 赛事ID
	MarketID            string `json:"market_id"`             // 盘口ID
	MarketEnName        string `json:"market_en_name"`        // 盘口名称
	Round               int16  `json:"round"`                 // 局数
	Result              string `json:"result"`                // 操作结果
	Category            int8   `json:"category"`              // 赛事类型 正常-1 冠军-2 大逃杀-3 体育-4 主播盘-5
}

/**
 * @Description: 发布日志
 * @Author: maxic
 * @Date: 2020/10/9
 * @LastEditTime: 2020/10/9
 * @LastEditors: maxic
 **/
func XPub(emqx mqtt.Client, data interface{}) error {

	topic := ""
	switch data.(type) {
	case TDLogin:
		topic = "trade_log/login"
	case TDCommon:
		topic = "trade_log/common"
	case TDMatch:
		topic = "trade_log/match"
	case TDMarket:
		topic = "trade_log/market"
	default:
		msg := "XPub invalid data type"
		Println(msg)
		return fmt.Errorf(msg)
	}

	return MQTTNotify(emqx, topic, QoSAtLeastOnce, data)
}

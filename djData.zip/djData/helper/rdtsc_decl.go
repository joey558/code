package helper

func Cputicks() (t uint64)

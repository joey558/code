package conf

import (
	"djData/helper"
	"djData/helper/mqtt_helper"
	"djData/helper/mysql_helper"
	"djData/helper/redis_helper"
	"djData/helper/rocket_mq"
)

var Cfg conf

// conf 配置结构体
type conf struct {
	DataSrv struct {
		HTTP string `json:"http"`
	} `json:"data_srv"`
	LogMode struct {
		Status int `json:"status"` //日志打印: 0-关闭,1-开启
	} `json:"log_mode"`
	ZkConf struct {
		TraderDb     *mysql_helper.MySQLConfig         `json:"trader_db"`
		RedisCluster *redis_helper.RedisConfig         `json:"zk_redis_cluster"`
		LockRedis    *redis_helper.RedisSentinelConfig `json:"lock_redis"`
		Mqtt         *mqtt_helper.MqttConfig           `json:"mqtt"`
		Emqx         *mqtt_helper.MqttConfig           `json:"emqx"`
		Zlog         *helper.LogConfig                 `json:"zlog"`
		Beanstalk    string                            `json:"beanstalk"`
		SettleMerchs []string                          `json:"settle_merch"` // 需要结算的商户名称
	} `json:"zk_conf"`

	TYApiConf struct {
		MerchantCode    string                  `json:"merchant_code"`      //商户码
		SecretKey       string                  `json:"secret_key"`         //秘钥
		QueryBetListUrl string                  `json:"query_bet_list_url"` // 拉单URL
		LoginUrl        string                  `json:"login_url"`          //登陆URL
		PlayerUrl       string                  `json:"player_url"`         //播放器URL
		MatchURL        string                  `json:"match_url"`          //赛事URL
		MarketURL       string                  `json:"market_url"`         //盘口URL
		VideoURL        string                  `json:"video_url"`          //视频URL
		TYTeamURL       string                  `json:"ty_team_url"`        //TY战队URL
		UploadTeamURL   string                  `json:"upload_team_url"`    //上传图片URL
		RocketMq        *rocket_mq.RocketMqConf `json:"rocket_mq"`
	} `json:"ty_api_conf"`
}

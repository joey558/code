package rocket_mq

import (
	"context"
	"djData/helper/beanstalk"
	"fmt"
	"github.com/apache/rocketmq-client-go/v2"
	"github.com/apache/rocketmq-client-go/v2/consumer"
	"github.com/apache/rocketmq-client-go/v2/primitive"
	"github.com/apache/rocketmq-client-go/v2/producer"
	"github.com/apache/rocketmq-client-go/v2/rlog"
	cPool "github.com/silenceper/pool"
	"log"
	"strings"
	"time"
)

type Logger struct {
	flag string
}
type RocketMqConf struct {
	ServerAddr []string `json:"server_addr"` // 服务器地址
	GroupName  string   `json:"group_name"`  // 分组名称
	AccessKey  string   `json:"access_key"`  // 服务AccessKey
	SecretKey  string   `json:"secret_key"`  // 服务SecretKey
	Model      int      `json:"model"`       // 服务SecretKey
}

const (
	TYResultTopic = "electronic_topic_market_result"
	TYMarkerTopic = "electronic_topic_market"
)

var (
	BeansPool cPool.Pool
)

func (l *Logger) Debug(msg string, fields map[string]interface{}) {
	return
}

func (l *Logger) Level(level string) {
	return
}

func (l *Logger) OutputPath(path string) (err error) {
	return
}

func (l *Logger) Info(msg string, fields map[string]interface{}) {
	return
}

func (l *Logger) Warning(msg string, fields map[string]interface{}) {

	if !strings.Contains(msg, "heart") {
		return
	}

	var flag string
	if topic, ok := fields["topic"]; ok {
		flag = getFlag(fmt.Sprintf("%v", topic))
	}
	if flag != "" {
		msg = flag + " : " + msg
	}
	err := beanstalk.BeansPutMonitorTask(BeansPool, beanstalk.MqAlertTpl, "warning", msg)
	if err != nil {
		fmt.Println("beanstalk push error")
	}
	fmt.Println(l.flag, "[warning]", msg)
}

func (l *Logger) Error(msg string, fields map[string]interface{}) {
	if len(fields) == 0 {
		msg = "Rocket服务连接失败,Error : " + msg
	}
	var flag string
	if topic, ok := fields["topic"]; ok {
		flag = getFlag(fmt.Sprintf("%v", topic))
	}
	if flag != "" {
		msg = flag + " : " + msg
	}
	err := beanstalk.BeansPutMonitorTask(BeansPool, beanstalk.MqAlertTpl, "error", msg)
	if err != nil {
		fmt.Println("beanstalk push error")
	}
	fmt.Println("[error]", msg)
}

func (l *Logger) Fatal(msg string, fields map[string]interface{}) {

	if msg == "" && len(fields) == 0 {
		return
	}
	err := beanstalk.BeansPutMonitorTask(BeansPool, beanstalk.MqAlertTpl, "fatal", msg)
	if err != nil {
		fmt.Println("beanstalk push error")
	}
	fmt.Println("[fatal]", msg)
}
func getFlag(topic string) string {

	switch topic {
	case TYResultTopic:
		return "自动结算RocketMQ"
	case TYMarkerTopic:
		return "自动变赔RocketMQ"
	default:
		return ""
	}
}

/**
* @Description: 获取MQ生产者
* @Author: noah
* @Date: 2021/9/21 15:03
* @LastEditTime:2021/9/21 15:03
* @LastEditors: noah
 */
func getMqProducer(cfg *RocketMqConf) (rocketmq.Producer, error) {

	rlog.SetLogger(&Logger{})
	rlog.SetLogLevel("error")

	p, err := rocketmq.NewProducer(
		// nameSrvAddr 是 Topic 路由注册中心
		producer.WithNameServer(cfg.ServerAddr),
		// 指定发送失败时的重试时间
		producer.WithRetry(2),
		// 设置 Group
		producer.WithGroupName(cfg.GroupName),
	)
	if err != nil {
		return nil, err
	}

	// 开始连接
	err = p.Start()
	if err != nil {
		return nil, err
	}

	return p, nil
}

// GetMqPushConsumer
/**
* @Description: 获取MQ消费者
* @Author: noah
* @Date: 2021/9/21 14:59
* @LastEditTime:2021/9/21 14:59
* @LastEditors: noah
 */
func GetMqPushConsumer(conf *RocketMqConf, strGroupName string) (rocketmq.PushConsumer, error) {

	rlog.SetLogger(&Logger{})
	rlog.SetLogLevel("error")

	var options []consumer.Option
	options = append(options, consumer.WithGroupName(strGroupName))
	options = append(options, consumer.WithNsResolver(primitive.NewPassthroughResolver(conf.ServerAddr)))
	options = append(options, consumer.WithConsumeFromWhere(consumer.ConsumeFromLastOffset)) // 选择消费时间(首次/当前/根据时间)
	options = append(options, consumer.WithConsumerModel(consumer.Clustering))               // 消费模式(集群消费:消费完其他人不能再读取/广播消费：所有人都能读)
	options = append(options, consumer.WithInstance("consumer-instance-1"))
	if conf.AccessKey != "" && conf.SecretKey != "" {
		options = append(options, consumer.WithCredentials(primitive.Credentials{AccessKey: conf.AccessKey, SecretKey: conf.SecretKey}))
	}
	c, err := rocketmq.NewPushConsumer(options...)
	if err != nil {
		fmt.Printf("【RocketMQ订阅服务】 GetMqPushConsumer-NewPushConsumer, Error:%s\n", err.Error())
		log.Fatalf("【GetMqPushConsumer】NewPushConsumer Error:%s \n", err.Error())
	}

	err = c.Start()
	if err != nil {
		fmt.Printf("【RocketMQ订阅服务】 GetMqPushConsumer-Start, Error:%s\n", err.Error())
		log.Fatalf("【GetMqPushConsumer】Start Error:%s \n", err.Error())
	}

	return c, nil
}

// InitRocketMQProducer
/**
* @Description: 初始化RocketMQ生产者
* @Author: noah
* @Date: 2021/12/15 16:16
* @LastEditTime:2021/12/15 16:16
* @LastEditors: noah
 */
func InitRocketMQProducer(cfg *RocketMqConf) rocketmq.Producer {

	rocketMqCli, err := getMqProducer(cfg)
	if err != nil {
		log.Fatal(err)
	}

	return rocketMqCli
}

// RocketMqMsgPush
/**
* @Description: RocketMQ消息推送
* @Author: noah
* @Date: 2021/9/5 11:42
* @LastEditTime:2021/9/5 11:42
* @LastEditors: noah
 */
func RocketMqMsgPush(cli rocketmq.Producer, topic string, data []byte) error {

	msg := &primitive.Message{
		Topic: topic,
		Body:  data,
	}
	msg.WithKeys([]string{fmt.Sprintf("%d", time.Now().UnixNano()/100)})
	_, err := cli.SendSync(context.Background(), msg)

	return err
}

// RocketMqMsgGet
/**
* @Description: RocketMQ消息获取(后台阻塞驻守,必须并发调用)
* @Author: noah
* @Date: 2021/12/15 16:54
* @LastEditTime:2021/12/15 16:54
* @LastEditors: noah
 */
func RocketMqMsgGet(ctx context.Context, cli rocketmq.PushConsumer, topic string, ch chan []byte) {

	defer close(ch)
	err := cli.Subscribe(
		topic,
		consumer.MessageSelector{
			Type:       consumer.TAG,
			Expression: "*",
		},
		func(ctx context.Context, msgs ...*primitive.MessageExt) (consumer.ConsumeResult, error) {
			for i := range msgs {
				ch <- msgs[i].Message.Body
			}
			return consumer.ConsumeSuccess, nil
		})

	if err != nil {
		fmt.Printf("【RocketMQ接收消息】 RocketMqMsgGet-cli.Subscribe, Error:%s\n", err.Error())
		log.Fatalln(err)
	}

	err = cli.Start()
	defer cli.Shutdown()
	if err != nil {
		fmt.Printf("【RocketMQ接收消息】 RocketMqMsgGet-cli.Start, Error:%s\n", err.Error())
		log.Fatalln(err)
		return
	}

	select {
	case <-ctx.Done():
		fmt.Printf("[%s]RocketMQService ctx return.\n", time.Now().Format("2006-01-02 15:04:05"))
		return
	}
}

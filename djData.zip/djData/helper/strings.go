package helper

import (
	"encoding/hex"
	md5simd "github.com/minio/md5-simd"
	"github.com/valyala/fasthttp"
	"github.com/wI2L/jettison"
	"math/rand"
	"strings"
	"time"
)

type Response struct {
	Status string      `json:"status"`
	Data   interface{} `json:"data"`
}

func Print(ctx *fasthttp.RequestCtx, state string, data interface{}) {

	ctx.SetStatusCode(200)
	ctx.SetContentType("application/json")

	res := Response{
		Status: state,
		Data:   data,
	}

	bytes, err := jettison.Marshal(res)
	if err != nil {
		ctx.SetBody([]byte(err.Error()))
		return
	}

	ctx.SetBody(bytes)
}

func PrintJson(ctx *fasthttp.RequestCtx, state, data string) {

	ctx.SetStatusCode(200)
	ctx.SetContentType("application/json")

	builder := strings.Builder{}

	builder.WriteString(`{"status":"`)
	builder.WriteString(state)
	builder.WriteString(`","data":`)
	builder.WriteString(data)
	builder.WriteString("}")

	ctx.SetBody([]byte(builder.String()))
}

func Echo(ctx *fasthttp.RequestCtx, code int, res Response) {

	ctx.SetStatusCode(code)

	data, err := jettison.Marshal(res)
	if err != nil {
		ctx.SetBody([]byte(err.Error()))
		return
	}

	ctx.SetBody(data)
}

//判断字符是否为数字
func isDigit(r rune) bool {
	return '0' <= r && r <= '9'
}

//判断字符是否为英文字符
func isAlpha(r rune) bool {

	if r >= 'A' && r <= 'Z' {
		return true
	} else if r >= 'a' && r <= 'z' {
		return true
	}
	return false
}

//判断字符串是不是数字
func CtypeDigit(s string) bool {

	if s == "" {
		return false
	}
	for _, r := range s {
		if !isDigit(r) {
			return false
		}
	}
	return true
}

//判断字符串是不是字母+数字
func CtypeAlnum(s string) bool {

	if s == "" {
		return false
	}
	for _, r := range s {
		if !isDigit(r) && !isAlpha(r) {
			return false
		}
	}
	return true
}

//获取source的子串,如果start小于0或者end大于source长度则返回""
//start:开始index，从0开始，包括0
//end:结束index，以end结束，但不包括end
func Substring(source string, start int, end int) string {

	var r = []rune(source)
	length := len(r)

	if start < 0 || end > length || start > end {
		return ""
	}

	if start == 0 && end == length {
		return source
	}

	return string(r[start:end])
}

func strReplace(str string, original []string, replacement []string) string {

	for i, replace := range original {
		r := strings.NewReplacer(replace, replacement[i])
		str = r.Replace(str)
	}

	return str
}

func FilterInjection(s string) string {

	s = strings.TrimSpace(s)
	original := []string{"<", ">", "\"", " ", "'", "\\", "\t"}
	replacement := []string{"&lt;", "&gt;", "&quot;", "&nbsp;", "&apos;", "", "&nbsp;"}

	return strReplace(s, original, replacement)
}

func GetRandomString(length int) string {

	str := "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
	bytes := []byte(str)
	var result []byte
	r := rand.New(rand.NewSource(time.Now().UnixNano()))
	for i := 0; i < length; i++ {
		result = append(result, bytes[r.Intn(len(bytes))])
	}
	return string(result)
}

func GetMD5Hash(text string) string {

	server := md5simd.NewServer()
	md5Hash := server.NewHash()

	md5Hash.Write([]byte(text))

	digest := md5Hash.Sum([]byte{})
	encrypted := hex.EncodeToString(digest)

	server.Close()
	md5Hash.Close()

	return encrypted
}

package mysql_helper

import (
	"log"
	"time"

	"github.com/jmoiron/sqlx"
)

type MySQLConfig struct {
	Addr        string `json:"addr"`
	MaxIdleConn int    `json:"max_idle_conn"`
	MaxOpenConn int    `json:"max_open_conn"`
}

// InitDB
/**
* @Description: 初始化MySQL
* @Author: daxie
* @Date: 2021/9/2 14:41
* @LastEditTime: 2021/9/2 14:41
* @LastEditors: daxie
 */
func InitDB(cfg *MySQLConfig) *sqlx.DB {

	dbConn, err := sqlx.Connect("mysql", cfg.Addr)
	if err != nil {
		log.Fatalf("【InitDB】connnet mysql Error:%s \n", err.Error())
	}

	dbConn.SetMaxOpenConns(cfg.MaxOpenConn)
	dbConn.SetMaxIdleConns(cfg.MaxIdleConn)
	dbConn.SetConnMaxLifetime(time.Second * 30)
	err = dbConn.Ping()
	if err != nil {
		log.Fatalf("【InitDB】ping mysql Error:%s \n", err.Error())
	}

	return dbConn
}

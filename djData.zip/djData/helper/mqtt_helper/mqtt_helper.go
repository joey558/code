package mqtt_helper

import (
	"djData/contrib/zlog"
	"djData/helper"
	"djData/utils"
	"fmt"
	mqtt "github.com/eclipse/paho.mqtt.golang"
	"github.com/panjf2000/ants/v2"
	"log"
	"time"
)

var (
	mqttCli     mqtt.Client
	mqPushPool  *ants.PoolWithFunc //mqtt推送协程池
	logPushPool *ants.PoolWithFunc //操盘日志发送协程池

)

type MarketNotify struct {
	MarketID    string
	OperateType int
}
type MqttConfig struct {
	Addr     []string `json:"addr"`
	Username string   `json:"username"`
	Password string   `json:"password"`
}

// TradeLog 总控后台操盘日志
type TradeLog struct {
	Topic string
	Data  interface{}
}

const (
	MqttFlags     = 0 // 普通MQTT
	MqttPoolFlags = 1 // MQTT池
	EmqxPoolFlags = 2 // EMQT池
)

//MQTT TOPIC
const (
	topicMatchStatUpdate        = "/match/stat/update"        // 赛事计数更新
	topicGameTourUpdate         = "/match/gameTour/update"    // 游戏联赛更新
	topicMarketStatusUpdate     = "/market/status/update"     // 盘口状态更新(关盘/开盘)
	topicMarketOddsUpdate       = "/market/odds/update"       // 盘口变赔
	topicMarketActionSuspended  = "/market/action/suspended"  // 盘口(暂停/取消暂停)
	topicMarketNameUpdate       = "/market/name/update"       // 盘口名称更新(基准分)
	topicMarketActionVisible    = "/market/action/visible"    // 盘口(显示/隐藏)
	topicMatchMarketCountUpdate = "/market/count/update"      // 用户前端比赛盘口统计变更
	topicMatchStatusUpdate      = "/match/status/update"      // 比赛状态更新(关盘/开盘)
	topicMatchActionSuspended   = "/match/action/suspended"   // 比赛(暂停/取消暂停)
	topicMatchActionVisible     = "/match/action/visible"     // 比赛(显示/隐藏)
	topicMatchTimerUpdate       = "/match/timer/update"       // 赛事计时器更新
	topicMatchScoreUpdate       = "/match/score/update"       // 比分更新
	topicMatchStatusLiveSupport = "/match/status/livesupport" // 赛事是否支持滚球状态-更新
	topicMatchStatusLive        = "/match/status/live"        // 比赛变更滚球状态
	topicMatchAdminVideoUrl     = "/match/videoUrl/update"    // 滚球赛事更新视频接口URL
	topicMarketStatisticUpdate  = "/market/statistic/update"  // 盘口统计数量更新
	topicOddActionVisible       = "/odd/action/visible"       // 投注项隐藏
	topicOddActionSuspended     = "/odd/action/suspended"     // 投注项暂停
	topicMarketAdd              = "/market/add"               // 增加盘口
	topicMarketOddsNameUpdate   = "/market/oddsName/update"   // 更新投注项名称,赔率
)

const (
	logTopicLogin  = "trade_log/login"
	logTopicCommon = "trade_log/common"
	logTopicMatch  = "trade_log/match"
	logTopicMarket = "trade_log/market"
)

type mqttNotify struct {
	Topic string //
	Data  interface{}
}

type RocketMqMsgData struct {
	Data     []interface{} `json:"data"`
	Category int           `json:"category"`
}

// 赛事计时器
type MatchTimer struct {
	MatchID    string `name:"match_id" json:"match_id" rule:"digit" min:"1" msg:"match_id error"`                      // 赛事ID
	TimeTicket int64  `name:"time_ticket" json:"time_ticket" rule:"digit" min:"0" max:"60000" msg:"time_ticket error"` // 计时器秒数（最大值计时时间为999分钟59秒）
	StartTime  int64  `name:"start_time" json:"start_time" rule:"none"`                                                // 计时器开始时间（程序使用）
	Status     int    `name:"status" json:"status" rule:"digit" min:"0" max:"4" msg:"status error"`                    // 计时器状态（0=暂停, 1-计时）
	Round      string `name:"round" json:"round" rule:"none"`                                                          // 局数 场次 节数
}

// 盘口列表数据统计
type CalcMarketCountsStat struct {
	TotalCounts     int `json:"total_counts"`      // 全部
	CanBetCounts    int `json:"can_bet_counts"`    // 可投注盘口数
	WaitOpenCounts  int `json:"wait_open_counts"`  // 待开盘数
	SuspendCounts   int `json:"suspend_counts"`    // 暂停盘口数
	HiddenCounts    int `json:"hidden_counts"`     // 隐藏盘口数
	WaitInputCounts int `json:"wait_input_counts"` // 待录入盘口数
	EnteredCounts   int `json:"entered_counts"`    // 已录入盘口数
	AllCounts       int `json:"all_counts"`        // 总盘口数
	CancelCount     int `json:"cancel_count"`      // 取消盘口数
	Settlement      int `json:"settlement"`        // 已结算订单
	WaitSettlement  int `json:"wait_settlement"`   // 待结算
}

/**
* @Description: 初始化mqtt
* @Author: daxie
* @Date: 2021/9/2 14:41
* @LastEditTime: 2021/9/2 14:41
* @LastEditors: daxie
 */
func initMqttService(cfg *MqttConfig) mqtt.Client {

	clientOptions := mqtt.NewClientOptions().
		SetClientID(fmt.Sprintf("%d", helper.Cputicks())).
		SetCleanSession(false).
		SetAutoReconnect(true).
		SetKeepAlive(120 * time.Second).
		SetPingTimeout(10 * time.Second).
		SetWriteTimeout(10 * time.Second).
		SetMaxReconnectInterval(10 * time.Second)

	if cfg.Username != "" {
		clientOptions.SetUsername(cfg.Username)
	}
	if cfg.Password != "" {
		clientOptions.SetPassword(cfg.Password)
	}

	for _, v := range cfg.Addr {
		clientOptions.AddBroker(v)
	}

	client := mqtt.NewClient(clientOptions)
	conn := client.Connect()
	conn.WaitTimeout(time.Duration(10) * time.Second)
	conn.Wait()
	if conn.Error() != nil {
		log.Fatalf("initMqttService: %s", conn.Error())
	}

	return client
}

// InitMqtt
/**
* @Description: 初始化MQTT服务
* @Author: noah
* @Date: 2021/12/20 17:04
* @LastEditTime:2021/12/20 17:04
* @LastEditors: noah
 */
func InitMqtt(cfg *MqttConfig, flags int) {

	cli := initMqttService(cfg)

	if flags == MqttFlags {
		mqttCli = cli
		return
	}

	// 初始化消息推送协程池
	pool, er := ants.NewPoolWithFunc(2000, func(payload interface{}) {
		if m, ok := payload.(mqttNotify); ok {
			err := utils.MQTTNotify(cli, m.Topic, utils.QoSAtLeastOnce, m.Data)
			if err != nil {
				zlog.Error(nil, "mqPush", "", fmt.Sprintf("topic:%s, msg:%+v, error:%s", m.Topic, m.Data, err.Error()), 0, 0)
				fmt.Printf("【InitMQTT】MQTTNotify: flag[%d] error[%s]\n", flags, err.Error())
			}
		}
	})

	if er != nil {
		panic(er)
	}

	switch flags {
	case MqttPoolFlags:
		mqPushPool = pool
	case EmqxPoolFlags:
		logPushPool = pool
	}
}

func MqttNotifyGameTourUpdate(gameId string, tours interface{}, filterList []uint64) {

	notify := mqttNotify{
		Topic: topicGameTourUpdate,
		Data: map[string]interface{}{
			"game_id":         gameId,
			"tours":           tours,
			"merchant_filter": filterList,
		},
	}

	if err := mqPushPool.Invoke(notify); err != nil {
		zlog.Error(nil, "mqPool", "", fmt.Sprintf("MqttNotifyGameTourUpdate error:%s", err.Error()), 0, 0)
	}
}

func MqttNotifyMatchStatUpdate(data []utils.MatchCountStatData) {

	notify := mqttNotify{
		Topic: topicMatchStatUpdate,
		Data:  data,
	}

	if err := mqPushPool.Invoke(notify); err != nil {
		zlog.Error(nil, "mqPool", "", fmt.Sprintf("MqttNotifyMatchStatUpdate error:%s", err.Error()), 0, 0)
	}
}

// MqttNotifyMarketStatus 通知盘口状态更新(关盘/开盘)
// 1 待录入 2 已录入 3 录入驳回 4 待审核 5 待开盘 6 已开盘 7 已关盘 8 待结算 9 已结算 10 结算驳回 11 待取消 12 已取消 13 无赛果 14 取消驳回
func MqttNotifyMarketStatus(matchID string, marketIDs []string, status int, oddWinnerStatus map[string]int) {

	var data []map[string]interface{}
	for _, id := range marketIDs {
		item := map[string]interface{}{
			"match_id":  matchID,
			"market_id": id,
			"status":    status,
		}
		if status == 9 && len(oddWinnerStatus) > 0 {
			item["odd_winner_status"] = oddWinnerStatus
		}

		data = append(data, item)
	}
	notify := mqttNotify{
		Topic: topicMarketStatusUpdate,
		Data:  data,
	}
	if err := mqPushPool.Invoke(notify); err != nil {
		zlog.Error(nil, "mqPool", "", fmt.Sprintf("MqttNotifyMarketStatus error:%s", err.Error()), 0, 0)
	}
}
func MqttNotifyMarketLogPub(data utils.TDMarket) {

	r := []rune(data.Result)
	if len(r) > 1024 { // max length 1024
		data.Result = string(r[0:1021]) + "..."
	}
	// 赛事类型: 篮球-4,足球-6
	tradeLog := mqttNotify{
		Topic: logTopicMarket,
		Data:  data,
	}
	if err := logPushPool.Invoke(tradeLog); err != nil {
		zlog.Error(nil, "marketLog", "", fmt.Sprintf("MarketLogPub error:%s", err.Error()), 0, 0)
		fmt.Printf("【MQTT】 盘口-Message Public Topic[%s],Error[%s]\n", logTopicMarket, err.Error())
	}
}

func MqttNotifyMatchLogPub(data utils.TDMatch) {

	r := []rune(data.Result)
	if len(r) > 1024 { // max length 1024
		data.Result = string(r[0:1021]) + "..."
	}

	tradeLog := mqttNotify{
		Topic: logTopicMatch,
		Data:  data,
	}
	if err := logPushPool.Invoke(tradeLog); err != nil {
		zlog.Error(nil, "matchLog", "", fmt.Sprintf("MatchLogPub error:%s", err.Error()), 0, 0)
		fmt.Printf("【MQTT】 赛事-Message Public Topic[%s],Error[%s]\n", logTopicMatch, err.Error())
	}
}

// MqttNotifyOddUpdate 盘口变赔
func MqttNotifyOddUpdate(odd interface{}) {

	notify := mqttNotify{
		Topic: topicMarketOddsUpdate,
		Data:  odd,
	}
	if err := mqPushPool.Invoke(notify); err != nil {
		zlog.Error(nil, "mqPool", "", fmt.Sprintf("MqttNotifyOddUpdate error:%s", err.Error()), 0, 0)
	}
}

// 盘口状态(暂停/取消暂停)
func MqttNotifyMarketSuspended(notifys []MarketNotify, suspended int, matchId string) {

	var data []map[string]interface{}
	for _, v := range notifys {
		data = append(data, map[string]interface{}{
			"match_id":  matchId,
			"market_id": v.MarketID,
			"suspended": suspended,
			"type":      v.OperateType,
		})
	}

	notify := mqttNotify{
		Topic: topicMarketActionSuspended,
		Data:  data,
	}
	if err := mqPushPool.Invoke(notify); err != nil {
		zlog.Error(nil, "mqPool", "", fmt.Sprintf("MqttNotifyMarketSuspended error:%s", err.Error()), 0, 0)
	}
}

// 盘口名称更新-基准分
func MqttNotifyMarketNameUpdate(matchId, marketId, marketCnName, marketEnName, scoreBenchmark string) {

	notify := mqttNotify{
		Topic: topicMarketNameUpdate,
		Data: map[string]interface{}{
			"match_id":        matchId,
			"market_id":       marketId,
			"cn_name":         marketCnName,
			"en_name":         marketEnName,
			"score_benchmark": scoreBenchmark,
		},
	}
	if err := mqPushPool.Invoke(notify); err != nil {
		zlog.Error(nil, "mqPool", "", fmt.Sprintf("MqttNotifyOddSuspendedUpdate error:%s", err.Error()), 0, 0)
	}
}

// 通知盘口 显示/隐藏
func MqttNotifyMarketVisible(notifys []MarketNotify, matchId string, visible int) {

	var data []map[string]interface{}
	for _, v := range notifys {
		data = append(data, map[string]interface{}{
			"market_id": v.MarketID,
			"match_id":  matchId,
			"visible":   visible,
			"type":      v.OperateType,
		})
	}

	notify := mqttNotify{
		Topic: topicMarketActionVisible,
		Data:  data,
	}
	if err := mqPushPool.Invoke(notify); err != nil {
		zlog.Error(nil, "mqPool", "", fmt.Sprintf("MqttNotifyMarketVisible error:%s", err.Error()), 0, 0)
	}
}

func MqttNotifyMarketCountUpdate(matchID string, count int64) {

	notify := mqttNotify{
		Topic: topicMatchMarketCountUpdate,
		Data: map[string]interface{}{
			"match_id": matchID,
			"count":    count,
		},
	}
	if err := mqPushPool.Invoke(notify); err != nil {
		zlog.Error(nil, "mqPool", "", fmt.Sprintf("MqttNotifyMarketCountUpdate error:%s", err.Error()), 0, 0)
	}
}

// 比赛状态更新
// 待录入-1 待审核-2 已驳回-3 待开盘-4 已开盘-5 已关盘-6 已结算-7 比赛取消-8 取消-9
func MqttNotifyMatchStatusUpdate(matchIDs []string, status int) {
	var data []map[string]interface{}
	for _, id := range matchIDs {
		data = append(data, map[string]interface{}{
			"match_id": id,
			"status":   status,
		})
	}
	notify := mqttNotify{
		Topic: topicMatchStatusUpdate,
		Data:  data,
	}
	if err := mqPushPool.Invoke(notify); err != nil {
		zlog.Error(nil, "mqPool", "", fmt.Sprintf("MqttNotifyMatchStatusUpdate error:%s", err.Error()), 0, 0)
	}
}

func MqttNotifyMatchTimerUpdate(timer MatchTimer) {

	notify := mqttNotify{
		Topic: topicMatchTimerUpdate,
		Data:  timer,
	}
	if err := mqPushPool.Invoke(notify); err != nil {
		zlog.Error(nil, "mqPool", "", fmt.Sprintf("MqttNotifyMatchTimerUpdate error:%s", err.Error()), 0, 0)
	}
}

func MqttNotifyMatchScoreUpdate(matchID string, score string) {

	notify := mqttNotify{
		Topic: topicMatchScoreUpdate,
		Data: map[string]interface{}{
			"match_id": matchID,
			"score":    score,
		},
	}
	if err := mqPushPool.Invoke(notify); err != nil {
		zlog.Error(nil, "mqPool", "", fmt.Sprintf("MqttNotifyMatchScoreUpdate error:%s", err.Error()), 0, 0)
	}
}

// 比赛是否支持滚球变更状态
func MqttNotifyMatchLiveSupportUpdate(matchIDs []string, liveSupport int) {
	var data []map[string]interface{}
	for _, id := range matchIDs {
		data = append(data, map[string]interface{}{
			"match_id":     id,
			"live_support": liveSupport,
		})
	}
	notify := mqttNotify{
		Topic: topicMatchStatusLiveSupport,
		Data:  data,
	}
	if err := mqPushPool.Invoke(notify); err != nil {
		zlog.Error(nil, "mqPool", "", fmt.Sprintf("MqttNotifyMatchLiveSupportUpdate error:%s", err.Error()), 0, 0)
	}
}

// 比赛初盘变更滚球状态
func MqttNotifyMatchLiveUpdate(matchID string, isLive int) {

	notify := mqttNotify{
		Topic: topicMatchStatusLive,
		Data: map[string]interface{}{
			"match_id": matchID,
			"is_live":  isLive,
		},
	}
	if err := mqPushPool.Invoke(notify); err != nil {
		zlog.Error(nil, "mqPool", "", fmt.Sprintf("MqttNotifyMatchLiveUpdate error:%s", err.Error()), 0, 0)
	}
}

// 滚球赛事更新视频接口URL
func MqttNotifyMatchAdminVideoUrlUpdate(matchID, sid string, strAdminVideoUrl string) {

	notify := mqttNotify{
		Topic: topicMatchAdminVideoUrl,
		Data: map[string]interface{}{
			"match_id":        matchID,
			"sid":             sid,
			"admin_video_url": strAdminVideoUrl,
		},
	}
	if err := mqPushPool.Invoke(notify); err != nil {
		zlog.Error(nil, "mqPool", "", fmt.Sprintf("MqttNotifyMatchAdminVideoUrlUpdate error:%s", err.Error()), 0, 0)
	}
}

//盘口计数变更通知
func MqttNotifyMarketCountsUpdate(matchID string, counts CalcMarketCountsStat) {

	notify := mqttNotify{
		Topic: topicMarketStatisticUpdate,
		Data: map[string]interface{}{
			"match_id": matchID,
			"counts":   counts,
		},
	}
	if err := mqPushPool.Invoke(notify); err != nil {
		zlog.Error(nil, "mqPool", "", fmt.Sprintf("MqttNotifyMarketCountsUpdate error:%s", err.Error()), 0, 0)
	}
}

//新增盘口
func MqttNotifyMarketAdd(matchID string) {
	var data []map[string]string
	data = append(data, map[string]string{"match_id": matchID})

	notify := mqttNotify{
		Topic: topicMarketAdd,
		Data:  data,
	}
	if err := mqPushPool.Invoke(notify); err != nil {
		zlog.Error(nil, "mqPool", "", fmt.Sprintf("MqttNotifyMarketAdd error:%s", err.Error()), 0, 0)
	}
}

/**
 * @Description: 赔率投注项目(暂停/取消暂停)
 * @Author: xp
 * @Date: 2021/6/18 19:11
 * @LastEditTime: 2021/6/18 19:11
 * @LastEditors: xp
 */
func MqttNotifyOddSuspendedUpdate(marketID, matchId, oddID string, suspended int) {

	notify := mqttNotify{
		Topic: topicOddActionSuspended,
		Data: map[string]interface{}{
			"market_id": marketID,
			"match_id":  matchId,
			"odd_id":    oddID,
			"suspended": suspended,
		},
	}
	if err := mqPushPool.Invoke(notify); err != nil {
		zlog.Error(nil, "mqPool", "", fmt.Sprintf("MqttNotifyOddSuspendedUpdate error:%s", err.Error()), 0, 0)
	}
}

/**
 * @Description: 赔率投注项目(显示/隐藏)
 * @Author: wesley
 * @Date: 2020/6/23 20:02
 * @LastEditTime: 2020/6/23 20:02
 * @LastEditors: wesley
 */
func MqttNotifyOddVisibleUpdate(marketID, matchId, oddID string, visible int) {

	notify := mqttNotify{
		Topic: topicOddActionVisible,
		Data: map[string]interface{}{
			"market_id": marketID,
			"match_id":  matchId,
			"odd_id":    oddID,
			"visible":   visible,
		},
	}
	if err := mqPushPool.Invoke(notify); err != nil {
		zlog.Error(nil, "mqPool", "", fmt.Sprintf("MqttNotifyOddVisibleUpdate error:%s", err.Error()), 0, 0)
	}
}

/*
 * @Description: 更新投注项(名称,赔率)
 * @Author: robin
 * @Date: 2022/2/7 16:42
 * @LastEditTime: 2022/2/7 16:42
 * @LastEditors: robin
 */
func MqttNotifyOddNameUpdate(odd interface{}) {

	notify := mqttNotify{
		Topic: topicMarketOddsNameUpdate,
		Data:  odd,
	}
	if err := mqPushPool.Invoke(notify); err != nil {
		zlog.Error(nil, "mqPool", "", fmt.Sprintf("MqttNotifyOddNameUpdate error:%s", err.Error()), 0, 0)
	}
}

// 比赛(暂停/取消暂停)
func MqttNotifyMatchSuspendUpdate(matchIds []string, suspended int) {
	var data []map[string]interface{}
	for _, id := range matchIds {
		data = append(data, map[string]interface{}{
			"match_id":  id,
			"suspended": suspended,
		})
	}
	notify := mqttNotify{
		Topic: topicMatchActionSuspended,
		Data:  data,
	}
	if err := mqPushPool.Invoke(notify); err != nil {
		zlog.Error(nil, "mqPool", "", fmt.Sprintf("MqttNotifyMatchSuspendUpdate error:%s", err.Error()), 0, 0)
	}
}

// 比赛状态(显示/隐藏)
func MqttNotifyMatchVisibleUpdate(matchIDs []string, visible int) {
	var data []map[string]interface{}
	for _, id := range matchIDs {
		data = append(data, map[string]interface{}{
			"match_id": id,
			"visible":  visible,
		})
	}
	notify := mqttNotify{
		Topic: topicMatchActionVisible,
		Data:  data,
	}
	if err := mqPushPool.Invoke(notify); err != nil {
		zlog.Error(nil, "mqPool", "", fmt.Sprintf("MqttNotifyMatchVisibleUpdate error:%s", err.Error()), 0, 0)
	}
}

func MqttNotifyCommonLogPub(data utils.TDCommon) {

	r := []rune(data.Result)
	if len(r) > 1024 { // max length 1024
		data.Result = string(r[0:1021]) + "..."
	}

	tradeLog := mqttNotify{
		Topic: logTopicCommon,
		Data:  data,
	}
	if err := logPushPool.Invoke(tradeLog); err != nil {
		zlog.Error(nil, "CommonLog", "", fmt.Sprintf("CommonLogPub error:%s", err.Error()), 0, 0)
		fmt.Printf("【MQTT】 操作-Message Public Topic[%s],Error[%s]\n", logTopicMatch, err.Error())
	}
}

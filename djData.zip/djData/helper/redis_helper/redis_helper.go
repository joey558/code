package redis_helper

import (
	"fmt"
	"log"
	"time"

	"github.com/go-redis/redis/v7"
)

type RedisHelper struct {
	redisClusterClient *redis.ClusterClient //  redis对象
	redisClient        *redis.Client
}

type RedisConfig struct {
	Addr     []string `json:"addr"`
	Password string   `json:"password"`
}

type RedisSentinelConfig struct {
	Addr     []string `json:"addr"`
	Password string   `json:"password"`
	Sentinel string   `json:"sentinel"`
}

// Redis KEY 统一定义在这里
const (
	//战队图标
	RedisTeamImages       = "teamImages"
	RedisOddTypeSIDMap    = "oddTypeSIDMap"
	RedisKeySetting       = "setting"        // 风控参数
	RedisSidUponMatchId   = "sidUponMatchId" // TY赛事ID映射DJ赛事ID
	RedisSidMatchTrade    = "sidMatchTrade"  // 电竞操盘界面对TY赛事进行的操作:暂停,隐藏
	RedisHKeyTournament   = "tmtInfo:%s"
	RedisMatchTimerRejson = "mchTimer"     //赛事计时器Rejson
	RedisMatchCalc        = "mch_calc:%s"  //赛事注单统计key
	RedisMatchTrader      = "Trader:%s:%d" // 操盘手分配
)

const (
	ReJsonDefaultExpiredTime = 7 * 24 * time.Hour   //7天
	TraderDefaultExpiredTime = 100 * 24 * time.Hour //3个月(100天)
)

/**
* @Description: 初始化redis集群客户端
* @Author: xp
* @Date: 2022/2/4 11:20 上午
* @LastEditTime: 2022/2/4 11:20 上午
* @LastEditors: xp
 */
func NewRedisCluster(cfg *RedisConfig) *RedisHelper {

	clusterClient := redis.NewClusterClient(&redis.ClusterOptions{
		Addrs:          cfg.Addr,         // 集群节点地址，理论上只要填一个可用的节点客户端就可以自动获取到集群的所有节点信息。但是最好多填一些节点以增加容灾能力，因为只填一个节点的话，如果这个节点出现了异常情况，则Go应用程序在启动过程中无法获取到集群信息。
		Password:       cfg.Password,     // 密码
		MaxRedirects:   8,                // 当遇到网络错误或者MOVED/ASK重定向命令时，最多重试几次，默认8
		ReadOnly:       false,            // 只含读操作的命令的"节点选择策略"。默认都是false，即只能在主节点上执行。 置为true则允许在从节点上执行只含读操作的命令
		RouteByLatency: false,            // 默认false。 置为true则ReadOnly自动置为true,表示在处理只读命令时，可以在一个slot对应的主节点和所有从节点中选取Ping()的响应时长最短的一个节点来读数据
		RouteRandomly:  false,            // 默认false。置为true则ReadOnly自动置为true,表示在处理只读命令时，可以在一个slot对应的主节点和所有从节点中随机挑选一个节点来读数据
		DialTimeout:    10 * time.Second, // 设置连接超时
		ReadTimeout:    30 * time.Second, // 设置读取超时
		WriteTimeout:   30 * time.Second, // 设置写入超时
		PoolSize:       100,              // 连接池最大socket连接数，默认为5倍CPU数， 5 * runtime.NumCPU
		MinIdleConns:   10,               // 在启动阶段创建指定数量的Idle连接，并长期维持idle状态的连接数不少于指定数量；。
		PoolTimeout:    30 * time.Second, // 当所有连接都处在繁忙状态时，客户端等待可用连接的最大等待时长，默认为读超时+1秒。
		MaxRetries:     2,                // 命令执行失败时，最多重试多少次，默认为0即不重试
		IdleTimeout:    5 * time.Minute,  // 闲置超时，默认5分钟，-1表示取消闲置超时检查
	})

	_, err := clusterClient.Ping().Result()
	if err != nil {
		log.Fatalln(err.Error())
	}

	redisHelper := &RedisHelper{
		redisClusterClient: clusterClient,
	}

	return redisHelper
}

/**
 * @Description: 初始化redis lock
 * @Author: robin
 * @Date: 2022/3/14 16:06
 * @LastEditTime: 2022/3/14 16:06
 * @LastEditors: robin
 */
func InitRedisLock(cfg *RedisSentinelConfig) *RedisHelper {

	if len(cfg.Addr) == 0 {
		log.Fatalf("InitRedisLock failed: no addr")
	}

	cli := redis.NewFailoverClient(&redis.FailoverOptions{
		MasterName:    cfg.Sentinel,
		SentinelAddrs: cfg.Addr,
		Password:      cfg.Password, // no password set
		DB:            0,            // use default DB
		DialTimeout:   10 * time.Second,
		ReadTimeout:   30 * time.Second,
		WriteTimeout:  30 * time.Second,
		PoolSize:      100,
		PoolTimeout:   30 * time.Second,
		MaxRetries:    2,
		IdleTimeout:   5 * time.Minute,
	})

	_, err := cli.Ping().Result()
	if err != nil {
		log.Fatalln(err.Error())
	}

	redisHelper := &RedisHelper{
		redisClient: cli,
	}

	return redisHelper
}

func (r *RedisHelper) GetClusterClient() *redis.ClusterClient {

	return r.redisClusterClient
}

func (r *RedisHelper) GetClient() *redis.Client {

	return r.redisClient
}

func (r *RedisHelper) CloseRedis() {

	if r.redisClusterClient != nil {
		_ = r.redisClusterClient.Close()
	}

	if r.redisClient != nil {
		_ = r.redisClient.Close()
	}
}

/*
 * @Description: 批量获取指定key对应字段的缓存
 * @Author: robin
 * @Date: 2021/9/30 17:21
 * @LastEditTime: 2021/9/30 17:21
 * @LastEditors: robin
 */
func RedisTxPipelineHMGet(redisCli *RedisHelper, ids []string, field, key string) (map[string]string, error) {

	data := map[string]string{}
	results := map[string]*redis.SliceCmd{}

	pipe := redisCli.GetClusterClient().Pipeline()
	defer pipe.Close()
	for _, id := range ids {
		key := fmt.Sprintf(key, id)
		value := pipe.HMGet(key, field)
		results[id] = value
	}
	_, err := pipe.Exec()
	if err != nil {
		return data, err
	}

	for id, result := range results {
		value, err := result.Result()
		if err != nil {
			return data, err
		}

		data[id] = ""
		if v, ok := value[0].(string); ok {
			data[id] = v
		}
	}

	return data, nil
}

/*
 * @Description: 公用哈希获取
 * @Author: robin
 * @Date: 2022/1/18 15:13
 * @LastEditTime: 2022/1/18 15:13
 * @LastEditors: robin
 */
func RedisHMGet(redisCli *RedisHelper, keyName string, fields []string) (map[string]string, error) {

	total := len(fields)
	data := map[string]string{}
	if total == 0 {
		return data, nil
	}

	value, err := redisCli.GetClusterClient().HMGet(keyName, fields...).Result()
	if err != nil {
		return data, err
	}

	for i := 0; i < total; i++ {
		// 取出interface{}类型数据，转换时类型断言
		data[fields[i]] = ""
		if v, ok := value[i].(string); ok {
			data[fields[i]] = v
		}
	}

	return data, nil
}

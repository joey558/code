package beanstalk

import (
	"djData/helper"
	"fmt"
	"log"
	"time"

	"github.com/beanstalkd/go-beanstalk"
	"github.com/panjf2000/ants/v2"
	cpool "github.com/silenceper/pool"
)

const (
	BkSettleTube      = "settle_%s"
	BkCancelTube      = "cancel_%s"         // 撤单任务队列
	BkTradeTube       = "trade_%s"          // 操盘相关任务
	BkRockerMqMonitor = "rocker_mq_monitor" // RocketMQ监控相关任务
)

// 报警模板
var (
	MqAlertTpl  = "ts=%s&service=djData&job=RocketMQ&level=%s&data=%s"
	ApiAlertTpl = "ts=%s&service=djData&job=HTTP&level=%s&data=%s"
)

type BeansFunc func(h *BeansHandler, msg BeansMessage) bool

type BeansHandler struct {
	Name          string             // handler name
	BeansPool     cpool.Pool         // beanstalk pool
	BeansTubeName string             // beanstalk tube name
	BeansReserve  time.Duration      // beanstalk reserve time
	FnPoolSize    int                // handle func pool size
	Fn            BeansFunc          // handle func
	fnPool        *ants.PoolWithFunc // handle func pool
}

type BeansMessage struct {
	ID       string          // uniq id
	Conn     *beanstalk.Conn // beanstalk conn
	MID      uint64          // msg id
	Msg      []byte          // msg data
	Reserves int             // 已获取到次数
}

type BeansTask struct {
	Tube    string        //tube 名称
	Message string        //job body
	Delay   time.Duration //延迟ready的秒数
	TTR     time.Duration //允许worker执行的最大秒数
	PRI     uint32        //优先级
}

func (h *BeansHandler) Release() {

	if h.fnPool != nil {
		h.fnPool.Release()
	}

	if h.BeansPool != nil {
		h.BeansPool.Release()
	}
}

/**
* @Description: 初始化Beanstalk
* @Author: daxie
* @Date: 2021/8/18 16:30
* @LastEditTime: 2021/8/18 16:30
* @LastEditors: daxie
 */
func InitBeanstalk(addr string, initialCap, maxIdle, maxCap int) cpool.Pool {

	factory := func() (interface{}, error) { return beanstalk.Dial("tcp", addr) }
	fnClose := func(v interface{}) error { return v.(*beanstalk.Conn).Close() }
	poolConfig := &cpool.Config{
		InitialCap:  initialCap, // 资源池初始连接数
		MaxIdle:     maxIdle,    // 最大空闲连接数
		MaxCap:      maxCap,     // 最大并发连接数
		Factory:     factory,
		Close:       fnClose,
		IdleTimeout: 15 * time.Second,
	}

	beanPool, err := cpool.NewChannelPool(poolConfig)
	if err != nil {
		log.Fatalf("InitBeanstalk Error:%s \n", err.Error())
	}

	return beanPool
}

func BeansAddTask(pool cpool.Pool, task BeansTask) error {

	v, err := pool.Get()
	if err != nil {
		return err
	}

	if conn, ok := v.(*beanstalk.Conn); ok {
		tube := &beanstalk.Tube{Conn: conn, Name: task.Tube}
		_, err = tube.Put([]byte(task.Message), task.PRI, task.Delay, task.TTR)
		if err != nil {
			return err
		}
	}

	//将连接放回连接池中
	return pool.Put(v)
}

// PutSettleTask
/**
* @Description: 推送结算任务
* @Author: noah
* @Date: 2021/12/15 15:59
* @LastEditTime:2021/12/15 15:59
* @LastEditors: noah
 */
func PutSettleTask(pool cpool.Pool, settleMerch []string, marketId string, mpOddResult map[string]int, settleCount, flag, reason, settRule int, score string) error {

	resByte, err := helper.JsonMarshal(mpOddResult)
	if err != nil {
		return err
	}

	message := fmt.Sprintf("market_id=%s&result=%s&settle_count=%d&flag=%d&reason=%d&sett_rule=%d&score=%s", marketId, string(resByte), settleCount, flag, reason, settRule, score)

	for _, m := range settleMerch {
		data := BeansTask{
			Tube:    fmt.Sprintf(BkSettleTube, m),
			Message: message,
			Delay:   0,
			PRI:     1,
			TTR:     60 * time.Second,
		}

		err = BeansAddTask(pool, data)
		if err != nil {
			return err
		}
	}

	return nil
}

/*
 * @Description: 追加撤单任务
 * @Author: robin
 * @Date: 2022/1/2 16:58
 * @LastEditTime: 2022/1/2 16:58
 * @LastEditors: robin
 */
func BeansPutCancelTask(pool cpool.Pool, settleMerch []string, ids string, reason int) error {

	message := fmt.Sprintf("ids=%s&order_type=1&reason=%d", ids, reason)
	for _, m := range settleMerch {

		data := BeansTask{
			Tube:    fmt.Sprintf(BkCancelTube, m),
			Message: message,
			Delay:   0,
			PRI:     1,
			TTR:     60 * time.Second,
		}

		err := BeansAddTask(pool, data)
		if err != nil {
			return err
		}
	}

	return nil
}

func BeansPutSettleTask(pool cpool.Pool, settleMerch []string, marketId string, mpOddResult map[string]int, settleCount, flag, reason int) error {

	resByte, err := helper.JsonMarshal(mpOddResult)
	if err != nil {
		return err
	}

	message := fmt.Sprintf("market_id=%s&result=%s&settle_count=%d&flag=%d&reason=%d", marketId, string(resByte), settleCount, flag, reason)

	for _, m := range settleMerch {

		data := BeansTask{
			Tube:    fmt.Sprintf(BkSettleTube, m),
			Message: message,
			Delay:   0,
			PRI:     1,
			TTR:     60 * time.Second,
		}

		err := BeansAddTask(pool, data)
		if err != nil {
			return err
		}
	}

	return nil
}

func BeansPutTradeTask(pool cpool.Pool, settleMerch []string, matchID, marketIds, extraInf, flag string) error {

	message := fmt.Sprintf("match_id=%s&market_id=%s&flag=%s", matchID, marketIds, flag)
	if len(extraInf) > 0 {
		message += extraInf
	}

	for _, m := range settleMerch {

		data := BeansTask{
			Tube:    fmt.Sprintf(BkTradeTube, m),
			Message: message,
			Delay:   0,
			PRI:     1,
			TTR:     60 * time.Second,
		}

		err := BeansAddTask(pool, data)
		if err != nil {
			return err
		}
	}

	return nil
}

// BeansPutMonitorTask
// 监控Beans推送
/**
* @Description:
* @Author: noah
* @Date: 2022/4/9 13:16
* @LastEditTime:2022/4/9 13:16
* @LastEditors: noah
 */
func BeansPutMonitorTask(pool cpool.Pool, tbl, lever, err string) error {

	msg := fmt.Sprintf(tbl,
		time.Now().Format("01-02 15:04:05"),
		lever,
		err,
	)
	data := BeansTask{
		Tube:    BkRockerMqMonitor,
		Message: msg,
		Delay:   0,
		PRI:     1,
		TTR:     60 * time.Second,
	}

	return BeansAddTask(pool, data)
}

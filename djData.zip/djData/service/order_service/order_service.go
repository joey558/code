package order_service

import (
	"context"
	"djData/service/common"
	"fmt"
)

type OrderService struct {
	ctx    context.Context
	cancel context.CancelFunc
}

func (that *OrderService) Start() {

	that.ctx, that.cancel = context.WithCancel(context.Background())
	go func() {
		for {
			checkOrderStatus()
			bReturn := common.ContextDone(that.ctx, "OrderService")
			if bReturn {
				return
			}
		}
	}()
}

func (that *OrderService) Stop() {

	that.cancel()
	fmt.Println("OrderService Stop")
}

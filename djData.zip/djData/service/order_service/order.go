package order_service

import (
	"bytes"
	"djData/helper"
	"djData/helper/beanstalk"
	"djData/helper/conf"
	"djData/model"
	"fmt"
	g "github.com/doug-martin/goqu/v9"
	"github.com/valyala/fasthttp"
	"io/ioutil"
	"net/http"
	"strconv"
	"time"
)

// 查询投注记录列表信息
type httpQueryBetListResponse struct {
	Status     bool   `json:"status"`
	Code       string `json:"code"`
	Msg        string `json:"msg"`
	ServerTime int64  `json:"serverTime"`
	Data       struct {
		PageSize   int `json:"pageSize"`
		TotalCount int `json:"totalCount"`
		PageNum    int `json:"pageNum"`
		List       []struct {
			UserName     string `json:"userName"`
			MerchantCode string `json:"merchantCode"`
			BetCount     int    `json:"betCount"`
			SeriesType   int    `json:"seriesType"`
			SeriesValue  string `json:"seriesValue"`
			OrderNo      string `json:"orderNo"`
			CreateTime   int64  `json:"createTime"`
			OrderAmount  string `json:"orderAmount"`
			OrderStatus  int    `json:"orderStatus"`
			DetailList   []struct {
				BetNo          int64   `json:"betNo"`
				PlayOptionsId  int64   `json:"playOptionsId"`
				MatchId        int     `json:"matchId"`
				BetAmount      float64 `json:"betAmount"`
				MatchName      string  `json:"matchName"`
				MatchInfo      string  `json:"matchInfo"`
				MatchType      int     `json:"matchType"`
				MarketType     string  `json:"marketType"`
				SportId        int     `json:"sportId"`
				PlayId         int     `json:"playId"`
				SportName      string  `json:"sportName"`
				PlayOptionName string  `json:"playOptionName"`
				PlayName       string  `json:"playName"`
				MarketValue    string  `json:"marketValue"`
				OddsValue      float64 `json:"oddsValue"`
				BetResult      string  `json:"betResult"`
				CancelType     int     `json:"cancelType"`
			} `json:"detailList"`
		} `json:"list"`
	} `json:"data"`
}

/*
 * @Description: 判断注单状态变更(撤单查询)
 * @Author: robin
 * @Date: 2022/3/7 16:25
 * @LastEditTime: 2022/3/7 16:25
 * @LastEditors: robin
 */
func checkOrderStatus() {

	pageNum := 1
	for pageIndex := 1; pageIndex <= pageNum; pageIndex++ {
		time.Sleep(time.Second * 2)
		orderInfo, err := httpQueryBetList(pageIndex)
		if err != nil {
			fmt.Printf("【注单列表】HTTP请求,Error:%s \n", err.Error())
			continue
		}

		if orderInfo.Code != model.TyApiSUCCESS {
			fmt.Printf("【注单列表】HTTP请求,MSG[%v],ErrCode:[%v] \n", orderInfo.Msg, orderInfo.Code)
			continue
		}

		if len(orderInfo.Data.List) == 0 {
			fmt.Println("【注单列表】HTTP请求,列表为空.")
			continue
		}

		if orderInfo.Data.PageSize > 0 && orderInfo.Data.TotalCount > orderInfo.Data.PageSize {
			pageNum = orderInfo.Data.TotalCount / orderInfo.Data.PageSize
			if orderInfo.Data.TotalCount%orderInfo.Data.PageSize > 0 {
				pageNum += 1
			}
		}

		orderCancelMap := map[string]int{}
		for _, order := range orderInfo.Data.List {
			if order.OrderStatus == model.TyOrderStatusCancelled || order.OrderStatus == model.TyOrderStatusRefuse ||
				order.OrderStatus == model.TyOrderStatusUndo {
				reason := 71
				ok := false
				if len(order.DetailList) > 0 {
					reason, ok = model.TyOrderCancelReason[order.DetailList[0].CancelType]
					if !ok {
						reason = 71
					}
				}
				orderCancelMap[order.OrderNo] = reason
			}
		}

		if len(orderCancelMap) == 0 {
			fmt.Println("【注单列表】HTTP请求,无取消注单信息")
			continue
		}

		var orderCancelIds []string
		for id := range orderCancelMap {
			orderCancelIds = append(orderCancelIds, id)
		}
		ex := g.Ex{
			"ty_order_id": orderCancelIds,
			"bet_status":  g.Op{"neq": []int{model.BetStatusRefused, model.BetStatusCancelled, model.BetStatusUndo}}, // 已拒绝 已取消 已撤消
		}

		orders, err := model.BetOrderFindAll(ex)
		if err != nil {
			fmt.Printf("【拉单接口】BetOrderFindAll, Error:%s\n", err.Error())
			continue
		}

		if len(orders) == 0 {
			fmt.Println("【拉单接口】 没有符合条件的撤销注单.")
			continue
		}

		// 撤消注单
		for _, order := range orders {
			if reason, ok := orderCancelMap[order.TYOrderID]; ok {
				beanstalk.BeansPutCancelTask(model.ZkBeansPool, conf.Cfg.ZkConf.SettleMerchs, order.ID, reason)
			}
		}
	}
}

/*
 * @Description: 请求体育注单列表
 * @Author: robin
 * @Date: 2022/3/7 16:59
 * @LastEditTime: 2022/3/7 16:59
 * @LastEditors: robin
 */
func httpQueryBetList(pageNum int) (httpQueryBetListResponse, error) {

	// 查询-最近2个小时内的注单
	startTime := fmt.Sprintf("%d", time.Now().Add(-2*time.Hour).UnixNano()/1e6)
	// 当前
	endTime := fmt.Sprintf("%d", time.Now().UnixNano()/1e6)
	signature := helper.GetMD5Hash(fmt.Sprintf("%s&%s&%s&%s", conf.Cfg.TYApiConf.MerchantCode, startTime, endTime, endTime))
	signature = helper.GetMD5Hash(fmt.Sprintf("%s&%s", signature, conf.Cfg.TYApiConf.SecretKey))

	data := new(fasthttp.Args)
	data.Add("startTime", startTime)
	data.Add("endTime", endTime)
	data.Add("merchantCode", conf.Cfg.TYApiConf.MerchantCode)
	data.Add("timestamp", endTime)
	data.Add("pageNum", strconv.Itoa(pageNum))
	data.Add("pageSize", "1000")
	data.Add("signature", signature)

	var orderResp httpQueryBetListResponse
	resp, err := http.Post(conf.Cfg.TYApiConf.QueryBetListUrl, "application/x-www-form-urlencoded", bytes.NewReader(data.QueryString()))
	if err != nil {
		fmt.Printf("【拉单接口】HttpPost,Error:%s\n", err.Error())
		if err = beanstalk.BeansPutMonitorTask(model.ZkBeansPool, beanstalk.ApiAlertTpl, "error", "获取体育注单列表错误 ： "+err.Error()); err != nil {
			fmt.Println(err.Error())
		}
		return orderResp, err
	}

	defer resp.Body.Close()
	respBytes, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		fmt.Printf("【拉单接口】ioutil.ReadAll,Error:%s\n", err.Error())
		return orderResp, err
	}

	err = helper.JsonUnmarshal(respBytes, &orderResp)
	if err != nil {
		fmt.Printf("【拉单接口】JsonUnmarshal,Error:%s\n", err.Error())
		return orderResp, err
	}

	return orderResp, nil
}

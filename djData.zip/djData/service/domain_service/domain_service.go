package domain_service

import (
	"context"
	"djData/service/common"
	"fmt"
	"time"
)

type DomainService struct {
	ctx    context.Context
	cancel context.CancelFunc
}

func (that *DomainService) Start() {

	that.ctx, that.cancel = context.WithCancel(context.Background())
	go func() {
		for {
			status, err := getAPIDomainURL()
			if err != nil {
				time.Sleep(time.Second * 5)
				continue
			}

			if status == false {
				bReturn := common.ContextDone(that.ctx, "DomainService")
				if bReturn {
					return
				}
				continue
			}

			status = updateDomainUrl()
			bReturn := common.ContextDone(that.ctx, "DomainService")
			if bReturn {
				return
			}
			if status {
				time.Sleep(time.Minute * 2)
			}
		}
	}()
}

func (that *DomainService) Stop() {

	that.cancel()
	fmt.Println("DomainService Stop")
}

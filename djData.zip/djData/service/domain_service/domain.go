package domain_service

import (
	"bytes"
	"djData/helper"
	"djData/helper/beanstalk"
	"djData/helper/conf"
	mqtt "djData/helper/mqtt_helper"
	"djData/model"
	"djData/utils"
	"fmt"
	g "github.com/doug-martin/goqu/v9"
	"github.com/valyala/fasthttp"
	"io/ioutil"
	"net/http"
	"time"
)

// 体育登录返回信息
type VideoResponse struct {
	Status     bool   `json:"status"`
	Msg        string `json:"msg"`
	Code       string `json:"code"`
	ServerTime int64  `json:"serverTime"`
	Data       struct {
		APIDomain string `json:"apiDomain"`
		IMGDomain string `json:"imgDomain"`
		Token     string `json:"token"`
	} `json:"data"`
}

/*
 * @Description: 获取视频域名接口信息
 * @Author: robin
 * @Date: 2022/2/3 12:58
 * @LastEditTime: 2022/2/3 12:58
 * @LastEditors: robin
 */
func getAPIDomainURL() (bool, error) {

	tyUserName := "djVideoAPI20220202"
	terminal := "pc"
	timestamp := fmt.Sprintf("%d", time.Now().UnixNano()/1e6)

	data := new(fasthttp.Args)
	data.Add("userName", tyUserName)
	data.Add("merchantCode", conf.Cfg.TYApiConf.MerchantCode)
	data.Add("terminal", terminal)
	data.Add("timestamp", timestamp)
	str := helper.GetMD5Hash(conf.Cfg.TYApiConf.MerchantCode + "&" + tyUserName + "&" + terminal + "&" + timestamp)
	signature := helper.GetMD5Hash(str + "&" + conf.Cfg.TYApiConf.SecretKey)
	data.Add("signature", signature)

	resp, err := http.Post(conf.Cfg.TYApiConf.LoginUrl, "application/x-www-form-urlencoded", bytes.NewReader(data.QueryString()))
	if err != nil {
		fmt.Printf("【视频域名接口】HttpPost,Error:%s\n", err.Error())
		if err = beanstalk.BeansPutMonitorTask(model.ZkBeansPool, beanstalk.ApiAlertTpl, "error", "获取视频域名接口信息错误 ： "+err.Error()); err != nil {
			fmt.Println(err.Error())
		}
		return false, err
	}

	defer resp.Body.Close()
	respBytes, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		fmt.Printf("【视频域名接口】ioutil.ReadAll,Error:%s\n", err.Error())
		return false, err
	}

	var videoResponse VideoResponse
	err = helper.JsonUnmarshal(respBytes, &videoResponse)
	if err != nil {
		fmt.Printf("【视频域名接口】JsonUnmarshal,Error:%s\n", err.Error())
		return false, err
	}

	if videoResponse.Code != model.TyApiSUCCESS {
		fmt.Printf("【视频域名接口】接口请求失败MSG[%v]. ErrCode:[%v] \n", videoResponse.Msg, videoResponse.Code)
		return false, nil
	}

	if len(videoResponse.Data.Token) == 0 || len(videoResponse.Data.APIDomain) == 0 {
		fmt.Printf("【视频域名接口】Token[%s],APIDomainURL[%s] \n", videoResponse.Data.Token, videoResponse.Data.APIDomain)
		return false, nil
	}

	var logResult string
	if len(videoResponse.Data.IMGDomain) > 0 {
		videoResponse.Data.IMGDomain += "/"
		if videoResponse.Data.IMGDomain != conf.Cfg.TYApiConf.TYTeamURL {
			conf.Cfg.TYApiConf.TYTeamURL = videoResponse.Data.IMGDomain
			logResult = fmt.Sprintf("【战队图片域名】:%s\n", conf.Cfg.TYApiConf.TYTeamURL)
			fmt.Printf("【视频请求接口-更新】战队图片域名[%v]\n", videoResponse.Data.IMGDomain)
		}
	}

	strToken := videoResponse.Data.Token
	strApiDoMainURL := fmt.Sprintf("%s/yewu20/v1/pub/videoAnimationUrl", videoResponse.Data.APIDomain)
	strUrl := fmt.Sprintf("%s|%s|%s", conf.Cfg.TYApiConf.PlayerUrl, strApiDoMainURL, strToken)
	if conf.Cfg.TYApiConf.VideoURL == strUrl {
		return false, nil
	} else {
		conf.Cfg.TYApiConf.VideoURL = strUrl
	}
	fmt.Printf("【视频请求接口-更新】视频接口URL:%s, requestId:%s\n", strApiDoMainURL, strToken)

	logResult += fmt.Sprintf("【视频API接口】:%s\n【requestId】:%s", strApiDoMainURL, strToken)
	commonLog := utils.TDCommon{
		TS:     "now",
		User:   "TY",
		Group:  "0",
		IP:     "0",
		Menu:   "HTTP请求",
		Action: "体育域名-更新",
		Result: logResult,
	}
	mqtt.MqttNotifyCommonLogPub(commonLog)

	return true, nil
}

/*
 * @Description: 视频请求接口-更新
 * @Author: robin
 * @Date: 2022/2/3 12:45
 * @LastEditTime: 2022/2/3 12:45
 * @LastEditors: robin
 */
func updateDomainUrl() bool {

	matchSlice, err := model.MatchListGet(g.Ex{"sid": g.Op{"gt": 0}, "status": model.MatchStatusOpened, "is_live": model.MatchLive})
	if err != nil {
		fmt.Printf("【视频请求接口-更新】获取滚球赛事列表,Error:%s\n", err.Error())
		return false
	}

	if len(matchSlice) == 0 {
		return false
	}

	record := g.Record{
		"admin_video_url": conf.Cfg.TYApiConf.VideoURL,
		"update_time":     time.Now().Unix(),
	}
	for _, match := range matchSlice {
		if conf.Cfg.TYApiConf.VideoURL == match.AdminVideoUrl {
			continue
		}
		err = model.MatchUpdate(record, g.Ex{"id": match.ID}, nil)
		if err != nil {
			fmt.Printf("【视频请求接口-更新:%s】MatchUpdate,赛事更新错误,Error:%s \n", match.ID, err.Error())
			continue
		}

		mqtt.MqttNotifyMatchAdminVideoUrlUpdate(match.ID, match.SID, conf.Cfg.TYApiConf.VideoURL)
	}

	return true
}

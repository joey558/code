package rocket_mq_service

import (
	"context"
	"djData/model"
	"fmt"
)

type RocketMQService struct {
	ctx    context.Context
	cancel context.CancelFunc
}

func (that *RocketMQService) Start() {

	that.ctx, that.cancel = context.WithCancel(context.Background())
	// 自动变赔服务
	go model.MarketOddAutoUpdate(that.ctx)
	// 自动结算服务
	go model.MarketAutoSettle(that.ctx)
}

func (that *RocketMQService) Stop() {

	that.cancel()
	fmt.Println("RocketMQService Stop")
}

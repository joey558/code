package service

import (
	"djData/helper/conf"
	"djData/router"
	"fmt"
	"log"
	"time"

	"github.com/valyala/fasthttp"
)

type Service interface {
	Start()
	Stop()
}

func StartHTTPServer(b router.BuildInfo) {
	app := router.SetupRouter(b)
	srv := &fasthttp.Server{
		Handler:            app.Handler,
		ReadTimeout:        5 * time.Second,
		WriteTimeout:       10 * time.Second,
		Name:               "djData",
		MaxRequestBodySize: 51 * 1024 * 1024,
	}

	// 监听服务
	go func() {
		fmt.Println("djData http running", conf.Cfg.DataSrv.HTTP)
		if err := srv.ListenAndServe(conf.Cfg.DataSrv.HTTP); err != nil {
			log.Fatalf("Error in ListenAndServe: %s", err)
		}
	}()
}

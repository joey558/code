package match_service

import (
	"bytes"
	"database/sql"
	"djData/helper"
	"djData/helper/beanstalk"
	"djData/helper/conf"
	mqtt "djData/helper/mqtt_helper"
	"djData/model"
	"djData/utils"
	"fmt"
	"io/ioutil"
	"net/http"
	"sort"
	"strconv"
	"strings"
	"time"

	g "github.com/doug-martin/goqu/v9"
)

var (
	tournamentIdMap  map[string]model.Tournament //map[id]
	tournamentSidMap map[string]model.Tournament // map[sid]
	gameMap          map[string]model.Game
	matchLevelMap    map[int]model.MatchLevel
	matchSettleMap   map[string]int64 //赛事ID[时间]
)

type MatchRiskData struct {
	match        model.Match
	strRiskTag   string
	riskTagSlice []model.MatchRiskTag
}

/*
 * @Description: 根据战队ID和战队信息 生产战队中文名和英文名
 * @Author: robin
 * @Date: 2021/11/30 14:47
 * @LastEditTime: 2021/11/30 14:47
 * @LastEditors: robin
 */
func genMatchCnTeamAndEnTeam(teams []model.Team, teamIDs []string) (string, string, string) {

	var shortTeam, cnTeam, enTeam string
	for _, tmID := range teamIDs {
		for _, tm := range teams {
			if tm.ID != tmID {
				continue
			}
			if len(shortTeam) > 0 {
				shortTeam += ","
				cnTeam += ","
				enTeam += ","
			}
			shortTeam += strings.ReplaceAll(tm.ShortName, ",", "，")
			cnTeam += strings.ReplaceAll(tm.CnName, ",", "，")
			enTeam += strings.ReplaceAll(tm.EnName, ",", "，")
		}
	}

	return shortTeam, cnTeam, enTeam
}

/*
 * @Description: 赛事信息-获取
 * @Author: robin
 * @Date: 2021/11/27 17:59
 * @LastEditTime: 2021/11/27 17:59
 * @LastEditors: robin
 */
func matchListGet(intUpdateTime *int64) []string {

	var ids []string
	err := loadBaseData()
	if err != nil {
		fmt.Printf("【赛事信息接口】联赛,游戏,赛事等级数据获取错误,Error: %s \n", err.Error())
		return ids
	}

	if matchSettleMap == nil {
		matchSettleMap = map[string]int64{}
	}

	if (time.Now().Unix() - *intUpdateTime) > model.OneMinute { //间隔1分钟 获取指定的赛事(已结束,且盘口均已结算)
		matchSlice, err := model.MatchListGet(g.Ex{"sid": g.Op{"gt": 0}, "status": model.MatchStatusClosed})
		if err != nil {
			fmt.Printf("【赛事列表接口】获取结束赛事列表,Error:%s\n", err.Error())
			return ids
		}

		for _, m := range matchSlice {
			_, ok := matchSettleMap[m.ID]
			if !ok {
				matchSettleMap[m.ID] = m.UpdateTime
			}
		}
		*intUpdateTime = time.Now().Unix()
	}

	if len(matchSettleMap) > 0 { // 赛事结算: 若出现盘口已全部结算,但是HTTP赛事信息接口,没有下发该赛事ID的现象,则进行检索超过30分钟的赛事ID,并结算赛事
		for matchId := range matchSettleMap {
			if len(matchId) == 0 {
				continue
			}
			if (time.Now().Unix() - matchSettleMap[matchId]) < model.ThirtyMinutes { //延时30分钟 等待注单结算完毕
				continue
			}

			// todo:xp
			mpMatchMarketID := map[string]string{
				"": matchId,
			}
			handicapInfo, err := utils.HandicapInfo(model.GetZkRedis().GetClusterClient(), mpMatchMarketID)
			if err != nil {
				fmt.Printf("【赛事列表接口-赛事ID:%s】HandicapInfo 赛事缓存信息,Error:%s\n", matchId, err.Error())
				continue
			}

			match := handicapInfo.Matches[matchId]
			if len(match.ID) == 0 {
				fmt.Printf("【赛事列表接口-赛事ID:%s,SID:%s】游戏[%s]电竞赛事不存在于缓存Redis \n", match.ID, match.SID, model.GameName[match.GameID])
				continue
			}
			checkMatchSettle(match)
		}
	}

	if len(gameMap) == 0 {
		fmt.Printf("【赛事信息接口】NAB2K,FIFA游戏 已全部关闭.\n")
		return ids
	}

	if len(tournamentSidMap) == 0 || len(matchLevelMap) == 0 {
		fmt.Printf("【赛事信息接口】联赛,游戏,赛事等级数据获取为空. tournamentSidMap[%d] matchLevelMap[%d]\n", len(tournamentSidMap), len(matchLevelMap))
		return ids
	}

	postParam := model.TYMatchPostParam{
		ReqSize: 100,
		Type:    3, //今日赛事(包括滚盘赛事)
	}
	reqBytes, err := helper.JsonMarshal(postParam)
	if err != nil {
		fmt.Printf("【赛事信息接口】JsonMarshal,Error. [%s]\n", err.Error())
		return ids
	}

	url := conf.Cfg.TYApiConf.MatchURL
	resp, err := http.Post(url, "application/json", bytes.NewReader(reqBytes))
	if err != nil {
		fmt.Printf("【赛事信息接口】HttpPost,Error:%s\n", err.Error())
		if err = beanstalk.BeansPutMonitorTask(model.ZkBeansPool, beanstalk.ApiAlertTpl, "error", "获取赛事信息错误 ： "+err.Error()); err != nil {
			fmt.Println(err.Error())
		}
		return ids
	}

	defer resp.Body.Close()
	respBytes, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		fmt.Printf("【赛事信息接口】ioutil.ReadAll,Error:%s\n", err.Error())
		return ids
	}

	var tyGetMatchData model.TYGetMatchDataResp
	err = helper.JsonUnmarshal(respBytes, &tyGetMatchData)
	if err != nil {
		fmt.Printf("【赛事信息接口】JsonUnmarshal Error:%s\n", err.Error())
		fmt.Printf("【赛事信息接口】HTTP请求返回信息 Error:%s\n", string(respBytes))
		return ids
	}

	//if conf.Cfg.LogMode.Status == 1 {
	//	marshal, _ := helper.JsonMarshal(tyGetMatchData)
	//	fmt.Printf("【赛事信息接口】HTTP请求返回信息,成功:%s\n", string(marshal))
	//}

	if tyGetMatchData.Code != model.SUCCESS {
		fmt.Printf("【赛事信息接口】请求失败[%s]. ErrCode:[%s] \n", tyGetMatchData.Msg, tyGetMatchData.Code)
		if err = beanstalk.BeansPutMonitorTask(model.ZkBeansPool, beanstalk.ApiAlertTpl, "error", "获取赛事信息错误,Code ： "+tyGetMatchData.Code); err != nil {
			fmt.Println(err.Error())
		}
		return ids
	}

	if len(tyGetMatchData.Data) == 0 {
		//fmt.Printf("[%s]【赛事信息接口】赛事列表为空\n", helper.TimeUnixToStr(time.Now().Unix()))
		return ids
	}

	var (
		tourDataSlice []model.Tournament
		teamDataSlice []model.Team
	)

	tourDataMap := map[string]model.Tournament{}
	teamDataMap := map[string]model.Team{}
	matchRiskDataMap := map[string]MatchRiskData{}

	for _, m := range tyGetMatchData.Data {

		category, err := strconv.Atoi(m.Category)
		if err != nil {
			continue
		}

		if category != model.TYCategoryFootball && category != model.TYCategoryBasketball {
			continue
		}

		if category == model.TYCategoryFootball { //足球
			category = model.DJCategoryFootball
		} else { //篮球
			category = model.DJCategoryBasketball
		}

		gameId := model.MatchCategoryGameID[category]
		//判断游戏是否存在
		gameData, ok := gameMap[gameId]
		if !ok {
			fmt.Printf("【%s】【赛事列表接口-赛事SID:%s】游戏ID[%s] 不存在\n", helper.TimeUnixToStr(time.Now().Unix()), m.StandardMatchID, gameId)
			continue
		}

		//联赛数据
		tourData, bExist, err := checkTournamentInfo(m, category)
		if err != nil {
			fmt.Println(err)
			continue
		}

		if len(tourData.SID) == 0 {
			fmt.Printf("【赛事列表接口-赛事SID:%s,联赛ID:%s】 联赛数据 不存在\n", m.StandardMatchID, m.TournamentID)
			continue
		}

		_, ok = tourDataMap[tourData.SID]
		if !bExist && !ok {
			tourDataMap[tourData.SID] = tourData
		}

		//战队数据
		teamData, matchTeams, err := checkTeamInfo(m, tourData, gameData.ShortName)
		if err != nil {
			fmt.Println(err)
			continue
		}

		if len(teamData) > 0 {
			for _, team := range teamData {
				if len(team.SID) == 0 {
					continue
				}
				_, ok = teamDataMap[team.SID]
				if !ok {
					teamDataMap[team.SID] = team
				}
			}
		}

		if len(matchTeams) != 2 {
			continue
		}

		//赛事数据
		matchId, matchRiskData, err := checkMatchInfo(m, tourData, matchTeams, category)
		if err != nil {
			fmt.Println(err)
			continue
		}

		if len(matchId) > 0 {
			ok = false
			if len(matchRiskData.match.SID) > 0 {
				_, ok = matchRiskDataMap[matchRiskData.match.SID]
				if !ok {
					matchRiskDataMap[matchRiskData.match.SID] = matchRiskData
				}
			} else {
				ids = append(ids, matchId)
			}
		}
	}

	//插入 联赛
	for _, t := range tourDataMap {
		tourDataSlice = append(tourDataSlice, t)
	}
	err = model.BatchTournamentInsert(tourDataSlice)
	if err != nil {
		fmt.Printf("【赛事信息接口】新增联赛, Error:%s \n", err.Error())
		return ids
	}

	for _, tour := range tourDataSlice {
		commonLog := utils.TDCommon{
			TS:     "now",
			User:   "TY",
			Group:  "0",
			IP:     "0",
			Menu:   "联赛管理",
			Action: "新增联赛",
			Result: fmt.Sprintf("【游戏ID】:%v \n【联赛SID】:%v 【联赛简称】:%v \n【中文名称】:%v \n【赛事等级】:%v/%v 【启用状态】:开启",
				tour.GameID, tour.SID, tour.ShortName, tour.CnName,
				tour.MatchLevel, tour.CreditLevel),
		}
		mqtt.MqttNotifyCommonLogPub(commonLog)
	}

	//插入 战队
	for _, t := range teamDataMap {
		teamDataSlice = append(teamDataSlice, t)
	}
	err = model.BatchTeamInsert(teamDataSlice)
	if err != nil {
		fmt.Printf("【赛事信息接口】新增战队,Error:%s \n", err.Error())
		return ids
	}

	for _, team := range teamDataSlice {
		commonLog := utils.TDCommon{
			TS:     "now",
			User:   "TY",
			Group:  "0",
			IP:     "0",
			Menu:   "战队管理",
			Action: "新增战队",
			Result: fmt.Sprintf("【游戏ID】:%s【战队SID】:%s \n【战队简称】:%s \n【中文名称】:%s \n【状态】:开启",
				team.GameID, team.SID, team.ShortName, team.CnName),
		}
		mqtt.MqttNotifyCommonLogPub(commonLog)
	}

	//插入 赛事
	for _, matchRiskData := range matchRiskDataMap {
		match := matchRiskData.match
		//赛事游戏风险标签表
		err = model.MatchRiskTagInsert(matchRiskData.riskTagSlice)
		if err != nil {
			fmt.Printf("【赛事列表接口-赛事ID:%s,SID:%s】游戏ID[%s]的风险标签-插入,Error:%s\n", match.ID, match.SID, match.GameID, err.Error())
			continue
		}

		//判断游戏是否存在
		game := gameMap[match.GameID]
		match.IsOpenMatch = game.IsOpenMatch
		match.IsOpenVideo = game.IsOpenVideo
		err = model.MatchInsert(match, matchRiskData.strRiskTag)
		if err != nil {
			fmt.Printf("【赛事列表接口-赛事ID:%s,SID:%s】新增赛事,Error:%s\n", match.ID, match.SID, err.Error())
			continue
		}

		matchLog := utils.TDMatch{
			TS:                  "now",
			User:                "TY",
			Group:               "0",
			IP:                  "0",
			Menu:                "接口请求",
			Action:              "新增赛事",
			GameID:              match.GameID,
			GameShortName:       model.GameName[match.GameID],
			TournamentId:        match.TournamentID,
			TournamentShortName: model.TournamentGetName(match.TournamentID),
			Teams:               match.MatchCnTeam,
			MatchID:             match.ID,
			Result: fmt.Sprintf("【赛事SID】:%s 【赛事等级】:M%v(X%v) 【赛事类型】:%v 【早盘/滚盘】:%s 【赛事状态】:隐藏 【开始时间】:%v",
				match.SID, match.MatchLevel, match.CreditLevel, model.MatchCategoryDesc[match.Category], model.MatchIsLiveDesc[match.IsLive],
				time.Unix(match.StartTime, 0).Format("2006-01-02 15:04:05")),
		}
		mqtt.MqttNotifyMatchLogPub(matchLog)

		// 赛事开盘初始化赛事注单统计json到redis中
		err = model.InitMatchCalcJson(match.ID)
		if err != nil {
			fmt.Printf("【%s】【赛事列表接口-赛事ID:%s,SID:%s】初始化赛事注单统计json到redis错误, Error:%s\n", helper.TimeUnixToStr(time.Now().Unix()), match.ID, match.SID, err.Error())
			continue
		}

		ids = append(ids, match.ID)
	}

	return ids
}

/*
 * @Description: 联赛数据-插入
 * @Author: robin
 * @Date: 2022/1/21 15:31
 * @LastEditTime: 2022/1/21 15:31
 * @LastEditors: robin
 */
func checkTournamentInfo(tyMatchData model.TYMatchData, category int) (model.Tournament, bool, error) {

	var insertTournament model.Tournament
	//判断联赛是否存在
	var matchLevel model.MatchLevel
	t := time.Now().Unix()
	tournament, ok := tournamentSidMap[tyMatchData.TournamentID]
	if !ok {
		level, err := model.MatchLevelGetDefault(category, tyMatchData.StandardMatchID)
		if err != nil {
			fmt.Printf("【赛事列表接口-赛事SID:%s,联赛ID:%s】MatchLevelGetDefault 获取风控管理-基本参数默认赛事等级,Error:%s \n", tyMatchData.StandardMatchID, tyMatchData.TournamentID, err.Error())
			return insertTournament, false, err
		}

		matchLevel, ok = matchLevelMap[level]
		if !ok {
			matchLevel, err = model.MatchLevelFindOne(g.Ex{"level": level})
			if err != nil {
				fmt.Printf("【赛事列表接口-赛事SID:%s,联赛ID:%s】MatchLevelFindOne 风控管理-赛事等级,查询赛事等级[%d]-Error:%s \n", tyMatchData.StandardMatchID, tyMatchData.TournamentID, level, err.Error())
				return insertTournament, false, err
			}

			matchLevelMap[level] = matchLevel
			commonLog := utils.TDCommon{
				TS:     "now",
				User:   "TY",
				Group:  "0",
				IP:     "0",
				Menu:   "风控管理",
				Action: "赛事等级",
				Result: fmt.Sprintf("【游戏ID】:%s 【默认等级】:%d/%d", model.MatchCategoryGameID[category], matchLevel.Level, matchLevel.CreditLevel),
			}
			mqtt.MqttNotifyCommonLogPub(commonLog)
		}

		insertTournament = model.Tournament{
			ID:           strconv.FormatUint(helper.Cputicks(), 10),
			SID:          tyMatchData.TournamentID,
			GameID:       model.MatchCategoryGameID[category],
			ShortName:    helper.FilterInjection(tyMatchData.TournamentName),
			EnName:       helper.FilterInjection(tyMatchData.TournamentName),
			CnName:       helper.FilterInjection(tyMatchData.TournamentName),
			MatchLevel:   matchLevel.Level,
			CreditLevel:  matchLevel.CreditLevel,
			IsPassOff:    0,
			Status:       model.StatusOpen,
			SortCode:     0,
			CreateTime:   t,
			CreateByID:   0,
			CreateByName: "TY",
			UpdateTime:   t,
			UpdateByID:   0,
			UpdateByName: "TY",
			GameName:     "",
			Visible:      model.VisibleOpen,
		}
		tournamentSidMap[tyMatchData.TournamentID] = insertTournament
		tournamentIdMap[insertTournament.ID] = insertTournament
		return insertTournament, false, nil
	}

	return tournament, true, nil
}

/*
 * @Description: 战队信息-插入
 * @Author: robin
 * @Date: 2022/1/21 14:57
 * @LastEditTime: 2022/1/21 14:57
 * @LastEditors: robin
 */
func checkTeamInfo(tyMatchData model.TYMatchData, tournament model.Tournament, gameShortName string) ([]model.Team, []model.Team, error) {

	var (
		matchTeamSlice []model.Team
		teamInsertData []model.Team
	)

	//判断战队是否存在(主队,客队)
	matchTeamSlice, err := model.TeamListDB(g.Ex{"sid": []string{tyMatchData.HomeTeamID, tyMatchData.GuestTeamID}})
	if err != nil {
		fmt.Printf("【赛事列表接口-赛事SID:%s】 获取战队数据[主战队:%s,客战队:%s],Error:%s\n", tyMatchData.StandardMatchID, tyMatchData.HomeTeamID, tyMatchData.GuestTeamID, err.Error())
		return teamInsertData, matchTeamSlice, err
	}

	if len(matchTeamSlice) > 2 {
		_ = model.DeleteTeam(g.Ex{"sid": []string{tyMatchData.HomeTeamID, tyMatchData.GuestTeamID}})
		matchTeamSlice = []model.Team{}
	}

	bHomeExist := false
	bGuestExist := false
	for _, team := range matchTeamSlice {
		if team.SID == tyMatchData.HomeTeamID {
			bHomeExist = true
		} else if team.SID == tyMatchData.GuestTeamID {
			bGuestExist = true
		}
	}

	t := time.Now().Unix()
	if bHomeExist == false { //新增战队-主队
		team := model.Team{
			ID:            fmt.Sprintf("%d", helper.Cputicks()),
			SID:           tyMatchData.HomeTeamID,
			GameID:        tournament.GameID,
			ShortName:     helper.FilterInjection(tyMatchData.HomeTeamName),
			CnName:        helper.FilterInjection(tyMatchData.HomeTeamName),
			EnName:        helper.FilterInjection(tyMatchData.HomeTeamName),
			Images:        model.GetTeamLogo(tyMatchData.HomeTeamLogo, tyMatchData.HomeTeamName),
			GameShortName: gameShortName,
			CreateByID:    0,
			UpdateByID:    0,
			CreateTime:    t,
			UpdateTime:    t,
			CreateByName:  "TY",
			UpdateByName:  "TY",
			SortCode:      0,
			Status:        model.StatusOpen,
			Visible:       model.VisibleOpen,
		}
		teamInsertData = append(teamInsertData, team)
		matchTeamSlice = append(matchTeamSlice, team)
	}

	if bGuestExist == false { //新增战队-客队
		team := model.Team{
			ID:            fmt.Sprintf("%d", helper.Cputicks()),
			SID:           tyMatchData.GuestTeamID,
			GameID:        tournament.GameID,
			ShortName:     helper.FilterInjection(tyMatchData.GuestTeamName),
			CnName:        helper.FilterInjection(tyMatchData.GuestTeamName),
			EnName:        helper.FilterInjection(tyMatchData.GuestTeamName),
			Images:        model.GetTeamLogo(tyMatchData.GuestTeamLogo, tyMatchData.GuestTeamName),
			GameShortName: gameShortName,
			CreateByID:    0,
			UpdateByID:    0,
			CreateTime:    t,
			UpdateTime:    t,
			CreateByName:  "TY",
			UpdateByName:  "TY",
			SortCode:      0,
			Status:        model.StatusOpen,
			Visible:       model.VisibleOpen,
		}
		teamInsertData = append(teamInsertData, team)
		matchTeamSlice = append(matchTeamSlice, team)
	}

	return teamInsertData, matchTeamSlice, nil
}

/*
 * @Description: 插入赛事信息
 * @Author: robin
 * @Date: 2021/12/6 16:45
 * @LastEditTime: 2021/12/6 16:45
 * @LastEditors: robin
 */
func checkMatchInfo(tyMatchData model.TYMatchData, tournament model.Tournament, matchTeams []model.Team, category int) (string, MatchRiskData, error) {

	var (
		matchId       string
		matchRiskData MatchRiskData
	)

	m, err := model.MatchFindOne(g.Ex{"sid": tyMatchData.StandardMatchID})
	if err != nil {
		fmt.Printf("【赛事列表接口-赛事SID：%s】MatchFindOne 赛事查询,Error[%s].\n", tyMatchData.StandardMatchID, err.Error())
		return matchId, matchRiskData, err
	}

	//赛事已取消
	if m.Status == model.MatchStatusCancel {
		fmt.Printf("【赛事列表接口-赛事ID：%s,SID:%s】赛事已取消.\n", m.ID, m.SID)
		return matchId, matchRiskData, nil
	}

	//赛事已结算
	if m.Status == model.MatchStatusSettle {
		fmt.Printf("【赛事列表接口-赛事ID：%s,SID:%s】赛事已结算.\n", m.ID, m.SID)
		if len(tyMatchData.ScoreArray) == 0 {
			return matchId, matchRiskData, nil
		}

		if (time.Now().Unix() - m.StartTime) > model.EighteenHours { // 忽略超过(赛事开始时间)18小时的赛事
			return matchId, matchRiskData, nil
		}

		// todo:xp
		mpMatchMarketID := map[string]string{
			"": m.ID,
		}
		handicapInfo, err := utils.HandicapInfo(model.GetZkRedis().GetClusterClient(), mpMatchMarketID)
		if err != nil {
			fmt.Printf("【赛事列表接口-赛事ID:%s,SID:%s】HandicapInfo 赛事缓存信息,Error:%s\n", m.ID, m.SID, err.Error())
			return matchId, matchRiskData, nil
		}

		match := handicapInfo.Matches[m.ID]
		if len(match.ID) == 0 {
			fmt.Printf("【赛事列表接口-赛事ID:%s,SID:%s】游戏[%s]电竞赛事不存在于缓存Redis \n", m.ID, m.SID, model.GameName[match.GameID])
			return matchId, matchRiskData, nil
		}

		checkMatchScore(&match, tyMatchData) //赛事结算之后,更新有争议的赛事比分.
		return matchId, matchRiskData, nil
	}

	fmt.Printf("【赛事信息】HTTP请求,【赛事ID:%s】【支持滚盘(0-否,1-是)】:(mlive=%d),【初盘/滚盘(早盘[0,111],滚盘[1,2,10,110])】:(ms=%d),【赛事结束状态-(ms:3,4 mo:1, mmp:999)】:(ms=%d,mo=%d,mmp=%v),【赛事取消(5-取消,6-比赛放弃,10-比赛中断)】:(ms=%d).\n",
		tyMatchData.StandardMatchID, tyMatchData.SupportLive,
		tyMatchData.MatchStatus,
		tyMatchData.MatchStatus, tyMatchData.IsOver, tyMatchData.Stage,
		tyMatchData.MatchStatus)

	if len(m.ID) > 0 {
		// todo:xp
		mpMatchMarketID := map[string]string{
			"": m.ID,
		}
		handicapInfo, err := utils.HandicapInfo(model.GetZkRedis().GetClusterClient(), mpMatchMarketID)
		if err != nil {
			fmt.Printf("【赛事列表接口-赛事ID:%s,SID:%s】HandicapInfo 赛事缓存信息,Error:%s\n", m.ID, m.SID, err.Error())
			return matchId, matchRiskData, nil
		}

		match := handicapInfo.Matches[m.ID]
		if len(match.ID) == 0 {
			fmt.Printf("【赛事列表接口-赛事ID:%s,SID:%s】游戏[%s]电竞赛事不存在于缓存Redis \n", m.ID, m.SID, model.GameName[match.GameID])
			return matchId, matchRiskData, nil
		}

		updateMatchStatus(match, tyMatchData)
		if match.Status == model.MatchStatusClosed { //赛事已结束
			return matchId, matchRiskData, nil
		}

		return m.ID, matchRiskData, nil
	}

	bFinishStatus := getMatchFinishStatus(tyMatchData)
	if !bFinishStatus { //已结束的赛事,不必新增赛事
		return matchId, matchRiskData, nil
	}

	bMatchCancel := getMatchCancelStatus(tyMatchData) //赛事已取消
	if bMatchCancel {                                 //已取消的赛事,不必新增赛事
		return matchId, matchRiskData, nil
	}

	//判断联赛是否存在
	var matchLevel model.MatchLevel
	t := time.Now().Unix()

	// 校验赛事等级
	matchLevel, ok := matchLevelMap[tournament.MatchLevel]
	if !ok {
		level, err := model.MatchLevelGetDefault(category, tyMatchData.StandardMatchID)
		if err != nil {
			fmt.Printf("【赛事列表接口-赛事SID:%s,联赛ID:%s】获取风控管理-基本参数默认赛事等级,Error:%s \n", tyMatchData.StandardMatchID, tyMatchData.TournamentID, err.Error())
			return matchId, matchRiskData, nil
		}

		matchLevel, ok = matchLevelMap[level]
		if !ok {
			matchLevel, err = model.MatchLevelFindOne(g.Ex{"level": level})
			if err != nil {
				fmt.Printf("【赛事列表接口-赛事SID:%s,联赛ID:%s】风控管理-赛事等级,查询NBA2K,FIFA默认赛事等级[%d] \n", tyMatchData.StandardMatchID, tyMatchData.TournamentID, level)
				return matchId, matchRiskData, nil
			}

			matchLevelMap[level] = matchLevel
			commonLog := utils.TDCommon{
				TS:     "now",
				User:   "TY",
				Group:  "0",
				IP:     "0",
				Menu:   "风控管理",
				Action: "赛事等级",
				Result: fmt.Sprintf("【游戏ID】:%s 【默认等级】:%d/%d", model.MatchCategoryGameID[category], matchLevel.Level, matchLevel.CreditLevel),
			}
			mqtt.MqttNotifyCommonLogPub(commonLog)
		}
	}

	var (
		teamIds  []string
		teamData []model.Team
	)

	bHomeExist := false
	bGuestExist := false
	for _, team := range matchTeams {
		if team.SID == tyMatchData.HomeTeamID {
			bHomeExist = true
			team.SortCode = 0
			teamData = append(teamData, team)
		} else if team.SID == tyMatchData.GuestTeamID {
			bGuestExist = true
			team.SortCode = 1
			teamData = append(teamData, team)
		}
	}

	if !bHomeExist {
		fmt.Printf("赛事【主战队-SID:%s】不存在于战队表里.\n", tyMatchData.HomeTeamID)
		return matchId, matchRiskData, nil
	}

	if !bGuestExist {
		fmt.Printf("赛事【客战队-SID:%s】不存在于战队表里.\n", tyMatchData.GuestTeamID)
		return matchId, matchRiskData, nil
	}

	//排序:0-主队,1-客队
	sort.Slice(teamData, func(i, j int) bool {
		return teamData[j].SortCode > teamData[i].SortCode
	})

	for _, team := range teamData {
		teamIds = append(teamIds, team.ID)
	}

	tyMatchData.StartTime = tyMatchData.StartTime[0:10]
	startTime, err := strconv.ParseInt(tyMatchData.StartTime, 10, 64)
	if err != nil {
		return matchId, matchRiskData, err
	}

	teamShortName, teamCnName, teamEnName := genMatchCnTeamAndEnTeam(teamData, teamIds)
	teamID := helper.FilterInjection(strings.Join(teamIds, ","))

	isLive := getMatchLiveStatus(tyMatchData.MatchStatus)

	var strVideoUrl string
	if tyMatchData.VideoStatus >= 0 && isLive == model.MatchLive { // 滚球阶段-体育赛事是否配置视频源: 0-视频源无效,1-视频源未播放,2-正在播放
		strVideoUrl = conf.Cfg.TYApiConf.VideoURL
	}
	matchID := fmt.Sprintf("%d", helper.Cputicks())
	match := model.Match{
		ID:                      matchID,
		SID:                     tyMatchData.StandardMatchID, //标准赛事ID
		DataSource:              model.DataSourceTY,          //数据源
		Mode:                    model.ModeMTS,               //MTS模式
		GameID:                  tournament.GameID,
		TournamentID:            tournament.ID,
		TournamentShortName:     helper.FilterInjection(tournament.ShortName),
		TournamentCnName:        helper.FilterInjection(tournament.CnName),
		MatchTeam:               helper.FilterInjection(teamShortName),
		MatchCnTeam:             helper.FilterInjection(teamCnName),
		MatchEnTeam:             helper.FilterInjection(teamEnName),
		TeamID:                  teamID,
		Category:                category,
		Title:                   "",
		Bo:                      -1,
		StartTime:               startTime,
		CloseTime:               0,
		EndTime:                 0,
		AutoClosedTime:          0,
		UserVideoUrl:            "",
		AdminVideoUrl:           strVideoUrl,
		MatchLevel:              tournament.MatchLevel,
		CreditLevel:             tournament.CreditLevel,
		Status:                  model.MatchStatusOpened,
		IsLive:                  isLive,
		LiveSupport:             tyMatchData.SupportLive,
		IsPassOff:               0,
		Suspended:               0,
		Visible:                 model.VisibleClose, //赛事默认隐藏
		BetDelayTime:            10,
		CreateTime:              time.Now().Unix(),
		CreateByID:              0,
		CreateByName:            "TY",
		UpdateTime:              0,
		Score:                   "0:0",
		Rec:                     0,
		RateLimit:               100, // 限红比例
		RateReduce:              0,   // 返还率缩减
		RndCompPrizeLimit:       matchLevel.RndCompPrizeLimit,
		RndCompMchPrizeLimit:    matchLevel.RndCompMchPrizeLimit,
		RndCompOddDscnt:         matchLevel.RndCompOddDscnt,
		MbMchPrizeLimit:         matchLevel.MbMchPrizeLimit, // 会员赛事限红
		VideoType:               1,
		VideoLabel:              0,
		MixOddDscnt:             matchLevel.MixOddDscnt,
		MixMchPrizeLimit:        matchLevel.MixMchPrizeLimit,
		MchsCompPrizeTotalLimit: matchLevel.MchsCompPrizeTotalLimit,
	}

	//获取游戏所关联的风险标签ID
	riskTagList, err := model.GameRiskTagFindAll(g.Ex{"game_id": tournament.GameID})
	if err != nil {
		fmt.Printf("【%s】【赛事列表接口-赛事SID:%s】游戏ID[%s]的风险标签查找错误\n", helper.TimeUnixToStr(time.Now().Unix()), tyMatchData.StandardMatchID, tournament.GameID)
		return matchId, matchRiskData, err
	}

	var (
		matchRiskTag []model.MatchRiskTag
		riskTagIds   string
	)
	if len(riskTagList) > 0 {
		for _, d := range riskTagList {
			riskTag := model.MatchRiskTag{
				ID:           fmt.Sprintf("%d", helper.Cputicks()),
				MatchID:      matchID,
				GameID:       tournament.GameID,
				RiskTagID:    d.RiskTagID,
				CreateTime:   t,
				CreateByID:   0,
				CreateByName: "TY",
			}
			matchRiskTag = append(matchRiskTag, riskTag)
			if riskTagIds != "" {
				riskTagIds += ","
			}
			riskTagIds += d.RiskTagID
		}
	}

	matchRiskData = MatchRiskData{
		match:        match,
		strRiskTag:   riskTagIds,
		riskTagSlice: matchRiskTag,
	}

	return match.ID, matchRiskData, nil
}

/*
 * @Description: 更新赛事状态信息(结束)
 * @Author: robin
 * @Date: 2021/12/19 13:29
 * @LastEditTime: 2021/12/19 13:29
 * @LastEditors: robin
 */
func updateMatchStatus(match utils.MatchData, tyMatchData model.TYMatchData) {

	bMatchCancel := getMatchCancelStatus(tyMatchData) //赛事已取消
	if bMatchCancel && match.Status == model.MatchStatusCancel {
		return
	}

	checkMatchScore(&match, tyMatchData)
	strStage := fmt.Sprintf("%v", tyMatchData.Stage)
	bFinishStatus := getMatchFinishStatus(tyMatchData)
	if bFinishStatus { //赛事未结束: (滚球赛事)更新赛事计时器
		//取消赛事
		if bMatchCancel && match.Status != model.MatchStatusCancel {

			err := model.RequestMatchCancel(match)
			if err != nil {
				fmt.Printf("【赛事取消-赛事ID:%s,SID:%s】RequestMatchCancel,Error: %s \n", match.ID, match.SID, err.Error())
			}
			return
		}

		//赛事设置支持滚球:0-否,1-是
		isLive := getMatchLiveStatus(tyMatchData.MatchStatus)
		if match.IsLive == isLive && match.LiveSupport != tyMatchData.SupportLive {
			match.LiveSupport = tyMatchData.SupportLive
			err := model.MatchLiveSupportSet(match)
			if err != nil {
				fmt.Printf("【赛事设置支持滚盘-赛事ID:%s,SID:%s】MatchLiveSupportSet,Error:%s\n", match.ID, match.SID, err.Error())
			}
		}

		//赛事阶段:早盘 切换为 滚盘
		if match.IsLive != isLive && isLive == model.MatchLive {
			match.IsLive = isLive
			match.LiveSupport = tyMatchData.SupportLive
			err := model.MatchLiveSet(match, tyMatchData)
			if err != nil {
				fmt.Printf("【赛事滚盘-赛事ID:%s,SID:%s】MatchLiveSupportSet,Error:%s\n", match.ID, match.SID, err.Error())
			}
		}

		//赛事计时器
		if match.IsLive != model.MatchLive {
			return
		}

		tyRound, ok := model.RoundsMapData[match.Category][strStage]
		if !ok {
			return
		}

		if len(tyMatchData.RunTime) == 0 {
			return
		}

		err := model.MatchRoundSet(match.ID, tyRound)
		if err != nil {
			fmt.Printf("【滚球赛事-赛事ID:%s,SID:%s】小节/半场 设置计时器错误, Error:%s \n", match.ID, match.SID, err.Error())
			return
		}

		roundTime, err := strconv.ParseInt(tyMatchData.RunTime, 10, 64)
		if err != nil {
			fmt.Printf("【滚球赛事-赛事ID:%s,SID:%s】RoundTime ParseInt 解析计时器错误, Error: %s \n", match.ID, match.SID, err.Error())
			return
		}
		param := mqtt.MatchTimer{
			MatchID:    match.ID,
			StartTime:  time.Now().Unix(),
			TimeTicket: roundTime,
			Round:      tyRound,
			Status:     model.TimerStatusOpen,
		}
		err = model.MatchTimerRejsonSet(param)
		if err != nil {
			fmt.Printf("【滚球赛事-赛事ID:%s,SID:%s】MatchTimerRejsonSet 设置滚球赛事计时器, Error: %s \n", match.ID, match.SID, err.Error())
			return
		}

		// MQTT推送
		tm, err := model.MatchTimerRejsonGet(match.ID, time.Now().Unix())
		if err != nil {
			fmt.Printf("【滚球赛事-赛事ID:%s,SID:%s】MatchTimerRejsonGet 推送滚球赛事计时器, Error: %s \n", match.ID, match.SID, err.Error())
			return
		}

		mqtt.MqttNotifyMatchTimerUpdate(tm)
		return
	}

	//赛事结束(同时更新所有已开盘的盘口均设置为已关盘)
	if match.Status < model.MatchStatusClosed {
		err := model.UpdateGameNav(match, model.MatchStatusClosed, model.VisibleClose)
		if err != nil {
			fmt.Printf("【赛事结束-赛事ID:%s,SID:%s】UpdateGameNav,Error:%s\n", match.ID, match.SID, err.Error())
			return
		}
		match.Status = model.MatchStatusClosed
	}

	//赛事结算
	if match.Status == model.MatchStatusClosed {
		_, ok := matchSettleMap[match.ID]
		if !ok {
			matchSettleMap[match.ID] = time.Now().Unix()
			return
		}

		if (time.Now().Unix() - matchSettleMap[match.ID]) < model.FiveMinutes { //延时5分钟 等待注单结算完毕
			return
		}

		checkMatchSettle(match)
	}
}

/*
 * @Description: 赛事结算
 * @Author: robin
 * @Date: 2022/1/28 17:26
 * @LastEditTime: 2022/1/28 17:26
 * @LastEditors: robin
 */
func checkMatchSettle(match utils.MatchData) {

	match.Visible = model.VisibleOpen
	match.Status = model.MatchStatusSettle
	bSettle, err := model.UpdateMatchSettle(match, matchSettleMap[match.ID])
	if err != nil {
		fmt.Printf("【赛事结算-赛事ID:%s,SID:%s】UpdateMatchStatus,Error:%s\n", match.ID, match.SID, err.Error())
	}
	if bSettle {
		delete(matchSettleMap, match.ID)
	}
	if len(matchSettleMap) == 0 {
		matchSettleMap = nil
		matchSettleMap = map[string]int64{}
	}
}

/*
 * @Description: 赛事比分
 * @Author: robin
 * @Date: 2021/12/23 19:46
 * @LastEditTime: 2021/12/23 19:46
 * @LastEditors: robin
 */
func checkMatchScore(match *utils.MatchData, tyMatchData model.TYMatchData) {

	if len(tyMatchData.ScoreArray) == 0 {
		return
	}

	if (time.Now().Unix() - match.StartTime) > model.EighteenHours { // 忽略超过(赛事开始时间)18小时的赛事
		return
	}

	//全场比分
	strScore := tyMatchData.ScoreArray[0]
	if !strings.Contains(strScore, "S1") {
		return
	}

	tmpScore := strings.Split(strScore, "|")
	if !(len(tmpScore) == 2 && tmpScore[1] != match.Score) {
		return
	}

	if match.Score != tmpScore[1] {
		match.Score = tmpScore[1]
		err := model.UpdateMatchScore(*match)
		if err != nil {
			fmt.Printf("【赛事比分:%s】UpdateMatchScore,全场比分更新错误,Error:%s\n", match.ID, err.Error())
			return
		}

		updateRoundScore(match, 0, match.Score)

		//记录赛事操盘日志
		matchLog := utils.TDMatch{
			TS:                  "now",
			User:                "TY",
			Group:               "0",
			IP:                  "0",
			Menu:                "赛事比分",
			Action:              "全场比分",
			GameID:              match.GameID,
			GameShortName:       model.GetGameName(match.GameID),
			TournamentId:        match.TournamentID,
			TournamentShortName: model.TournamentGetName(match.TournamentID),
			Teams:               match.MatchCnTeam,
			MatchID:             match.ID,
			Result:              fmt.Sprintf("【局数】:全场比分【比分】:%v", match.Score),
		}
		mqtt.MqttNotifyMatchLogPub(matchLog)
	}

	if match.Category == model.DJCategoryBasketball { //忽略篮球上半场比分,仅需更新足球FIFA上半场比分
		return
	}

	//上半场比分
	strFirstHalfScore := tyMatchData.ScoreArray[1]
	if !strings.Contains(strFirstHalfScore, "S2") {
		return
	}

	tmpScore = strings.Split(strFirstHalfScore, "|")
	if !(len(tmpScore) == 2 && len(tmpScore[1]) > 0) {
		return
	}

	updateRoundScore(match, 100, tmpScore[1])

	//记录赛事操盘日志
	matchLog := utils.TDMatch{
		TS:                  "now",
		User:                "TY",
		Group:               "0",
		IP:                  "0",
		Menu:                "赛事比分",
		Action:              "上半场比分",
		GameID:              match.GameID,
		GameShortName:       model.GetGameName(match.GameID),
		TournamentId:        match.TournamentID,
		TournamentShortName: model.TournamentGetName(match.TournamentID),
		Teams:               match.MatchCnTeam,
		MatchID:             match.ID,
		Result:              fmt.Sprintf("【局数】:上半场比分【比分】:%v", tmpScore[1]),
	}
	mqtt.MqttNotifyMatchLogPub(matchLog)
}

func updateRoundScore(match *utils.MatchData, round int, roundScore string) {

	record := g.Record{
		"match_id":   match.ID,
		"round":      round,
		"match_team": match.TeamID,
		"score":      roundScore,
		"result":     1,
	}

	ex := g.Ex{
		"match_id": match.ID,
		"round":    round,
	}

	tmpScore, err := model.MatchScoreFindOne(ex)
	if err != nil && err != sql.ErrNoRows {
		fmt.Printf("【赛事比分:%s】MatchScoreFindOne,赛事比分查询错误,Error:%s\n", match.ID, err.Error())
		return
	}

	// 赛事比分录入
	if err == sql.ErrNoRows { // 新增
		record["id"] = helper.Cputicks()
		record["create_by_id"] = 0
		record["create_by_name"] = "TY"
		record["create_time"] = time.Now().Unix()
		record["winner_team"] = ""
		err = model.MatchScoreInsert(record)
	} else { // 更新
		if tmpScore.Score == roundScore {
			return
		}
		err = model.MatchScoreUpdate(record, ex)
	}

	if err != nil {
		fmt.Printf("【赛事比分:%s】赛事比分录入错误,Error:%s\n", match.ID, err.Error())
		return
	}
}

/*
 * @Description: 获取赛事结束状态(ms:3,4 mo:1, mmp:"999")
 * @Author: robin
 * @Date: 2021/12/24 13:40
 * @LastEditTime: 2021/12/24 13:40
 * @LastEditors: robin
 */
func getMatchFinishStatus(tyMatchData model.TYMatchData) bool {

	strStage := fmt.Sprintf("%v", tyMatchData.Stage)
	bFinishStatus := !(tyMatchData.MatchStatus == model.TYMatchFinishStatus3 ||
		tyMatchData.MatchStatus == model.TYMatchFinishStatus4 ||
		tyMatchData.IsOver == model.TYMatchFinishStatus1 ||
		strStage == model.TYMatchFinishStatus9)

	return bFinishStatus
}

/*
 * @Description: 获取赛事撤销状态
 * @Author: robin
 * @Date: 2022/1/2 15:12
 * @LastEditTime: 2022/1/2 15:12
 * @LastEditors: robin
 */
func getMatchCancelStatus(tyMatchData model.TYMatchData) bool {

	bCancelStatus := tyMatchData.MatchStatus == model.TYMatchFinishStatus5 ||
		tyMatchData.MatchStatus == model.TYMatchFinishStatus6 ||
		tyMatchData.MatchStatus == model.TYMatchFinishStatus10

	return bCancelStatus
}

/*
 * @Description: 获取赛事滚球状态
 * @Author: robin
 * @Date: 2021/12/24 15:20
 * @LastEditTime: 2021/12/24 15:20
 * @LastEditors: robin
 */
func getMatchLiveStatus(matchStatus int) int {

	var (
		isLive int
	)
	switch matchStatus { //赛事状态：(早盘[0,111],滚盘[1,2,10,110])
	case 0, 111: //初盘
		isLive = model.MatchEarly
	case 1, 2, 10, 110: //滚盘
		isLive = model.MatchLive
	}

	return isLive
}

/*
 * @Description: 获取赛事的所有玩法
 * @Author: robin
 * @Date: 2021/11/30 17:26
 * @LastEditTime: 2021/11/30 17:26
 * @LastEditors: robin
 */
func oddsInfoListGet(matchId string) {

	mpMatchMarketID := map[string]string{
		"": matchId,
	}
	handicapInfo, err := utils.HandicapInfo(model.GetZkRedis().GetClusterClient(), mpMatchMarketID)
	if err != nil {
		fmt.Printf("【玩法赔率接口-赛事ID:%s】HandicapInfo 赛事缓存信息,Error:%s\n", matchId, err.Error())
		return
	}

	match := handicapInfo.Matches[matchId]
	if len(match.ID) == 0 || len(match.SID) == 0 {
		fmt.Printf("【玩法赔率接口-赛事ID:%s】电竞赛事不存在于缓存Redis \n", matchId)
		return
	}

	if match.Status != model.MatchStatusOpened {
		fmt.Printf("【玩法赔率接口-赛事ID:%s,SID:%s】游戏[%s]赛事状态[%s],不必再新增盘口\n", match.ID, match.SID, model.GameName[match.GameID], model.MatchStatusDesc[match.Status])
		return
	}

	sid := match.SID
	url := fmt.Sprintf("%s%s", conf.Cfg.TYApiConf.MarketURL, sid)
	resp, err := http.Get(url)
	if err != nil {
		fmt.Printf("【玩法赔率接口-赛事ID:%s,SID:%s】玩法赔率-HTTP请求,Error. [%v]\n", match.ID, sid, err)
		if err = beanstalk.BeansPutMonitorTask(model.ZkBeansPool, beanstalk.ApiAlertTpl, "error", "获取赛事的所有玩法错误 ： "+err.Error()); err != nil {
			fmt.Println(err.Error())
		}
		return
	}

	defer resp.Body.Close()
	respBytes, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		fmt.Printf("【玩法赔率接口-赛事ID:%s,SID:%s】HTTP请求-读取返回数据,Error:%s\n", match.ID, sid, err.Error())
		return
	}

	tyGetOddTypeData := model.TYGetOddTypeDataResp{}
	err = helper.JsonUnmarshal(respBytes, &tyGetOddTypeData)
	if err != nil {
		fmt.Printf("【玩法赔率接口-赛事ID:%s,SID:%s】JsonUnmarshal,Error: %v \n", match.ID, sid, err.Error())
		fmt.Printf("【玩法赔率接口-赛事ID:%s,SID:%s】HTTP请求返回信息,Error:%s\n", match.ID, sid, string(respBytes))
		return
	}

	if tyGetOddTypeData.Code != model.SUCCESS {
		fmt.Printf("【玩法赔率接口-赛事ID:%s,SID:%s】HTTP请求失败 Error[%v].ErrCode:[%v].\n返回信息:%s\n", match.ID, sid, tyGetOddTypeData.Msg, tyGetOddTypeData.Code, string(respBytes))
		if err = beanstalk.BeansPutMonitorTask(model.ZkBeansPool, beanstalk.ApiAlertTpl, "error", "获取赛事的所有玩法错误,Code ： "+tyGetOddTypeData.Code); err != nil {
			fmt.Println(err.Error())
		}
		return
	}

	var tyOddData model.TYOddTypeData
	for _, v := range tyGetOddTypeData.Data {
		if len(v.MarketList) == 0 {
			continue
		}
		tyOddData.MarketList = append(tyOddData.MarketList, v.MarketList...)
	}
	if len(tyOddData.MarketList) == 0 {
		fmt.Printf("【玩法赔率接口-赛事ID:%s,SID:%s】盘口列表为空.\n", match.ID, sid)
		return
	}

	//判断联赛是否存在
	tournament, ok := tournamentIdMap[match.TournamentID]
	if !ok {
		fmt.Printf("【玩法赔率接口-赛事ID:%s,SID:%s】游戏[%s]联赛ID[%s]不存在\n", match.ID, sid, model.GameName[match.GameID], match.TournamentID)
		return
	}

	// 获取赛事等级设置
	matchLv, ok := matchLevelMap[tournament.MatchLevel]
	if !ok {
		fmt.Printf("【玩法赔率接口-赛事ID:%s,SID:%s】游戏[%s]联赛ID[%s]的联赛等级[%d]不存在\n", match.ID, sid, model.GameName[match.GameID], match.TournamentID, tournament.MatchLevel)
		return
	}

	ex := g.Ex{
		"game_id":  match.GameID,
		"status":   model.StatusOpen,
		"category": []int{model.OddTypeCategoryAll, model.OddTypeCategoryHalf},
		"sid":      g.Op{"gt": 0},
	}

	// 获取玩法类型列表数据
	oddTypes, err := model.OddTypeListDB(ex)
	if err != nil {
		fmt.Printf("【玩法赔率接口-赛事ID:%s,SID:%s】获取玩法类型列表数据错误,Error:%s\n", match.ID, sid, err.Error())
		return
	}

	if len(oddTypes) == 0 {
		return
	}

	oddTypeMap := map[string]int16{}
	oddTypeListMap := map[string]string{}
	for _, oddType := range oddTypes {
		round := int16(0)         //0-全局  100-半场
		switch oddType.Category { //体育NBA2K 不开启单节(单局)玩法
		case model.OddTypeCategoryAll:
			round = 0
		case model.OddTypeCategoryHalf:
			round = 100
		}
		oddTypeMap[oddType.SID] = round
		oddTypeListMap[oddType.SID] = oddType.ID
	}

	round := []interface{}{
		model.AllOfRound,  //全局/全场
		model.HalfOfRound, //半场
	}
	// 先获取已保存的盘口
	var (
		strDefaultMarketID string           //新的默认盘口ID
		existDefaultMarket model.MarketData //已存在默认盘口
	)

	marketsSave, err := model.MarketListDB(g.Ex{"match_id": match.ID, "round": round})
	if err != nil {
		fmt.Printf("【玩法赔率接口-赛事ID:%s,SID:%s】获取已保存盘口列表,Error:%s\n", match.ID, sid, err.Error())
		return
	}

	marketsSaveMap := map[string][]model.MarketData{}
	for _, m := range marketsSave {
		marketsSaveMap[m.OddTypeID] = append(marketsSaveMap[m.OddTypeID], m)
	}
	var (
		tyMarkets      []model.TYMarketListData
		tyExistMarkets []model.TYMarketListData
	)
	//插入更新-盘口
	for _, v := range tyOddData.MarketList {
		_, ok := oddTypeMap[v.OddID]
		if !ok {
			fmt.Printf("【玩法赔率接口-赛事ID:%s,SID:%s】游戏[%s]玩法ID[%s]不存在.\n", match.ID, sid, model.GameName[match.GameID], v.OddID)
			continue
		}

		oddID := oddTypeListMap[v.OddID]
		if _, ok := marketsSaveMap[oddID]; ok {
			bExist := false
			for _, m := range marketsSaveMap[oddID] {
				if v.ID == m.ID { // 已保存盘口
					bExist = true
					if m.IsDefault == 1 { //  该保存盘口为默认盘口
						existDefaultMarket = m
					}
					break
				}
			}
			if !bExist {
				tyMarkets = append(tyMarkets, v)
			} else {
				tyExistMarkets = append(tyExistMarkets, v)
			}
		} else {
			tyMarkets = append(tyMarkets, v)
		}
	}

	if len(tyExistMarkets) > 0 { //更新盘口值-投注项名称
		err := model.OddsNameUpdate(match, tyExistMarkets, oddTypes)
		if err != nil {
			fmt.Printf("【玩法赔率接口-赛事ID:%s,SID:%s】OddsNameUpdate 更新盘口值-投注项名称,Error:%s \n", match.ID, sid, err.Error())
		}
	}

	if len(tyMarkets) == 0 {
		return
	}

	//根据玩法生成初始化盘口数据
	oddTypeMarkets, err := model.MarketListInit(match, matchLv, tyMarkets, oddTypes, &existDefaultMarket, &strDefaultMarketID)
	if err != nil {
		fmt.Printf("【玩法赔率接口-赛事ID:%s,SID:%s】marketListInit 根据玩法生成初始化盘口数据错误,Error:%s \n", match.ID, sid, err.Error())
		return
	}

	var (
		markets []model.Market
		odds    []model.Odd
	)
	t := time.Now().Unix()
	userID := helper.Cputicks()
	for _, data := range oddTypeMarkets {
		var (
			mkt []model.Market
			odd []model.Odd
		)
		err = model.MarketSaveArgs(data, userID, match, t, &mkt, &odd)
		if err != nil {
			fmt.Printf("【玩法赔率接口-赛事ID:%s,SID:%s】盘口ID[%s]保存错误, Error:%v \n", match.ID, sid, data.ID, err.Error())
			return
		}

		markets = append(markets, mkt...)
		odds = append(odds, odd...)
	}

	if len(markets) == 0 {
		return
	}

	bUpdateDefMarket := true
	if len(strDefaultMarketID) > 0 && len(existDefaultMarket.ID) > 0 {
		for i, mkt := range markets {
			if mkt.ID == existDefaultMarket.ID && mkt.IsDefault == 1 { // 更新设置其他默认盘口为非默认盘口,确保当前新增盘口,仅有一个默认盘口
				markets[i].IsDefault = 0
				bUpdateDefMarket = false
				fmt.Printf("存在重复默认盘口 盘口名称:%s ,ID:%s \n", existDefaultMarket.CnName, existDefaultMarket.ID)
				break
			}
		}
	}

	//保存盘口
	status, err := model.MarketSave(match.ID, markets, odds)
	if err != nil {
		fmt.Printf("【玩法赔率接口-赛事ID:%s,SID:%s】盘口保存错误 Error:%s \n", match.ID, sid, err.Error())
		return
	}

	//推送新增盘口消息
	mqtt.MqttNotifyMarketAdd(match.ID)

	if status && bUpdateDefMarket && len(strDefaultMarketID) > 0 && len(existDefaultMarket.ID) > 0 { //默认盘口-变更:是->否
		record := g.Record{
			"is_default":     0,
			"update_by_name": "TY",
			"update_time":    time.Now().Unix(),
		}
		fmt.Printf("替换默认盘口 盘口名称:%s ,ID:%s , 新盘口ID:%s \n", existDefaultMarket.CnName, existDefaultMarket.ID, strDefaultMarketID)
		err = model.MarketUpdate(existDefaultMarket.MatchID, record, g.Ex{"id": existDefaultMarket.ID})
		if err != nil {
			fmt.Printf("【玩法赔率接口-赛事ID:%s,SID:%s】默认盘口[%s]变更:是->否,Error:%s\n", match.ID, sid, existDefaultMarket.ID, err.Error())
			return
		}

		logResult := fmt.Sprintf("【类型】:%v 【默认盘口】:是->否 \n【显示/隐藏】:%s 【暂停/取消暂停】状态:%s\n",
			model.OddTypeOptionTypeDesc[int(existDefaultMarket.OptionType)],
			model.VisibleStatus[int(existDefaultMarket.Visible)],
			model.SuspendedStatus[int(existDefaultMarket.Suspended)])
		mktLog := utils.TDMarket{
			TS:                  "now",
			User:                "TY",
			Group:               "0",
			IP:                  "0",
			Menu:                "请求接口",
			Action:              "默认盘口-变更",
			GameID:              match.GameID,
			GameShortName:       model.GameName[match.GameID],
			TournamentId:        match.TournamentID,
			TournamentShortName: tournament.ShortName,
			Teams:               match.MatchCnTeam,
			MatchID:             match.ID,
			MarketID:            existDefaultMarket.ID,
			MarketEnName:        existDefaultMarket.CnName,
			Round:               existDefaultMarket.Round,
			Result:              logResult,
			Category:            int8(match.Category),
		}

		mqtt.MqttNotifyMarketLogPub(mktLog)
	}

	for _, mkt := range markets {
		logResult := fmt.Sprintf("【类型】:%v 【默认盘口】:%v\n【显示/隐藏】状态:%s \n【暂停/取消暂停】状态:%s\n",
			model.OddTypeOptionTypeDesc[int(mkt.OptionType)],
			model.YesNoDesc[int(mkt.IsDefault)],
			model.VisibleStatus[int(mkt.Visible)],
			model.SuspendedStatus[int(mkt.Suspended)])
		mktLog := utils.TDMarket{
			TS:                  "now",
			User:                "TY",
			Group:               "0",
			IP:                  "0",
			Menu:                "请求接口",
			Action:              "新增盘口",
			GameID:              match.GameID,
			GameShortName:       model.GameName[match.GameID],
			TournamentId:        match.TournamentID,
			TournamentShortName: tournament.ShortName,
			Teams:               match.MatchCnTeam,
			MatchID:             match.ID,
			MarketID:            mkt.ID,
			MarketEnName:        mkt.CnName,
			Round:               mkt.Round,
			Result:              logResult,
			Category:            int8(match.Category),
		}

		mqtt.MqttNotifyMarketLogPub(mktLog)
	}

	//操盘界面-盘口数统计(待开盘,可投注,暂停,隐藏)
	mkts, err := model.MarketListDB(g.Ex{
		"match_id": match.ID,
		"status":   []int{model.MarketStatusWaitOpen, model.MarketStatusOpen},
	})
	counts := model.CalcMarketCountGet(mkts)
	mqtt.MqttNotifyMarketCountsUpdate(match.ID, counts)

	//设置游戏客户端 赛事计数
	if status == true { //
		matchVisible := match.Visible //若电竞操盘界面 已操作赛事(隐藏) 则保持赛事当前(隐藏)状态
		if !model.GetMatchTradeStatus(match.SID) {
			matchVisible = model.VisibleOpen
		}
		err = model.UpdateGameNav(match, match.Status, matchVisible)
		if err != nil {
			fmt.Printf("【玩法赔率接口-赛事ID:%s,SID:%s】UpdateGameNav 更新游戏赛事计数错误, Error: %s \n", match.ID, sid, err.Error())
			return
		}
		//设置滚球赛事默认局数及计时器
		err = model.SetDefaultRound(match.ID, match.Category)
		if err != nil {
			fmt.Printf("【玩法赔率接口-赛事ID:%s,SID:%s】SetDefaultRound 设置滚球赛事默认局数及计时器错误, Error: %s \n", match.ID, sid, err.Error())
			return
		}
	}
}

/*
 * @Description: 加载联赛数据到Map
 * @Author: robin
 * @Date: 2021/12/13 19:27
 * @LastEditTime: 2021/12/13 19:27
 * @LastEditors: robin
 */
func loadBaseData() error {

	tournamentIdMap = map[string]model.Tournament{}
	tournamentSidMap = map[string]model.Tournament{}
	gameMap = map[string]model.Game{}
	matchLevelMap = map[int]model.MatchLevel{}

	gameSlice, err := model.GameList(g.Ex{"id": []string{model.NBA2K, model.FIFA}, "status": model.StatusOpen})
	if err != nil {
		return err
	}

	tournamentSlice, err := model.TournamentList(g.Ex{"game_id": []string{model.NBA2K, model.FIFA}, "status": model.StatusOpen})
	if err != nil {
		return err
	}

	levelSlice, err := model.MatchLevelList(g.Ex{"status": model.StatusOpen})
	if err != nil {
		return err
	}

	for _, t := range tournamentSlice {
		if t.SID == "0" {
			continue
		}
		tournamentIdMap[t.ID] = t
		tournamentSidMap[t.SID] = t
	}

	for _, v := range gameSlice {
		gameMap[v.ID] = v
	}

	for _, l := range levelSlice {
		matchLevelMap[l.Level] = l
	}

	return nil
}

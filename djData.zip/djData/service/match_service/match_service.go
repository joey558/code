package match_service

import (
	"context"
	"djData/service/common"
	"fmt"
	"time"
)

type MatchService struct {
	ctx    context.Context
	cancel context.CancelFunc
}

func (that *MatchService) Start() {

	that.ctx, that.cancel = context.WithCancel(context.Background())
	intUpdateTime := time.Now().Unix()
	go func() {
		for {
			matchIds := matchListGet(&intUpdateTime)
			if len(matchIds) == 0 {
				bReturn := common.ContextDone(that.ctx, "MatchService")
				if bReturn {
					return
				}
				continue
			}

			for _, id := range matchIds {
				oddsInfoListGet(id)
			}

			bReturn := common.ContextDone(that.ctx, "MatchService")
			if bReturn {
				return
			}
		}
	}()
}

func (that *MatchService) Stop() {

	that.cancel()
	fmt.Println("MatchService Stop")
}
//
//
//type MatchService struct {
//	bExit bool
//}
//
//func (that MatchService) Start() {
//
//	that.bExit = false
//	intUpdateTime := time.Now().Unix()
//	go func() {
//		for {
//			if that.bExit {
//				break
//			}
//
//			time.Sleep(time.Second * 5)
//			matchIds := matchListGet(&intUpdateTime)
//			if len(matchIds) == 0 {
//				continue
//			}
//
//			for _, id := range matchIds {
//				oddsInfoListGet(id)
//			}
//		}
//	}()
//}
//
//func (that MatchService) Stop() {
//
//	fmt.Println("MatchService Stop")
//	that.bExit = true
//}

package common

import (
	"context"
	"djData/helper/redis_helper"
	"djData/model"
	"encoding/json"
	"fmt"
	g "github.com/doug-martin/goqu/v9"
	"time"
)

func InitOddTypeSID() error {

	ex := g.Ex{"sid": g.Op{"gt": 0}}
	oddTypes, err := model.OddTypeListDB(ex)
	if err != nil {
		return err
	}

	model.GetZkRedis().GetClusterClient().Unlink(redis_helper.RedisOddTypeSIDMap)
	m := map[string]string{}
	for _, v := range oddTypes {
		m[v.ID] = v.SID
	}

	buff, err := json.Marshal(m)
	if err != nil {
		return err
	}

	return model.GetZkRedis().GetClusterClient().Do("JSON.SET", redis_helper.RedisOddTypeSIDMap, ".", buff).Err()
}

/*
 * @Description:  Context执行过程
 * @Author: robin
 * @Date: 2022/3/11 18:07
 * @LastEditTime: 2022/3/11 18:07
 * @LastEditors: robin
 */
func ContextDone(ctx context.Context, srvName string) bool {

	select {
	case <-ctx.Done():
		fmt.Printf("[%s]%s context return.\n", time.Now().Format("2006-01-02 15:04:05"), srvName)
		return true
	default:
		time.Sleep(time.Second * 5)
	}
	return false
}

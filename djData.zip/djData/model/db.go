package model

import (
	"djData/utils"
)

var (
	colTournament = utils.EnumFields(Tournament{})
	colTeam       = utils.EnumFields(Team{})
	colMatchData  = utils.EnumFields(MatchData{})
	colMatchLevel = utils.EnumFields(MatchLevel{})
	colGame       = utils.EnumFields(Game{})
	colOddType    = utils.EnumFields(OddType{})
	colOdd        = utils.EnumFields(Odd{})
	colMarketData = utils.EnumFields(MarketData{})
	colMarket     = utils.EnumFields(Market{})
	colMatchScore = utils.EnumFields(MatchScore{})
	colBetOrder   = utils.EnumFields(BetOrder{})
)

package model

import (
	"djData/helper/redis_helper"
	"fmt"

	g "github.com/doug-martin/goqu/v9"
)

const (
	TblTournaments = "tbl_tournaments" //联赛信息表
)

// Tournament 联赛数据库表结构体
type Tournament struct {
	ID           string `db:"id" json:"id"`                                                                   // id
	SID          string `db:"sid" json:"sid"`                                                                 // 标准联赛id
	GameID       string `db:"game_id" json:"game_id"`                                                         // 游戏id
	GameName     string `db:"-" rule:"none" json:"game_name"`                                                 // 游戏名称
	CreateTime   int64  `db:"create_time" json:"create_time"`                                                 // 创建时间
	UpdateTime   int64  `db:"update_time" json:"update_time"`                                                 // 更新时间
	CreateByID   uint64 `db:"create_by_id" json:"create_by_id"`                                               // 创建用户id
	UpdateByID   uint64 `db:"update_by_id" json:"update_by_id"`                                               // 更新用户id
	CreateByName string `db:"create_by_name" json:"create_by_name"`                                           // 创建用户名
	CnName       string `db:"cn_name" json:"cn_name"`                                                         // 联赛中文名
	EnName       string `db:"en_name" json:"en_name"`                                                         // 联赛英文名
	ShortName    string `db:"short_name" json:"short_name"`                                                   // 联赛简称
	UpdateByName string `db:"update_by_name" json:"update_by_name"`                                           // 更新用户名
	MatchLevel   int    `db:"match_level" json:"match_level"`                                                 // 默认赛事等级
	CreditLevel  int    `db:"credit_level" json:"credit_level" rule:"digit" min:"0" msg:"credit_level error"` // 信用联赛等级
	IsPassOff    int    `db:"is_pass_off" json:"is_pass_off"`                                                 // 是否串关 是-1 否-0
	SortCode     int    `db:"sort_code" json:"sort_code"`                                                     // 排序码
	Status       int    `db:"status" json:"status"`                                                           // 状态 开启-1 关闭-0
	Visible      int    `db:"visible" json:"visible"`                                                         // 是否显示
}

func TournamentList(ex g.Ex) ([]Tournament, error) {

	var data []Tournament
	query, _, _ := dialect.From(TblTournaments).Select(colTournament...).Where(ex).Order(g.C("sort_code").Asc()).ToSQL()
	err := zkDB.Select(&data, query)

	return data, err
}

/**
 * @Description: 获取单个联赛名称
 * @Author: maxic
 * @Date: 2020/10/15
 * @LastEditTime: 2020/10/15
 * @LastEditors: maxic
 **/
func TournamentGetName(tourId string) string {

	tourName, err := TournamentGetNames([]string{tourId}, "")
	if err != nil {
		return ""
	}
	return tourName[tourId]
}

/**
* @Description: 通过联赛ids获取联赛名列表
* @Author: maxic
* @Date: 2020/7/4
* @LastEditTime: 2021/9/28 16:47
* @LastEditors: robin
 */
func TournamentGetNames(ids []string, lan string) (map[string]string, error) {

	var (
		fieldName string
	)

	switch lan {
	case "cn":
		fieldName = "cn_name"
	case "en":
		fieldName = "en_name"
	default:
		fieldName = "short_name"
	}

	return redis_helper.RedisTxPipelineHMGet(zkRedis, ids, fieldName, redis_helper.RedisHKeyTournament)
}

/*
 * @Description: 联赛id和联赛简称哈希设置
 * @Author: robin
 * @Date: 2022/1/18 14:18
 * @LastEditTime: 2022/1/18 14:18
 * @LastEditors: robin
 */
func tournamentsHashSet(data []Tournament) error {

	pipe := zkRedis.GetClusterClient().Pipeline()
	defer pipe.Close()
	for _, t := range data {
		values := map[string]interface{}{
			"id":         t.ID,
			"short_name": t.ShortName,
			"cn_name":    t.CnName,
			"en_name":    t.EnName,
		}
		key := fmt.Sprintf(redis_helper.RedisHKeyTournament, t.ID)
		pipe.HMSet(key, values)
	}
	_, err := pipe.Exec()
	return err
}

/*
 * @Description: 批量联赛新增
 * @Author: robin
 * @Date: 2022/1/18 14:18
 * @LastEditTime: 2022/1/18 14:18
 * @LastEditors: robin
 */
func BatchTournamentInsert(data []Tournament) error {

	if len(data) == 0 {
		return nil
	}

	// 开启事务
	tx, err := zkDB.Begin()
	if err != nil {
		return err
	}

	// 写入数据库
	query, _, _ := dialect.Insert(TblTournaments).Rows(data).ToSQL()
	fmt.Println(query)
	_, err = tx.Exec(query)
	if err != nil {
		return err
	}

	// 写入缓存
	err = tournamentsHashSet(data)
	if err != nil {
		_ = tx.Rollback()
		return err
	}

	// 提交事务
	return tx.Commit()
}

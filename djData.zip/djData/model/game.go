package model

import (
	"djData/utils"
	"fmt"

	g "github.com/doug-martin/goqu/v9"
	"github.com/go-redis/redis/v7"
)

const (
	TblGames = "tbl_games" // 游戏信息表
)

// Game 游戏数据表结构体
type Game struct {
	ID           string `db:"id" rule:"none" json:"id"`             //游戏ID
	CreateByID   uint64 `db:"create_by_id" json:"create_by_id" `    //创建人ID
	UpdateByID   uint64 `db:"update_by_id" json:"update_by_id"`     //修改人ID
	CreateTime   int64  `db:"create_time" json:"create_time"`       //创建时间
	UpdateTime   int64  `db:"update_time" json:"update_time"`       //修改时间
	MatchesCount int64  `db:"-" json:"matches_count"`               //
	CreateByName string `db:"create_by_name" json:"create_by_name"` //创建人名称
	ShortName    string `db:"short_name" json:"short_name"`         //简称
	CnName       string `db:"cn_name" json:"cn_name"`               //中文名称
	EnName       string `db:"en_name" json:"en_name"`               //英文名称
	UpdateByName string `db:"update_by_name" json:"update_by_name"` //修改人名称
	SortCode     int    `db:"sort_code" json:"sort_code"`           //排序码
	Status       int    `db:"status" json:"status"`                 //状态[开启:1|关闭:0]
	Visible      int    `db:"visible" json:"visible"`               //是否显示[0:隐藏|1:显示]
	IsOpenMatch  int    `db:"is_open_match" json:"is_open_match"`   //是否显示赛事 1-是 0-否
	IsOpenVideo  int    `db:"is_open_video" json:"is_open_video"`   //是否显示视频 1-是 0-否
}

func GameList(ex g.Ex) ([]Game, error) {

	var gm []Game
	query, _, _ := dialect.From(TblGames).Select(colGame...).Where(ex).Order(g.C("sort_code").Asc()).ToSQL()
	err := zkDB.Select(&gm, query)

	return gm, err
}

/**
 * @Description: 获取单个游戏名
 * @Author: maxic
 * @Date: 2020/10/14
 * @LastEditTime: 2020/10/14
 * @LastEditors: maxic
 **/
func GetGameName(gameId string) string {

	gName, err := GameGetNames([]string{gameId}, "")
	if err != nil {
		return ""
	}
	return gName[gameId]
}

/**
* @Description: 通过游戏ids获取游戏名列表
* @Author: brandon
* @Date: 2020/6/30 10:22 下午
* @LastEditTime: 2020/6/30 10:22 下午
* @LastEditors: brandon
 */
func GameGetNames(ids []string, lan string) (map[string]string, error) {

	data := map[string]string{}

	pipe := zkRedis.GetClusterClient().Pipeline()
	defer pipe.Close()

	field := "short_name"
	switch lan {
	case "cn":
		field = "cn_name"
	case "en":
		field = "en_name"
	}

	cmdMap := map[string]*redis.SliceCmd{}
	for _, id := range ids {
		key := fmt.Sprintf(utils.RedisGameNav, id)
		cmdMap[id] = pipe.HMGet(key, field)
	}

	_, err := pipe.Exec()
	if err != nil {
		return data, err
	}

	for id, cmd := range cmdMap {
		res, err := cmd.Result()
		if err != nil {
			continue
		}

		if v, ok := res[0].(string); ok {
			data[id] = v
		}
	}

	return data, nil
}

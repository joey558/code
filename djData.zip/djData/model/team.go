package model

import (
	"bytes"
	"djData/helper"
	"djData/helper/beanstalk"
	"djData/helper/conf"
	"djData/helper/redis_helper"
	"fmt"
	"io"
	"io/ioutil"
	"mime/multipart"
	"net/http"
	"time"

	g "github.com/doug-martin/goqu/v9"
)

const (
	TblTeams = "tbl_teams" //战队信息表
)

// Team 战队表结构体
type Team struct {
	GameID        string `db:"game_id" json:"game_id"`               // 游戏ID
	ID            string `db:"id" json:"id"`                         // id
	SID           string `db:"sid" json:"sid"`                       // 标准战队id
	CreateByID    uint64 `db:"create_by_id" json:"create_by_id"`     // 创建用户id
	UpdateByID    uint64 `db:"update_by_id" json:"update_by_id"`     // 更新用户id
	CreateTime    int64  `db:"create_time" json:"create_time"`       // 创建时间
	UpdateTime    int64  `db:"update_time" json:"update_time"`       // 更新时间
	ShortName     string `db:"short_name" json:"short_name"`         // 战队简称
	CnName        string `db:"cn_name" json:"cn_name"`               // 中文名
	EnName        string `db:"en_name" json:"en_name"`               // 英文名
	Images        string `db:"images" json:"images"`                 // pc_图标
	GameShortName string `db:"-" json:"game_short_name"`             // 游戏简称
	CreateByName  string `db:"create_by_name" json:"create_by_name"` // 创建用户名
	UpdateByName  string `db:"update_by_name" json:"update_by_name"` // 更新用户名
	SortCode      int    `db:"sort_code" json:"sort_code"`           // 排序码
	Status        int    `db:"status" json:"status"`                 // 状态 开启-1关闭-0
	Visible       int    `db:"visible" json:"visible"`               // 是否显示：0=隐藏，1=显示
}
type RespData struct {
	Data   string `json:"data"`
	Status string `json:"status"`
}

func BatchTeamInsert(data []Team) error {

	if len(data) == 0 {
		return nil
	}

	dbConn, err := zkDB.Begin()
	if err != nil {
		return err
	}

	query, _, _ := dialect.Insert(TblTeams).Rows(data).OnConflict(g.DoNothing()).ToSQL()
	fmt.Println(query)
	_, err = dbConn.Exec(query)
	if err != nil {
		_ = dbConn.Rollback()
		return err
	}

	err = InitTeamImages(data)
	if err != nil {
		fmt.Printf("战队logo 图片缓存写入失败, Error:%s\n", err.Error())
	}

	return dbConn.Commit()
}

func TeamListDB(ex g.Ex) ([]Team, error) {
	var data []Team
	query, _, _ := dialect.Select(colTeam...).From(TblTeams).Where(ex).ToSQL()
	err := zkDB.Select(&data, query)
	return data, err
}

func DeleteTeam(ex g.Ex) error {
	query, _, _ := dialect.Delete(TblTeams).Where(ex).ToSQL()
	_, err := zkDB.Exec(query)
	if err != nil {
		return err
	}
	return nil
}

func InitTeamImages(teams []Team) error {

	var err error
	pipe := zkRedis.GetClusterClient().TxPipeline()
	s := 0
	for i := range teams {
		s++
		pipe.HSet(redis_helper.RedisTeamImages, teams[i].ID, teams[i].Images)
		if s >= 100 {
			_, err = pipe.Exec()
			_ = pipe.Close()
			if err != nil {
				fmt.Println(err.Error())
			}
			pipe = zkRedis.GetClusterClient().TxPipeline()
			s = 0
		}
	}

	if s > 0 {
		_, err = pipe.Exec()
		_ = pipe.Close()
		if err != nil {
			fmt.Println(err.Error())
		}
	}

	return err
}

// GetTeamLogo
/**
* @Description: 获取战队图片
* @Author: noah
* @Date: 2022/1/5 15:06
* @LastEditTime:2022/1/5 15:06
* @LastEditors: noah
 */
func GetTeamLogo(paths []string, teamName string) string {

	if len(paths) == 0 {
		return ""
	}

	if conf.Cfg.TYApiConf.TYTeamURL == "" || conf.Cfg.TYApiConf.UploadTeamURL == "" {
		fmt.Println("no setting ty_team_url and upload_team_url")
		return ""
	}

	url := conf.Cfg.TYApiConf.TYTeamURL + paths[0]
	client := &http.Client{Timeout: time.Duration(5 * time.Second)}
	resp, err := client.Get(url)
	if err != nil {
		fmt.Println("get team logo client.Get error ", err.Error())
		if err = beanstalk.BeansPutMonitorTask(ZkBeansPool, beanstalk.ApiAlertTpl, "error", "获取TY战队图片错误 ： "+err.Error()); err != nil {
			fmt.Println(err.Error())
		}
		return ""
	}

	if resp.StatusCode != http.StatusOK {
		fmt.Printf("get team logo error status %s \n", resp.Status)
		return ""
	}

	url = conf.Cfg.TYApiConf.UploadTeamURL + "upload"
	payload := &bytes.Buffer{}
	writer := multipart.NewWriter(payload)
	part, err := writer.CreateFormFile("file", "images.png")
	if err != nil {
		fmt.Println("get team logo CreateFormFile error ", err.Error())
		return ""
	}

	_, err = io.Copy(part, resp.Body)
	if err != nil {
		fmt.Println("get team logo io.Copy error ", err.Error())
		return ""
	}

	_ = writer.WriteField("region", "game")
	_ = writer.WriteField("name", teamName)
	_ = writer.WriteField("type", "png")
	err = writer.Close()
	if err != nil {
		fmt.Println("get team logo writer.Close error ", err.Error())
		return ""
	}

	req, err := http.NewRequest(http.MethodPost, url, payload)
	if err != nil {
		fmt.Println("get team logo http.NewRequest error ", err.Error())
		return ""
	}

	req.Header.Set("Content-Type", writer.FormDataContentType())
	res, err := client.Do(req)
	if err != nil {
		fmt.Println("get team logo client.Do error ", err.Error())
		return ""
	}

	defer res.Body.Close()
	body, err := ioutil.ReadAll(res.Body)
	if err != nil {
		fmt.Println("get team logo ioutil.ReadAll error ", err.Error())
		return ""
	}

	data := RespData{}
	err = helper.JsonUnmarshal(body, &data)
	if err != nil {
		fmt.Println("get team logo helper.JsonUnmarshal error ", err.Error())
		return ""
	}

	return data.Data
}

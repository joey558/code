package model

import (
	"database/sql"
	"djData/helper"
	"djData/helper/beanstalk"
	"djData/helper/conf"
	mqtt "djData/helper/mqtt_helper"
	"djData/utils"
	"encoding/json"
	"errors"
	"fmt"
	g "github.com/doug-martin/goqu/v9"
	"github.com/go-redis/redis/v7"
	"github.com/shopspring/decimal"
	"sort"
	"strconv"
	"strings"
)

const (
	TblMarkets = "tbl_markets" // 盘口信息表
)

//投注项集合
type TYOddListData struct {
	ID             string `json:"oid"` //投注项ID
	Name           string `json:"on"`  //投注项名称
	DataSource     string `json:"cds"` //数据源：sr,bg
	SortID         int    `json:"ood"` //排序
	OddInterNation string `json:"onc"` //国际化关联name_code
	Status         int    `json:"os"`  //投注项状态： 1-开盘 2-封盘 3-关盘 4-?
	Type           string `json:"ot"`  //投注项类型
	OddTemplate    int    `json:"otd"` //投注项模板
	Loss           int    `json:"ov"`  //赔率
	AppendFiled1   string `json:"ad1"` //备用字段1
	AppendFiled2   string `json:"ad2"` //备用字段2
	AppendFiled3   string `json:"ad3"` //备用字段3
	AppendFiled4   string `json:"ad4"` //备用字段4
	AppendFiled5   string `json:"ad5"` //备用字段5
}

//体育盘口集合
type TYMarketListData struct {
	ID                string          `json:"hid"`   //盘口id
	Type              int             `json:"ht"`    //盘口类型: 1-早盘 0-滚盘
	Level             string          `json:"hon"`   //盘口级别(数字越小优先级越高)
	Status            int             `json:"hs"`    //盘口状态(0-开盘,1-封盘,2-关盘,3-已结算,4-取消,5-handedOver,11-锁盘)
	Value             string          `json:"hv"`    //盘口值
	OddID             string          `json:"hpid"`  //玩法ID
	SubOddID          string          `json:"chpid"` //子玩法ID
	MarketInterNation string          `json:"hnd"`   //盘口国际化关联name_code
	UpdateTime        string          `json:"mdm"`   //修改时间
	AppendFiled1      string          `json:"ad1"`   //盘口附加字段1
	AppendFiled2      string          `json:"ad2"`   //盘口附加字段2
	AppendFiled3      string          `json:"ad3"`   //盘口附加字段3
	AppendFiled4      string          `json:"ad4"`   //盘口附加字段4
	OddList           []TYOddListData `json:"ol"`    //玩法集合
}

//体育-玩法类型列表-返回结果
type TYGetOddTypeDataResp struct {
	Code string                   `json:"code"`
	Data map[string]TYOddTypeData `json:"data"`
	Msg  string                   `json:"msg"`
	Time int64                    `json:"ts"`
}

//体育-玩法类型列表-返回结果
type TYOddTypeData struct {
	MatchID      string             `json:"mid"`          //标准赛事ID
	BallID       int64              `json:"csid"`         //球种ID
	OddID        string             `json:"hpid"`         //玩法ID
	OddName      string             `json:"hpn"`          //玩法名称
	OddSortID    int                `json:"hpon"`         //玩法排序
	IsShowOdd    string             `json:"hshow"`        //是否展开玩法
	IsLiveSeries int                `json:"isLiveSeries"` //滚球是否支持串关
	RoundFiled   string             `json:"jno"`          //局玩法ID相同时,局字段
	MarketList   []TYMarketListData `json:"hl"`           //盘口集合
}

// 盘口列表数据
type MarketData struct {
	ID                  string                    `json:"id" db:"id"`                                     // 盘口id
	MatchID             string                    `json:"match_id" db:"match_id"`                         // 赛事id
	OddTypeID           string                    `json:"odd_type_id" db:"odd_type_id"`                   // 玩法类型ID
	EnName              string                    `json:"en_name" db:"en_name"`                           // 英文名称
	CnName              string                    `json:"cn_name" db:"cn_name"`                           // 中文名称
	Round               int16                     `json:"round" db:"round"`                               // 第几局 0-全局 1-第一局 2-第二局 ... 100-上半场
	OptionType          int8                      `json:"option_type" db:"option_type"`                   // 玩法类型 1-输赢 2-让分 3-大小 4趣味 5-波胆 6-胜负平 7-单双 8-是否 12-复合
	ReturnRate          float64                   `json:"return_rate" db:"return_rate"`                   // 返还率
	DefaultReturnRate   float64                   `json:"default_return_rate" db:"default_return_rate"`   // 限红之前-返还率默认值
	BonusProportion     int                       `json:"bonus_proportion" db:"bonus_proportion"`         // 赔付占比
	Suspended           int8                      `json:"suspended" db:"suspended"`                       // 是否暂停  1-暂停 0-取消暂停
	Visible             int8                      `json:"visible" db:"visible"`                           // 是否显示  1-显示 0-隐藏
	AutoOdd             int8                      `json:"auto_odd" db:"auto_odd"`                         // 是否开启自动变赔  1-是 0-否
	LockReturnRate      int8                      `json:"lock_return_rate" db:"lock_return_rate"`         // 是否锁定返还率  1-是 0-否
	IsReopen            int8                      `json:"is_reopen" db:"is_reopen"`                       // 是否重新开盘  1-是 0-否
	IsInputReject       int8                      `json:"is_input_reject" db:"is_input_reject"`           // 是否录入驳回  1-是 0-否
	Status              int8                      `json:"status" db:"status"`                             // 待录入-1 已录入-2  录入驳回-3 待审核-4 待开盘-5 已开盘-6 已关盘-7 待结算-8 已结算-9 赛果驳回-10 待取消-11 已取消-12
	Remark              string                    `json:"remark" db:"remark"`                             // 备注
	SortCode            int                       `json:"sort_code" db:"sort_code"`                       // 排序码
	CompSubNum          int                       `json:"comp_sub_num" db:"comp_sub_num"`                 // 复合玩法管理子盘口数量
	SubMktID            string                    `json:"sub_mkt_id" db:"sub_mkt_id"`                     // 复合盘口子盘口ID
	SubOddID            string                    `json:"sub_odd_id" db:"sub_odd_id"`                     // 复合盘口子选项ID
	SettleTime          int64                     `json:"settle_time" db:"settle_time"`                   // 结算时间
	SettleCount         int                       `json:"settle_count" db:"settle_count"`                 // 结算次数
	IsSettleReject      int64                     `json:"is_settle_reject" db:"is_settle_reject"`         // 是否结算驳回  1-是 0-否
	IsDefault           int                       `json:"is_default" db:"is_default"`                     // 是否首页展示默认盘口
	IsUpdateName        int                       `json:"is_update_name" db:"is_update_name"`             // [程序使用] 是否可编辑选项
	OptionTotal         int                       `json:"option_total"`                                   // [程序使用] 选项数量
	Odds                []Odd                     `json:"odds"`                                           // [程序使用] 投注项
	PrizeLimit          int                       `json:"prize_limit" db:"prize_limit"`                   // 风控单注赔付
	MbMktPrizeLimit     int                       `json:"mb_mkt_prize_limit" db:"mb_mkt_prize_limit"`     // 风控会员盘口赔付
	WarningProfit       int                       `json:"warning_profit" db:"warning_profit"`             // 预警值
	StopProfit          int                       `json:"stop_profit" db:"stop_profit"`                   // 停盘值
	Reason              int                       `json:"reason" db:"reason"`                             // 101-无赛果，102-赛果无法定义，103-赛制错误，104-盘口信息错误，105-平局退款，300-返还率缩减未生效
	PrizeStaticProfit   int                       `json:"prize_static_profit" db:"prize_static_profit"`   // 单注限红
	Tag                 int                       `json:"tag" db:"tag"`                                   // 玩法标签
	CheckedDefault      int                       `json:"checked_default"`                                //
	OddTypeModule       int                       `json:"odd_type_module"`                                // 玩法模组 1-赛前 2-BP 3-滚球中
	IsPassOff           int                       `json:"is_pass_off" db:"is_pass_off"`                   // 是否允许串关 0-不允许串关 1-只允许赛事串关 2-只允许赛事和局内串关
	MchCompPrizeLimit   int                       `json:"mch_comp_prize_limit" db:"mch_comp_prize_limit"` // 比赛串关单注赔付
	SuspendedType       int                       `json:"suspended_type" db:"suspended_type"`             // 暂停类型 1-手动 0-自动
	VisibleType         int                       `json:"visible_type" db:"visible_type"`                 // 显示类型 1-手动 0-自动
	OddRangeStatus      int                       `json:"odd_range_status" db:"odd_range_status"`         // 是否启用特殊抽水 1-启用 0-禁用
	OddRanges           []utils.OddRangeDscntInfo `json:"odd_ranges"`                                     // 特殊抽水配置项
	CnNamePlayerHero    string                    `json:"cn_name_player_hero"`                            // 队员|英雄(大小,单双,是否)-中文名称
	EnNamePlayerHero    string                    `json:"en_name_player_hero"`                            // 队员|英雄(大小,单双,是否)-英文名称
	OddLinkage          int                       `json:"odd_linkage" db:"odd_linkage"`                   // 是否开启赔率联动 1-启用 0-禁用
	OddLinkageParamConf int                       `json:"odd_linkage_param_conf"`                         // 是否关联赔率联动参数配置
	ScoreBenchmark      string                    `json:"score_benchmark"`                                // 玩法基准分
}

// Market 盘口结构体
type Market struct {
	ID                string  `json:"id" db:"id"`                                     // 盘口id
	MatchID           string  `json:"match_id" db:"match_id"`                         // 赛事id
	OddTypeID         string  `json:"odd_type_id" db:"odd_type_id"`                   // 玩法类型ID
	EnName            string  `json:"en_name" db:"en_name"`                           // 英文名称
	CnName            string  `json:"cn_name" db:"cn_name"`                           // 中文名称
	SingleMaxBonus    string  `json:"single_max_bonus" db:"single_max_bonus"`         // 单注最高赔付
	MaxBonusTotal     string  `json:"max_bonus_total" db:"max_bonus_total"`           // 盘口最高总赔付
	Remark            string  `json:"remark" db:"remark"`                             // 备注
	Round             int16   `json:"round" db:"round"`                               // 第几局 0-全局 1-第一局 2-第二局 ... 100-上半场
	OptionType        int8    `json:"option_type" db:"option_type"`                   // 玩法类型 1-输赢 2-让分 3-大小 4趣味 5-波胆 6-胜负平 7-单双 8-是否 12-复合
	BonusProportion   int     `json:"bonus_proportion" db:"bonus_proportion"`         // 赔付占比
	ReturnRate        float64 `json:"return_rate" db:"return_rate"`                   // 返还率
	DefaultReturnRate float64 `json:"default_return_rate" db:"default_return_rate"`   // 限红之前 返还率默认值
	Suspended         int8    `json:"suspended" db:"suspended"`                       // 是否暂停  1-暂停 0-取消暂停
	Visible           int8    `json:"visible" db:"visible"`                           // 是否显示  1-显示 0-隐藏
	LockReturnRate    int8    `json:"lock_return_rate" db:"lock_return_rate"`         // 是否锁定返还率  1-是 0-否
	AutoOdd           int8    `json:"auto_odd" db:"auto_odd"`                         // 是否开启自动变赔  1-是 0-否
	IsReopen          int8    `json:"is_reopen" db:"is_reopen"`                       // 是否重新开盘  1-是 0-否
	IsInputReject     int8    `json:"is_input_reject" db:"is_input_reject"`           // 是否录入驳回  1-是 0-否
	Status            int8    `json:"status" db:"status"`                             // 待录入-1 已录入-2  录入驳回-3 待审核-4 待开盘-5 已开盘-6 已关盘-7 待结算-8 已结算-9 赛果驳回-10 待取消-11 已取消-12
	IsDefault         int8    `json:"is_default" db:"is_default"`                     // 是否首页展示默认盘口
	SortCode          int     `json:"sort_code" db:"sort_code"`                       // 排序码
	CompSubNum        int     `json:"comp_sub_num" db:"comp_sub_num"`                 // 复合玩法管理子盘口数量
	SubMktID          string  `json:"sub_mkt_id" db:"sub_mkt_id"`                     // 复合盘口子盘口ID
	SubOddID          string  `json:"sub_odd_id" db:"sub_odd_id"`                     // 复合盘口子选项ID
	SettleTime        int64   `json:"settle_time" db:"settle_time"`                   // 结算时间
	SettleCount       int     `json:"settle_count" db:"settle_count"`                 // 结算次数
	UpdateByID        uint64  `json:"update_by_id" db:"update_by_id"`                 // 修改人ID
	CreateByID        uint64  `json:"create_by_id" db:"create_by_id"`                 // 创建人ID
	CreateTime        int64   `json:"create_time" db:"create_time"`                   // 创建时间
	UpdateTime        int64   `json:"update_time" db:"update_time"`                   // 修改时间
	CloseTime         int64   `json:"close_time" db:"close_time"`                     // 盘口关闭时间
	IsSettleReject    int64   `json:"is_settle_reject" db:"is_settle_reject"`         // 是否结算驳回  1-是 0-否
	CreateByName      string  `json:"create_by_name" db:"create_by_name"`             // 创建人名称
	UpdateByName      string  `json:"update_by_name" db:"update_by_name"`             // 修改人名称
	PrizeLimit        int     `json:"prize_limit" db:"prize_limit"`                   // 风控单注赔付
	MbMktPrizeLimit   int     `json:"mb_mkt_prize_limit" db:"mb_mkt_prize_limit"`     // 风控会员盘口赔付
	WarningProfit     int     `json:"warning_profit" db:"warning_profit"`             // 预警值
	StopProfit        int     `json:"stop_profit" db:"stop_profit"`                   // 停盘值
	Reason            int     `json:"reason" db:"reason"`                             // 101-无赛果，102-赛果无法定义，103-赛制错误，104-盘口信息错误，105-平局退款，300-返还率缩减未生效
	PrizeStaticProfit int     `json:"prize_static_profit" db:"prize_static_profit"`   // 单注限红
	Tag               string  `json:"tag" db:"tag"`                                   // 玩法标签
	TagCode           int     `json:"tag_code" db:"tag_code"`                         // 玩法标签排序
	IsUpdateName      int     `json:"is_update_name"  db:"is_update_name"`            // 是否可编辑投注项 1-是 0-否
	MchCompPrizeLimit int     `json:"mch_comp_prize_limit" db:"mch_comp_prize_limit"` // 普通串关单注赔付
	IsPassOff         int     `json:"is_pass_off" db:"is_pass_off"`                   // 是否允许串关 0-不允许串关 1-只允许赛事串关 2-只允许赛事和局内串关
	SuspendedType     int     `json:"suspended_type" db:"suspended_type"`             // 暂停类型 1-手动 0-自动
	VisibleType       int     `json:"visible_type" db:"visible_type"`                 // 显示类型 1-手动 0-自动
	OddRangeStatus    int     `json:"odd_range_status" db:"odd_range_status"`         // 是否启用特殊抽水 1-启用 0-禁用
	OddLinkage        int     `json:"odd_linkage" db:"odd_linkage"`                   // 是否开启赔率联动 1-启用 0-禁用
	ScoreBenchmark    string  `json:"score_benchmark" db:"score_benchmark"`           // 玩法基准分
}

/*
 * @Description: 创建盘口,投注项
 * @Author: robin
 * @Date: 2021/12/12 13:41
 * @LastEditTime: 2021/12/12 13:41
 * @LastEditors: robin
 */
func createMarket(data *[]MarketData, mk TYMarketListData, oddType OddType, matchLv MatchLevel, round int, match utils.MatchData, existDefaultMarket *MarketData, strDefaultMarketID *string, checkedDefault int) {

	intSuspended := SuspendedClose
	if mk.Status == TYStatusSeal {
		intSuspended = SuspendedOpen
	}
	market := MarketData{
		ID:                mk.ID,
		MatchID:           match.ID,
		OddTypeID:         oddType.ID,
		EnName:            oddType.EnName,
		CnName:            oddType.CnName,
		Round:             int16(round),
		OptionType:        int8(oddType.OptionType),
		BonusProportion:   oddType.BonusProportion,
		ReturnRate:        matchLv.ReturnRate,
		Suspended:         int8(intSuspended),
		Visible:           int8(VisibleOpen),
		Status:            int8(MarketStatusOpen),
		Remark:            "",
		SortCode:          oddType.SortCode,
		IsUpdateName:      oddType.IsUpdateName,
		OptionTotal:       0,
		Odds:              nil,
		PrizeLimit:        matchLv.PrizeLimit,         //单注赔付
		MbMktPrizeLimit:   matchLv.MbMktPrizeLimit,    //会员盘口赔付
		PrizeStaticProfit: matchLv.PrizeStaticProfit,  //单注限红
		MchCompPrizeLimit: matchLv.MchsCompPrizeLimit, //普通串关单注赔付
		CheckedDefault:    checkedDefault,
		ScoreBenchmark:    "",
	}

	//玩法基准分
	if IsScoreBenchmark(mk.OddID) && mk.Type == MarketLive { //滚盘阶段的盘口,获取盘口基准分
		if (mk.OddID == ScoreOddType27 || mk.OddID == ScoreOddType29) && mk.AppendFiled1 != "" && mk.AppendFiled2 != "" {
			market.ScoreBenchmark = fmt.Sprintf("%s:%s", mk.AppendFiled1, mk.AppendFiled2)
			market.CnName = fmt.Sprintf("%s(%s-%s)", market.CnName, mk.AppendFiled1, mk.AppendFiled2)
			market.EnName = fmt.Sprintf("%s(%s-%s)", market.EnName, mk.AppendFiled1, mk.AppendFiled2)
		} else if (mk.OddID == ScoreOddType4 || mk.OddID == ScoreOddType19) && mk.AppendFiled3 != "" && mk.AppendFiled4 != "" {
			market.ScoreBenchmark = fmt.Sprintf("%s:%s", mk.AppendFiled3, mk.AppendFiled4)
			market.CnName = fmt.Sprintf("%s(%s-%s)", market.CnName, mk.AppendFiled3, mk.AppendFiled4)
			market.EnName = fmt.Sprintf("%s(%s-%s)", market.EnName, mk.AppendFiled3, mk.AppendFiled4)
		}
		fmt.Printf("【玩法赔率接口-赛事ID:%s】盘口ID[%s]玩法基准分[%s] 玩法ID[%s]中文名称[%s] 英文名称[%s]\n", match.ID, market.ID, market.ScoreBenchmark, market.OddTypeID, market.CnName, market.EnName)
	}

	// 全场胜负默认首页展示
	if oddType.Category == OddTypeCategoryAll { // 全场
		if oddType.OptionType == OptionTypeWinLose { //输赢
			if len((*existDefaultMarket).ID) == 0 {
				market.IsDefault = 1
				*existDefaultMarket = market
			}
		} else if oddType.OptionType == OptionType1X2 { //胜负平
			if len((*existDefaultMarket).ID) == 0 {
				market.IsDefault = 1
				*existDefaultMarket = market
			} else {
				if market.CnName == DefaultMarketCnName { //更新设置 全场独赢为默认盘口
					market.IsDefault = 1
					*strDefaultMarketID = market.ID
				}
			}
		}
	}

	// 构建投注项名称
	cnNames, enNames := generateOddNames(oddType, &mk)
	sort.Slice(mk.OddList, func(i, j int) bool {
		return mk.OddList[j].SortID > mk.OddList[i].SortID
	})

	for i, d := range mk.OddList {
		odd := Odd{
			ID:     d.ID,
			Name:   cnNames[i],
			EnName: enNames[i],
			Odd:    decimal.NewFromInt(int64(d.Loss)).Div(decimal.NewFromInt(int64(100000))).Truncate(3),
			SortID: d.SortID,
		}
		market.Odds = append(market.Odds, odd)
	}

	strLog := fmt.Sprintf("【玩法赔率接口-赛事ID:%s】-【盘口信息】-【盘口ID:%s】,【盘口名称:%s】,【默认盘口:%s】,【盘口状态-hs:%d】,【玩法ID:%s】,【玩法名称:%s】,【投注项ID-1:%s】,【投注项名称-1:%s】,【投注项赔率-1:%s】, 【投注项ID-2:%s】,【投注项名称-2:%s】,【投注项赔率-2:%s】.\n",
		match.ID, market.ID, market.CnName, YesNoDesc[market.IsDefault], mk.Status,
		oddType.ID, oddType.CnName,
		market.Odds[0].ID, market.Odds[0].Name, market.Odds[0].Odd,
		market.Odds[1].ID, market.Odds[1].Name, market.Odds[1].Odd)
	if len(market.Odds) == 3 {
		strLog = fmt.Sprintf("%s 【投注项ID-3:%s】,【投注项名称-3:%s】,【投注项赔率-3:%s】.\n", strLog, market.Odds[2].ID, market.Odds[2].Name, market.Odds[2].Odd)
	}
	fmt.Print(strLog)

	market.OptionTotal = len(market.Odds)
	*data = append(*data, market)
}

/*
 * @Description: 更新盘口值-投注项名称
 * @Author: robin
 * @Date: 2022/2/7 12:35
 * @LastEditTime: 2022/2/7 12:35
 * @LastEditors: robin
 */
func OddsNameUpdate(match utils.MatchData, tyExistMarkets []TYMarketListData, oddTypes []OddType) error {

	var (
		tyUpdateMarkets []TYMarketListData
		marketIds       []string
	)
	oddTypeMap := map[string]OddType{}
	for _, oddType := range oddTypes {
		oddTypeMap[oddType.SID] = oddType
	}

	for _, mk := range tyExistMarkets {
		if _, ok := oddTypeMap[mk.OddID]; !ok {
			fmt.Printf("【玩法赔率接口-赛事ID:%s,SID:%s】OddsNameUpdate, 游戏[%s]盘口ID[%s]玩法ID[%s]不存在.\n", match.ID, match.SID, GameName[match.GameID], mk.ID, mk.OddID)
			continue
		}

		oddType := oddTypeMap[mk.OddID]
		if oddType.OptionType != OptionTypeHandicap && oddType.OptionType != OptionTypeOverUnder { //让分,大小
			continue
		}

		if mk.Status == TYStatusSettled || mk.Status == TYStatusCancel { //已结算 已取消
			continue
		}

		if len(mk.OddList) < 2 || len(mk.OddList) > 3 {
			fmt.Printf("【玩法赔率接口-赛事ID:%s,SID:%s】OddsNameUpdate, 游戏ID[%s]盘口ID[%s]玩法ID[%s]玩法名称[%s]投注项个数[%d]错误.\n", match.ID, match.SID, match.GameID, mk.ID, oddTypeMap[mk.OddID].SID, oddTypeMap[mk.OddID].CnName, len(mk.OddList))
			continue
		}

		tyUpdateMarkets = append(tyUpdateMarkets, mk)
		marketIds = append(marketIds, mk.ID)
	}

	if len(tyUpdateMarkets) == 0 {
		return nil
	}

	oddsSlice, err := OddListDB(g.Ex{"market_id": marketIds})
	if err != nil {
		return err
	}

	if len(oddsSlice) == 0 {
		return nil
	}

	marketOddsMap := map[string]Odd{}
	for _, odd := range oddsSlice {
		marketOddsMap[odd.ID] = odd
	}

	for _, mk := range tyUpdateMarkets {
		oddType := oddTypeMap[mk.OddID]
		// 构建投注项名称
		cnNames, enNames := generateOddNames(oddType, &mk)
		sort.Slice(mk.OddList, func(i, j int) bool {
			return mk.OddList[j].SortID > mk.OddList[i].SortID
		})

		var (
			marketId  string
			logResult string
		)
		marketOddsMapSave := map[string]Odd{}
		for i, v := range mk.OddList {
			if _, ok := marketOddsMap[v.ID]; !ok {
				fmt.Printf("【玩法赔率接口-赛事ID:%s,SID:%s】Map缓存映射投注项-ID[%s]不存在.\n", match.ID, match.SID, v.ID)
				continue
			}

			odd := Odd{
				ID:     v.ID,
				Name:   helper.FilterInjection(cnNames[i]),
				EnName: helper.FilterInjection(enNames[i]),
				Odd:    decimal.NewFromInt(int64(v.Loss)).Div(decimal.NewFromInt(int64(100000))).Truncate(3),
				SortID: v.SortID,
			}

			if marketOddsMap[v.ID].ID != odd.ID {
				continue
			}

			oddTemp := marketOddsMap[v.ID]
			if oddTemp.Name != odd.Name {
				oddTemp.Name = odd.Name
				oddTemp.EnName = odd.EnName
				oddTemp.Odd = odd.Odd
				marketId = oddTemp.MarketID
				marketOddsMapSave[v.ID] = oddTemp
				fmt.Printf("【玩法赔率接口-赛事ID:%s,SID:%s】盘口值变更[%s],[赔率]%v->%v,投注项名称变更[%s]:%s->%s \n", match.ID, match.SID, marketOddsMap[v.ID].Odd, oddTemp.Odd, marketId, v.ID, marketOddsMap[v.ID].Name, oddTemp.Name)
				logResult += fmt.Sprintf("【投注项ID】:%s,[赔率]%v->%v\n【投注项名称】:(%s)->(%s)\n", v.ID, marketOddsMap[v.ID].Odd, oddTemp.Odd, marketOddsMap[v.ID].Name, oddTemp.Name)
			}
		}

		if len(marketOddsMapSave) == 0 {
			continue
		}

		dbConn, err := zkDB.Begin()
		if err != nil {
			return err
		}

		//更新投注项:名称,赔率
		var (
			records []OdUpdate
			odds    []OddNameUpdateItem
		)

		for _, odd := range marketOddsMapSave {
			records = append(records, OdUpdate{
				Record: g.Record{"name": odd.Name, "en_name": odd.EnName, "odd": odd.Odd.RoundFloor(2).String()},
				Ex:     g.Ex{"id": odd.ID},
			})
			odds = append(odds, OddNameUpdateItem{
				MarketId: marketId,
				MatchId:  match.ID,
				ID:       odd.ID,
				Name:     odd.Name,
				EnName:   odd.EnName,
				Odd:      odd.Odd.RoundFloor(2).String(),
			})
		}
		if len(records) == 0 {
			continue
		}

		err = OddsUpdate(dbConn, records...)
		if err != nil {
			_ = dbConn.Rollback()
			fmt.Printf("【玩法赔率接口-赛事ID:%s,SID:%s】盘口值变更-投注项更新, Error:%s\n", match.ID, match.SID, err.Error())
			continue
		}

		// 获取默认盘口
		defaultMarket, err := MarketFindOne(g.Ex{"match_id": match.ID, "is_default": 1})
		if err != nil {
			_ = dbConn.Rollback()
			fmt.Printf("【玩法赔率接口-赛事ID:%s,SID:%s】盘口值变更-查询默认盘口, Error:%s\n", match.ID, match.SID, err.Error())
			continue
		}

		// 更新盘口-投注项-缓存
		pipe := zkRedis.GetClusterClient().Pipeline()
		for _, rec := range records {
			utils.MarketCacheOddUpdate(pipe, match.ID, marketId, rec.Record, rec.Ex, defaultMarket.ID)
		}
		_, err = pipe.Exec()
		_ = pipe.Close()
		if err != nil {
			_ = dbConn.Rollback()
			fmt.Printf("【玩法赔率接口-赛事ID:%s,SID:%s】盘口值变更-投注项更新缓存, Error:%s\n", match.ID, match.SID, err.Error())
			continue
		}

		err = dbConn.Commit()
		if err != nil {
			fmt.Printf("【玩法赔率接口-赛事ID:%s,SID:%s】盘口值变更-投注项更新提交Commit, Error:%s\n", match.ID, match.SID, err.Error())
			continue
		}

		// (名称,赔率)变更推送
		mqtt.MqttNotifyOddNameUpdate(odds)

		round := 0 //0-全局/全场 100-半场
		switch oddType.Category {
		case OddTypeCategoryAll:
			round = 0
		case OddTypeCategoryHalf:
			round = 100
		}

		marketLog := utils.TDMarket{
			TS:                  "now",
			User:                "TY",
			Group:               "0",
			IP:                  "0",
			Menu:                "请求接口",
			Action:              "盘口值-变更",
			GameID:              match.GameID,
			GameShortName:       GameName[match.GameID],
			TournamentId:        match.TournamentID,
			TournamentShortName: TournamentGetName(match.TournamentID),
			Teams:               match.MatchCnTeam,
			MatchID:             match.ID,
			MarketID:            marketId,
			MarketEnName:        oddType.CnName,
			Round:               int16(round),
			Result:              logResult,
			Category:            int8(match.Category),
		}

		mqtt.MqttNotifyMarketLogPub(marketLog)
	}

	return nil
}

/*
 * @Description: 根据玩法生成盘口
 * @Author: robin
 * @Date: 2021/12/1 14:14
 * @LastEditTime: 2021/12/1 14:14
 * @LastEditors: robin
 */
func MarketListInit(match utils.MatchData, matchLv MatchLevel, tyMarkets []TYMarketListData, oddTypes []OddType, existDefaultMarket *MarketData, strDefaultMarketID *string) ([]MarketData, error) {

	var data []MarketData
	oddTypeMap := map[string]OddType{}
	for _, oddType := range oddTypes {
		oddTypeMap[oddType.SID] = oddType
	}

	for _, mk := range tyMarkets {
		if _, ok := oddTypeMap[mk.OddID]; !ok {
			fmt.Printf("【玩法赔率接口-赛事ID:%s,SID:%s】MarketListInit, 游戏[%s]盘口ID[%s]玩法ID[%s]不存在.\n", match.ID, match.SID, GameName[match.GameID], mk.ID, mk.OddID)
			continue
		}

		if mk.Status > TYStatusSeal { //盘口状态hs(0-开盘,1-封盘,2-关盘,3-已结算,4-取消,5-handedOver,11-锁盘)
			fmt.Printf("【玩法赔率接口-赛事ID:%s,SID:%s】MarketListInit,游戏[%s]盘口ID[%s]玩法ID[%s]玩法名称[%s]盘口状态[%d-%s].\n", match.ID, match.SID, GameName[match.GameID], mk.ID, oddTypeMap[mk.OddID].SID, oddTypeMap[mk.OddID].CnName, mk.Status, TYMarketStatusDesc[mk.Status])
			continue
		}

		if mk.Status == TYStatusSeal { // 盘口状态-封盘
			fmt.Printf("【玩法赔率接口-赛事ID:%s,SID:%s】MarketListInit, 赛事阶段[%s]游戏[%s]盘口ID[%s]玩法ID[%s]玩法名称[%s]盘口状态[%d-%s].\n", match.ID, match.SID, MatchIsLiveDesc[match.IsLive], GameName[match.GameID], mk.ID, oddTypeMap[mk.OddID].SID, oddTypeMap[mk.OddID].CnName, mk.Status, TYMarketStatusDesc[mk.Status])
			if match.IsLive == MatchEarly { //早盘赛事-封盘状态,不必创建(即滚盘赛事,可创建封盘状态的盘口)
				continue
			}
		}

		if len(mk.OddList) < 2 || len(mk.OddList) > 3 {
			fmt.Printf("【玩法赔率接口-赛事ID:%s,SID:%s】MarketListInit, 游戏ID[%s]盘口ID[%s]玩法ID[%s]玩法名称[%s]投注项个数[%d]错误.\n", match.ID, match.SID, match.GameID, mk.ID, oddTypeMap[mk.OddID].SID, oddTypeMap[mk.OddID].CnName, len(mk.OddList))
			continue
		}

		oddType := oddTypeMap[mk.OddID]
		checkedDefault := 0
		oddTypeLevel := strings.Split(oddType.LeagueLevel, ",")
		for _, oddLv := range oddTypeLevel {
			lv, err := strconv.Atoi(oddLv)
			if err != nil {
				return data, err
			}

			if match.MatchLevel == lv {
				checkedDefault = 1
			}
		}
		round := 0 //0-全局/全场 100-半场
		switch oddType.Category {
		case OddTypeCategoryAll:
			round = 0
		case OddTypeCategoryHalf:
			round = 100
		}

		createMarket(&data, mk, oddType, matchLv, round, match, existDefaultMarket, strDefaultMarketID, checkedDefault)
	}

	return data, nil
}

/*
 * @Description: 构建盘口投注项名称
 * @Author: robin
 * @Date: 2021/12/1 16:55
 * @LastEditTime: 2021/12/1 16:55
 * @LastEditors: robin
 */
func generateOddNames(oddType OddType, mk *TYMarketListData) ([]string, []string) {

	switch oddType.OptionType {
	case OptionTypeWinLose: //输赢
		return []string{"@T1", "@T2"}, []string{"@T1", "@T2"}
	case OptionTypeHandicap: //让分
		value1 := mk.Value
		value2 := mk.Value
		var valueSlice []string
		if len(mk.Value) > 0 && strings.Contains(mk.Value, "-") {
			value2 = strings.Replace(mk.Value, "-", "+", 1)
		} else if len(mk.Value) > 0 {
			value1 = fmt.Sprintf("+%v", mk.Value)
			value2 = fmt.Sprintf("-%v", mk.Value)
		}
		if strings.Contains(mk.Value, "/") {
			valueSlice = append(valueSlice, value1)
			valueSlice = append(valueSlice, value2)
			value1, value2 = updateOddValue(valueSlice, 1)
			fmt.Printf("让分玩法-盘口ID[%s], 盘口值[%s] 投注项盘口值-1[%s], 投注项盘口值-2[%s]\n", mk.ID, mk.Value, value1, value2)
		}
		return []string{fmt.Sprintf("@T1 %s", value1), fmt.Sprintf("@T2 %s", value2)}, []string{fmt.Sprintf("@T1 %s", value1), fmt.Sprintf("@T2 %s", value2)}
	case OptionTypeOverUnder: //大小
		for i, odd := range mk.OddList {
			if odd.Type == "Over" { //大于
				odd.SortID = 1
			} else if odd.Type == "Under" { //小于
				odd.SortID = 2
			}
			mk.OddList[i] = odd
		}
		value1 := mk.Value
		value2 := mk.Value
		var valueSlice []string
		if strings.Contains(mk.Value, "/") {
			valueSlice = append(valueSlice, value1)
			valueSlice = append(valueSlice, value2)
			value1, value2 = updateOddValue(valueSlice, 0)
			fmt.Printf("大小玩法-盘口ID[%s], 盘口值[%s] 投注项盘口值-1[%s], 投注项盘口值-2[%s]\n", mk.ID, mk.Value, value1, value2)
		}
		return []string{fmt.Sprintf("大于> %s", value1), fmt.Sprintf("小于< %s", value2)}, []string{fmt.Sprintf("Over> %s", value1), fmt.Sprintf("Under< %s", value2)}
	case OptionType1X2: //胜负平
		return []string{"@T1", "平", "@T2"}, []string{"@T1", "Draw", "@T2"}
	case OptionTypeOddEven: //单双
		for i, odd := range mk.OddList {
			if odd.Type == "Odd" { //单
				odd.SortID = 1
			} else if odd.Type == "Even" { //双
				odd.SortID = 2
			}
			mk.OddList[i] = odd
		}
		return []string{"单", "双"}, []string{"Odd", "Even"}
	default:
		return nil, nil
	}
}

/*
 * @Description: 更新投注项名称
 * @Author: robin
 * @Date: 2022/1/5 19:33
 * @LastEditTime: 2022/1/5 19:33
 * @LastEditors: robin
 */
func updateOddValue(valueSlice []string, idx int) (string, string) {

	var (
		strValue []string
	)
	for _, value := range valueSlice {
		var (
			strSlice []string
			ft       string
		)
		length := len(value)
		strSlice = strings.Split(value[idx:length], "/")
		if len(strSlice) == 2 {
			ft1, err := decimal.NewFromString(strSlice[0])
			if err != nil {
				fmt.Printf("updateOddValue decimal.NewFromString, Err:%s\n", err.Error())
				return "", ""
			}
			ft2, err := decimal.NewFromString(strSlice[1])
			if err != nil {
				fmt.Printf("updateOddValue decimal.NewFromString, Err:%s\n", err.Error())
				return "", ""
			}
			ft = (ft1.Add(ft2).Div(decimal.NewFromInt(2))).StringFixed(2)
			if idx > 0 {
				ft = fmt.Sprintf("%s%s", value[0:1], ft)
			}
			strValue = append(strValue, ft)
		}
	}

	if len(strValue) == 2 {
		return strValue[0], strValue[1]
	}
	return "", ""
}

/*
 * @Description: 获取盘口列表
 * @Author: robin
 * @Date: 2021/12/1 17:30
 * @LastEditTime: 2021/12/1 17:30
 * @LastEditors: robin
 */
func MarketListDB(ex g.Ex) ([]MarketData, error) {

	var data []MarketData
	query, _, _ := g.Dialect("mysql").From(TblMarkets).Select(colMarketData...).Where(ex).ToSQL()
	err := zkDB.Select(&data, query)

	return data, err
}

/*
 * @Description: 保存盘口
 * @Author: robin
 * @Date: 2021/12/7 16:40
 * @LastEditTime: 2021/12/7 16:40
 * @LastEditors: robin
 */
func MarketSaveArgs(data MarketData, userID uint64, match utils.MatchData, t int64, markets *[]Market, odds *[]Odd) error {

	var err error
	mktName := data.CnName
	// 胜平负-投注项个数校验
	if data.OptionType == OptionType1X2 && len(data.Odds) != 3 {
		return errors.New(mktName + "投注项格式错误")
	}
	// 输赢,让分,大小,单双-投注项个数校验
	if data.OptionType == OptionTypeWinLose ||
		data.OptionType == OptionTypeHandicap ||
		data.OptionType == OptionTypeOverUnder ||
		data.OptionType == OptionTypeOddEven {
		if len(data.Odds) != 2 {
			return errors.New(mktName + "投注项格式错误")
		}
	}

	// 获取玩法
	oddType, err := OddTypeFindOne(g.Ex{"id": data.OddTypeID})
	if err != nil {
		return err
	}

	var (
		marketCnName string
		marketEnName string
	)
	marketCnName = helper.FilterInjection(data.CnName)
	marketEnName = helper.FilterInjection(data.EnName)

	// 新增盘口
	returnRate := data.ReturnRate
	mkt := Market{
		ID:                data.ID,
		MatchID:           match.ID,               //赛事ID
		OddTypeID:         data.OddTypeID,         //玩法类型ID
		EnName:            marketEnName,           //英文名称
		CnName:            marketCnName,           //中文名称
		Round:             data.Round,             //第几局 0-全局
		BonusProportion:   data.BonusProportion,   //赔付占比
		OptionType:        data.OptionType,        //玩法类型 1-输赢 2-让分 3-大小  6-胜负平 7-单双
		ReturnRate:        returnRate,             //返还率
		DefaultReturnRate: data.DefaultReturnRate, //限红之前-返还率默认值
		SingleMaxBonus:    "0",                    //单注最高赔付
		MaxBonusTotal:     "0",                    //盘口最高总赔付
		Suspended:         data.Suspended,         //是否暂停  1-暂停 0-取消暂停
		Visible:           data.Visible,           //是否显示  1-显示 0-隐藏
		LockReturnRate:    0,                      //是否锁定返还率  1-开启 0-取消
		AutoOdd:           0,                      //是否开启自动变赔  1-开启 0-取消
		IsReopen:          0,                      //是否重新开盘  1-是 0-否
		IsInputReject:     0,                      //是否录入驳回  1-是 0-否
		IsSettleReject:    0,                      //是否结算驳回  1-是 0-否
		Status:            data.Status,            //待录入-1 已录入-2  录入驳回-3 待审核-4 待开盘-5 已开盘-6 已关盘-7 待结算-8 已结算-9 赛果驳回-10 待取消-11 已取消-12
		CloseTime:         0,                      //关盘时间
		Remark:            "",                     //备注
		SortCode:          data.SortCode,          //排序码
		CreateTime:        t,                      //创建时间
		CreateByID:        userID,                 //创建人ID
		CreateByName:      "TY",                   //创建人名称
		UpdateTime:        t,                      //修改时间
		UpdateByID:        userID,                 //修改人ID
		UpdateByName:      "TY",                   //修改人名称
		SettleCount:       0,                      //结算次数
		IsDefault:         int8(data.IsDefault),   //是否首页默认展示盘口
		PrizeLimit:        data.PrizeLimit,        //单注赔付
		PrizeStaticProfit: data.PrizeStaticProfit, //单注限红
		MbMktPrizeLimit:   data.MbMktPrizeLimit,   //会员盘口赔付
		MchCompPrizeLimit: data.MchCompPrizeLimit, //普通串关单注赔付
		WarningProfit:     data.WarningProfit,     //预警值
		StopProfit:        data.StopProfit,        //停盘值
		Tag:               oddType.Tag,            //玩法标签
		TagCode:           oddType.TagCode,        //玩法标签排序
		IsUpdateName:      oddType.IsUpdateName,   //是否可编辑投注项 1-是 0-否
		IsPassOff:         0,                      //是否允许串关 0-不允许串关 1-只允许赛事串关 2-只允许赛事和局内串关
		Reason:            0,                      //盘口标记
		OddRangeStatus:    0,                      //是否启用特殊抽水 1-启用 0-禁用
		OddLinkage:        0,                      //是否开启赔率联动 1-启用 0-禁用
		ScoreBenchmark:    data.ScoreBenchmark,    //基准分
	}

	*markets = append(*markets, mkt)

	for k := range data.Odds {
		// 新增投注项
		odd := Odd{
			ID:        data.Odds[k].ID,
			MatchID:   match.ID,                                    //赛事ID
			MarketID:  mkt.ID,                                      //盘口ID
			Round:     int(data.Round),                             //赛事局数
			Name:      helper.FilterInjection(data.Odds[k].Name),   //选项名称(中文)
			EnName:    helper.FilterInjection(data.Odds[k].EnName), //选项名称(英文)
			Odd:       data.Odds[k].Odd,                            //赔率
			OrgOdd:    "",                                          //初始赔率
			SortID:    data.Odds[k].SortID,                         //排序ID
			IsWinner:  0,                                           //是否获胜 1-是 0-否
			Visible:   VisibleOpen,                                 //是否显示  1-显示 0-隐藏
			Suspended: SuspendedClose,                              //是否暂停  1-暂停 0-取消暂停
			TeamID:    "0",                                         //猜冠军玩法 战队id
		}
		*odds = append(*odds, odd)
	}

	return nil
}

/*
 * @Description: 盘口保存
 * @Author: robin
 * @Date: 2021/12/7 17:58
 * @LastEditTime: 2021/12/7 17:58
 * @LastEditors: robin
 */
func MarketSave(matchID string, markets []Market, odds []Odd) (bool, error) {

	status := false
	if len(markets) == 0 {
		return status, nil
	}

	if len(odds) == 0 {
		return status, nil
	}

	dbConn, err := zkDB.Begin()
	if err != nil {
		return status, err
	}

	//新增赛事盘口
	query, _, _ := dialect.Insert(TblMarkets).Rows(markets).ToSQL()
	fmt.Println(query)
	_, err = dbConn.Exec(query)
	if err != nil {
		_ = dbConn.Rollback()
		return status, err
	}

	//新增赛事投注项
	query, _, _ = dialect.Insert(TblOdds).Rows(odds).ToSQL()
	fmt.Println(query)
	_, err = dbConn.Exec(query)
	if err != nil {
		_ = dbConn.Rollback()
		return status, err
	}

	// 赛事状态是已开盘 则写入盘口calc json
	for _, v := range markets {
		var oddIDs []string
		for _, odd := range odds {
			if odd.MarketID != v.ID {
				continue
			}
			oddIDs = append(oddIDs, odd.ID)
		}

		mktCalc, err := marketCalcGen(v.ID, oddIDs)
		if err != nil {
			_ = dbConn.Rollback()
			return status, err
		}

		bytes, err := helper.JsonMarshal(mktCalc)
		if err != nil {
			_ = dbConn.Rollback()
			return status, err
		}

		err = MarketStatInsert(zkRedis.GetClusterClient(), matchID, v.ID, string(bytes))
		if err != nil {
			_ = dbConn.Rollback()
			return status, err
		}
	}

	//保存盘口缓存
	pipe := zkRedis.GetClusterClient().Pipeline()
	defer pipe.Close()
	err = MarketCacheSave(pipe, matchID, markets, odds)
	if err != nil {
		_ = dbConn.Rollback()
		return status, err
	}
	_, err = pipe.Exec()
	if err != nil {
		_ = dbConn.Rollback()
		return status, err
	}

	return true, dbConn.Commit()
}

func MarketCacheSave(pipe redis.Pipeliner, matchID string, mkts []Market, odds []Odd) error {

	if len(mkts) <= 0 || len(odds) <= 0 {
		return nil
	}

	// 先加载mkt_ids的数据到map
	marketIds := map[string][]string{}
	idxKey := fmt.Sprintf(utils.RedisGameIndex, matchID)
	strJson, err := zkRedis.GetClusterClient().Do("JSON.GET", idxKey, "mkt_ids").Text()
	if err != nil {
		return err
	}

	err = json.Unmarshal([]byte(strJson), &marketIds)
	if err != nil {
		return err
	}

	for _, mkt := range mkts {
		mktCache := utils.Market{
			ID:                mkt.ID,
			MatchID:           mkt.MatchID,
			OddTypeID:         mkt.OddTypeID,
			CnName:            mkt.CnName,
			EnName:            mkt.EnName,
			Round:             int(mkt.Round),
			IsDefault:         int(mkt.IsDefault),
			OptionType:        int(mkt.OptionType),
			SortCode:          mkt.SortCode,
			CompSubNum:        mkt.CompSubNum,
			SubMktID:          mkt.SubMktID,
			SubOddID:          mkt.SubOddID,
			Status:            int(mkt.Status),
			Suspended:         int(mkt.Suspended),
			Visible:           int(mkt.Visible),
			PrizeLimit:        mkt.PrizeLimit,
			MbMktPrizeLimit:   mkt.MbMktPrizeLimit,
			WarningProfit:     mkt.WarningProfit,
			StopProfit:        mkt.StopProfit,
			Remark:            mkt.Remark,
			PrizeStaticProfit: mkt.PrizeStaticProfit,
			Tag:               mkt.Tag,
			TagCode:           mkt.TagCode,
			Odds:              map[string]utils.Odd{},
			MchCompPrizeLimit: mkt.MchCompPrizeLimit,
			IsPassOff:         mkt.IsPassOff,
			SettleCount:       mkt.SettleCount,
			ScoreBenchmark:    mkt.ScoreBenchmark,
		}
		for _, odd := range odds {
			if odd.MarketID == mkt.ID {
				mktCache.Odds["$"+odd.ID] = utils.Odd{
					ID:        odd.ID,
					MarketID:  odd.MarketID,
					Name:      odd.Name,
					EnName:    odd.EnName,
					Odd:       fmt.Sprintf("%v", odd.Odd),
					IsWinner:  odd.IsWinner,
					SortID:    odd.SortID,
					Visible:   odd.Visible,
					Suspended: odd.Suspended,
					TeamID:    odd.TeamID,
				}
			}
		}

		res, err := helper.JsonMarshal(mktCache)
		if err != nil {
			return err
		}
		idxPath := fmt.Sprintf(utils.JPathField, "default_market")
		utils.MarketCacheSet(pipe, mktCache.MatchID, mktCache.ID, utils.JPathRoot, res, mktCache.IsDefault == 1, idxPath)

		// 处理盘口id map
		marketIds[mkt.OddTypeID] = append(marketIds[mkt.OddTypeID], mkt.ID)
	}

	_, err = pipe.Exec()

	// 把map的数据写回mkt_ids
	if len(marketIds) > 0 {
		data, err := json.Marshal(marketIds)
		if err != nil {
			return err
		}
		utils.MatchCacheSet(zkRedis.GetClusterClient(), matchID, ".mkt_ids", data)
	}

	return err
}

/**
 * @Description: 根据条件从数据库获取一个盘口数据
 * @Author: wesley
 * @Date: 2020/6/23 11:28
 * @LastEditTime: 2020/6/23 11:28
 * @LastEditors: wesley
 */
func MarketFindOne(ex g.Ex) (Market, error) {

	data := Market{}
	query, _, _ := dialect.Select(colMarket...).From(TblMarkets).Where(ex).Limit(1).ToSQL()
	err := zkDB.Get(&data, query)
	if err == sql.ErrNoRows {
		return data, nil
	}

	return data, err
}

/**
* @Description: 盘口更新
* @Author: brandon
* @Date: 2020/6/20 8:27 下午
* @LastEditTime: 2020/6/20 8:27 下午
* @LastEditors: brandon
 */
func MarketUpdate(matchId string, record g.Record, ex g.Ex) error {

	tx, err := zkDB.Begin()
	if err != nil {
		return err
	}

	// 更新盘口数据库
	query, _, _ := dialect.Update(TblMarkets).Set(record).Where(ex).ToSQL()
	fmt.Println(query)
	_, err = tx.Exec(query)
	if err != nil {
		_ = tx.Rollback()
		return err
	}

	// 如果是开盘状态，需要把tbl_odds的org_odd设置odd
	isReopen, ok := record["is_reopen"]
	if record["status"] == MarketStatusOpen && (!ok || isReopen == 0) {
		oddRecord := g.Record{"org_odd": g.C("odd")}
		oddEx := g.Ex{"market_id": ex["id"]}
		query, _, _ = dialect.Update(TblOdds).Set(oddRecord).Where(oddEx).ToSQL()
		fmt.Println(query)
		_, err = tx.Exec(query)
		if err != nil {
			_ = tx.Rollback()
			return err
		}
	}

	// 更新盘口缓存
	pipe := zkRedis.GetClusterClient().Pipeline()
	defer pipe.Close()
	// 获取默认盘口
	market, err := MarketFindOne(g.Ex{"match_id": matchId, "is_default": 1})
	if err != nil {
		_ = tx.Rollback()
		return err
	}

	MarketCacheUpdate(pipe, matchId, record, ex, market.ID)
	_, err = pipe.Exec()
	if err != nil {
		_ = tx.Rollback()
		return err
	}

	return tx.Commit()
}

/**
 * @Description: 更新盘口缓存字段
 * @Author: maxic
 * @Date: 2020/8/15
 * @LastEditTime: 2020/8/15
 * @LastEditors: maxic
 **/
func MarketCacheUpdate(pipe redis.Pipeliner, matchId string, record g.Record, ex g.Ex, defaultMarketId string) {

	cacheFields := map[string]bool{
		"cn_name":              true,
		"en_name":              true,
		"score_benchmark":      true,
		"is_default":           true,
		"option_type":          true,
		"sort_code":            true,
		"status":               true,
		"suspended":            true,
		"visible":              true,
		"prize_limit":          true,
		"mb_mkt_prize_limit":   true,
		"warning_profit":       true,
		"stop_profit":          true,
		"remark":               true,
		"prize_static_profit":  true,
		"tag":                  true,
		"tag_code":             true,
		"is_pass_off":          true,
		"mch_comp_prize_limit": true,
		"suspended_type":       true,
		"visible_type":         true,
		"settle_count":         true,
		"odd_linkage":          true,
	}
	fn := func(id string) {
		isDefault := id == defaultMarketId
		for k, v := range record {
			if cacheFields[k] {
				path := fmt.Sprintf(utils.JPathField, k)
				idxPath := fmt.Sprintf(utils.JPathIdxMarketField, k)
				utils.MarketCacheSet(pipe, matchId, id, path, v, isDefault, idxPath)
			}
		}
	}
	if id, ok := ex["id"]; ok {
		switch id.(type) {
		case string:
			fn(id.(string))
		case []string:
			for _, v := range id.([]string) {
				fn(v)
			}
		}
	}
}

func CalcMarketCountGet(markets []MarketData) mqtt.CalcMarketCountsStat {

	var counts mqtt.CalcMarketCountsStat
	counts.TotalCounts = len(markets)
	for _, market := range markets {

		if market.Status == MarketStatusWaitOpen { // 待开盘
			counts.WaitOpenCounts++
		} else if market.Status == MarketStatusOpen && market.Visible == VisibleOpen && market.Suspended == SuspendedClose {
			counts.CanBetCounts++ // 可投注 (开盘且可见且未暂停)
		}
		if market.Suspended == SuspendedOpen { // 暂停
			counts.SuspendCounts++
		}
		if market.Visible == VisibleClose { // 隐藏
			counts.HiddenCounts++
		}
		if market.Status == MarketStatusResultRejected || market.Status == MarketStatusClose {
			// 待录入盘口数 只统计单盘口的 不统计复合盘口
			if market.OptionType != OptionTypeMix {
				counts.WaitInputCounts++ // 待录入盘口（已关盘 赛果驳回）
			}
		}
		if market.Status == MarketStatusWaitSettle || market.Status == MarketStatusWaitCancel ||
			market.Status == MarketStatusSettled || market.Status == MarketStatusCancelled {
			counts.EnteredCounts++ // 已录入盘口（待结算 待取消 已结算 已取消）
		}
		if market.Status != MarketStatusWaitInput && market.Status != MarketStatusInputReject &&
			market.Status != MarketStatusPending {
			counts.AllCounts++ // 全部（所有赛事审核通过盘口）
		}
		if market.Status == MarketStatusCancelled && market.Remark != "取消理由:无赛果" {
			counts.CancelCount++ // 已取消（已取消且无赛果）
		}
		if market.Status == MarketStatusWaitSettle {
			counts.WaitSettlement++ // 待结算盘口（待结算）
		}
		if market.Status == MarketStatusSettled || market.Status == MarketStatusCancelled {
			counts.Settlement++ // 已结算盘口（已结算 已取消）
		}
	}

	return counts
}

/*
 * @Description: 获取赛事盘口数
 * @Author: robin
 * @Date: 2021/12/19 16:25
 * @LastEditTime: 2021/12/19 16:25
 * @LastEditors: robin
 */
func MarketCount(ex g.Ex) (int64, error) {

	var count int64
	query, _, _ := dialect.From(TblMarkets).Select(g.COUNT("id")).Where(ex).ToSQL()
	err := zkDB.Get(&count, query)

	return count, err
}

/*
 * @Description: 根据赛事ID更新并推送前端首页的赛事盘口数量统计(盘口状态:已开盘,已结算)
 * @Author: robin
 * @Date: 2021/12/19 15:29
 * @LastEditTime: 2021/12/19 15:29
 * @LastEditors: robin
 */
func MarketCountUpdate(matchID string, mkCount int) error {

	utils.MatchCacheSet(zkRedis.GetClusterClient(), matchID, fmt.Sprintf(utils.JPathField, "count"), mkCount)
	mqtt.MqttNotifyMarketCountUpdate(matchID, int64(mkCount))
	return nil
}

/*
 * @Description: 盘口取消,二次取消
 * @Author: robin
 * @Date: 2022/1/4 16:55
 * @LastEditTime: 2022/1/4 16:55
 * @LastEditors: robin
 */
func MarketCancel(matchId string, marketIds []string, record g.Record, settleCount int, marketReason map[string]int) error {

	tx, err := zkDB.Begin()
	if err != nil {
		return err
	}

	//更新盘口
	ex := g.Ex{"id": marketIds}
	query, _, _ := dialect.Update(TblMarkets).Set(record).Where(ex).ToSQL()
	fmt.Println(query)
	_, err = tx.Exec(query)
	if err != nil {
		_ = tx.Rollback()
		return err
	}

	// 更新选项
	odds, err := OddListDB(g.Ex{"market_id": marketIds})
	if err != nil {
		_ = tx.Rollback()
		return err
	}
	var records []OdUpdate
	for _, odd := range odds {
		rec := OdUpdate{
			Record: g.Record{"is_winner": 0},
			Ex:     g.Ex{"id": odd.ID, "market_id": odd.MarketID},
		}
		records = append(records, rec)
	}
	err = OddsUpdate(tx, records...)
	if err != nil {
		_ = tx.Rollback()
		return err
	}

	// 获取默认盘口
	market, err := MarketFindOne(g.Ex{"match_id": matchId, "is_default": 1})
	if err != nil {
		_ = tx.Rollback()
		return err
	}

	// 更新盘口缓存
	pipe := zkRedis.GetClusterClient().Pipeline()
	defer pipe.Close()

	MarketCacheUpdate(pipe, matchId, record, ex, market.ID)
	for _, rec := range records {
		marketId := rec.Ex["market_id"].(string)
		MarketCacheOddUpdate(zkRedis.GetClusterClient(), matchId, marketId, rec.Record, rec.Ex, market.ID)
	}
	_, err = pipe.Exec()
	if err != nil {
		_ = tx.Rollback()
		return err
	}

	// 发送redis stream
	if settleCount > 1 {
		err = beanstalk.BeansPutSettleTask(ZkBeansPool, conf.Cfg.ZkConf.SettleMerchs, marketIds[0], nil, settleCount, SettleStreamFlagCancel, 1)
	} else {
		ids := strings.Join(marketIds, ",")
		s, _ := helper.MarshalToString(marketReason)
		err = beanstalk.BeansPutTradeTask(ZkBeansPool, conf.Cfg.ZkConf.SettleMerchs, matchId, ids, "&reason="+s, TradeStreamFlagCancel)
	}
	if err != nil {
		_ = tx.Rollback()
		return err
	}

	return tx.Commit()
}

/**
 * @Description: 更新盘口投注项缓存字段
 * @Author: maxic
 * @Date: 2020/8/15
 * @LastEditTime: 2020/8/15
 * @LastEditors: maxic
 **/
func MarketCacheOddUpdate(pool *redis.ClusterClient, matchId, marketId string, record g.Record, ex g.Ex, defaultMarketId string) {

	cacheFields := map[string]bool{
		"odd":       true,
		"is_winner": true,
		"sort_id":   true,
		"visible":   true,
		"suspended": true,
		"name":      true,
		"en_name":   true,
	}

	pipe := pool.Pipeline()
	defer pipe.Close()

	isDefault := marketId == defaultMarketId
	fn := func(id string) {
		for k, v := range record {
			if cacheFields[k] {
				path := fmt.Sprintf(utils.JPathOddField, id, k)
				idxPath := fmt.Sprintf(utils.JPathIdxOddField, id, k)
				utils.MarketCacheSet(pipe, matchId, id, path, v, isDefault, idxPath)
			}
		}
	}
	if id, ok := ex["id"]; ok {
		switch id.(type) {
		case string:
			fn(id.(string))
		case []string:
			for _, v := range id.([]string) {
				fn(v)
			}
		}
	}

	_, err := pipe.Exec()
	if err != nil {
		fmt.Println("MarketCacheOddUpdate:", err)
	}
}

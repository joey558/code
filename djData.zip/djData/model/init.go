package model

import (
	"djData/helper"
	"djData/helper/beanstalk"
	"djData/helper/conf"
	mqtt "djData/helper/mqtt_helper"
	"djData/helper/mysql_helper"
	redis "djData/helper/redis_helper"
	"djData/helper/rocket_mq"
	"fmt"
	"github.com/apache/rocketmq-client-go/v2"
	g "github.com/doug-martin/goqu/v9"
	_ "github.com/go-sql-driver/mysql"
	"github.com/jmoiron/sqlx"
	cPool "github.com/silenceper/pool"
	_ "go.uber.org/automaxprocs"
	"time"
)

var (
	zkDB          *sqlx.DB              // 总控mysql主库
	zkRedis       *redis.RedisHelper    // 总控redis主库
	lockRedis     *redis.RedisHelper    // 锁从库
	autoOddCli    rocketmq.PushConsumer // 自动变陪
	autoSettleCli rocketmq.PushConsumer // 自动结算

	ZkBeansPool cPool.Pool // 总控
)

var (
	dialect = g.Dialect("mysql")
)

func GetZkRedis() *redis.RedisHelper {

	return zkRedis
}

/**
* @Description: 初始化
* @Author: daxie
* @Date: 2021/6/16 15:14
* @LastEditTime: 2021/6/16 15:14
* @LastEditors: daxie
 */
func Constructor() {

	// 总控模式
	zkCfg := conf.Cfg.ZkConf

	// 初始化总控延时队列,总控和商户都需要用到
	ZkBeansPool = beanstalk.InitBeanstalk(zkCfg.Beanstalk, 50, 50, 100)
	// 初始化总控db
	zkDB = mysql_helper.InitDB(zkCfg.TraderDb)

	// 初始化日志组件
	helper.InitLogger(zkCfg.Zlog)

	// 初始化mqtt
	mqtt.InitMqtt(zkCfg.Mqtt, mqtt.MqttPoolFlags)

	// 初始化emqx
	mqtt.InitMqtt(zkCfg.Emqx, mqtt.EmqxPoolFlags)

	// 初始化总控主redis
	zkRedis = redis.NewRedisCluster(zkCfg.RedisCluster)

	// 初始化锁redis
	lockRedis = redis.InitRedisLock(zkCfg.LockRedis)
	rocket_mq.BeansPool = ZkBeansPool
	fmt.Println("djData 总控模式启动")
}

// ServerStop
/**
* @Description: 停止服务
* @Author: noah
* @Date: 2021/9/28 19:29
* @LastEditTime:2021/9/28 19:29
* @LastEditors: noah
 */
func ServerStop() {

	// 退出程序，结束RocketMQ订阅
	_ = autoOddCli.Shutdown()
	_ = autoSettleCli.Shutdown()
	//检查管道数据是否全部消费
	for {
		quit := true
		if len(settleChan) != 0 {
			quit = false
		}

		if len(oddChan) != 0 {
			quit = false
		}

		for _, i := range autoSettleChan {
			if len(i) != 0 {
				quit = false
			}
		}
		for _, j := range autoOddChan {
			if len(j) != 0 {
				quit = false
			}
		}
		if quit {
			break
		}
		time.Sleep(1 * time.Second)
	}

	if zkDB != nil {
		_ = zkDB.Close()
	}

	// 关闭redis
	if zkRedis != nil {
		zkRedis.CloseRedis()
	}

	if ZkBeansPool != nil {
		ZkBeansPool.Release()
	}

	fmt.Printf("[%s]关闭RocketMQ服务相关通道, 断开数据库连接.\n", time.Now().Format("2006-01-02 15:04:05"))
}

package model

import (
	"database/sql"
	"djData/helper/conf"
	"fmt"
	g "github.com/doug-martin/goqu/v9"
)

type BetOrder struct {
	ID                    string  `db:"id" json:"id"`                                           // 主键ID
	MemberID              uint64  `db:"member_id" json:"member_id"`                             // 会员ID
	MemberAccount         string  `db:"member_account" json:"member_account"`                   // 会员名
	OddID                 uint64  `db:"odd_id" json:"odd_id"`                                   // 投注项ID
	MatchID               uint64  `db:"match_id" json:"match_id"`                               // 赛事ID
	MarketID              uint64  `db:"market_id" json:"market_id"`                             // 盘口ID
	TheoryPrize           float64 `db:"theory_prize" json:"theory_prize"`                       // 预派彩金额
	ParentMerchantAccount string  `db:"parent_merchant_account" json:"parent_merchant_account"` // 父商户账户名
	MerchantAccount       string  `db:"merchant_account" json:"merchant_account"`               // 商户账户名
	TopMerchantID         uint64  `db:"top_merchant_id" json:"top_merchant_id"`                 // 顶层商户ID
	TopMerchantAccount    string  `db:"top_merchant_account" json:"top_merchant_account"`       // 顶层商户账号
	TeamCnNames           string  `db:"team_cn_names" json:"team_cn_names"`                     // 战队中文名称
	TeamEnNames           string  `db:"team_en_names" json:"team_en_names"`                     // 战队英文名称
	MarketCnName          string  `db:"market_cn_name" json:"market_cn_name"`                   // 盘口中文名称
	MarketEnName          string  `db:"market_en_name" json:"market_en_name"`                   // 盘口英文名称
	OddName               string  `db:"odd_name" json:"odd_name"`                               // 投注项名称
	OddEnName             string  `db:"odd_en_name" json:"odd_en_name"`                         // 投注项英文名称
	Odds                  string  `db:"odd" json:"odd"`                                         // 赔率
	BetAmount             float64 `db:"bet_amount" json:"bet_amount"`                           // 注单金额
	WinAmount             float64 `db:"win_amount" json:"win_amount"`                           // 派奖金额
	BetTime               int64   `db:"bet_time" json:"bet_time"`                               // 投注时间
	SettleTime            uint    `db:"settle_time" json:"settle_time"`                         // 结算时间
	BetStatus             int     `db:"bet_status" json:"bet_status"`                           // 注单状态 1-待确认 2-已拒绝 3-待结算 4-已取消 5-已中奖 6-未中奖
	Device                int     `db:"device" json:"device"`                                   // 投注设备
	OrderType             int     `db:"order_type" json:"order_type"`                           // 注单类型 1普通注单 2串关注单
	IsLive                int     `db:"is_live" json:"is_live"`                                 // 赛事阶段 1-初盘 2-滚盘
	Tester                int     `db:"tester" json:"tester"`                                   // 是否测试账户
	OrgOddID              int     `json:"org_odd_id" db:"org_odd_id"`                           // 玩法id
	RiskTagID             int     `db:"risk_tag_id" json:"risk_tag_id"`                         // 风险标签ID
	TYMatchSID            int     `db:"ty_match_sid" json:"ty_match_sid"`                       // 体育赛事的SID
	TYOrderID             string  `db:"ty_order_id" json:"ty_order_id"`                         // 体育的注单ID
}

/*
 * @Description: 根据条件查询注单
 * @Author: robin
 * @Date: 2022/1/2 17:18
 * @LastEditTime: 2022/1/2 17:18
 * @LastEditors: robin
 */
func BetOrderFindAll(ex g.Ex) ([]BetOrder, error) {

	var data []BetOrder
	query, _, _ := dialect.From(TblBetOrder).Select(colBetOrder...).Where(ex).Order(g.C("bet_time").Desc()).ToSQL()
	err := zkDB.Select(&data, query)

	return data, err
}

// GetBetOrderSettleCount
/*
 * @Description: 根据条件查询注单结算次数
 * @Author: robin
 * @Date: 2022/1/2 17:18
 * @LastEditTime: 2022/1/2 17:18
 * @LastEditors: robin
 */
func GetBetOrderSettleCount(ex g.Ex) (int, error) {

	var count int
	query, _, _ := dialect.From(TblBetOrder).Select("settle_count").Where(ex).Limit(1).ToSQL()
	err := zkDB.Get(&count, query)
	if err == sql.ErrNoRows {
		return count, nil
	}

	return count, err
}

/**
 * @Description: 判断盘口结算任务是否在运行中
 * @Author: noah
 * @Date: 2020/9/18 15:48
 * @LastEditTime: 2020/9/18 15:48
 * @LastEditors: noah
 */
func marketSettleIsRunning(marketID string) (bool, error) {

	var (
		keys  []string
		count int64
		err   error
	)
	for _, m := range conf.Cfg.ZkConf.SettleMerchs {
		keys = append(keys, fmt.Sprintf("rlock:%s_draw:%s", m, marketID))
	}

	count, err = lockRedis.GetClient().Exists(keys...).Result()
	if err != nil {
		return false, err
	}

	if count == 0 {
		return false, nil
	}

	return true, nil
}

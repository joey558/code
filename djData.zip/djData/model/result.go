package model

import (
	"context"
	"djData/helper"
	"djData/helper/beanstalk"
	"djData/helper/conf"
	mqtt "djData/helper/mqtt_helper"
	rmq "djData/helper/rocket_mq"
	"djData/utils"
	"fmt"
	"strconv"
	"time"

	g "github.com/doug-martin/goqu/v9"
	errx "github.com/pkg/errors"
)

// MarketResult 赛果下发
type MarketResult struct {
	MatchId         int64 `json:"matchId"`         // 赛事Id
	MarketId        int64 `json:"marketId"`        // 盘口ID
	SettlementTimes int   `json:"settlementTimes"` // 结算次数
	//MultipleSettlementWay interface{}            `json:"multipleSettlementWay"` // 多次结算方式 1-事件审核二次下发，2-数据源二次下发，3-手动录入二次下发,4-使用数据源修正，5-使用PD修正
	SportId interface{} `json:"sportId"` // 体种id
	//Flag                  string                 `json:"flag"`                  // 分数
	//SecondarySettleTag    interface{}            `json:"secondarySettleTag"`    // 修改赛果下发二次结算标识 ,0-否，1-是
	MarketOptionsResults []MarketOptionsResults `json:"marketOptionsResults"` // 盘口下投注项结果集
}

// MarketOptionsResults 盘口下投注项结果集
type MarketOptionsResults struct {
	OptionsId int64 `json:"optionsId"` // 投注项ID
	Result    int   `json:"result"`    // 投注项赛果  0-无结果  2-走水  3-输 4-赢 5-赢一半 6-输一半
}

var (
	settleChan     chan []byte // 结算管道
	autoSettleChan = map[string]chan AutoSettleData{}
)

type AutoSettleData struct {
	MchId string       `json:"mch_id"`
	Data  MarketResult `json:"data"`
}

// MarketAutoSettle
/**
* @Description: RocketMQ盘口自动结算主函数
* @Author: noah
* @Date: 2021/12/18 15:33
* @LastEditTime:2021/12/18 15:33
* @LastEditors: noah
 */
func MarketAutoSettle(ctx context.Context) {

	var err error
	settleChan = make(chan []byte, ChanMax)
	cfg := conf.Cfg.TYApiConf.RocketMq
	strGroupName := cfg.GroupName + rmq.TYResultTopic
	autoSettleCli, err = rmq.GetMqPushConsumer(cfg, strGroupName)
	if err != nil {
		fmt.Printf("【自动结算】GetMqPushConsumer,Error[%s].\n", err.Error())
		return
	}

	// 订阅RocketMQ信息
	go rmq.RocketMqMsgGet(ctx, autoSettleCli, rmq.TYResultTopic, settleChan)
	for i := range settleChan {
		data := MarketResult{}
		err = helper.JsonUnmarshal(i, &data)
		if err != nil {
			fmt.Println(err.Error())
			fmt.Printf("【自动结算】JsonUnmarshal,Error[%s].\n", err.Error())
			fmt.Printf("【自动结算】JsonUnmarshal,解析内容错误[%s].\n", string(i))
			continue
		}

		sportId, _ := strconv.Atoi(fmt.Sprintf("%v", data.SportId))
		if sportId != TYCategoryFootball && sportId != TYCategoryBasketball {
			continue
		}

		mchId := getMatchId(fmt.Sprintf("%d", data.MatchId))
		if mchId == "" {
			fmt.Printf("【自动结算-赛事ID:%d】不存在于电竞赛事列表里.\n", data.MatchId)
			continue
		}

		fmt.Printf("【自动结算】RocketMQ消息, 赛事种类:%v, 赛事SID:%d, 盘口ID:%d, 消息内容:%v \n", data.SportId, data.MatchId, data.MarketId, data.MarketOptionsResults)
		d := AutoSettleData{mchId, data}
		if _, ok := autoSettleChan[mchId]; !ok {
			autoSettleChan[mchId] = make(chan AutoSettleData, ChanMax)
			go func() {
				for j := range autoSettleChan[mchId] {
					err = settle(j.MchId, j.Data)
					if err != nil {
						fmt.Printf("【自动结算-赛事ID:%s】settle,Error:%+v.\n", j.MchId, err)
						time.Sleep(5 * time.Second)
						autoSettleChan[mchId] <- d
					}
				}
			}()
		}
		autoSettleChan[mchId] <- d
	}
}

/**
* @Description: 结算
* @Author: noah
* @Date: 2021/12/18 15:34
* @LastEditTime:2021/12/18 15:34
* @LastEditors: noah
 */
func settle(mchId string, data MarketResult) error {

	// todo:xp
	mpMatchMarketID := map[string]string{
		fmt.Sprintf("%d", data.MarketId): mchId,
	}
	handicapInfo, err := utils.HandicapInfo(zkRedis.GetClusterClient(), mpMatchMarketID)
	if err != nil {
		fmt.Printf("【自动结算赛事ID:%s】获取赛事缓存错误[%s]\n. 盘口ID:%v\n", mchId, err.Error(), mpMatchMarketID)
		return err
	}

	match := handicapInfo.Matches[mchId]
	if len(match.ID) == 0 {
		fmt.Printf("【自动结算】赛事SID：%d 赛事ID：%s 不存在于Redis缓存.\n", data.MatchId, mchId)
		return nil
	}

	mkt, err := MarketFindOne(g.Ex{"id": data.MarketId})
	if err != nil {
		return err
	}

	if len(mkt.ID) == 0 || mkt.Status == MarketStatusCancelled {
		fmt.Printf("【自动结算】赛事SID：%d 赛事ID：%s 盘口ID:%d  盘口状态[%d].\n", data.MatchId, match.ID, data.MarketId, mkt.Status)
		return nil
	}

	oddWinStatus := map[string]int{}
	for _, result := range data.MarketOptionsResults {
		if result.Result == 0 || result.Result > TYOddWinStatusLoseHalf { //无赛果 或 取消盘口
			reason, ok := MarketCancelReason[result.Result]
			if !ok {
				fmt.Printf("【自动结算】赛事SID：%d 赛事ID：%s 盘口ID:%d  投注项赛果:%d 盘口取消原因字段值不存在,默认设置为(125-其他).\n", data.MatchId, match.ID, data.MarketId, result.Result)
				reason = MarketReason125
			}
			fmt.Printf("【自动结算】盘口取消,赛事SID：%d 赛事ID：%s 盘口ID:%d 盘口取消原因字段值【%d】.\n", data.MatchId, match.ID, data.MarketId, result.Result)
			mkt.Reason = reason
			mch, err := MatchFindOne(g.Ex{"id": mchId})
			if err != nil {
				fmt.Printf("【自动结算】MatchFindOne 赛事SID：%d 赛事ID：%s 盘口ID:%d , Error:%s\n", data.MatchId, match.ID, data.MarketId, err.Error())
				return err
			}

			markets, err := MarketListDB(g.Ex{"id": mkt.ID})
			if err != nil {
				fmt.Printf("【自动结算】MarketListDB 赛事SID：%d 赛事ID：%s 盘口ID:%d , Error:%s\n", data.MatchId, match.ID, data.MarketId, err.Error())
				return err
			}

			err = marketCancel(mch, markets, mkt.Reason) //取消盘口
			if err != nil {
				fmt.Printf("【自动结算】marketCancel 赛事SID：%d 赛事ID：%s 盘口ID:%d , Error:%s\n", data.MatchId, match.ID, data.MarketId, err.Error())
				return err
			}

			if match.Status == MatchStatusClosed {
				fmt.Printf("【自动结算】赛事SID：%d 赛事ID：%s 盘口ID:%d  赛事已关闭.\n", data.MatchId, match.ID, data.MarketId)
				return err
			}

			if match.Visible == VisibleOpen {
				updateMarketSettleCountTotal(handicapInfo.Matches[mchId])
			}
			return nil
		} else {
			oid := fmt.Sprintf("%d", result.OptionsId)
			status := OddWinStatusLose
			switch result.Result {
			case TYOddWinStatusDraw: //平(走水)
				status = OddWinStatusDraw
			case TYOddWinStatusWin: //赢
				status = OddWinStatusWin
			case TYOddWinStatusWinHalf: //赢半
				status = OddWinStatusWinHalf
			case TYOddWinStatusLoseHalf: //输半
				status = OddWinStatusLoseHalf
			}
			oddWinStatus[oid] = status
		}
	}

	if len(oddWinStatus) == 0 {
		return nil
	}

	for {
		//判断结算是否在运行中
		isRunning, err := marketSettleIsRunning(mkt.ID)
		if err != nil {
			return errx.Wrap(err, "MarketSettleIsRunning error : "+mkt.ID)
		}

		if !isRunning {
			break
		}

		time.Sleep(3 * time.Second)
	}

	now := time.Now().Unix()
	timeStr := time.Now().Format("2006-01-02 15:04:05")
	//构建修改数据
	record := g.Record{
		"update_by_id":   "0",
		"update_by_name": "TY",
		"update_time":    now,
		"settle_time":    now,
		"status":         MarketStatusSettled,
		"reason":         mkt.Reason,
		"visible":        VisibleOpen,
	}
	if mkt.SettleCount < data.SettlementTimes {
		record["settle_count"] = data.SettlementTimes
		mkt.SettleCount = data.SettlementTimes
	}
	// 盘口设置赛果
	err = MarketResultSet(mkt, record, oddWinStatus)
	if err != nil {
		return errx.Wrap(err, "MarketResultSet")
	}

	//结算日志
	go ResultLog(match, mkt, MarketStatusSettled, oddWinStatus)
	fmt.Printf("【自动结算】结算时间：%s 赛事SID：%d 赛事ID：%s 盘口ID:%d 盘口结算次数:%d \n", timeStr, data.MatchId, match.ID, data.MarketId, mkt.SettleCount)

	if match.Status == MatchStatusClosed {
		return nil
	}

	if match.Visible == VisibleClose {
		updateGameMatchTotal(handicapInfo.Matches[mchId], "自动结算")
	} else {
		updateMarketSettleCountTotal(handicapInfo.Matches[mchId])
	}

	return nil
}

// MarketResultSet
/**
 * @Description: 盘口设置赛果
 * @Author: wesley
 * @Date: 2020/6/23 19:52
 * @LastEditTime: 2020/6/23 19:52
 * @LastEditors: wesley
 */
func MarketResultSet(mkt Market, record g.Record, mpOddWinStatus map[string]int) error {

	tx, err := zkDB.Begin()
	if err != nil {
		return err
	}

	ex := g.Ex{"id": mkt.ID}
	//更新盘口
	query, _, _ := dialect.Update(TblMarkets).Set(record).Where(ex).ToSQL()
	fmt.Println(query)
	_, err = tx.Exec(query)
	if err != nil {
		_ = tx.Rollback()
		return err
	}

	//更新投注项
	odds, err := OddListDB(g.Ex{"market_id": mkt.ID})
	if err != nil {
		_ = tx.Rollback()
		return err
	}

	var records []OdUpdate
	for _, odd := range odds {
		isWinner, ok := mpOddWinStatus[odd.ID]
		if !ok {
			continue
		}

		records = append(records, OdUpdate{
			Record: g.Record{"is_winner": isWinner},
			Ex:     g.Ex{"id": odd.ID},
		})
	}
	if len(records) == 0 {
		return nil
	}

	err = OddsUpdate(tx, records...)
	if err != nil {
		_ = tx.Rollback()
		return err
	}

	// 获取默认盘口
	dfMarket, err := MarketFindOne(g.Ex{"match_id": mkt.MatchID, "is_default": 1})
	if err != nil {
		_ = tx.Rollback()
		return err
	}

	settRule := SettleRuleNormal
	settScore := ""
	// 更新盘口缓存
	pipe := zkRedis.GetClusterClient().Pipeline()
	MarketCacheUpdate(pipe, mkt.MatchID, record, ex, dfMarket.ID)
	for _, rec := range records {
		utils.MarketCacheOddUpdate(pipe, mkt.MatchID, mkt.ID, rec.Record, rec.Ex, dfMarket.ID)
	}
	_, err = pipe.Exec()
	if err != nil {
		_ = tx.Rollback()
		return err
	}

	err = beanstalk.PutSettleTask(ZkBeansPool, conf.Cfg.ZkConf.SettleMerchs, mkt.ID, mpOddWinStatus, mkt.SettleCount, SettleStreamFlagResettle, mkt.Reason, settRule, settScore)
	if err != nil {
		_ = tx.Rollback()
		return err
	}

	return tx.Commit()
}

// IsBenchmarkScore
/**
* @Description: 判断玩法类型是否为基准分结算的玩法
* @Author: noah
* @Date: 2022/1/2 11:48
* @LastEditTime:2022/1/2 11:48
* @LastEditors: noah
 */
func IsBenchmarkScore(oddTypeID string) bool {

	switch oddTypeID {
	case AllConcedePoints, HalfConcedePoints, AllTimeLeftToWin, FirstTimeLeftToWin:
		return true
	}

	return false
}

// ResultLog
/**
* @Description: 结算推送及日志记录
* @Author: noah
* @Date: 2021/12/19 15:31
* @LastEditTime:2021/12/19 15:31
* @LastEditors: noah
 */
func ResultLog(match utils.MatchData, mkt Market, resStatus int, oddWinnerStatus map[string]int) {

	mqtt.MqttNotifyMarketStatus(mkt.MatchID, []string{mkt.ID}, resStatus, oddWinnerStatus)
	for k, v := range oddWinnerStatus {
		//记录操盘日志
		mktLog := utils.TDMarket{
			TS:                  "now",
			User:                "TY",
			Group:               "0",
			IP:                  "0",
			Menu:                "结算管理-赛事结算",
			Action:              "盘口结算",
			GameID:              match.GameID,
			GameShortName:       GetGameName(match.GameID),
			TournamentId:        match.TournamentID,
			TournamentShortName: TournamentGetName(match.TournamentID),
			Teams:               match.MatchCnTeam,
			MatchID:             match.ID,
			MarketID:            mkt.ID,
			MarketEnName:        mkt.CnName,
			Round:               mkt.Round,
			Result:              fmt.Sprintf("【动作】:%v %v %v", ResettleDesc[1], k, ResultStatus[v]),
			Category:            int8(match.Category),
		}
		mqtt.MqttNotifyMarketLogPub(mktLog)
	}
}

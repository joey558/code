package model

import (
	"database/sql"
	"djData/helper"
	"djData/helper/conf"
	mqtt "djData/helper/mqtt_helper"
	"djData/helper/redis_helper"
	"djData/utils"
	"fmt"
	"strconv"
	"strings"
	"time"

	g "github.com/doug-martin/goqu/v9"
	"github.com/scylladb/go-set"

	"github.com/go-redis/redis/v7"
)

const (
	TblMatches       = "tbl_matches"         //赛事信息表
	TblMatchScore    = "tbl_match_score"     //赛事比分表
	TblMatchLevel    = "tbl_match_level"     //风控赛事等级表
	TblGameRiskTags  = "tbl_game_risk_tags"  //游戏风险标签表
	TblMatchRiskTags = "tbl_match_risk_tags" //赛事游戏风险标签表
	TblBetOrder      = "tbl_bet_order"       // 注单表
)

//体育-赛事列表-返回结果
type TYGetMatchDataResp struct {
	Code string        `json:"code"`
	Data []TYMatchData `json:"data"`
	Msg  string        `json:"msg"`
	Time int64         `json:"ts"`
}

//体育-赛事列表-返回结果
type TYMatchData struct {
	StandardMatchID   string      `json:"mid"`    //标准赛事ID
	OtherMatchID      string      `json:"srid"`   //第三方赛事ID
	CategoryName      string      `json:"csna"`   //赛事类型-名称: 正常-1,冠军-2,大逃杀-3,篮球-4,主播盘-5,足球-6
	Category          string      `json:"csid"`   //体育类型: 足球-1,篮球-2
	TournamentName    string      `json:"tn"`     //体育联赛名称
	TournamentID      string      `json:"tid"`    //体育联赛ID
	MatchLevel        int         `json:"tlev"`   //赛事等级
	StartTime         string      `json:"mgt"`    //赛事开始时间
	RunTime           string      `json:"mststr"` //赛事进行时间(足球-正计时 篮球-倒计时)作为电竞计时器
	NavType           int         `json:"mcg"`    //栏目类型： 1-滚球,2-即将开赛,3-今日赛事,4-早盘
	Stage             interface{} `json:"mmp"`    //比赛阶段: 0-未开始,6-上半场,31-中场休息,7-下半场,41-加时赛上半场,100-全场结束,32-即将加时
	VideoStatus       int         `json:"mms"`    //视频状态: (-1)-无视频源,0-视频源无效,1-视频源未播放,2-正在播放
	HomeTeamID        string      `json:"mhid"`   //主队ID
	HomeTeamName      string      `json:"mhn"`    //主队名称
	HomeTeamLogo      []string    `json:"mhlu"`   //主队LOGO(图片URL地址,默认取0;双打球队取0,1元素)
	HomeTeamThumb     string      `json:"mhlut"`  //主队LOGO缩略图URL地址
	GuestTeamID       string      `json:"maid"`   //客队ID
	GuestTeamName     string      `json:"man"`    //客队名称
	GuestTeamLogo     []string    `json:"malu"`   //客队LOGO(图片URL地址,默认取0;双打球队取0,1元素)
	GuestTeamThumb    string      `json:"malut"`  //客队LOGO缩略图URL地址
	MatchRound        int         `json:"mct"`    //当前第几盘或第几局
	PushBall          string      `json:"mat"`    //发球方:主-home,客-away
	IsOver            int         `json:"mo"`     //比赛是否结束(0-未结束 1-已结束)
	IsLive            int         `json:"mp"`     //是否支持赛前盘
	SupportLive       int         `json:"mlive"`  //赛事是否支持滚球
	MatchStatus       int         `json:"ms"`     //是否支持赛前盘赛事状态：(早盘[0,10],滚盘[1,2,10,111])
	IsNeutralPosition int         `json:"mng"`    //是否中立场: 1-是中立场,0-非中立场
	AddTime           int         `json:"mle"`    //赛节配寘足球：0 = default（默认90分钟），1 = 2 x 40 minutes，9 = 2 x 35 minutes，10 = 2 x 30 minutes，11 = 2 x 25 minutes，46 = 2 x 45 minutes with ABBA shootout format，篮球：0 = default（默认）四节每节10分钟，7=12 munutes periods四节每节12分钟，17=2 X 20 minutes上下半场各20分钟
	AnimationStatus   int         `json:"mvs"`    //动画状态:(-1)-无动画源,0-动画源无效,1-视频源未播放,2-正在播放
	Bo                string      `json:"mfo"`    //赛制
	MarketStatus      int         `json:"mhs"`    //盘口状态
	TotalRounds       int         `json:"mft"`    //总局数
	ScoreArray        []string    `json:"msc"`    //比分-比分类型|比分
	RoundTime         string      `json:"mlet"`   //获取每节比赛的时长
	SeasonID          string      `json:"seid"`   //赛季id
	HomeFirstAlpha    []string    `json:"frmhn"`  //主队名称首字母
	GuestFirstAlpha   []string    `json:"frman"`  //客队名称首字母
	TournamentLogo    string      `json:"lurl"`   //联赛logo
	DataSource        string      `json:"cds"`    //数据源
	StartEndStatus    int         `json:"mess"`   //开始结束状态  1-start 0-stop(此字段只适用于特定事件编码) 篮球暂停事件编码=time_start
	IsHot             int         `json:"th"`     //联赛是否热门:  1-是, 0-否
}

// Match 赛事结构体
type Match struct {
	ID                      string  `json:"id" db:"id" rule:"none" name:"id"`                                                                                                               //赛事id
	SID                     string  `json:"sid" db:"sid" rule:"none" name:"sid"`                                                                                                            //体育赛事ID(标准赛事ID)
	DataSource              int     `json:"data_src" db:"data_src" rule:"none" name:"data_src"`                                                                                             //数据源: (1.默认为空, 2.TY)
	Mode                    int     `json:"mode" db:"mode" rule:"digit" default:"0" name:"mode"`                                                                                            //操盘模式:0-手动操盘,1-MTS
	GameID                  string  `json:"game_id" db:"game_id" rule:"digit" min:"1" msg:"game_id error" name:"game_id"`                                                                   //游戏ID
	UpdateByID              uint64  `json:"update_by_id" db:"update_by_id" rule:"none" name:"update_by_id"`                                                                                 //修改人ID
	CreateByID              uint64  `json:"create_by_id" db:"create_by_id" rule:"none" name:"create_by_id"`                                                                                 //创建人ID
	StartTime               int64   `json:"start_time" db:"start_time" rule:"none" name:"start_time"`                                                                                       //开始时间
	CloseTime               int64   `json:"close_time" db:"close_time" rule:"none" default:"0" name:"close_time"`                                                                           //赛事关闭时间
	EndTime                 int64   `json:"end_time" db:"end_time" rule:"none" name:"end_time"`                                                                                             //结束时间
	BetDelayTime            int     `json:"bet_delay_time" db:"bet_delay_time" rule:"none" name:"bet_time"`                                                                                 //注单确认时间
	CreateTime              int64   `json:"create_time" db:"create_time" rule:"none" name:"create_time"`                                                                                    //创建时间
	AutoClosedTime          int64   `json:"auto_closed_time" db:"auto_closed_time" rule:"none" name:"odd_close_time"`                                                                       //自动关盘时间
	UpdateTime              int64   `json:"update_time" db:"update_time" rule:"none" name:"update_time"`                                                                                    //修改时间
	UpdateByName            string  `json:"update_by_name" db:"update_by_name" rule:"none" name:"update_by_name"`                                                                           //修改人名称
	CreateByName            string  `json:"create_by_name" db:"create_by_name" rule:"none" name:"create_by_name"`                                                                           //创建人名称
	MatchTeam               string  `json:"match_team" db:"match_team" rule:"none" name:"match_team"`                                                                                       //战队信息
	MatchCnTeam             string  `json:"match_cn_team" db:"match_cn_team" rule:"none" name:"match_cn_team"`                                                                              //战队中文名
	MatchEnTeam             string  `json:"match_en_team" db:"match_en_team" rule:"none" name:"match_en_team"`                                                                              //战队英文名
	TeamID                  string  `json:"team_id" db:"team_id" rule:"none" name:"team_id"`                                                                                                //战队id
	TournamentShortName     string  `json:"tournament_short_name" db:"tournament_short_name" rule:"none" min:"2" max:"60" msg:"tournament_short_name错误[2-60]" name:"tournament_short_name"` //联赛简称
	TournamentCnName        string  `json:"tournament_cn_name" db:"tournament_cn_name" rule:"none" min:"2" max:"60" msg:"tournament_cn_name错误[2-60]" name:"tournament_cn_name"`             //联赛中文名
	UserVideoUrl            string  `json:"user_video_url" db:"user_video_url" rule:"none" min:"2" max:"120" msg:"video_src_url error" name:"user_video_url"`                               //直播源地址
	AdminVideoUrl           string  `json:"admin_video_url" db:"admin_video_url" rule:"none" min:"2" max:"120" msg:"live_src error" name:"admin_video_url"`                                 //操盘直播源
	Title                   string  `json:"title" db:"title" rule:"none" name:"title"`                                                                                                      //标题
	TournamentID            string  `json:"tournament_id" db:"tournament_id" rule:"digit" min:"1" msg:"TournamentID error" name:"tournament_id"`                                            //联赛ID
	Score                   string  `json:"score" db:"score" rule:"none"`                                                                                                                   //赛事比分
	Category                int     `json:"category" db:"category" rule:"digit" min:"1" max:"6" name:"category" msg:"category error"`                                                       //赛事类型 正常-1 冠军-2 大逃杀-3 篮球-4 主播盘-5 足球-6
	Bo                      int     `json:"bo" db:"bo" rule:"digit" min:"-1" max:"100" msg:"bo error" name:"bo"`                                                                            // 赛制 无:-1 BO0:0 B01:1 B02:2 B03:3
	MatchLevel              int     `json:"match_level" db:"match_level" rule:"none" name:"match_level"`                                                                                    //赛事等级 1-M1 2-M2 3-M3 4-M4 ... 9999 M9999
	CreditLevel             int     `json:"credit_level" db:"credit_level" rule:"none" name:"credit_level" msg:"credit_level error"`                                                        //信用联赛等级
	Visible                 int     `json:"visible" db:"visible" rule:"none" name:"visible"`                                                                                                //是否显示  1-显示 0-隐藏
	Suspended               int     `json:"suspended" db:"suspended" rule:"none" name:"suspended"`                                                                                          //是否暂停  1-暂停 0-非暂停
	LiveSupport             int     `json:"live_support" db:"live_support" rule:"none" name:"live_support"`                                                                                 //是否滚球 1-是 0-否
	IsPassOff               int     `json:"is_pass_off" db:"is_pass_off" rule:"none" name:"is_pass_off"`                                                                                    //是否串关 0-否 1-普通串关 2-局内串关
	Status                  int     `json:"status" db:"status" rule:"none" name:"status"`                                                                                                   //待录入-1 待审核-2 已驳回-3 待开盘-4 已开盘-5 已关盘-6 已结算-7 待取消-8 比赛取消-9
	IsLive                  int     `json:"is_live" db:"is_live" rule:"none" name:"is_live"`                                                                                                //赛事阶段 1-初盘 2-滚盘
	Rec                     int     `json:"rec" db:"rec" rule:"none"  name:"rec"`                                                                                                           //推荐序号
	RndCompPrizeLimit       int     `json:"rnd_comp_prize_limit" db:"rnd_comp_prize_limit" rule:"none"`                                                                                     //单局串关单注赔付
	RndCompMchPrizeLimit    int     `json:"rnd_comp_mch_prize_limit" db:"rnd_comp_mch_prize_limit" rule:"none"`                                                                             //单局串关赛事赔付
	RndCompOddDscnt         float64 `json:"rnd_comp_odd_dscnt" db:"rnd_comp_odd_dscnt" default:"100" rule:"amount" min:"1" max:"100"`                                                       //局内串关返还率
	MbMchPrizeLimit         int     `json:"mb_mch_prize_limit" db:"mb_mch_prize_limit" rule:"none"`                                                                                         //会员赛事赔付
	RateLimit               int     `json:"rate_limit" db:"rate_limit" rule:"none" default:"100" min:"1" max:"100"`                                                                         //限红比例
	RateReduce              float64 `json:"rate_reduce" db:"rate_reduce" rule:"amount" default:"0" min:"0" max:"15"`                                                                        //返还率缩减
	VideoType               int     `json:"video_type" db:"video_type" rule:"digit" default:"1" name:"video_type"`                                                                          //视频类型1-国内直播源 2-转播直播源
	VideoLabel              int     `json:"video_label" db:"video_label" rule:"digit" default:"0" name:"video_label"`                                                                       //视频标签1.虎牙 2.斗鱼3.腾讯
	IsMatchNotes            int     `json:"is_match_notes" db:"-" name:"is_match_notes" rule:"none"`                                                                                        //
	MixOddDscnt             float64 `json:"mix_odd_dscnt" db:"mix_odd_dscnt" name:"mix_odd_dscnt" rule:"none"`                                                                              //复合玩法返还率
	MixMchPrizeLimit        int     `json:"mix_mch_prize_limit" db:"mix_mch_prize_limit" rule:"none" msg:"mix_mch_prize_limit error"`                                                       //复合玩法赛事赔付
	MchsCompPrizeTotalLimit int     `json:"mchs_comp_prize_total_limit" db:"mchs_comp_prize_total_limit" rule:"none"`                                                                       //普通串关最高赛事赔付
	IsOpenMatch             int     `json:"is_open_match" rule:"digit" default:"1" db:"is_open_match"`                                                                                      //是否显示赛事 1-是 0-否
	IsOpenVideo             int     `json:"is_open_video" rule:"digit" default:"1" db:"is_open_video"`                                                                                      //是否显示视频 1-是 0-否
}

// Match 赛事结构体
type MatchData struct {
	ID                      string        `json:"id" db:"id"`                                                   //赛事id
	SID                     string        `json:"sid" db:"sid"`                                                 //体育赛事ID(标准赛事ID)
	DataSource              string        `json:"data_src" db:"data_src"`                                       //数据源: (1.默认为空, 2.TY)
	Mode                    int           `json:"mode" db:"mode"`                                               //操盘模式:0-手动操盘,1-MTS
	GameID                  string        `json:"game_id" db:"game_id"`                                         //游戏ID
	CreateByName            string        `json:"create_by_name" db:"create_by_name"`                           //创建人名称
	UpdateByName            string        `json:"update_by_name" db:"update_by_name"`                           //修改人名称
	CreateTime              int64         `json:"create_time" db:"create_time"`                                 //创建时间
	UpdateTime              int64         `json:"update_time" db:"update_time"`                                 //修改时间
	StartTime               int64         `json:"start_time" db:"start_time"`                                   //开始时间
	CloseTime               int64         `json:"close_time" db:"close_time"  `                                 //赛事关闭时间
	EndTime                 int64         `json:"end_time" db:"end_time"`                                       //结束时间
	BetDelayTime            int64         `json:"bet_delay_time" db:"bet_delay_time"`                           //注单确认时间
	TeamID                  string        `json:"team_id" db:"team_id"`                                         //战队id
	MatchTeam               string        `json:"match_team" db:"match_team"`                                   //战队信息
	MatchCnTeam             string        `json:"match_cn_team" db:"match_cn_team"`                             //战队中文名
	MatchEnTeam             string        `json:"match_en_team" db:"match_en_team"`                             //战队英文名
	TournamentShortName     string        `json:"tournament_short_name" db:"tournament_short_name"`             //联赛简称
	TournamentCnName        string        `json:"tournament_cn_name" db:"tournament_cn_name"`                   //联赛中文名
	UserVideoUrl            string        `json:"user_video_url" db:"user_video_url"`                           //直播源地址
	AdminVideoUrl           string        `json:"admin_video_url" db:"admin_video_url"`                         //操盘直播源
	Title                   string        `json:"title" db:"title"`                                             //标题
	TournamentID            string        `json:"tournament_id" db:"tournament_id"`                             //联赛ID
	Score                   string        `json:"score" db:"score"`                                             //赛事比分
	Category                int           `json:"category" db:"category"`                                       //赛事类型 正常-1 冠军-2 大逃杀-3 篮球-4 主播盘-5 足球-6
	Bo                      int           `json:"bo" db:"bo"`                                                   //赛制 无:-1 BO0:0 B01:1 B02:2 B03:3
	MatchLevel              int           `json:"match_level" db:"match_level"`                                 //赛事等级 1-M1 2-M2 3-M3 4-M4 ... 9999 M9999
	CreditLevel             int           `json:"credit_level" db:"credit_level"`                               //信用联赛等级
	Visible                 int           `json:"visible" db:"visible"`                                         //是否显示  1-显示 0-隐藏
	Suspended               int           `json:"suspended" db:"suspended"`                                     //是否暂停  1-暂停 0-非暂停
	LiveSupport             int           `json:"live_support" db:"live_support"`                               //是否滚球 1-是 0-否
	IsPassOff               int           `json:"is_pass_off" db:"is_pass_off"`                                 //是否串关 0-否 1-普通串关 2-局内串关
	Status                  int           `json:"status" db:"status"`                                           //待录入-1 待审核-2 已驳回-3 待开盘-4 已开盘-5 已关盘-6 已结算-7 待取消-8 比赛取消-9
	IsLive                  int           `json:"is_live" db:"is_live"`                                         //赛事阶段 1-初盘 2-滚盘
	Rec                     int           `json:"rec" db:"rec"`                                                 //推荐序号
	RndCompPrizeLimit       int           `json:"rnd_comp_prize_limit" db:"rnd_comp_prize_limit"`               //单局串关单注赔付
	RndCompMchPrizeLimit    int           `json:"rnd_comp_mch_prize_limit" db:"rnd_comp_mch_prize_limit"`       //单局串关赛事赔付
	RndCompOddDscnt         float64       `json:"rnd_comp_odd_dscnt" db:"rnd_comp_odd_dscnt"`                   //局内串关返还率
	MbMchPrizeLimit         int           `json:"mb_mch_prize_limit" db:"mb_mch_prize_limit"`                   //会员赛事赔付
	RateLimit               int           `json:"rate_limit" db:"rate_limit"`                                   //限红比例
	RateReduce              float64       `json:"rate_reduce" db:"rate_reduce"`                                 //返还率缩减
	IsCollect               int           `json:"is_collect"`                                                   //赛事是否收藏
	VideoType               int           `json:"video_type" db:"video_type"`                                   //视频类型1-国内直播源 2-转播直播源
	VideoLabel              int           `json:"video_label" db:"video_label"`                                 //视频标签1.虎牙 2.斗鱼3.腾讯
	IsMatchNotes            int           `json:"is_match_notes" db:"-" `                                       //是否拥有赛事注意事项
	MixOddDscnt             float64       `json:"mix_odd_dscnt" db:"mix_odd_dscnt"`                             //复合玩法返还率
	DefaultMarket           DefaultMarket `json:"default_market" db:"-" `                                       //默认盘口列表
	MixMchPrizeLimit        int           `json:"mix_mch_prize_limit" db:"mix_mch_prize_limit"`                 //复合玩法赛事赔付
	OddRangeStatus          int           `json:"odd_range_status" db:"-"`                                      //是否启用特殊抽水 1-启用 0-禁用
	MchsCompPrizeTotalLimit int           `json:"mchs_comp_prize_total_limit" db:"mchs_comp_prize_total_limit"` //普通串关最高赛事赔付
	MatchCompUsedLimit      string        `json:"match_comp_used_limit" db:"-"`                                 //普通串关最高赛事赔付累计值
}

// 首页默认盘口
type DefaultMarket struct {
	Markets   []DefaultMarketData `json:"markets" db:"markets"`       // 盘口玩法类型信息
	DefaultID string              `json:"default_id" db:"default_id"` // 默认盘口id
}

type DefaultMarketData struct {
	ID         string `json:"id" db:"id"`                   // 盘口id
	Name       string `json:"name" db:"name"`               // 盘口名称
	OptionType int8   `json:"option_type" db:"option_type"` // 玩法类型 1-输赢 2-让分 3-大小 4趣味 5-波胆 6-胜负平 7-单双 8-是否 12-复合
}

//赛事等级设置
type MatchLevel struct {
	ID                         int     `json:"id" db:"id"`                                                                                                                                   // 主键id
	Level                      int     `json:"level" db:"level"`                                                                                                                             // 等级
	CreditLevel                int     `json:"credit_level" db:"credit_level"`                                                                                                               // 信用联赛等级
	PrizeLimit                 int     `json:"prize_limit" db:"prize_limit"`                                                                                                                 // 单注赔付默认值
	MaxPrizeLimit              int     `json:"max_prize_limit" db:"max_prize_limit"`                                                                                                         // 单注赔付最大值
	MbMktPrizeLimit            int     `json:"mb_mkt_prize_limit" db:"mb_mkt_prize_limit"`                                                                                                   // 会员盘口赔付默认值
	MaxMbMktPrizeLimit         int     `json:"max_mb_mkt_prize_limit" db:"max_mb_mkt_prize_limit"`                                                                                           // 会员盘口赔付最大值
	WarningProfit              int     `json:"warning_profit" db:"warning_profit"`                                                                                                           // 预警值
	MaxWarningProfit           int     `json:"max_warning_profit" db:"max_warning_profit"`                                                                                                   // 预警值最大值
	StopProfit                 int     `json:"stop_profit" db:"stop_profit"`                                                                                                                 // 停盘值
	MaxStopProfit              int     `json:"max_stop_profit" db:"max_stop_profit"`                                                                                                         // 停盘值最大值
	MbMchPrizeLimit            int     `json:"mb_mch_prize_limit" db:"mb_mch_prize_limit"`                                                                                                   // 会员赛事赔付
	ReturnRate                 float64 `json:"return_rate" db:"return_rate"`                                                                                                                 // 返还率
	RndCompPrizeLimit          int     `json:"rnd_comp_prize_limit" db:"rnd_comp_prize_limit"`                                                                                               // 单局串关单注赔付
	RndCompMchPrizeLimit       int     `json:"rnd_comp_mch_prize_limit" db:"rnd_comp_mch_prize_limit"`                                                                                       // 单局串关赛事赔付
	RndCompOddDscnt            float64 `json:"rnd_comp_odd_dscnt" db:"rnd_comp_odd_dscnt"`                                                                                                   // 局内串关返还率
	PrizeStaticProfit          int     `json:"prize_static_profit" db:"prize_static_profit"`                                                                                                 // 单注限红默认值
	MaxPrizeStaticProfit       int     `json:"max_prize_static_profit" db:"max_prize_static_profit"`                                                                                         // 单注限红最大值
	MbMchMaxPrizeLimit         int     `json:"mb_mch_max_prize_limit" db:"mb_mch_max_prize_limit"`                                                                                           // 会员赛事最大赔付
	RndCompMaxPrizeLimit       int     `json:"rnd_comp_max_prize_limit" db:"rnd_comp_max_prize_limit"`                                                                                       // 单局串关单注最大赔付
	RndCompMchMaxPrizeLimit    int     `json:"rnd_comp_mch_max_prize_limit" db:"rnd_comp_mch_max_prize_limit"`                                                                               // 单局串关赛事最大赔付
	Status                     int     `json:"status" db:"status"`                                                                                                                           // 启用状态(0-关闭, 1-开启)
	OpTime                     int64   `json:"op_time" db:"op_time"`                                                                                                                         // 操作时间
	OpById                     int     `json:"op_by_id" db:"op_by_id"`                                                                                                                       // 操作人员id
	OpByName                   string  `json:"op_by_name" db:"op_by_name"`                                                                                                                   // 操作人员名称
	MchsCompPrizeLimit         int     `json:"mchs_comp_prize_limit" db:"mchs_comp_prize_limit" `                                                                                            // 普通串关单注赔付默认值
	MchsCompMaxPrizeLimit      int     `json:"mchs_comp_max_prize_limit" db:"mchs_comp_max_prize_limit"`                                                                                     // 普通串关单注赔付最大值
	LevelRemark                string  `json:"level_remark" db:"level_remark"`                                                                                                               // 赛事等级备注
	SortCode                   int     `json:"sort_code" db:"sort_code"`                                                                                                                     // 排序码(序号)
	MixStopProfit              int     `db:"mix_stop_profit" json:"mix_stop_profit" rule:"digit" min:"1" msg:"mix_stop_profit error" name:"mix_stop_profit"`                                 // 复合玩法停盘值
	MixMaxStopProfit           int     `db:"mix_max_stop_profit" json:"mix_max_stop_profit" rule:"digit" min:"1" msg:"mix_max_stop_profit error" name:"mix_max_stop_profit"`                 // 复合玩法停盘最大值
	MixWarningProfit           int     `db:"mix_warning_profit" json:"mix_warning_profit" rule:"digit" min:"1" msg:"mix_warning_profit error" name:"mix_warning_profit"`                     // 复合玩法预警值
	MixMaxWarningProfit        int     `db:"mix_max_warning_profit" json:"mix_max_warning_profit" rule:"digit" min:"1" msg:"mix_max_warning_profit error" name:"mix_max_warning_profit"`     // 复合玩法预警最大值
	MixPrizeLimit              int     `db:"mix_prize_limit" json:"mix_prize_limit" rule:"digit" min:"1" msg:"mix_prize_limit error" name:"mix_prize_limit"`                                 // 复合玩法单注赔付
	MixMaxPrizeLimit           int     `db:"mix_max_prize_limit" json:"mix_max_prize_limit" rule:"digit" min:"1" msg:"mix_max_prize_limit error" name:"mix_max_prize_limit"`                 // 复合玩法单注赔付最大值
	MixMchPrizeLimit           int     `db:"mix_mch_prize_limit" json:"mix_mch_prize_limit" rule:"digit" min:"1" msg:"mix_mch_prize_limit error" name:"mix_mch_prize_limit"`                 // 复合玩法赛事赔付
	MixMaxMchPrizeLimit        int     `db:"mix_mch_max_prize_limit" json:"mix_mch_max_prize_limit" rule:"digit" min:"1" msg:"mix_mch_max_prize_limit error" name:"mix_mch_max_prize_limit"` // 复合玩法赛事赔付最大值
	MixOddDscnt                float64 `db:"mix_odd_dscnt" json:"mix_odd_dscnt" rule:"amount" min:"1" max:"100" msg:"mix_odd_dscnt error" name:"mix_odd_dscnt"`                              // 复合玩法返还率
	MchsCompPrizeTotalLimit    int     `db:"mchs_comp_prize_total_limit" json:"mchs_comp_prize_total_limit"`                                                                                 // 普通串关最高赛事赔付
	MchsCompPrizeMaxTotalLimit int     `db:"mchs_comp_prize_max_total_limit" json:"mchs_comp_prize_max_total_limit"`                                                                         // 普通串关最高赛事赔付最大值
}

// 游戏-风险标签
type GameRiskTag struct {
	ID        string `db:"id" json:"id"`                   //id
	RiskTagID string `db:"risk_tag_id" json:"risk_tag_id"` //风险标签ID
}

// 赛事-游戏-风险标签
type MatchRiskTag struct {
	ID           string `json:"id" db:"id"`                         //赛事id
	MatchID      string `json:"match_id" db:"match_id"`             //赛事ID
	GameID       string `json:"game_id" db:"game_id"`               //游戏ID
	RiskTagID    string `json:"risk_tag_id" db:"risk_tag_id"`       //风险标签ID
	CreateTime   int64  `json:"create_time" db:"create_time"`       //创建时间
	CreateByID   uint64 `json:"create_by_id" db:"create_by_id"`     //创建人ID
	CreateByName string `json:"create_by_name" db:"create_by_name"` //创建人名称
}

type MatchTeams struct {
	TeamID     string `json:"team_id"`      //战队id
	TeamEnName string `json:"team_en_name"` //战队英文名称
	TeamCnName string `json:"team_cn_name"` //战队中文名称
	SortID     int    `json:"sort_id" `     //排序码
}

// 赛事比分结构体
type MatchScore struct {
	CreateByID   uint64 `db:"create_by_id" rule:"none" json:"create_by_id" name:"create_by_id"`                  //创建人ID
	CreateTime   int64  `db:"create_time" rule:"none" json:"create_time" name:"create_time"`                     //创建时间
	ID           string `db:"id" rule:"none" json:"id" name:"id"`                                                //主键id
	MatchID      string `db:"match_id" rule:"digit" json:"match_id" name:"match_id"`                             //赛事ID
	MatchTeam    string `db:"match_team" rule:"none" json:"match_team" name:"match_team"`                        //战队信息
	WinnerTeam   string `db:"winner_team" rule:"none" json:"winner_team" name:"winner_team"`                     //获胜战队
	CreateByName string `db:"create_by_name" rule:"none" json:"create_by_name" name:"create_by_name"`            //创建人名称
	Score        string `db:"score" rule:"none" msg:"score error" json:"score" name:"score"`                     //比分
	Round        int    `db:"round" rule:"digit" min:"1" msg:"round error" json:"round" name:"round"`            //所属局数
	Result       int    `db:"result" rule:"none" min:"0" max:"1" msg:"result error" json:"result" name:"result"` //是否有赛果 0-无  1-有
}

type TYMatchPostParam struct {
	ReqSize int `json:"cps"`  // 请求赛事个数(cps)
	Type    int `json:"type"` // 筛选类型(type): 1-滚球,2-即将开赛,3-今日赛事,4-早盘,11-串关
}

type TYVideoPostParam struct {
	MatchID string `json:"mid"`    // 赛事ID
	Type    string `json:"type"`   //视频类型: Animation,Video
	Device  string `json:"device"` //设备类型: PC,H5
}

type BetOrderMarketUnsettle struct {
	MarketID string `db:"market_id" json:"market_id"`
}

/*
 * @Description: 赛事信息-插入
 * @Author: robin
 * @Date: 2021/11/27 17:54
 * @LastEditTime: 2021/11/27 17:54
 * @LastEditors: robin
 */
func MatchInsert(match Match, riskTagIds string) error {

	// 更新数据库
	dbConn, err := zkDB.Begin()
	if err != nil {
		return err
	}

	query, _, _ := dialect.Insert(TblMatches).Rows(match).ToSQL()
	fmt.Println(query)

	_, err = dbConn.Exec(query)
	if err != nil {
		_ = dbConn.Rollback()
		return err
	}

	// 更新缓存
	mchIndex := utils.GameIndex{
		Bo:                   match.Bo,
		Category:             match.Category,
		GameID:               match.GameID,
		ID:                   match.ID,
		SID:                  match.SID,
		IsLive:               match.IsLive,
		IsPassOff:            match.IsPassOff,
		LiveSupport:          match.LiveSupport,
		MatchLevel:           match.MatchLevel,
		CreditLevel:          match.CreditLevel,
		MatchTeam:            match.MatchTeam,
		MatchCnTeam:          match.MatchCnTeam,
		MatchEnTeam:          match.MatchEnTeam,
		Rec:                  match.Rec,
		Score:                match.Score,
		StartTime:            match.StartTime,
		CloseTime:            match.CloseTime, // 冠军盘隐藏时间
		EndTime:              match.EndTime,
		BetDelayTime:         match.BetDelayTime,
		Status:               match.Status,
		Suspended:            match.Suspended,
		TeamID:               match.TeamID,
		TournamentID:         match.TournamentID,
		TournamentShortName:  match.TournamentShortName,
		TournamentCnName:     match.TournamentCnName,
		UserVideoURL:         match.UserVideoUrl,
		AdminVideoURL:        match.AdminVideoUrl,
		VideoType:            match.VideoType,
		VideoLabel:           match.VideoLabel,
		Visible:              match.Visible,
		RndCompPrizeLimit:    match.RndCompPrizeLimit,
		RndCompMchPrizeLimit: match.RndCompMchPrizeLimit,
		RndCompOddDscnt:      match.RndCompOddDscnt,
		MbMchPrizeLimit:      match.MbMchPrizeLimit,
		MixOddDscnt:          match.MixOddDscnt,
		MixMchPrizeLimit:     match.MixMchPrizeLimit,
		Count:                0,
		DefaultMarket:        nil,
		MktIDs:               map[string][]string{},
		IsOpenMatch:          match.IsOpenMatch,
		IsOpenVideo:          match.IsOpenVideo,
	}
	node := utils.MatchBrief{
		ID:          match.ID,
		Category:    match.Category,
		GameID:      match.GameID,
		StartTime:   match.StartTime,
		Status:      match.Status,
		Visible:     match.Visible,
		LiveSupport: match.LiveSupport,
		IsPassOff:   match.IsPassOff,
		IsLive:      match.IsLive,
		IsOpenMatch: match.IsOpenMatch,
		IsOpenVideo: match.IsOpenVideo,
	}

	data, err := helper.JsonMarshal(mchIndex)
	if err != nil {
		_ = dbConn.Rollback()
		return err
	}

	pipe := zkRedis.GetClusterClient().TxPipeline()
	defer pipe.Close()

	pipe.HSet("sidUponMatchId", match.SID, match.ID) // 哈希存储 体育赛事SID,赛事ID
	utils.MatchCacheSet(zkRedis.GetClusterClient(), match.ID, utils.JPathRoot, data)
	utils.MatchZSetUpdate(pipe, node)
	utils.MatchRiskTagIdSet(pipe, match.ID, riskTagIds)
	_, err = pipe.Exec()
	if err != nil {
		_ = dbConn.Rollback()
		return err
	}

	return dbConn.Commit()
}

/*
 * @Description: 赛事更新
 * @Author: robin
 * @Date: 2021/12/19 16:52
 * @LastEditTime: 2021/12/19 16:52
 * @LastEditors: robin
 */
func MatchUpdate(record g.Record, ex g.Ex, nodes []utils.MatchBrief) error {

	// 更新数据库
	tx, err := zkDB.Begin()
	if err != nil {
		return err
	}
	query, _, _ := dialect.Update(TblMatches).Set(record).Where(ex).ToSQL()
	fmt.Println(query)
	_, err = tx.Exec(query)
	if err != nil {
		_ = tx.Rollback()
		return err
	}

	// 更新赛事缓存
	pipe := zkRedis.GetClusterClient().TxPipeline()
	defer pipe.Close()

	MatchCacheUpdate(record, ex)
	for _, node := range nodes {
		utils.MatchZSetUpdate(pipe, node)
	}

	_, err = pipe.Exec()
	if err != nil {
		_ = tx.Rollback()
		return err
	}

	return tx.Commit()
}

/*
 * @Description: 赛事信息-查找
 * @Author: robin
 * @Date: 2021/11/29 18:37
 * @LastEditTime: 2021/11/29 18:37
 * @LastEditors: robin
 */
func MatchFindOne(ex g.Ex) (MatchData, error) {

	data := MatchData{}
	query, _, _ := dialect.From(TblMatches).Where(ex).Select(colMatchData...).Limit(1).ToSQL()
	err := zkDB.Get(&data, query)
	if err == sql.ErrNoRows {
		return data, nil
	}

	return data, err
}

/**
 * @Description: 更新赛事缓存字段
 * @Author: maxic
 * @Date: 2020/8/15
 * @LastEditTime: 2020/8/15
 * @LastEditors: maxic
 **/
func MatchCacheUpdate(record g.Record, ex g.Ex) {

	cacheFields := map[string]bool{
		"is_live":                     true,
		"is_pass_off":                 true,
		"live_support":                true,
		"match_level":                 true,
		"match_team":                  true,
		"rec":                         true,
		"score":                       true,
		"start_time":                  true,
		"close_time":                  true,
		"end_time":                    true,
		"bet_delay_time":              true,
		"status":                      true,
		"suspended":                   true,
		"team_id":                     true,
		"tournament_id":               true,
		"tournament_short_name":       true,
		"tournament_cn_name":          true,
		"user_video_url":              true,
		"admin_video_url":             true,
		"video_type":                  true,
		"video_label":                 true,
		"visible":                     true,
		"rnd_comp_prize_limit":        true,
		"rnd_comp_mch_prize_limit":    true,
		"rnd_comp_odd_dscnt":          true,
		"mb_mch_prize_limit":          true,
		"match_cn_team":               true,
		"match_en_team":               true,
		"credit_level":                true,
		"mix_odd_dscnt":               true,
		"mix_mch_prize_limit":         true,
		"mchs_comp_prize_total_limit": true,
	}

	fn := func(id string) {
		for k, v := range record {
			if cacheFields[k] {
				path := fmt.Sprintf(utils.JPathField, k)
				utils.MatchCacheSet(zkRedis.GetClusterClient(), id, path, v)
			}
		}
	}
	if id, ok := ex["id"]; ok {
		switch id.(type) {
		case string:
			fn(id.(string))
		case []string:
			for _, v := range id.([]string) {
				fn(v)
			}
		}
	}
}

/*
 * @Description:
 * @Author: robin
 * @Date: 2021/11/29 19:22
 * @LastEditTime: 2021/11/29 19:22
 * @LastEditors: robin
 */
func MatchLevelList(ex g.Ex) ([]MatchLevel, error) {

	var data []MatchLevel
	query, _, _ := dialect.From(TblMatchLevel).Select(colMatchLevel...).Where(ex).ToSQL()
	err := zkDB.Select(&data, query)
	if err == sql.ErrNoRows {
		return data, nil
	}

	return data, err
}

/*
 * @Description:
 * @Author: robin
 * @Date: 2021/11/29 19:22
 * @LastEditTime: 2021/11/29 19:22
 * @LastEditors: robin
 */
func GameRiskTagFindAll(ex g.Ex) ([]GameRiskTag, error) {

	var data []GameRiskTag
	query, _, _ := dialect.From(TblGameRiskTags).Select("id", "risk_tag_id").Where(ex).ToSQL()
	err := zkDB.Select(&data, query)

	return data, err
}

/*
 * @Description: 赛事游戏风险标签-插入
 * @Author: robin
 * @Date: 2021/11/29 19:25
 * @LastEditTime: 2021/11/29 19:25
 * @LastEditors: robin
 */
func MatchRiskTagInsert(data []MatchRiskTag) error {

	if len(data) == 0 {
		return nil
	}

	// 开启事务
	dbConn, err := zkDB.Begin()
	if err != nil {
		return err
	}

	// 写入数据库
	query, _, _ := dialect.Insert(TblMatchRiskTags).Rows(data).ToSQL()
	fmt.Println(query)
	_, err = dbConn.Exec(query)
	if err != nil {
		_ = dbConn.Rollback()
		return err
	}

	return dbConn.Commit()
}

/*
 * @Description:赛事游戏风险标签-查询
 * @Author: robin
 * @Date: 2021/11/14 17:56
 * @LastEditTime: 2021/11/14 17:56
 * @LastEditors: robin
 */
func MatchRiskTagFindAll(ex g.Ex) ([]string, error) {

	var data []string
	query, _, _ := dialect.Select("risk_tag_id").From(TblMatchRiskTags).Where(ex).ToSQL()
	fmt.Println(query)
	err := zkDB.Select(&data, query)
	if err == sql.ErrNoRows {
		return data, nil
	}

	return data, err
}

/*
 * @Description: 游戏导航赛事数，今日 滚球 赛前 串关 赛果计数
 * @Author: robin
 * @Date: 2021/12/14 13:07
 * @LastEditTime: 2021/12/14 13:07
 * @LastEditors: robin
 */
func MatchGameNavCountStat(gameId string) error {

	// 从redis中获取所有商户过滤的游戏
	filterGameMap, err := utils.GetMerchantFilterGameMap(zkRedis.GetClusterClient())
	if err != nil {
		return err
	}

	// 首先统计没有过滤游戏的商户
	dataAll := utils.MatchCountStatData{}
	dataAll.MerchantId = 0
	dataAll.GameId = gameId
	dataAll.Stats, err = utils.GameNavMatchCountStat(zkRedis.GetClusterClient(), gameId)
	if err != nil {
		return err
	}
	dataAll.StatsAll, err = utils.GameNavMatchCountGet(zkRedis.GetClusterClient(), nil, set.NewStringSet())
	if err != nil {
		return err
	}

	var result []utils.MatchCountStatData
	result = append(result, dataAll)

	// 最后统计有游戏过滤的商户
	for merchantID, gameIdSet := range filterGameMap {
		data := utils.MatchCountStatData{}
		data.MerchantId = merchantID
		data.GameId = gameId

		// 判断游戏是否被过滤
		// 如果被过滤，数量都是0
		// 如果没有被过滤，数量和dataAll.Stats一样
		if !gameIdSet.Has(gameId) {
			data.Stats = dataAll.Stats
		}

		ids := set.NewStringSet()
		list, err := zkRedis.GetClusterClient().SMembers(fmt.Sprintf(utils.RedisMerchantFilterGame, merchantID)).Result()
		if err != nil {
			return err
		}

		for _, id := range list {
			ids.Add(id)
		}
		// 统计商户总数量
		data.StatsAll, err = utils.GameNavMatchCountGet(zkRedis.GetClusterClient(), nil, ids)
		if err != nil {
			return err
		}

		result = append(result, data)
	}

	mqtt.MqttNotifyMatchStatUpdate(result)

	return nil
}

/*
 * @Description: 更新游戏联赛缓存
 * @Author: robin
 * @Date: 2021/12/14 13:26
 * @LastEditTime: 2021/12/14 13:26
 * @LastEditors: robin
 */
func GameTourCacheUpdate(gameId, tourId, matchId string, startTime int64, flag bool) error {

	pipe := zkRedis.GetClusterClient().TxPipeline()
	defer pipe.Close()

	if flag {
		count, err := MarketCount(g.Ex{"match_id": matchId, "visible": VisibleOpen})
		if err != nil {
			return err
		}

		if count == 0 {
			return nil
		}

		utils.GameTourCacheSet(pipe, gameId, tourId, matchId, startTime, false)
	} else {
		utils.GameTourCacheDel(pipe, gameId, tourId, matchId, false)
	}

	_, err := pipe.Exec()
	if err != nil {
		return err
	}

	tours, err := utils.GameTourCacheGet(zkRedis.GetClusterClient(), gameId, tourId, set.NewStringSet())
	if err != nil {
		return err
	}

	// 获取过滤当前游戏的商户
	filterList := []uint64{}
	filterGameMap, err := utils.GetMerchantFilterGameMap(zkRedis.GetClusterClient())
	if err != nil {
		return err
	}
	for merchantId, gameSet := range filterGameMap {
		if gameSet.Has(gameId) {
			filterList = append(filterList, merchantId)
		}
	}
	mqtt.MqttNotifyGameTourUpdate(gameId, tours, filterList)

	return nil
}

/*
 * @Description: 判断赛事的操盘状态-缓存Key是否存在
 * @Author: robin
 * @Date: 2022/3/6 16:47
 * @LastEditTime: 2022/3/6 16:47
 * @LastEditors: robin
 */
func GetMatchTradeStatus(sid string) bool {

	_, err := zkRedis.GetClusterClient().HGet(redis_helper.RedisSidMatchTrade, sid).Result()
	if err != nil {
		return false
	}

	return true
}

/*
 * @Description: 删除赛事的操盘缓存Key
 * @Author: robin
 * @Date: 2022/3/6 19:03
 * @LastEditTime: 2022/3/6 19:03
 * @LastEditors: robin
 */
func delMatchTradeKey(sid string) {
	_, err := zkRedis.GetClusterClient().HGet(redis_helper.RedisSidMatchTrade, sid).Result()
	if err != nil {
		return
	}

	zkRedis.GetClusterClient().HDel(redis_helper.RedisSidMatchTrade, sid)
	return
}

/**
* @Description: 获取赛事ID
* @Author: noah
* @Date: 2021/12/17 14:49
* @LastEditTime:2021/12/17 14:49
* @LastEditors: noah
 */
func getMatchId(sid string) string {

	result, err := zkRedis.GetClusterClient().HGet(redis_helper.RedisSidUponMatchId, sid).Result()
	if err != nil {
		return ""
	}

	return result
}

/*
 * @Description: 更新赛事状态(赛事结束),更新游戏客户端计数(滚盘,早盘等)
 * @Author: robin
 * @Date: 2021/12/16 12:15
 * @LastEditTime: 2021/12/16 12:15
 * @LastEditors: robin
 */
func UpdateGameNav(match utils.MatchData, matchStatus, matchVisible int) error {

	var (
		mkCount    int64
		settledCnt int64
		err        error
	)

	intTime := time.Now().Unix()
	if matchStatus == MatchStatusOpened { // 赛事开启
		mkCount, err = MarketCount(g.Ex{"visible": VisibleOpen, "match_id": match.ID})
		if err != nil {
			fmt.Printf("【新增盘口-赛事ID:%s,SID:%s】MarketCount,获取赛事盘口数,Error:%s \n", match.ID, match.SID, err.Error())
			return err
		}

		if mkCount == 0 { // 赛事开启
			return nil
		}

		intTime = 0
	}

	// 更新数据
	record := g.Record{
		"update_by_name": "TY",
		"update_time":    time.Now().Unix(),
		"close_time":     intTime,
		"status":         matchStatus,
		"visible":        matchVisible,
		"is_live":        match.IsLive,
	}
	nodes := []utils.MatchBrief{{
		ID:          match.ID,
		Category:    match.Category,
		GameID:      match.GameID,
		StartTime:   match.StartTime,
		Status:      matchStatus,
		Visible:     matchVisible,
		LiveSupport: match.LiveSupport,
		IsPassOff:   match.IsPassOff,
		IsLive:      match.IsLive,
		MktCount:    mkCount,
	}}

	if matchStatus == MatchStatusClosed { // 赛事关闭:更新(已开盘)盘口为已关盘
		markets, err := MarketListDB(g.Ex{"status": []int{MarketStatusOpen}, "match_id": match.ID})
		record := g.Record{
			"status":         MarketStatusClose,
			"visible":        VisibleClose,
			"update_by_name": "TY",
			"update_time":    time.Now().Unix(),
		}

		var ids []string
		if len(markets) > 0 {
			for _, m := range markets {
				ids = append(ids, m.ID)
			}
			err = MarketUpdate(match.ID, record, g.Ex{"id": ids})
			if err != nil {
				fmt.Printf("【赛事结束-赛事ID:%s,SID:%s】MarketCount,更新(已开盘)盘口为已关盘,Error:%s\n", match.ID, match.SID, err.Error())
				return err
			}
		}

		settledCnt, err = MarketCount(g.Ex{"match_id": match.ID, "visible": 1, "status": MarketStatusSettled})
		if err != nil {
			fmt.Printf("【赛事结束-赛事ID:%s,SID:%s】MarketCount,获取赛事结算盘口数,Error:%s\n", match.ID, match.SID, err.Error())
			return err
		}

		record["visible"] = match.Visible
		nodes[0].SettledMktCount = settledCnt

		for _, mkt := range markets {
			mktLog := utils.TDMarket{
				TS:                  "now",
				User:                "TY",
				Group:               "0",
				IP:                  "0",
				Menu:                "请求接口",
				Action:              "关闭盘口",
				GameID:              match.GameID,
				GameShortName:       GameName[match.GameID],
				TournamentId:        match.TournamentID,
				TournamentShortName: match.TournamentShortName,
				Teams:               match.MatchCnTeam,
				MatchID:             match.ID,
				MarketID:            mkt.ID,
				MarketEnName:        mkt.CnName,
				Round:               mkt.Round,
				Result:              "【备注】:赛事结束,状态:隐藏",
				Category:            int8(match.Category),
			}

			mqtt.MqttNotifyMarketLogPub(mktLog)
		}
	}

	err = MatchUpdate(record, g.Ex{"id": match.ID}, nodes)
	if err != nil {
		fmt.Printf("【%s-赛事ID:%s,SID:%s】MatchUpdate,赛事更新错误,Error:%s\n", MatchOperateDesc[matchStatus], match.ID, match.SID, err.Error())
		return err
	}

	// 更新游戏客户端-前端赛事盘口数
	err = MarketCountUpdate(match.ID, int(mkCount))
	if err != nil {
		fmt.Printf("【%s-赛事ID:%s,SID:%s】MarketCountUpdate,更新游戏客户端-前端赛事盘口数,Error: %s \n", MatchOperateDesc[matchStatus], match.ID, match.SID, err.Error())
		return err
	}

	//推送赛事状态变更
	if matchStatus == MatchStatusClosed {
		mqtt.MqttNotifyMatchStatusUpdate([]string{match.ID}, matchStatus)
		mqtt.MqttNotifyMatchVisibleUpdate([]string{match.ID}, matchVisible)
	}

	// 开启/关闭赛事时 更新游戏赛事计数
	err = MatchGameNavCountStat(match.GameID)
	if err != nil {
		fmt.Printf("【%s-赛事ID:%s,SID:%s】MatchGameNavCountStat 开启/关闭赛事时 更新游戏赛事计数错误, Error: %s\n ", MatchOperateDesc[matchStatus], match.ID, match.SID, err.Error())
		return err
	}

	//(赛事结束|新增盘口)更新联赛缓存
	err = GameTourCacheUpdate(match.GameID, match.TournamentID, match.ID, match.StartTime, matchStatus == MatchStatusOpened)
	if err != nil {
		fmt.Printf("【%s-赛事ID:%s,SID:%s】GameTourCacheUpdate 游戏客户端更新联赛缓存错误, Error: %s\n ", MatchOperateDesc[matchStatus], match.ID, match.SID, err.Error())
		return err
	}

	if matchStatus == MatchStatusClosed { //赛事结束
		matchLog := utils.TDMatch{
			TS:                  "now",
			User:                "TY",
			Group:               "0",
			IP:                  "0",
			Menu:                "接口请求",
			Action:              "赛事结束",
			GameID:              match.GameID,
			GameShortName:       GameName[match.GameID],
			TournamentId:        match.TournamentID,
			TournamentShortName: TournamentGetName(match.TournamentID),
			Teams:               match.MatchCnTeam,
			MatchID:             match.ID,
			Result:              fmt.Sprintf("【赛事显示/隐藏】:%s", VisibleStatus[matchVisible]),
		}
		mqtt.MqttNotifyMatchLogPub(matchLog)
	} else { //赛事-新增盘口
		matchLog := utils.TDMatch{
			TS:                  "now",
			User:                "TY",
			Group:               "0",
			IP:                  "0",
			Menu:                "接口请求",
			Action:              "新增盘口",
			GameID:              match.GameID,
			GameShortName:       GameName[match.GameID],
			TournamentId:        match.TournamentID,
			TournamentShortName: TournamentGetName(match.TournamentID),
			Teams:               match.MatchCnTeam,
			MatchID:             match.ID,
			Result:              fmt.Sprintf("【赛事显示/隐藏】:%s【显示盘口数量】:%d", VisibleStatus[matchVisible], mkCount),
		}
		mqtt.MqttNotifyMatchLogPub(matchLog)
	}

	return nil
}

/*
 * @Description: 赛事结算
 * @Author: robin
 * @Date: 2021/12/23 13:56
 * @LastEditTime: 2021/12/23 13:56
 * @LastEditors: robin
 */
func UpdateMatchSettle(match utils.MatchData, intUpdateTime int64) (bool, error) {

	// 所有【已关盘】的盘口都结算完成,才能结算赛事结算
	ex := g.Ex{
		"match_id": match.ID,
		"status":   MarketStatusClose,
	}
	markets, err := MarketListDB(ex)
	if err != nil {
		fmt.Printf("【赛事结算-赛事ID:%s,SID:%s】MarketListDB,获取[已关盘]盘口数量错误,Error:%s\n", match.ID, match.SID, err.Error())
		return false, err
	}

	mktCount := int64(len(markets))
	if mktCount > 0 {
		fmt.Printf("【赛事结算-赛事ID:%s,SID:%s】当前赛事存在[已关盘]盘口没有完成结算,无法进行结算赛事.\n", match.ID, match.SID)
		if (time.Now().Unix() - intUpdateTime) < TwoHours { //赛事结束-2小时后, 更新【没有注单的盘口】为取消状态
			return false, nil
		}

		cancelMarketSet := set.NewStringSet()
		for _, m := range markets {
			cancelMarketSet.Add(m.ID)
		}

		if len(cancelMarketSet.List()) == 0 {
			fmt.Printf("【赛事结算-赛事ID:%s,SID:%s】赛事结束-已超过2小时,盘口ID列表为空\n", match.ID, match.SID)
			return false, nil
		}

		fmt.Printf("【赛事结算-赛事ID:%s,SID:%s】赛事结束-已超过2小时,未结算的盘口: %v\n", match.ID, match.SID, cancelMarketSet)
		betOrders, err := BetOrderFindAll(g.Ex{
			"match_id":   match.ID,
			"market_id":  cancelMarketSet.List(),
			"bet_status": []int{BetStatusWaitSettle}, //查询注单(待结算)
			"order_type": 1,                          //普通注单
		})

		if err != nil {
			fmt.Printf("【赛事结算-赛事ID:%s,SID:%s】BetOrderFindAll, Error:%s.\n", match.ID, match.SID, err.Error())
			return false, nil
		}

		if len(betOrders) > 0 { //查询注单(待结算)
			fmt.Printf("【赛事结算-赛事ID:%s,SID:%s】当前赛事[已关盘]盘口存在注单(待结算),不能进行强制取消盘口.\n", match.ID, match.SID)
			return false, nil
		}

		mch, err := MatchFindOne(g.Ex{"id": match.ID})
		if err != nil {
			fmt.Printf("【赛事结算-赛事ID:%s,SID:%s】MatchFindOne, Error:%s\n", match.ID, match.SID, err.Error())
			return false, err
		}

		err = marketCancel(mch, markets, MarketReason101) // 101-无赛果
		if err != nil {
			fmt.Printf("【赛事结算-赛事ID:%s,SID:%s】当前赛事[已关盘]盘口,强制取消盘口, Error:%s\n", match.ID, match.SID, err.Error())
		} else {
			fmt.Printf("【赛事结算-赛事ID:%s,SID:%s】当前赛事[已关盘]盘口,执行强制取消盘口-完毕.\n", match.ID, match.SID)
		}
		return false, err
	}

	mktCount, err = MarketCount(g.Ex{"match_id": match.ID, "status": MarketStatusSettled, "visible": VisibleOpen})
	if err != nil {
		fmt.Printf("【赛事结算-赛事ID:%s,SID:%s】MarketCount,获取可见盘口数量错误,Error:%s\n ", match.ID, match.SID, err.Error())
		return false, err
	}

	if mktCount == 0 {
		fmt.Printf("【赛事结算-赛事ID:%s,SID:%s】当前赛事存在[已结算]且可见的盘口,数量为0.\n ", match.ID, match.SID)
		match.Visible = VisibleClose
	}

	now := time.Now().Unix()
	ex = g.Ex{"id": match.ID, "status": MatchStatusClosed}
	record := g.Record{
		"update_time": now,
		"end_time":    now,
		"status":      match.Status,
		"visible":     match.Visible,
	}

	nodes := []utils.MatchBrief{{
		ID:          match.ID,
		Category:    match.Category,
		GameID:      match.GameID,
		StartTime:   match.StartTime,
		Status:      match.Status,
		Visible:     match.Visible,
		LiveSupport: match.LiveSupport,
		IsPassOff:   match.IsPassOff,
		IsLive:      match.IsLive,
		MktCount:    mktCount,
	}}

	err = MatchUpdate(record, ex, nodes)
	if err != nil {
		fmt.Printf("【赛事结算-赛事ID:%s,SID:%s】MatchUpdate,赛事更新错误,Error:%s\n", match.ID, match.SID, err.Error())
		return false, err
	}

	// 更新游戏客户端-前端赛事盘口数
	err = MarketCountUpdate(match.ID, int(mktCount))
	if err != nil {
		fmt.Printf("【赛事结算-赛事ID:%s,SID:%s】MarketCountUpdate,更新游戏客户端-前端赛事盘口数,Error: %s \n", match.ID, match.SID, err.Error())
		return true, err
	}

	// 赛事完成结算时 更新游戏赛事计数
	err = MatchGameNavCountStat(match.GameID)
	if err != nil {
		fmt.Printf("【赛事结算-赛事ID:%s,SID:%s】MatchGameNavCountStat,更新游戏赛事计数错误,Error:%s\n ", match.ID, match.SID, err.Error())
		return true, err
	}

	err = MatchCacheClear(match.ID, match.SID)
	if err != nil {
		fmt.Printf("【赛事结算-赛事ID:%s,SID:%s】MatchCacheClear,赛事缓存清理错误,Error:%s\n ", match.ID, match.SID, err.Error())
		return true, err
	}

	//推送赛事状态变更
	mqtt.MqttNotifyMatchStatusUpdate([]string{match.ID}, MatchStatusSettle)
	matchLog := utils.TDMatch{
		TS:                  "now",
		User:                "TY",
		Group:               "0",
		IP:                  "0",
		Menu:                "接口请求",
		Action:              "赛事结算",
		GameID:              match.GameID,
		GameShortName:       GameName[match.GameID],
		TournamentId:        match.TournamentID,
		TournamentShortName: TournamentGetName(match.TournamentID),
		Teams:               match.MatchCnTeam,
		MatchID:             match.ID,
		Result:              fmt.Sprintf("【赛事状态】:%s 【已结算且可见-盘口数量】:%d", VisibleStatus[match.Visible], mktCount),
	}
	mqtt.MqttNotifyMatchLogPub(matchLog)

	return true, nil
}

/*
 * @Description: 请求赛事取消(设置盘口为隐藏状态)
 * @Author: robin
 * @Date: 2021/12/24 12:40
 * @LastEditTime: 2021/12/24 12:40
 * @LastEditors: robin
 */
func RequestMatchCancel(match utils.MatchData) error {

	//设置取消赛事的所有盘口为隐藏状态
	markets, err := MarketListDB(g.Ex{"visible": VisibleOpen, "match_id": match.ID, "status": MarketStatusOpen})
	if err != nil {
		fmt.Printf("【赛事取消:%s】盘口列表获取, Error: %s\n ", match.ID, err.Error())
		return err
	}

	record := g.Record{
		"visible":        VisibleClose,
		"update_by_name": "TY",
		"update_time":    time.Now().Unix(),
	}

	var ids []string
	if len(markets) > 0 {
		for _, m := range markets {
			ids = append(ids, m.ID)
		}
		err = MarketUpdate(match.ID, record, g.Ex{"id": ids})
		if err != nil {
			fmt.Printf("【赛事取消:%s】更新所有盘口为隐藏状态,Error:%s\n", match.ID, err.Error())
			return err
		}

		for _, mkt := range markets {
			mktLog := utils.TDMarket{
				TS:                  "now",
				User:                "TY",
				Group:               "0",
				IP:                  "0",
				Menu:                "请求接口",
				Action:              "隐藏盘口",
				GameID:              match.GameID,
				GameShortName:       GameName[match.GameID],
				TournamentId:        match.TournamentID,
				TournamentShortName: match.TournamentShortName,
				Teams:               match.MatchCnTeam,
				MatchID:             match.ID,
				MarketID:            mkt.ID,
				MarketEnName:        mkt.CnName,
				Round:               mkt.Round,
				Result:              "【备注】:赛事取消,盘口状态:隐藏",
				Category:            int8(match.Category),
			}

			mqtt.MqttNotifyMarketLogPub(mktLog)
		}
	}

	// 更新赛事状态
	t := time.Now().Unix()
	record = g.Record{
		"status":         MatchStatusCancel,
		"visible":        VisibleClose,
		"update_by_name": "TY",
		"update_time":    t,
		"end_time":       t,
		"reason":         1,
	}

	node := utils.MatchBrief{
		ID:          match.ID,
		Category:    match.Category,
		GameID:      match.GameID,
		StartTime:   match.StartTime,
		Status:      MatchStatusCancel,
		Visible:     VisibleClose,
		LiveSupport: match.LiveSupport,
		IsPassOff:   match.IsPassOff,
		IsLive:      match.IsLive,
	}

	//取消赛事
	err = matchCancel(record, g.Ex{"id": match.ID}, node)
	if err != nil {
		fmt.Printf("【赛事取消:%s】MatchCancel,赛事取消错误 Error: %s\n ", match.ID, err.Error())
		return err
	}

	// 取消赛事 更新游戏赛事计数
	err = MatchGameNavCountStat(match.GameID)
	if err != nil {
		fmt.Printf("【赛事取消:%s】MatchGameNavCountStat,更新游戏赛事计数错误,Error:%v\n ", match.ID, err.Error())
		return err
	}

	// 取消赛事 更新联赛缓存
	err = GameTourCacheUpdate(match.GameID, match.TournamentID, match.ID, match.StartTime, false)
	if err != nil {
		fmt.Printf("【赛事取消:%s】GameTourCacheUpdate,更新联赛缓存错误,Error:%v\n ", match.ID, err.Error())
		return err
	}

	// 删除赛事相关缓存
	err = MatchCacheClear(match.ID, match.SID)
	if err != nil {
		fmt.Printf("【赛事取消:%s】MatchCacheClear,删除赛事ReJson, Error:%v\n ", match.ID, err.Error())
		return err
	}

	matchLog := utils.TDMatch{
		TS:                  "now",
		User:                "TY",
		Group:               "0",
		IP:                  "0",
		Menu:                "接口请求",
		Action:              "赛事取消",
		GameID:              match.GameID,
		GameShortName:       GameName[match.GameID],
		TournamentId:        match.TournamentID,
		TournamentShortName: TournamentGetName(match.TournamentID),
		Teams:               match.MatchCnTeam,
		MatchID:             match.ID,
		Result:              "",
	}
	mqtt.MqttNotifyMatchLogPub(matchLog)
	// 赛事结算关闭变赔Chan
	if _, ok := autoOddChan[match.ID]; ok {
		close(autoOddChan[match.ID])
	}
	// 赛事结算关闭结算Chan
	if _, ok := autoSettleChan[match.ID]; ok {
		close(autoSettleChan[match.ID])
	}
	// 推送赛事状态变更通知
	mqtt.MqttNotifyMatchStatusUpdate([]string{match.ID}, MatchStatusCancel)
	mqtt.MqttNotifyMatchVisibleUpdate([]string{match.ID}, VisibleClose)

	return nil
}

/*
 * @Description: 盘口取消
 * @Author: robin
 * @Date: 2022/1/4 16:43
 * @LastEditTime: 2022/1/4 16:43
 * @LastEditors: robin
 */
func marketCancel(match MatchData, markets []MarketData, reason int) error {

	if len(markets) == 0 {
		fmt.Printf("【盘口取消:%s】MarketListDB 需要取消盘口数为0.\n ", match.ID)
		return nil
	}

	record := g.Record{
		"update_by_id":   0,
		"update_by_name": "TY",
		"update_time":    time.Now().Unix(),
		"status":         MarketStatusCancelled,
		"settle_count":   1,
		"visible":        VisibleClose,
		"reason":         reason,
	}

	var ids []string
	reasonMap := map[string]int{}
	for _, m := range markets {
		ids = append(ids, m.ID)
		reasonMap[m.ID] = reason
	}
	err := MarketCancel(match.ID, ids, record, 1, reasonMap)
	if err != nil {
		fmt.Printf("【盘口取消:%s】MarketCancel Error:%s.\n ", match.ID, err.Error())
		return err
	}

	for _, mkt := range markets {
		mktLog := utils.TDMarket{
			TS:                  "now",
			User:                "TY",
			Group:               "0",
			IP:                  "0",
			Menu:                "请求接口",
			Action:              "取消盘口",
			GameID:              match.GameID,
			GameShortName:       GameName[match.GameID],
			TournamentId:        match.TournamentID,
			TournamentShortName: match.TournamentShortName,
			Teams:               match.MatchCnTeam,
			MatchID:             match.ID,
			MarketID:            mkt.ID,
			MarketEnName:        mkt.CnName,
			Round:               mkt.Round,
			Result:              fmt.Sprintf("【备注】:%s", MarketCancelReasonDesc[reason]),
			Category:            int8(match.Category),
		}

		mqtt.MqttNotifyMarketLogPub(mktLog)
	}

	return nil
}

/*
 * @Description: 赛事取消
 * @Author: robin
 * @Date: 2021/12/30 12:43
 * @LastEditTime: 2021/12/30 12:43
 * @LastEditors: robin
 */
func matchCancel(record g.Record, ex g.Ex, node utils.MatchBrief) error {

	// 1.更新数据库
	dbConn, err := zkDB.Begin()
	if err != nil {
		return err
	}

	// 取消赛事
	query, _, _ := dialect.Update(TblMatches).Set(record).Where(ex).ToSQL()
	fmt.Println(query)
	_, err = dbConn.Exec(query)
	if err != nil {
		_ = dbConn.Rollback()
		return err
	}

	pipe := zkRedis.GetClusterClient().TxPipeline()
	defer pipe.Close()

	MatchCacheUpdate(record, ex)
	utils.MatchZSetUpdate(pipe, node)

	_, err = pipe.Exec()
	if err != nil {
		_ = dbConn.Rollback()
		return err
	}

	return dbConn.Commit()
}

/*
 * @Description: 设置赛事是否支持滚球
 * @Author: robin
 * @Date: 2021/12/24 15:59
 * @LastEditTime: 2021/12/24 15:59
 * @LastEditors: robin
 */
func MatchLiveSupportSet(match utils.MatchData) error {

	var (
		nodes []utils.MatchBrief
	)

	mkCount, err := MarketCount(g.Ex{"status": MarketStatusOpen, "visible": VisibleOpen, "match_id": match.ID})
	if err != nil {
		fmt.Printf("【赛事设置支持滚盘:%s】MarketCount,获取赛事盘口数,Error:%s \n", match.ID, err.Error())
		return err
	}

	node := utils.MatchBrief{
		ID:          match.ID,
		Category:    match.Category,
		GameID:      match.GameID,
		StartTime:   match.StartTime,
		Status:      match.Status,
		Visible:     match.Visible,
		LiveSupport: match.LiveSupport,
		IsPassOff:   match.IsPassOff,
		IsLive:      match.IsLive,
		MktCount:    mkCount,
	}
	nodes = append(nodes, node)
	record := g.Record{
		"live_support":   match.LiveSupport,
		"update_by_name": "TY",
		"update_time":    time.Now().Unix(),
	}

	err = MatchUpdate(record, g.Ex{"id": match.ID}, nodes)
	if err != nil {
		fmt.Printf("【赛事设置支持滚盘:%s】MatchUpdate,赛事更新错误,Error:%s \n", match.ID, err.Error())
		return err
	}

	// 更新游戏客户端-前端赛事盘口数
	err = MarketCountUpdate(match.ID, int(mkCount))
	if err != nil {
		fmt.Printf("MarketCountUpdate,更新游戏客户端-前端赛事盘口数,Error: %s \n", err.Error())
		return err
	}

	// 修改滚盘状态 更新游戏赛事计数
	err = MatchGameNavCountStat(match.GameID)
	if err != nil {
		fmt.Printf("【赛事设置支持滚盘:%s】MatchGameNavCountStat,更新游戏赛事计数错误,Error:%v\n ", match.ID, err.Error())
		return err
	}

	// 滚球是否支持滚球-状态变更推送
	mqtt.MqttNotifyMatchLiveSupportUpdate([]string{match.ID}, match.LiveSupport)
	matchLog := utils.TDMatch{
		TS:                  "now",
		User:                "TY",
		Group:               "0",
		IP:                  "0",
		Menu:                "接口请求",
		Action:              "赛事设置支持滚盘",
		GameID:              match.GameID,
		GameShortName:       GameName[match.GameID],
		TournamentId:        match.TournamentID,
		TournamentShortName: TournamentGetName(match.TournamentID),
		Teams:               match.MatchCnTeam,
		MatchID:             match.ID,
		Result:              fmt.Sprintf("【赛事是否支持滚盘】: %s", YesNoDesc[match.LiveSupport]),
	}
	mqtt.MqttNotifyMatchLogPub(matchLog)
	return nil
}

/*
 * @Description: 设置赛事滚球
 * @Author: robin
 * @Date: 2021/12/24 15:59
 * @LastEditTime: 2021/12/24 15:59
 * @LastEditors: robin
 */

func MatchLiveSet(match utils.MatchData, tyMatchData TYMatchData) error {

	var (
		nodes []utils.MatchBrief
	)

	mkCount, err := MarketCount(g.Ex{"status": MarketStatusOpen, "visible": VisibleOpen, "match_id": match.ID})
	if err != nil {
		fmt.Printf("【赛事滚盘:%s】MarketCount,获取赛事盘口数,Error:%s \n", match.ID, err.Error())
		return err
	}

	var strVideoUrl string
	if tyMatchData.VideoStatus >= 0 { // 滚球阶段-体育赛事是否配置视频源: 0-视频源无效,1-视频源未播放,2-正在播放
		strVideoUrl = conf.Cfg.TYApiConf.VideoURL
	}

	node := utils.MatchBrief{
		ID:          match.ID,
		Category:    match.Category,
		GameID:      match.GameID,
		StartTime:   match.StartTime,
		Status:      match.Status,
		Visible:     match.Visible,
		LiveSupport: match.LiveSupport,
		IsPassOff:   match.IsPassOff,
		IsLive:      match.IsLive,
		MktCount:    mkCount,
	}
	nodes = append(nodes, node)
	record := g.Record{
		"admin_video_url": strVideoUrl,
		"is_live":         match.IsLive,
		"live_support":    match.LiveSupport,
		"update_time":     time.Now().Unix(),
	}

	err = MatchUpdate(record, g.Ex{"id": match.ID}, nodes)
	if err != nil {
		fmt.Printf("【赛事滚盘:%s】MatchUpdate,赛事更新错误,Error:%s \n", match.ID, err.Error())
		return err
	}

	// 更新游戏客户端-前端赛事盘口数
	err = MarketCountUpdate(match.ID, int(mkCount))
	if err != nil {
		fmt.Printf("MarketCountUpdate,更新游戏客户端-前端赛事盘口数,Error: %s \n", err.Error())
		return err
	}

	// 修改滚盘状态 更新游戏赛事计数
	err = MatchGameNavCountStat(match.GameID)
	if err != nil {
		fmt.Printf("【赛事滚盘:%s】MatchGameNavCountStat,更新游戏赛事计数错误,Error:%v\n ", match.ID, err.Error())
		return err
	}

	// 赛事状态(初盘->滚盘)变更推送
	mqtt.MqttNotifyMatchLiveUpdate(match.ID, match.IsLive)
	matchLog := utils.TDMatch{
		TS:                  "now",
		User:                "TY",
		Group:               "0",
		IP:                  "0",
		Menu:                "接口请求",
		Action:              "赛事滚盘",
		GameID:              match.GameID,
		GameShortName:       GameName[match.GameID],
		TournamentId:        match.TournamentID,
		TournamentShortName: TournamentGetName(match.TournamentID),
		Teams:               match.MatchCnTeam,
		MatchID:             match.ID,
		Result:              "",
	}
	mqtt.MqttNotifyMatchLogPub(matchLog)
	return nil
}

/*
 * @Description: 赛事结算-清理缓存
 * @Author: robin
 * @Date: 2021/12/23 14:29
 * @LastEditTime: 2021/12/23 14:29
 * @LastEditors: robin
 */
func MatchCacheClear(matchID, sid string) error {

	//删除注单统计ReJson
	key := fmt.Sprintf(redis_helper.RedisMatchCalc, matchID)
	zkRedis.GetClusterClient().Expire(key, redis_helper.ReJsonDefaultExpiredTime)

	//设置赛事盘口rejson的过期时间
	key = fmt.Sprintf(utils.RedisGameIndex, matchID)
	zkRedis.GetClusterClient().Expire(key, redis_helper.ReJsonDefaultExpiredTime)
	//设置盘口 先加载mkt_ids的数据到map
	strJson, err := zkRedis.GetClusterClient().Do("JSON.GET", key, "mkt_ids").Text()
	if err != nil {
		fmt.Printf("【赛事-清理缓存】 赛事ID[%s]\n", matchID)
		return err
	}

	marketIDMap := map[string][]string{}
	err = helper.JsonUnmarshal([]byte(strJson), &marketIDMap)
	if err != nil {
		return err
	}
	for _, ids := range marketIDMap {
		for _, id := range ids {
			key = fmt.Sprintf(utils.RedisMarketCache, id)
			err = zkRedis.GetClusterClient().Expire(key, redis_helper.ReJsonDefaultExpiredTime).Err()
			if err != nil {
				fmt.Printf("【赛事-清理缓存】 赛事ID[%s] 盘口ID[%s]\n", matchID, id)
				return err
			}
		}
	}

	//早盘操盘手分配数据
	key = fmt.Sprintf(redis_helper.RedisMatchTrader, matchID, EarlyTrader)
	zkRedis.GetClusterClient().Expire(key, redis_helper.TraderDefaultExpiredTime)
	//滚球操盘手分配数据
	key = fmt.Sprintf(redis_helper.RedisMatchTrader, matchID, LiveTrader)
	zkRedis.GetClusterClient().Expire(key, redis_helper.TraderDefaultExpiredTime)

	//销毁计时器缓存
	zkRedis.GetClusterClient().Do("JSON.DEL", redis_helper.RedisMatchTimerRejson, "$"+matchID)

	//删除赛事风险标签相关Key
	err = deleteMatchRiskTagCache([]string{matchID}, zkRedis.GetClusterClient())

	delMatchTradeKey(sid)
	return err
}

/*
 * @Description: 删除赛事风险标签相关Key
 * @Author: robin
 * @Date: 2021/12/16 15:38
 * @LastEditTime: 2021/12/16 15:38
 * @LastEditors: robin
 */
func deleteMatchRiskTagCache(matchIds []string, pool *redis.ClusterClient) error {

	//删除赛事风险标签统计相关的Key
	var (
		riskBetCalcKeys []string
		err             error
		cursor          uint64
	)

	for _, matchId := range matchIds {
		//判断赛事是否设置游戏风险标签
		var riskTagSlice []string
		riskTagIds, _ := utils.MatchRiskTagIdGet(pool, matchId)
		if len(riskTagIds) == 0 {
			continue
		}
		riskTagSlice = strings.Split(riskTagIds, ",")
		redisKey := fmt.Sprintf(utils.RedisRiskBetCalc, matchId, "*", "*")
		for {
			var arr []string
			arr, cursor, err = pool.Scan(cursor, redisKey, 2000).Result()
			if err != nil {
				fmt.Println("Delete Match Risk Tag Redis Scan Error: ", err)
				return err
			}

			for _, key := range arr {
				riskBetCalcKeys = append(riskBetCalcKeys, key)
			}

			if cursor == 0 {
				break
			}
		}

		//批量删除
		pipe := pool.TxPipeline()
		//赛事游戏风险标签统计(人数)
		for _, k := range riskBetCalcKeys {
			pipe.Del(k)
		}

		//赛事游戏风险标签统计(金额,单数)
		for _, tagId := range riskTagSlice {
			key := fmt.Sprintf(utils.RedisRiskTagCalc, matchId, tagId)
			pipe.Del(key)
		}

		//赛事游戏风险标签
		pipe.HDel(utils.RedisMatchRiskTag, matchId)

		_, err = pipe.Exec()
		_ = pipe.Close()
		if err != nil {
			fmt.Println("Pipe Redis Exec Error: ", err)
			return err
		}
	}

	return nil
}

/*
 * @Description: 更新赛事比分(全场比分)
 * @Author: robin
 * @Date: 2021/12/23 19:31
 * @LastEditTime: 2021/12/23 19:31
 * @LastEditors: robin
 */
func UpdateMatchScore(match utils.MatchData) error {

	tx, err := zkDB.Begin()
	if err != nil {
		return err
	}

	record := g.Record{
		"update_time": time.Now().Unix(),
		"score":       match.Score,
	}
	query, _, _ := dialect.Update(TblMatches).Set(record).Where(g.Ex{"id": match.ID}).ToSQL()
	fmt.Println(query)
	_, err = tx.Exec(query)
	if err != nil {
		_ = tx.Rollback()
		return err
	}

	// 更新赛事缓存
	pipe := zkRedis.GetClusterClient().TxPipeline()
	defer pipe.Close()

	// 修改缓存
	MatchCacheUpdate(record, g.Ex{"id": match.ID})

	//消息推送
	mqtt.MqttNotifyMatchScoreUpdate(match.ID, match.Score)

	_, err = pipe.Exec()
	if err != nil {
		_ = tx.Rollback()
		return err
	}

	return tx.Commit()

}

/*
 * @Description: 赛事上半场比分
 * @Author: robin
 * @Date: 2021/12/29 15:31
 * @LastEditTime: 2021/12/29 15:31
 * @LastEditors: robin
 */
func MatchScoreFindOne(ex g.Ex) (MatchScore, error) {

	data := MatchScore{}
	query, _, _ := dialect.Select(colMatchScore...).From(TblMatchScore).Where(ex).Limit(1).ToSQL()
	err := zkDB.Get(&data, query)

	return data, err
}

/*
 * @Description: 新增赛事上半场比分
 * @Author: robin
 * @Date: 2021/12/29 16:02
 * @LastEditTime: 2021/12/29 16:02
 * @LastEditors: robin
 */
func MatchScoreInsert(record g.Record) error {

	query, _, _ := dialect.Insert(TblMatchScore).Rows(record).ToSQL()
	fmt.Println(query)
	_, err := zkDB.Exec(query)
	return err
}

/**
 * @Description: 更新赛事上半场比分
 * @Author: robin
 * @Date: 2021/12/29 16:02
 * @LastEditTime: 2021/12/29 16:02
 * @LastEditors: robin
 */
func MatchScoreUpdate(record g.Record, ex g.Ex) error {

	query, _, _ := dialect.Update(TblMatchScore).Set(record).Where(ex).ToSQL()
	fmt.Println(query)
	_, err := zkDB.Exec(query)
	return err
}

/*
 * @Description: 设置滚球赛事的默认计时器
 * @Author: robin
 * @Date: 2021/12/19 11:55
 * @LastEditTime: 2021/12/19 11:55
 * @LastEditors: robin
 */
func SetDefaultRound(matchId string, matchCategory int) error {

	round := "1"
	if matchCategory == DJCategoryFootball { //足球
		round = "first_half"
	}
	// 更新赛事计时器局数
	err := MatchRoundSet(matchId, round)

	return err
}

/*
 * @Description: 赛事局数设置
 * @Author: robin
 * @Date: 2021/12/19 12:00
 * @LastEditTime: 2021/12/19 12:00
 * @LastEditors: robin
 */
func MatchRoundSet(matchId string, round string) error {

	path := "$" + matchId + ".round"
	roundFmt := fmt.Sprintf(`"%s"`, round)
	_, err := zkRedis.GetClusterClient().Do("JSON.SET", redis_helper.RedisMatchTimerRejson, path, roundFmt).Result()
	// 赛事计时尚未设置
	if err != nil && err.Error() == "ERR missing key at non-terminal path level" {
		round = fmt.Sprintf(`{"match_id":"%s","round":"%s"}`, matchId, round)
		path = "$" + matchId
		_, err = zkRedis.GetClusterClient().Do("JSON.SET", redis_helper.RedisMatchTimerRejson, path, round).Result()

	}
	return err
}

/*
 * @Description: 以Rejson 设置 赛事计时器
 * @Author: robin
 * @Date: 2021/12/19 16:06
 * @LastEditTime: 2021/12/19 16:06
 * @LastEditors: robin
 */
func MatchTimerRejsonSet(mchTimer mqtt.MatchTimer) error {

	infJson, err := helper.JsonMarshal(mchTimer)
	if err != nil {
		fmt.Println("marshal err :", err.Error())
		return err
	}

	path := "$" + mchTimer.MatchID
	err = zkRedis.GetClusterClient().Do("JSON.SET", redis_helper.RedisMatchTimerRejson, path, infJson).Err()
	return err
}

/**
 * @Description: 赛事计时器rejson 获取
 * @Author:Sven
 * @Date:2021/11/21 15:15
 * @LastEditTime: 2021/11/21 15:15
 * @LastEditors: Sven
 */
func MatchTimerRejsonGet(matchId string, now int64) (mqtt.MatchTimer, error) {

	t := mqtt.MatchTimer{MatchID: matchId}
	path := "$" + matchId
	res, err := zkRedis.GetClusterClient().Do("JSON.GET", redis_helper.RedisMatchTimerRejson, path).Result()
	if err != nil {
		// 旧赛事可能不存在
		return t, nil
	}

	err = helper.JsonUnmarshal([]byte(res.(string)), &t)
	if err != nil {
		return t, err
	}

	if t.Status == 1 {
		// 计时中每次获取时重新计算TimeTicket时间
		t.TimeTicket += now - t.StartTime
	}

	return t, nil
}

/*
 * @Description: 赛事等级-查询
 * @Author: robin
 * @Date: 2022/1/18 15:52
 * @LastEditTime: 2022/1/18 15:52
 * @LastEditors: robin
 */
func MatchLevelFindOne(ex g.Ex) (MatchLevel, error) {

	data := MatchLevel{}
	query, _, _ := dialect.Select(colMatchLevel...).From(TblMatchLevel).Where(ex).ToSQL()
	err := zkDB.Get(&data, query)

	return data, err
}

/*
 * @Description: 获取风控管理-基本参数的默认赛事等级
 * @Author: robin
 * @Date: 2022/1/18 16:46
 * @LastEditTime: 2022/1/18 16:46
 * @LastEditors: robin
 */
func MatchLevelGetDefault(category int, sid string) (int, error) {

	keys := []string{MatchCategoryLevel[category]}
	setting, err := redis_helper.RedisHMGet(GetZkRedis(), redis_helper.RedisKeySetting, keys)
	if err != nil {
		fmt.Printf("【赛事列表接口-赛事SID:%s】RedisHMGet 获取风控管理-基本参数的联赛默认等级,Error:%s \n", sid, err.Error())
		return 0, err
	}

	level, err := strconv.ParseInt(setting[MatchCategoryLevel[category]], 10, 64)
	if err != nil {
		fmt.Printf("【赛事列表接口-赛事SID:%s】ParseInt 获取风控管理-基本参数的联赛默认等级,Error:%s \n", sid, err.Error())
		return 0, err
	}

	return int(level), nil
}

/*
 * @Description: 获取赛事列表
 * @Author: robin
 * @Date: 2022/2/3 13:00
 * @LastEditTime: 2022/2/3 13:00
 * @LastEditors: robin
 */
func MatchListGet(ex g.Ex) ([]Match, error) {

	var data []Match
	query, _, _ := dialect.Select(colMatchData...).From(TblMatches).Where(ex).ToSQL()
	err := zkDB.Select(&data, query)
	return data, err
}

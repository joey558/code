package model

import g "github.com/doug-martin/goqu/v9"

const (
	TblOddTypes = "tbl_odd_types" // 玩法类型表
)

// 玩法类型结构体
type OddType struct {
	ID              string  `db:"id" json:"id"`                             // ID
	SID             string  `db:"sid" json:"sid"`                           // 体育玩法ID
	CreateByID      uint64  `db:"create_by_id" json:"create_by_id"`         // 创建人ID
	GameID          string  `db:"game_id"  json:"game_id"`                  // 游戏ID
	UpdateByID      uint64  `db:"update_by_id" json:"update_by_id"`         // 修改人ID
	CreateTime      int64   `db:"create_time" json:"create_time"`           // 创建时间
	UpdateTime      int64   `db:"update_time" json:"update_time"`           // 修改时间
	OptionTotal     int     `db:"option_total" json:"option_total"`         // 选项数量
	OptionType      int     `db:"option_type" json:"option_type"`           // 选项类型 1-输赢 2-让分 3-大小 4趣味 5-波胆 6-胜负平 7-单双 8-是否 9-复合
	BonusProportion int     `db:"bonus_proportion" json:"bonus_proportion"` // 赔付占比
	Category        int     `db:"category" json:"category"`                 // 玩法类型 全局-1 单场-2 半场-3
	IsUpdateName    int     `db:"is_update_name" json:"is_update_name"`     // 是否可编辑选项 1-是 0-否
	SortCode        int     `db:"sort_code" json:"sort_code"`               // 排序码
	Status          int     `db:"status" json:"status"`                     // 状态 开启-1关闭-0
	CnName          string  `db:"cn_name" json:"cn_name"`                   // 中文名称
	CreateByName    string  `db:"create_by_name" json:"create_by_name"`     // 创建人名称
	EnName          string  `db:"en_name" json:"en_name"`                   // 英文名称
	UpdateByName    string  `db:"update_by_name" json:"update_by_name"`     // 修改人名称
	OptionName      string  `db:"option_name" json:"option_name"`           // 选项名称
	OptionEnName    string  `db:"option_en_name"  json:"option_en_name"`    // 选项英文名称
	Tag             string  `db:"tag"  json:"tag" `                         // 玩法标签
	TagCode         int     `db:"tag_code"  json:"tag_code" `               // 玩法标签排序
	Module          int     `db:"module"  json:"module" `                   // 玩法模组 1-赛前 2-BP 3-滚球中
	LeagueLevel     string  `db:"league_level"  json:"league_level"`        // 联赛等级 1-M1 2-M2 3-M3 4-M4 ... 9999 M9999
	LncReturnRate   float64 `db:"lnc_return_rate" json:"lnc_return_rate" `  // 返还率递增 范围限定在负15%至正15%
	IsPassOff       int     `db:"is_pass_off" json:"is_pass_off"`           // 是否允许串关 0-不允许串关 1-只允许赛事串关 2-只允许赛事和局内串关
}

/*
 * @Description: 获取玩法列表
 * @Author: robin
 * @Date: 2021/12/1 14:41
 * @LastEditTime: 2021/12/1 14:41
 * @LastEditors: robin
 */
func OddTypeListDB(ex g.Ex) ([]OddType, error) {

	var data []OddType
	query, _, _ := dialect.Select(colOddType...).From(TblOddTypes).Order(g.C("sort_code").Asc()).Where(ex).ToSQL()
	err := zkDB.Select(&data, query)

	return data, err
}

/**
* @Description: 获取一个玩法
* @Author: brandon
* @Date: 2020/6/25 1:53 下午
* @LastEditTime: 2020/6/25 1:53 下午
* @LastEditors: brandon
 */
func OddTypeFindOne(ex g.Ex) (OddType, error) {

	data := OddType{}
	query, _, _ := dialect.Select(colOddType...).From(TblOddTypes).Where(ex).Limit(1).ToSQL()
	err := zkDB.Get(&data, query)

	return data, err
}

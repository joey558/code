package model

// 计时器
var RoundsMapData = map[int]map[string]string{
	MatchCategoryBasketball: {
		"13":  "1",        //第1节-篮球 NBA2K
		"14":  "2",        //第2节-篮球
		"15":  "3",        //第3节-篮球
		"16":  "4",        //第4节-篮球
		"40":  "overtime", //加时-篮球
		"301": "rest1",    //第1节休息-篮球
		"302": "rest2",    //第2节休息-篮球
		"303": "rest3",    //第3节休息-篮球
		"100": "rest4",    //第4节结束-篮球
	},
	MatchCategoryFootball: {
		"6":   "first_half",                //上半场-足球 FIFA
		"7":   "second_half",               //下半场-足球
		"41":  "overtime_first_half",       //加时上半场-足球
		"42":  "overtime_second_half",      //加时下半场-足球
		"31":  "mid_rest",                  //(上半场结束)中场休息-足球
		"33":  "mid_rest",                  //(加时上半场结束)中场休息-足球
		"100": "second_half_over",          //下半场结束-足球
		"110": "overtime_second_half_over", //加时下半场结束-足球
	},
}

//1分钟时间
const (
	OneMinute = 60 //1分钟时间
)

//5分钟时间
const (
	FiveMinutes = 300 //5分钟时间
)

//30分钟时间
const (
	ThirtyMinutes = 1800 //30分钟时间
)

//2小时时间
const (
	TwoHours = 7200 //2小时时间
)

//18小时
const (
	EighteenHours = 3600 * 18 //18小时
)

// TY游戏
const (
	NBA2K = "257733146228414"
	FIFA  = "258337013509741"
)

//游戏名称
var GameName = map[string]string{
	NBA2K: "NBA2K",
	FIFA:  "FIFA",
}

// 赛事种类-游戏ID
var MatchCategoryGameID = map[int]string{
	DJCategoryBasketball: NBA2K,
	DJCategoryFootball:   FIFA,
}

// 赛事种类-联赛等级缓存KEY
var MatchCategoryLevel = map[int]string{
	DJCategoryBasketball: "nba2k_org_level", // NBA2K
	DJCategoryFootball:   "fifa_org_level",  // FIFA
}

// 默认盘口名称-胜平负
const (
	DefaultMarketCnName = "全场独赢"
)

//HTTP 请求状态
const (
	SUCCESS      = "0000000"
	TyApiSUCCESS = "0000"
)

//状态: 1-开启 0-关闭
const (
	StatusOpen  = 1
	StatusClose = 0
)

//计时器状态: 0-暂停 1-开启
const (
	TimerStatusPause = 0
	TimerStatusOpen  = 1
)

// 局数
const (
	AllOfRound  = 0   //0-总局/全场
	HalfOfRound = 100 //100-半场
)

// 电竞赛事类型: 篮球-4 足球-6 体育赛事类型:篮球-2 足球-1
const (
	TYCategoryFootball   = 1
	TYCategoryBasketball = 2
	DJCategoryBasketball = 4
	DJCategoryFootball   = 6
)

// 电竞注单状态
const (
	BetStatusWaitConfirm = 1  // 待确认
	BetStatusRefused     = 2  // 已拒绝
	BetStatusWaitSettle  = 3  // 等待结算
	BetStatusCancelled   = 4  // 已取消
	BetStatusWin         = 5  // 已中奖
	BetStatusLose        = 6  // 未中奖
	BetStatusUndo        = 7  // 已撤销
	BetStatusWinHalf     = 8  // 赢半
	BetStatusLoseHalf    = 9  // 输半
	BetStatusDraw        = 10 // 走水
)

// TY注单状态
const (
	TyOrderStatusPending     = 0 // 待处理
	TyOrderStatusSettled     = 1 // 已结算
	TyOrderStatusCancelled   = 2 // 取消(人工)
	TyOrderStatusWaitConfirm = 3 // 待确认
	TyOrderStatusRefuse      = 4 // 风控拒单
	TyOrderStatusUndo        = 5 // 撤单(赛事取消)
)

const (
	OddTypeCategoryAll      = 1 // 全局
	OddTypeCategorySingle   = 2 // 单场
	OddTypeCategoryHalf     = 3 // 半场（体育）
	OddTypeCategoryChampion = 4 // 冠军
)

//盘口-玩法类型
const (
	OptionTypeWinLose         = 1  // 输赢
	OptionTypeHandicap        = 2  // 让分
	OptionTypeOverUnder       = 3  // 大小
	OptionTypePloy            = 4  // 趣味
	OptionTypeCorrectScore    = 5  // 波胆
	OptionType1X2             = 6  // 胜平负
	OptionTypeOddEven         = 7  // 单双
	OptionTypeYesNo           = 8  // 是否
	OptionTypeChampWin        = 10 // 猜冠军 单选
	OptionTypeChampWinMore    = 11 // 猜冠军 多选
	OptionTypeMix             = 12 // 复合玩法
	OptionTypePlayerWinLose   = 13 // 队员输赢
	OptionTypePlayerHandicap  = 14 // 队员让分
	OptionTypePlayerOverUnder = 15 // 队员大小
	OptionTypePlayerOddEven   = 16 // 队员单双
	OptionTypePlayerYesNo     = 17 // 队员是否
	OptionTypeHeroWinLose     = 18 // 英雄输赢
	OptionTypeHeroHandicap    = 19 // 英雄让分
	OptionTypeHeroOverUnder   = 20 // 英雄大小
	OptionTypeHeroOddEven     = 21 // 英雄单双
	OptionTypeHeroYesNo       = 22 // 英雄是否
)

// 盘口类型
const (
	MarketStatusWaitInput      = 1  // 待录入
	MarketStatusInputFinished  = 2  // 已录入
	MarketStatusInputReject    = 3  // 录入驳回
	MarketStatusPending        = 4  // 待审核
	MarketStatusWaitOpen       = 5  // 待开盘
	MarketStatusOpen           = 6  // 已开盘
	MarketStatusClose          = 7  // 已关盘
	MarketStatusWaitSettle     = 8  // 待结算
	MarketStatusSettled        = 9  // 已结算
	MarketStatusResultRejected = 10 // 赛果驳回
	MarketStatusWaitCancel     = 11 // 待取消
	MarketStatusCancelled      = 12 // 已取消
)

//赛事状态
const (
	MatchStatusEntered    = 1 // 已录入
	MatchStatusPending    = 2 // 待审核
	MatchStatusReject     = 3 // 驳回
	MatchStatusWaitOpen   = 4 // 待开盘
	MatchStatusOpened     = 5 // 开盘
	MatchStatusClosed     = 6 // 关盘
	MatchStatusSettle     = 7 // 结算
	MatchStatusWaitCancel = 8 // 待取消
	MatchStatusCancel     = 9 // 取消
)

//体育赛事(结束|取消)状态值
const (
	TYMatchFinishStatus3  = 3     //结束
	TYMatchFinishStatus4  = 4     //结束
	TYMatchFinishStatus1  = 1     //结束
	TYMatchFinishStatus9  = "999" //结束
	TYMatchFinishStatus5  = 5     //取消
	TYMatchFinishStatus6  = 6     //取消(比赛放弃)
	TYMatchFinishStatus10 = 10    //取消(比赛中断)
)

// 赛事阶段: 1-初盘 2-滚盘
const (
	MatchEarly = 1
	MatchLive  = 2
)

// 盘口类型: 1-早盘 0-滚盘
const (
	MarketEarly = 1
	MarketLive  = 0
)

const (
	EarlyTrader  = 1 // 早盘操盘手
	LiveTrader   = 2 // 滚球操盘手
	SettleTrader = 3 // 结算操盘手
)

//数据源: 0-无 1-TY
const (
	DataSourceNone = 0
	DataSourceTY   = 1
)

//操盘模式: 1-手动 2-MTS
const (
	ModeManual = 1
	ModeMTS    = 2
)

// 体育登录返回信息
type TYLoginResp struct {
	Status     bool   `json:"status"`
	Msg        string `json:"msg"`
	Code       string `json:"code"`
	ServerTime int64  `json:"serverTime"`
	Data       struct {
		UserId    string `json:"userId"`
		Domain    string `json:"domain"`
		Token     string `json:"token"`
		ImgDomain string `json:"imgDomain"`
		Url       string `json:"url"`
		LoginUrl  string `json:"loginUrl"`
	} `json:"data"`
}

// 体育获取API域名返回信息
type TYGetApiDomainNameResp struct {
	Status     bool     `json:"status"`
	Msg        string   `json:"msg"`
	Code       string   `json:"code"`
	ServerTime int64    `json:"serverTime"`
	Data       []string `json:"data"`
}

var ResettleDesc = map[int]string{
	1: "录入赛果",
	2: "取消盘口",
}

// 重新结算：1—盘口结算 2-盘口取消
const (
	SettleStreamFlagResettle = 1
	SettleStreamFlagCancel   = 2
)

// 操盘动作stream. market_id=1,2,3...&flag=1  [2盘口取消]
const (
	TradeStreamFlagCancel = "2"
)

// 赛事类型 正常-1 冠军-2 大逃杀-3 篮球-4 主播盘-5 足球-6
const (
	MatchCategoryNormal     = 1
	MatchCategoryChampion   = 2
	MatchCategoryEscape     = 3
	MatchCategoryBasketball = 4
	MatchCategoryAnchor     = 5
	MatchCategoryFootball   = 6
)

//是否显示
const (
	VisibleClose = 0 //隐藏
	VisibleOpen  = 1 //显示
)

//是否暂停
const (
	SuspendedClose = 0 //取消暂停
	SuspendedOpen  = 1 //暂停
)

const (
	OddWinStatusLose     = 0 //输
	OddWinStatusWin      = 1 //赢
	OddWinStatusWinHalf  = 2 //赢半
	OddWinStatusLoseHalf = 3 //输半
	OddWinStatusDraw     = 4 //平(走水)
)

//TY
const (
	TYOddWinStatusNo       = 0 //无赛果
	TYOddWinStatusDraw     = 2 //平(走水)
	TYOddWinStatusLose     = 3 //输
	TYOddWinStatusWin      = 4 //赢
	TYOddWinStatusWinHalf  = 5 //赢半
	TYOddWinStatusLoseHalf = 6 //输半
)

// TY状态
const (
	TYStatusOpen    = 0  // 0-开盘
	TYStatusSeal    = 1  // 1-封盘
	TYStatusClosed  = 2  // 2-关盘
	TYStatusSettled = 3  // 3-已结算
	TYStatusCancel  = 4  // 4-取消
	TYStatusLock    = 11 // 11-锁盘
)

const (
	TYOddStatusOpen   = 1 // 1-开盘
	TYOddStatusSeal   = 2 // 2-封盘
	TYOddStatusClosed = 3 // 3-关盘
	TYOddStatusLock   = 4 // 4-锁盘
)

const (
	ChanMax = 999 // 最大管道数量
)

var TeamTypeDesc = map[int]string{
	0: "主队",
	1: "客队",
}

var OddTypeOptionTypeDesc = map[int]string{
	1: "输赢",
	2: "让分",
	3: "大小",
	6: "胜负平",
	7: "单双",
}

var YesNoDesc = map[int]string{
	0: "否",
	1: "是",
}

var TYMarketStatusDesc = map[int]string{
	0:  "开盘",
	1:  "封盘",
	2:  "关盘",
	3:  "已结算",
	4:  "取消",
	5:  "handedOver",
	11: "锁盘",
}

var MatchCategoryDesc = map[int]string{
	MatchCategoryBasketball: "篮球",
	MatchCategoryFootball:   "足球",
}

var MatchIsLiveDesc = map[int]string{
	MatchEarly: "初盘",
	MatchLive:  "滚盘",
}

var MatchOperateDesc = map[int]string{
	5: "新增盘口",
	6: "赛事结束",
}

var (
	ResultStatus = map[int]string{
		0: "输",
		1: "赢",
		2: "赢半",
		3: "输半",
		4: "走水",
	}
)

var (
	MatchStatusDesc = map[int]string{
		1: "已录入",
		2: "待审核",
		3: "驳回",
		4: "待开盘",
		5: "开盘",
		6: "关盘",
		7: "结算",
		8: "待取消",
		9: "取消",
	}
	MktStatus = map[int]string{
		1:  "待录入",
		2:  "已录入",
		3:  "录入驳回",
		4:  "待审核",
		5:  "待开盘",
		6:  "已开盘",
		7:  "已关盘",
		8:  "待结算",
		9:  "已结算",
		10: "赛果驳回",
		11: "待取消",
		12: "已取消",
	}
	VisibleStatus = map[int]string{
		0: "隐藏",
		1: "显示",
	}
	SuspendedStatus = map[int]string{
		0: "取消暂停",
		1: "暂停",
	}
)

const (
	SettleRuleNormal    = 0 //普通结算
	SettleRuleBenchmark = 1 //基准分结算
)

//BenchmarkScore
const (
	AllConcedePoints   = "14650626566501040"  // 全场让球
	HalfConcedePoints  = "47957485339937812"  // 半场让球
	AllTimeLeftToWin   = "123445693265569240" // 剩余时间获胜
	FirstTimeLeftToWin = "53758685711873936"  // 上半场剩余时间获胜
)

//基准分玩法ID
const (
	ScoreOddType4  = "4"
	ScoreOddType19 = "19"
	ScoreOddType27 = "27"
	ScoreOddType29 = "29"
)

//盘口取消原因
const (
	MarketReason101 = 101 //101-无赛果
	MarketReason102 = 102 //102-赛果无法定义
	MarketReason103 = 103 //103-赛制错误
	MarketReason104 = 104 //104-盘口信息错误
	MarketReason105 = 105 //105-平局退款
	MarketReason106 = 106 //106-不公平对局
	MarketReason107 = 107 //107-比赛取消
	MarketReason108 = 108 //108-比赛延期
	MarketReason109 = 109 //109-比赛放弃
	MarketReason110 = 110 //110-比赛延迟
	MarketReason111 = 111 //111-比赛中断
	MarketReason112 = 112 //112-未知状态
	MarketReason113 = 113 //113-无进球球员
	MarketReason114 = 114 //114-比分丢失
	MarketReason115 = 115 //115-无法确认赛果
	MarketReason116 = 116 //116-格式变更
	MarketReason117 = 117 //117-进球球员丢失
	MarketReason118 = 118 //118-主动弃赛
	MarketReason119 = 119 //119-并列获胜
	MarketReason120 = 120 //120-中途弃赛
	MarketReason121 = 121 //121-赔率错误
	MarketReason122 = 122 //122-统计错误
	MarketReason123 = 123 //123-投手变更
	MarketReason124 = 124 //124-盘口错误
	MarketReason125 = 125 //125-其他
)

var MarketCancelReasonDesc = map[int]string{
	MarketReason101: "101-无赛果",
	MarketReason102: "102-赛果无法定义",
	MarketReason103: "103-赛制错误",
	MarketReason104: "104-盘口信息错误",
	MarketReason105: "105-平局退款",
	MarketReason106: "106-不公平对局",
	MarketReason107: "107-比赛取消",
	MarketReason108: "108-比赛延期",
	MarketReason109: "109-比赛放弃",
	MarketReason110: "110-比赛延迟",
	MarketReason111: "111-比赛中断",
	MarketReason112: "112-未知状态",
	MarketReason113: "113-无进球球员",
	MarketReason114: "114-比分丢失",
	MarketReason115: "115-无法确认赛果",
	MarketReason116: "116-格式变更",
	MarketReason117: "117-进球球员丢失",
	MarketReason118: "118-主动弃赛",
	MarketReason119: "119-并列获胜",
	MarketReason120: "120-中途弃赛",
	MarketReason121: "121-赔率错误",
	MarketReason122: "122-统计错误",
	MarketReason123: "123-投手变更",
	MarketReason124: "124-盘口错误",
	MarketReason125: "125-其他",
}

var MarketCancelReason = map[int]int{
	0:  MarketReason101, //101-无赛果
	33: MarketReason103, //103-赛制错误
	18: MarketReason107, //107-比赛取消
	19: MarketReason108, //108-比赛延期
	7:  MarketReason107, //107-比赛取消
	8:  MarketReason108, //108-比赛延期
	15: MarketReason109, //109-比赛放弃
	11: MarketReason110, //110-比赛延迟
	12: MarketReason111, //111-比赛中断
	13: MarketReason112, //112-未知状态
	17: MarketReason112, //112-未知状态
	21: MarketReason113, //113-无进球球员
	22: MarketReason114, //114-比分丢失
	23: MarketReason115, //115-无法确认赛果
	24: MarketReason116, //116-格式变更
	25: MarketReason117, //117-进球球员丢失
	26: MarketReason118, //118-主动弃赛
	27: MarketReason119, //119-并列获胜
	28: MarketReason120, //120-中途弃赛
	29: MarketReason121, //121-赔率错误
	30: MarketReason122, //122-统计错误
	31: MarketReason123, //123-投手变更
	32: MarketReason124, //124-盘口错误
	16: MarketReason124, //124-盘口错误
	20: MarketReason125, //125-其他
}

var TyOrderCancelReason = map[int]int{
	1:  50,  //比赛取消
	2:  51,  //比赛延期
	3:  53,  //比赛中断
	4:  54,  //比赛重赛
	5:  55,  //比赛腰斩
	6:  56,  //比赛放弃
	7:  57,  //盘口错误
	8:  201, //赔率错误
	9:  58,  //队伍错误
	10: 59,  //联赛错误
	11: 60,  //比分错误
	12: 61,  //电视裁判
	13: 62,  //主客场错误
	14: 63,  //赛制错误
	15: 64,  //赛程错误
	16: 65,  //事件错误
	17: 202, //赛事提前
	18: 71,  //其他
	19: 71,  //其他
	20: 52,  //比赛延迟
	21: 66,  //操盘手取消
	22: 67,  //主动弃赛
	23: 68,  //并列获胜
	24: 69,  //中途弃赛
	25: 70,  //统计错误
	40: 71,  //其他
	41: 71,  //其他
	42: 71,  //其他
	43: 71,  //其他
	44: 71,  //其他
	45: 71,  //其他
}

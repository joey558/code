package model

import (
	"djData/helper"
	"djData/utils"
	"fmt"
	g "github.com/doug-martin/goqu/v9"
	"github.com/go-redis/redis/v7"
	"github.com/shopspring/decimal"
)

type MatchTotalCalc struct {
	T int     `db:"t"` // 总投注数
	A float64 `db:"a"` // 总投注金额
}

type MatchRiskCalc struct {
	Pending  int `db:"pending"`  // 风险注单-待处理数
	Accepted int `db:"accepted"` // 风险注单-已接受数
	Rejected int `db:"rejected"` // 风险注单-已拒绝数
}

// 盘口统计
type MarketCalc struct {
	MarketID         string  `db:"market_id"`
	Risk             int     `db:"risk"` // 盘口风险注单数
	RealityBetAmount float64 `db:"rba"`  // 盘口总实际注单金额
	FloatBetAmount   float64 `db:"fba"`  // 盘口总浮动注单金额
}

// odd统计
type OddCalc struct {
	MarketID           string  `db:"market_id"`
	OddID              string  `db:"odd_id"`
	RealityBetCount    int     `db:"rbc"`  // 实际注单数
	FloatBetCount      int     `db:"fbc"`  // 浮动注单数
	RealityBetAmount   float64 `db:"rba"`  // 实际注单金额
	FloatBetAmount     float64 `db:"fba"`  // 浮动注单金额
	RealityTheoryPrize float64 `db:"rthp"` // 实际预期盈利金额
	FloatTheoryPrize   float64 `db:"fthp"` // 浮动预期盈利金额
}

//赛事风险标签统计数据结构体
type MatchRiskTagOrderData struct {
	RiskTagID   string          `db:"risk_tag_id"` //风险标签ID
	BetAmount   decimal.Decimal `db:"ba"`          //投注金额
	BetCount    int             `db:"bc"`          //投注单数
	MemberCount int             `db:"mc"`          //投注人数
}

func marketCalcGen(marketID string, oddIDs []string) (utils.MarketCalc, error) {

	data := utils.MarketCalc{
		MarketID: marketID,
	}

	oddCalc := make(map[string]utils.OddCalc)
	for _, oddID := range oddIDs {
		oddCalc["$"+oddID] = utils.OddCalc{
			RealityBetCount:    0,
			FloatBetCount:      0,
			RealityBetAmount:   0,
			FloatBetAmount:     0,
			RealityTheoryPrize: 0,
			FloatTheoryPrize:   0,
		}
	}

	data.Odds = oddCalc

	return data, nil
}

func MarketStatInsert(pool *redis.ClusterClient, matchID, marketID, marketInfo string) error {

	key := fmt.Sprintf("mch_calc:%s", matchID)
	return pool.Do("JSON.SET", key, ".market.$"+marketID, marketInfo).Err()
}

func matchCalcGen(matchID string) (*utils.MatchOrderCalcStat, error) {

	data := &utils.MatchOrderCalcStat{}
	// 1.获取赛事所有盘口和投注项
	mkts, err := MarketListDB(g.Ex{"match_id": matchID})
	if err != nil {
		return data, err
	}

	odds, err := OddListMap(g.Ex{"match_id": matchID})
	if err != nil {
		return data, err
	}

	mktCalc := make(map[string]utils.MarketCalc)
	for _, mkt := range mkts {
		oddCalc := make(map[string]utils.OddCalc)
		for _, odd := range odds[mkt.ID] {
			oddCalc["$"+odd.ID] = utils.OddCalc{
				RealityBetCount:    0,
				FloatBetCount:      0,
				RealityBetAmount:   0,
				FloatBetAmount:     0,
				RealityTheoryPrize: 0,
				FloatTheoryPrize:   0,
			}
		}

		mktCalc["$"+mkt.ID] = utils.MarketCalc{
			MarketID:         mkt.ID,
			Risk:             0,
			RealityBetAmount: 0,
			FloatBetAmount:   0,
			Odds:             oddCalc,
		}
	}

	data.Market = mktCalc

	return data, nil
}

/*
 * @Description: 赛事注单统计json初始化
 * @Author: robin
 * @Date: 2021/12/13 15:43
 * @LastEditTime: 2021/12/13 15:43
 * @LastEditors: robin
 */
func InitMatchCalcJson(matchID string) error {

	data, err := matchCalcGen(matchID)
	if err != nil {
		return err
	}

	bytes, err := helper.JsonMarshal(data)
	if err != nil {
		return err
	}

	return utils.InitMatchStat(zkRedis.GetClusterClient(), matchID, string(bytes))
}

package model

import (
	"context"
	"database/sql"
	"djData/helper"
	"djData/helper/conf"
	mqtt "djData/helper/mqtt_helper"
	rmq "djData/helper/rocket_mq"
	"djData/utils"
	"fmt"
	"log"
	"strconv"
	"strings"
	"time"

	g "github.com/doug-martin/goqu/v9"
	"github.com/go-redis/redis/v7"
	"github.com/shopspring/decimal"
)

const (
	TblOdds = "tbl_odds" // 投注项信息表
)

// OddUpdateItem 更新盘口赔率参数
type OddUpdateItem struct {
	MarketId   string  `json:"market_id"`   //盘口ID
	MatchId    string  `json:"match_id"`    //赛事ID
	ID         string  `json:"id"`          //投注项ID
	Odd        string  `json:"odd"`         //赔率
	ReturnRate float64 `json:"return_rate"` //返还率
}

// 更新盘口-投注项名称,赔率
type OddNameUpdateItem struct {
	MarketId string `json:"market_id"` //盘口ID
	MatchId  string `json:"match_id"`  //赛事ID
	ID       string `json:"id"`        //投注项ID
	Odd      string `json:"odd"`       //赔率
	Name     string `json:"name"`      //中文-投注项名称
	EnName   string `json:"en_name"`   //英文-投注项名称
}

// Odd 投注项
type Odd struct {
	ID        string          `json:"id" db:"id"`               // 投注项ID
	MatchID   string          `json:"match_id" db:"match_id"`   // 赛事ID
	MarketID  string          `json:"market_id" db:"market_id"` // 盘口ID
	Name      string          `json:"name" db:"name"`           // 选项名称
	EnName    string          `json:"en_name" db:"en_name"`     // 选项英文名称
	Odd       decimal.Decimal `json:"odd" db:"odd"`             // 赔率
	OrgOdd    string          `json:"org_odd" db:"org_odd"`     // 初始赔率
	Round     int             `json:"round" db:"round"`         // 赛事局数
	IsWinner  int             `json:"is_winner" db:"is_winner"` // 是否获胜 1-是 0-否
	SortID    int             `json:"sort_id" db:"sort_id"`     // 排序码
	Visible   int             `json:"visible" db:"visible"`     // 是否显示 1-显示 0-隐藏
	Suspended int             `json:"suspended" db:"suspended"` // 是否暂停 1-暂停 0-取消暂停
	TeamID    string          `json:"team_id" db:"team_id"`     // 战队id
}

type MarketOdds struct {
	SportId             string     `json:"sportId"`             // 体种id
	StandardMatchInfoId string     `json:"standardMatchInfoId"` // 标准赛事id
	Status              int        `json:"status"`              // 赛事盘口状态
	SMarkets            []SMarkets `json:"sMarkets"`            // 盘口集合
	DjMatchId           string     `json:"dj_match_id"`         //电竞赛事ID
	ModifyTime          string     `json:"modifyTime"`          // 修改时间
}

// SMarkets 盘口集合
type SMarkets struct {
	ID             string           `json:"id"`             // 盘口id
	OddTypeID      string           `json:"playId"`         // 玩法ID-基准分(玩法ID:4,19,27,29,128,130,143,113,121)
	Addition1      string           `json:"addition1"`      // 盘口附加字段值-1 (玩法ID:27,29)-(addition1:addition2)
	Addition2      string           `json:"addition2"`      // 盘口附加字段值-2
	Addition3      string           `json:"addition3"`      // 盘口附加字段值-3 (玩法ID:4,19,128,130,143,113,121)-(addition3:addition4)
	Addition4      string           `json:"addition4"`      // 盘口附加字段值-4
	Status         int              `json:"status"`         // 盘口状态 0-开盘,1-封盘,2-关盘,11-锁盘
	MarketType     int              `json:"ht"`             // 盘口类型: 0-滚盘 1-早盘
	MarketOddsList []MarketOddsList `json:"marketOddsList"` // 投注项集合
}

type MarketOddsList struct {
	ID          string `json:"id"`          // 投注项id
	PaOddsValue int    `json:"paOddsValue"` // Panda自己赔率
	OddsStatus  int    `json:"oddsStatus"`  // 投注项状态 1-开盘	2-封盘	3-关盘	4-锁盘
}

// OdUpdate 投注项更新
type OdUpdate struct {
	Record g.Record
	Ex     g.Ex
}

type AutoOddData struct {
	MchId string     `json:"mch_id"`
	Data  MarketOdds `json:"data"`
}

var (
	TYOddMultiple = decimal.NewFromInt(100000)
	oddChan       chan []byte
	autoOddChan   = map[string]chan AutoOddData{}
)

/*
 * @Description: 从mysql获取投注项列表
 * @Author: robin
 * @Date: 2021/12/1 18:05
 * @LastEditTime: 2021/12/1 18:05
 * @LastEditors: robin
 */
func OddListDB(ex g.Ex) ([]Odd, error) {

	var data []Odd
	query, _, _ := dialect.Select(colOdd...).From(TblOdds).Where(ex).ToSQL()
	err := zkDB.Select(&data, query)

	return data, err
}

func OddListMap(ex g.Ex) (map[string][]Odd, error) {

	res := make(map[string][]Odd, 0)
	list, err := OddListDB(ex)
	if err != nil {
		return res, err
	}
	for _, v := range list {
		if data, ok := res[v.MarketID]; ok {
			data = append(data, v)
			res[v.MarketID] = data
		} else {
			res[v.MarketID] = []Odd{v}
		}
	}
	return res, nil
}

func OddsUpdate(tx *sql.Tx, records ...OdUpdate) error {

	for _, rec := range records {
		query, _, _ := dialect.Update(TblOdds).Set(rec.Record).Where(rec.Ex).ToSQL()
		fmt.Println(query)
		_, err := tx.Exec(query)
		if err != nil {
			return err
		}
	}
	return nil
}

/*
 * @Description: 玩法基准分(4,19,27,29)
 * @Author: robin
 * @Date: 2022/1/8 15:54
 * @LastEditTime: 2022/1/8 15:54
 * @LastEditors: robin
 */
func IsScoreBenchmark(oddTypeID string) bool {

	scoreBenchmarkMap := map[string]bool{
		"4":  true, //全场让球
		"19": true, //半场让球
		"27": true, //上半场剩余时间获胜
		"29": true, //剩余时间获胜
	}

	if _, ok := scoreBenchmarkMap[oddTypeID]; ok {
		return true
	}

	return false
}

// MarketOddAutoUpdate
/**
* @Description: MQ订阅盘口数据变更函数入口
* @Author: noah
* @Date: 2021/12/17 19:13
* @LastEditTime:2021/12/17 19:13
* @LastEditors: noah
 */
func MarketOddAutoUpdate(ctx context.Context) {

	var err error
	oddChan = make(chan []byte, ChanMax)
	cfg := conf.Cfg.TYApiConf.RocketMq
	strGroupName := cfg.GroupName + rmq.TYMarkerTopic
	autoOddCli, err = rmq.GetMqPushConsumer(cfg, strGroupName)
	if err != nil {
		log.Fatalln(err)
	}

	go rmq.RocketMqMsgGet(ctx, autoOddCli, rmq.TYMarkerTopic, oddChan)
	for i := range oddChan {
		data := MarketOdds{}
		err = helper.JsonUnmarshal(i, &data)
		if err != nil {
			fmt.Printf("【自动变赔-赛事ID:%s】JsonUnmarshal,Error[%s].\n", data.StandardMatchInfoId, err.Error())
			fmt.Printf("【自动变赔-赛事ID:%s】JsonUnmarshal,解析内容错误[%s].\n", data.StandardMatchInfoId, string(i))
			continue
		}

		sportId, _ := strconv.Atoi(data.SportId)
		if sportId != TYCategoryFootball && sportId != TYCategoryBasketball {
			continue
		}

		mchId := getMatchId(data.StandardMatchInfoId)
		if mchId == "" {
			fmt.Printf("【自动变赔-赛事ID:%s】不存在于电竞赛事列表里.\n", data.StandardMatchInfoId)
			continue
		}

		d := AutoOddData{mchId, data}
		if _, ok := autoOddChan[mchId]; !ok {
			autoOddChan[mchId] = make(chan AutoOddData, ChanMax)
			go func() {
				for j := range autoOddChan[mchId] {
					err = autoOdd(j.MchId, j.Data)
					if err != nil {
						fmt.Printf("【自动变赔-赛事ID:%s】autoOdd,Error[%s].\n", j.MchId, err.Error())
					}
				}
			}()
		}
		autoOddChan[mchId] <- d
	}
}

// AutoOdd
/**
* @Description: 体育自动变赔
* @Author: noah
* @Date: 2021/12/17 18:58
* @LastEditTime:2021/12/17 18:58
* @LastEditors: noah
 */
func autoOdd(mchId string, data MarketOdds) error {

	// todo:xp
	mpMatchMarketID := map[string]string{}
	for _, v := range data.SMarkets {
		mpMatchMarketID[v.ID] = mchId
	}
	handicapInfo, err := utils.HandicapInfo(zkRedis.GetClusterClient(), mpMatchMarketID)
	if err != nil {
		fmt.Printf("【自动变赔-赛事ID:%s】获取赛事缓存错误[%s]\n. 盘口ID:%v\n", data.StandardMatchInfoId, err.Error(), mpMatchMarketID)
		return err
	}

	match := handicapInfo.Matches[mchId]
	//盘口及赔率变更的条件：赛事状态(开盘)
	if match.Status != MatchStatusOpened {
		fmt.Printf("【自动变赔接口-赛事ID:%s】赛事状态为[%s]不是开盘状态,不能继续变赔.\n", mchId, MatchStatusDesc[match.Status])
		return nil
	}

	//赛事状态隐藏/显示,暂停/取消变更
	bUpdateMatchVisible := false
	mchRecord := g.Record{}
	mchEx := g.Ex{"id": mchId}
	if !GetMatchTradeStatus(match.SID) { //若电竞操盘界面 已操作赛事(暂停,隐藏) 则忽略TY下发赛事的开,封,关,锁等行为
		switch data.Status {
		case TYStatusOpen:
			if match.Suspended != SuspendedClose {
				mchRecord["suspended"] = SuspendedClose
			}
			if match.Visible != VisibleOpen {
				mchRecord["visible"] = VisibleOpen
				bUpdateMatchVisible = true
			}

		case TYStatusSeal, TYStatusLock:
			if match.Suspended != SuspendedOpen {
				mchRecord["suspended"] = SuspendedOpen
			}
		case TYStatusClosed:
			if match.Visible != VisibleClose {
				mchRecord["visible"] = VisibleClose
				bUpdateMatchVisible = true
			}
		}
	}

	timeStr := time.Now().String()
	atoi, _ := strconv.Atoi(data.ModifyTime)
	if atoi != 0 {
		unix := atoi / 1000
		timeStr = time.Unix(int64(unix), 0).Format("2006-01-02 15:04:05")
	}
	if len(mchRecord) > 0 {
		mchRecord["update_by_name"] = "TY"
		mchRecord["update_time"] = time.Now().Unix()
		var (
			nodes    []utils.MatchBrief
			mktCount int
		)
		if bUpdateMatchVisible {
			mktCount, err := MarketCount(g.Ex{"match_id": mchId, "visible": VisibleOpen})
			if err != nil {
				fmt.Println(err.Error())
				return nil
			}
			nodes = []utils.MatchBrief{{
				ID:          match.ID,
				Category:    match.Category,
				GameID:      match.GameID,
				StartTime:   match.StartTime,
				Status:      match.Status,
				Visible:     mchRecord["visible"].(int),
				LiveSupport: match.LiveSupport,
				IsPassOff:   match.IsPassOff,
				IsLive:      match.IsLive,
				MktCount:    mktCount,
			}}
		}
		err = MatchUpdate(mchRecord, mchEx, nodes)
		if err != nil {
			fmt.Printf("【自动变赔-赛事ID:%s,%s】MatchUpdate,Error[%s].\n", match.ID, match.SID, err.Error())
			return err
		}

		for k, v := range mchRecord {
			mchLog := utils.TDMatch{
				TS:                  "now",
				User:                "TY",
				Group:               "0",
				IP:                  "0",
				Menu:                "操盘管理-赛事主页",
				GameID:              match.GameID,
				GameShortName:       GetGameName(match.GameID),
				TournamentId:        match.TournamentID,
				TournamentShortName: TournamentGetName(match.TournamentID),
				Teams:               match.MatchCnTeam,
				MatchID:             match.ID,
			}
			switch k {
			case "suspended":
				// mqtt通知赛事暂停/取消暂停
				mqtt.MqttNotifyMatchSuspendUpdate([]string{mchId}, v.(int))
				l := fmt.Sprintf("【自动变赔-赛事暂停】变更时间：%s 赛事SID：%s 赛事ID:%s 赛事暂停状态:%s->%s\n", timeStr, data.StandardMatchInfoId, match.ID, SuspendedStatus[match.Suspended], SuspendedStatus[v.(int)])
				fmt.Println(l)
				mchLog.Action = "赛事暂停"
				mchLog.Result = fmt.Sprintf("【状态】:%v", SuspendedStatus[v.(int)])
				mqtt.MqttNotifyMatchLogPub(mchLog)
			case "visible":
				//(赛事显示,隐藏)更新游戏赛事计数
				err = MatchGameNavCountStat(match.GameID)
				if err != nil {
					fmt.Println(err.Error())
					continue
				}

				//(赛事显示,隐藏)更新联赛缓存
				err = GameTourCacheUpdate(match.GameID, match.TournamentID, match.ID, match.StartTime, v.(int) == VisibleOpen && match.Status == MatchStatusOpened)
				if err != nil {
					fmt.Println(err.Error())
					continue
				}
				// mqtt通知赛事隐藏/显示
				mqtt.MqttNotifyMatchVisibleUpdate([]string{mchId}, v.(int))
				l := fmt.Sprintf("【自动变赔-赛事显示/隐藏】变更时间：%s 赛事SID：%s 赛事ID:%s 赛事隐藏状态:%s->%s\n", timeStr, data.StandardMatchInfoId, match.ID, VisibleStatus[match.Visible], VisibleStatus[v.(int)])
				fmt.Println(l)
				mchLog.Action = "赛事显示/隐藏"
				mchLog.Result = fmt.Sprintf("【状态】:%v 【显示盘口数量】:%d", VisibleStatus[v.(int)], mktCount)
				mqtt.MqttNotifyMatchLogPub(mchLog)
			}
		}
	}

	defaultMktId := ""
	bUpdateMatchCount := false
	for _, mkt := range handicapInfo.Markets {
		if mkt.IsDefault != 0 {
			defaultMktId = mkt.ID
			break
		}
	}

	for _, m := range data.SMarkets {
		ex := g.Ex{"id": m.ID}
		record := g.Record{}
		var records []OdUpdate
		var odds []OddUpdateItem
		mkt, ok := handicapInfo.Markets[m.ID]
		if !ok {
			continue
		}
		mktLog := utils.TDMarket{
			TS:                  "now",
			User:                "TY",
			Group:               "0",
			IP:                  "0",
			Menu:                "赛事管理-赛事主页",
			GameID:              match.GameID,
			GameShortName:       GetGameName(match.GameID),
			TournamentId:        match.TournamentID,
			TournamentShortName: TournamentGetName(match.TournamentID),
			Teams:               match.MatchCnTeam,
			MatchID:             match.ID,
			MarketID:            mkt.ID,
			MarketEnName:        mkt.CnName,
			Round:               int16(mkt.Round),
			Category:            int8(match.Category),
		}
		pipe := zkRedis.GetClusterClient().Pipeline()
		//盘口状态(0-开盘,1-封盘,2-关盘,3-已结算,4-取消,11-锁盘)
		switch m.Status {
		case TYStatusOpen: // 开盘
			if mkt.Suspended != SuspendedClose {
				record["suspended"] = SuspendedClose
			}
			if mkt.Visible != VisibleOpen {
				record["visible"] = VisibleOpen
				bUpdateMatchCount = true
			}
			if mkt.Status < MarketStatusOpen {
				record["status"] = MarketStatusOpen
				bUpdateMatchCount = true
			}
		case TYStatusSeal, TYStatusLock: //封盘 锁盘
			if mkt.Suspended != SuspendedOpen {
				record["suspended"] = SuspendedOpen
			}
		case TYStatusClosed: //关盘
			if mkt.Visible != VisibleClose {
				record["visible"] = VisibleClose
				bUpdateMatchCount = true
			}
		case TYStatusSettled: //已结算
			if mkt.Status != MarketStatusSettled {
				record["status"] = MarketStatusSettled
			}
		}

		//玩法基准分
		bUpdateBenchmark := false
		if IsScoreBenchmark(m.OddTypeID) && m.MarketType == MarketLive { //滚盘的盘口, 才能更新 基准分
			if (m.OddTypeID == ScoreOddType27 || m.OddTypeID == ScoreOddType29) && m.Addition1 != "" && m.Addition2 != "" && mkt.ID == m.ID {
				strScore := fmt.Sprintf("%s:%s", m.Addition1, m.Addition2)
				if mkt.ScoreBenchmark != strScore {
					bUpdateBenchmark = true
					record["score_benchmark"] = strScore
					if strings.Contains(mkt.CnName, "(") {
						strNameSlice := strings.Split(mkt.CnName, "(")
						record["cn_name"] = fmt.Sprintf("%s(%s-%s)", strNameSlice[0], m.Addition1, m.Addition2)
						strNameSlice = strings.Split(mkt.EnName, "(")
						record["en_name"] = fmt.Sprintf("%s(%s-%s)", strNameSlice[0], m.Addition1, m.Addition2)
					} else {
						record["cn_name"] = fmt.Sprintf("%s(%s-%s)", mkt.CnName, m.Addition1, m.Addition2)
						record["en_name"] = fmt.Sprintf("%s(%s-%s)", mkt.EnName, m.Addition1, m.Addition2)
					}
					fmt.Printf("【自动变赔-基准分玩法】赛事ID[%s],盘口ID[%s],盘口名称[%s],玩法ID[%s],盘口基准分:[%s]->[%s]\n", match.ID, m.ID, record["cn_name"], m.OddTypeID, mkt.ScoreBenchmark, record["score_benchmark"])
				}
			} else if (m.OddTypeID == ScoreOddType4 || m.OddTypeID == ScoreOddType19) && m.Addition3 != "" && m.Addition4 != "" && mkt.ID == m.ID {
				strScore := fmt.Sprintf("%s:%s", m.Addition3, m.Addition4)
				if mkt.ScoreBenchmark != strScore {
					bUpdateBenchmark = true
					record["score_benchmark"] = strScore
					if strings.Contains(mkt.CnName, "(") {
						strNameSlice := strings.Split(mkt.CnName, "(")
						record["cn_name"] = fmt.Sprintf("%s(%s-%s)", strNameSlice[0], m.Addition3, m.Addition4)
						strNameSlice = strings.Split(mkt.EnName, "(")
						record["en_name"] = fmt.Sprintf("%s(%s-%s)", strNameSlice[0], m.Addition3, m.Addition4)
					} else {
						record["cn_name"] = fmt.Sprintf("%s(%s-%s)", mkt.CnName, m.Addition3, m.Addition4)
						record["en_name"] = fmt.Sprintf("%s(%s-%s)", mkt.EnName, m.Addition3, m.Addition4)
					}
					fmt.Printf("【自动变赔-基准分玩法】赛事ID[%s],盘口ID[%s],盘口名称[%s],玩法ID[%s],盘口基准分:[%s]->[%s]\n", match.ID, m.ID, record["cn_name"], m.OddTypeID, mkt.ScoreBenchmark, record["score_benchmark"])
				}
			}
		}

		if len(record) != 0 {
			if m.Status == TYStatusClosed && mkt.Status == MarketStatusSettled { //已结算盘口,忽略设置盘口隐藏状态
				continue
			}
			var notify []mqtt.MarketNotify
			notify = append(notify, mqtt.MarketNotify{MarketID: m.ID, OperateType: 1})
			record["update_by_name"] = "TY"
			record["update_time"] = time.Now().Unix()
			err = MarketUpdate(mchId, record, ex)
			if err != nil {
				fmt.Printf("【自动变赔】MarketUpdate,赛事ID[%s],盘口ID[%s]盘口更新 Error:%s\n", mchId, m.ID, err.Error())
				return err
			}

			if bUpdateBenchmark {
				var notify []mqtt.MarketNotify
				notify = append(notify, mqtt.MarketNotify{MarketID: m.ID, OperateType: 1})
				mqtt.MqttNotifyMarketNameUpdate(mchId, m.ID, record["cn_name"].(string), record["en_name"].(string), record["score_benchmark"].(string))
				mktLog.Action = "盘口基准分"
				mktLog.Result = fmt.Sprintf("【玩法ID】:%s 【盘口名称】:%s \n【基准分】:%s", m.OddTypeID, record["cn_name"].(string), record["score_benchmark"].(string))
				mqtt.MqttNotifyMarketLogPub(mktLog)
			}

			for k, v := range record {
				switch k {
				case "suspended":
					mqtt.MqttNotifyMarketSuspended(notify, v.(int), mchId)
					l := fmt.Sprintf("【自动变赔-盘口暂停】变更时间：%s 赛事SID：%s 赛事ID:%s  盘口ID:%s 盘口暂停状态:%s->%s\n", timeStr, data.StandardMatchInfoId, match.ID, mkt.ID, SuspendedStatus[mkt.Suspended], SuspendedStatus[v.(int)])
					fmt.Println(l)
					mktLog.Action = "盘口暂停"
					mktLog.Result = fmt.Sprintf("【状态】:%v", SuspendedStatus[v.(int)])
					mqtt.MqttNotifyMarketLogPub(mktLog)
				case "visible":
					mqtt.MqttNotifyMarketVisible(notify, mchId, v.(int))
					l := fmt.Sprintf("【自动变赔-盘口隐藏】变更时间：%s 赛事SID：%s 赛事ID：%s 盘口ID:%s 盘口隐藏状态:%s->%s\n", timeStr, data.StandardMatchInfoId, match.ID, mkt.ID, VisibleStatus[mkt.Visible], VisibleStatus[v.(int)])
					fmt.Println(l)
					mktLog.Action = "盘口隐藏"
					mktLog.Result = fmt.Sprintf("【状态】:%v", VisibleStatus[v.(int)])
					mqtt.MqttNotifyMarketLogPub(mktLog)
				case "status":
					mqtt.MqttNotifyMarketStatus(mchId, []string{m.ID}, v.(int), nil)
					l := fmt.Sprintf("【自动变赔-盘口状态】变更时间：%s 赛事SID：%s 赛事ID：%s 盘口ID:%s 盘口状态:%s->%s\n", timeStr, data.StandardMatchInfoId, match.ID, mkt.ID, MktStatus[mkt.Status], MktStatus[v.(int)])
					fmt.Println(l)
					mktLog.Action = "盘口状态"
					mktLog.Result = fmt.Sprintf("【状态】:%v", VisibleStatus[v.(int)])
					mqtt.MqttNotifyMarketLogPub(mktLog)
				}
			}
		}

		for _, o := range m.MarketOddsList {
			//盘口及赔率变更的条件：赛事状态(开盘)
			if match.Status != MatchStatusOpened {
				continue
			}
			oddData := handicapInfo.Odds[o.ID]
			oddRecord := g.Record{}
			oddEx := g.Ex{"id": o.ID}
			switch o.OddsStatus {
			// 1-开盘
			case TYOddStatusOpen:
				if oddData.Visible != VisibleOpen {
					oddRecord["visible"] = VisibleOpen
					l := fmt.Sprintf("【自动变赔-隐藏选项】变更时间：%s 赛事SID：%s 赛事ID：%s 盘口ID:%s 投注项ID:%s 投注项隐藏状态:%s->%s\n", timeStr, data.StandardMatchInfoId, match.ID, mkt.ID, o.ID, VisibleStatus[oddData.Visible], VisibleStatus[VisibleOpen])
					fmt.Println(l)
					mktLog.Action = "隐藏选项"
					mktLog.Result = fmt.Sprintf("【选项名称】:%v 【显示状态】:%v", oddData.Name, VisibleStatus[VisibleOpen])
					mqtt.MqttNotifyMarketLogPub(mktLog)
				}
				if oddData.Suspended != SuspendedClose {
					oddRecord["suspended"] = SuspendedClose
					l := fmt.Sprintf("【自动变赔-暂停选项】变更时间：%s 赛事SID：%s 赛事ID：%s 盘口ID:%s 投注项ID:%s 投注项暂停状态:%s->%s\n", timeStr, data.StandardMatchInfoId, match.ID, mkt.ID, o.ID, SuspendedStatus[oddData.Suspended], SuspendedStatus[SuspendedClose])
					fmt.Println(l)
					mktLog.Action = "暂停选项"
					mktLog.Result = fmt.Sprintf("【选项名称】:%v 【暂停状态】:%v", oddData.Name, SuspendedStatus[SuspendedClose])
					mqtt.MqttNotifyMarketLogPub(mktLog)
				}
			// 2-封盘  4-锁盘
			case TYOddStatusSeal, TYOddStatusLock:
				if oddData.Suspended != SuspendedOpen {
					oddRecord["suspended"] = SuspendedOpen
					l := fmt.Sprintf("【自动变赔-暂停选项】变更时间：%s 赛事SID：%s 赛事ID：%s 盘口ID:%s 投注项ID:%s 投注项暂停状态:%s->%s\n", timeStr, data.StandardMatchInfoId, match.ID, mkt.ID, o.ID, SuspendedStatus[oddData.Suspended], SuspendedStatus[SuspendedOpen])
					fmt.Println(l)
					mktLog.Action = "暂停选项"
					mktLog.Result = fmt.Sprintf("【选项名称】:%v 【暂停状态】:%v", oddData.Name, SuspendedStatus[SuspendedClose])
					mqtt.MqttNotifyMarketLogPub(mktLog)
				}
			// 3-关盘
			case TYOddStatusClosed:
				if oddData.Visible != VisibleClose {
					oddRecord["visible"] = VisibleClose
					l := fmt.Sprintf("【自动变赔-隐藏选项】变更时间：%s 赛事SID：%s 赛事ID：%s 盘口ID:%s 投注项ID:%s 投注项隐藏状态:%s->%s\n", timeStr, data.StandardMatchInfoId, match.ID, mkt.ID, o.ID, VisibleStatus[oddData.Visible], VisibleStatus[VisibleClose])
					fmt.Println(l)
					mktLog.Action = "隐藏选项"
					mktLog.Result = fmt.Sprintf("【选项名称】:%v 【显示状态】:%v", oddData.Name, VisibleStatus[VisibleOpen])
					mqtt.MqttNotifyMarketLogPub(mktLog)
				}
			}
			odd := decimal.NewFromInt(int64(o.PaOddsValue)).Div(TYOddMultiple).RoundFloor(2).String()
			oldOdd := oddData.Odd
			if odd != oldOdd {
				oddRecord["odd"] = odd
				records = append(records, OdUpdate{
					Record: oddRecord,
					Ex:     oddEx,
				})
				l := fmt.Sprintf("【自动变赔-赔率】变更时间：%s 赛事SID：%s 赛事ID：%s 盘口ID:%s 投注项ID：%s 自动变赔:%s->%s\n", timeStr, data.StandardMatchInfoId, match.ID, mkt.ID, o.ID, oldOdd, odd)
				fmt.Println(l)
				mktLog.Action = "自动变赔"
				mktLog.Result = fmt.Sprintf("【选项名称】:%s 【赔率】:%s -> %s\n", oddData.Name, oldOdd, odd)
				mqtt.MqttNotifyMarketLogPub(mktLog)
				odds = append(odds, OddUpdateItem{
					MarketId: m.ID,
					MatchId:  mchId,
					ID:       o.ID,
					Odd:      odd,
				})
			}
		}
		if len(records) != 0 {
			err = oddUpdate(pipe, mchId, mkt.ID, records, defaultMktId)
			if err != nil {
				fmt.Printf("【自动变赔-赛事ID:%s】更新盘口ID[%s]投注项,错误[%s]\n", mchId, mkt.ID, err.Error())
				return err
			}

			for _, oUpdate := range records {
				oddMqtt(oUpdate, mchId, mkt.ID)
			}
			// 赔率变更推送
			mqtt.MqttNotifyOddUpdate(odds)
		}
		_, err = pipe.Exec()
		if err != nil {
			fmt.Printf("【自动变赔-赛事ID:%s】更新盘口ID[%s]投注项ID,pipe.Exec 错误[%s]\n", mchId, mkt.ID, err.Error())
			fmt.Println(err.Error())
		}
		_ = pipe.Close()
	}

	if bUpdateMatchCount {
		go updateGameMatchTotal(handicapInfo.Matches[mchId], "自动变赔")
	}

	return nil
}

/**
* @Description: 投注想隐藏/显示,暂停/取消暂停状态推送
* @Author: noah
* @Date: 2021/12/29 15:51
* @LastEditTime:2021/12/29 15:51
* @LastEditors: noah
 */
func oddMqtt(data OdUpdate, mchId, mktId string) {

	oid := data.Ex["id"].(string)
	for k, v := range data.Record {
		switch k {
		case "suspended":
			// mqtt通知投注项暂停/取消暂停
			mqtt.MqttNotifyOddSuspendedUpdate(mktId, mchId, oid, v.(int))

		case "visible":
			// mqtt通知投注项隐藏/显示
			mqtt.MqttNotifyOddVisibleUpdate(mktId, mchId, oid, v.(int))
		}
	}
}

/*
 * @Description: 盘口状态更新,同步更新游戏客户端的赛事相关统计(联赛,早盘,滚盘等)
 * @Author: robin
 * @Date: 2021/12/28 12:12
 * @LastEditTime: 2021/12/28 12:12
 * @LastEditors: robin
 */

func updateGameMatchTotal(match utils.MatchData, strMenu string) {

	matchVisible := match.Visible
	//查询统计赛事【已开盘,已结算】并且显示的盘口数量
	mkCount, err := MarketCount(g.Ex{"status": []int{MarketStatusOpen, MarketStatusSettled}, "visible": VisibleOpen, "match_id": match.ID})
	if err != nil {
		fmt.Printf("【盘口状态RocketMQ消息更新:%s】MarketCount, 【已开盘,已结算】并且显示的盘口数,Error:%s \n", match.ID, err.Error())
		return
	}

	strAction := ""
	if mkCount == 0 && match.Visible == VisibleOpen { // 【已开盘,已结算】并且显示的盘口数量
		matchVisible = VisibleClose
		strAction = "赛事隐藏"
	}

	if !GetMatchTradeStatus(match.SID) { //若电竞操盘界面 已操作赛事(暂停,隐藏) 则不能根据盘口数量进行设置赛事显示状态
		if mkCount > 0 && match.Visible == VisibleClose { // 【已开盘,已结算】并且显示的盘口数量
			matchVisible = VisibleOpen
			strAction = "赛事显示"
		}
		fmt.Printf("【RocketMQ消息更新,赛事ID:%s】消息类型[%s],根据盘口数量进行设置赛事显示状态[%s]\n", match.ID, strMenu, VisibleStatus[matchVisible])
	} else {
		fmt.Printf("【RocketMQ消息更新,赛事ID:%s】消息类型[%s],电竞操盘界面 已操作赛事(暂停,隐藏),忽略设置赛事显示状态[%s]\n", match.ID, strMenu, VisibleStatus[matchVisible])
	}

	// 更新数据
	record := g.Record{
		"update_by_name": "TY",
		"update_time":    time.Now().Unix(),
		"visible":        matchVisible,
	}
	nodes := []utils.MatchBrief{{
		ID:          match.ID,
		Category:    match.Category,
		GameID:      match.GameID,
		StartTime:   match.StartTime,
		Status:      match.Status,
		Visible:     matchVisible,
		LiveSupport: match.LiveSupport,
		IsPassOff:   match.IsPassOff,
		IsLive:      match.IsLive,
		MktCount:    mkCount,
	}}

	err = MatchUpdate(record, g.Ex{"id": match.ID}, nodes)
	if err != nil {
		fmt.Printf("【盘口状态RocketMQ消息更新:%s】MatchUpdate,赛事更新错误,Error:%s\n", match.ID, err.Error())
		return
	}

	// 更新游戏客户端-前端赛事盘口数
	err = MarketCountUpdate(match.ID, int(mkCount))
	if err != nil {
		fmt.Printf("【盘口状态RocketMQ消息更新:%s】MarketCountUpdate,更新游戏客户端-前端赛事盘口数,Error: %s \n", match.ID, err.Error())
		return
	}

	//操盘界面-盘口数统计(待开盘,可投注,暂停,隐藏)
	mkts, err := MarketListDB(g.Ex{
		"match_id": match.ID,
		"status":   []int{MarketStatusWaitOpen, MarketStatusOpen},
	})
	if err != nil {
		fmt.Println(err.Error())
		return
	}

	counts := CalcMarketCountGet(mkts)
	mqtt.MqttNotifyMarketCountsUpdate(match.ID, counts)

	if len(strAction) == 0 {
		return
	}

	if match.Visible == matchVisible {
		return
	}

	//(赛事显示,隐藏)更新游戏赛事计数
	err = MatchGameNavCountStat(match.GameID)
	if err != nil {
		fmt.Printf("【盘口状态RocketMQ消息更新:%s】MatchGameNavCountStat,(赛事显示,隐藏)更新游戏赛事计数错误,Error: %v\n ", match.ID, err.Error())
		return
	}

	//(赛事显示,隐藏)更新联赛缓存
	err = GameTourCacheUpdate(match.GameID, match.TournamentID, match.ID, match.StartTime, matchVisible == VisibleOpen && match.Status == MatchStatusOpened)
	if err != nil {
		fmt.Printf("【盘口状态RocketMQ消息更新:%s】GameTourCacheUpdate,(赛事显示,隐藏)更新联赛缓存错误,Error: %v\n ", match.ID, err.Error())
		return
	}

	mqtt.MqttNotifyMatchVisibleUpdate([]string{match.ID}, matchVisible)

	matchLog := utils.TDMatch{
		TS:                  "now",
		User:                "TY",
		Group:               "0",
		IP:                  "0",
		Menu:                strMenu,
		Action:              strAction,
		GameID:              match.GameID,
		GameShortName:       GameName[match.GameID],
		TournamentId:        match.TournamentID,
		TournamentShortName: TournamentGetName(match.TournamentID),
		Teams:               match.MatchCnTeam,
		MatchID:             match.ID,
		Result:              fmt.Sprintf("【赛事显示】:%v 【显示盘口数量】:%d", VisibleStatus[matchVisible], mkCount),
	}
	mqtt.MqttNotifyMatchLogPub(matchLog)
}

/*
 * @Description: 盘口结算-盘口计数
 * @Author: robin
 * @Date: 2022/2/6 13:26
 * @LastEditTime: 2022/2/6 13:26
 * @LastEditors: robin
 */
func updateMarketSettleCountTotal(match utils.MatchData) {

	//查询统计赛事【已开盘,已结算】并且显示的盘口数量
	mkCount, err := MarketCount(g.Ex{"status": []int{MarketStatusOpen, MarketStatusSettled}, "visible": VisibleOpen, "match_id": match.ID})
	if err != nil {
		fmt.Printf("【盘口状态RocketMQ消息更新:%s】MarketCount,【已开盘,已结算】并且显示的盘口数,Error:%s \n", match.ID, err.Error())
		return
	}

	// 更新游戏客户端-前端赛事盘口数
	err = MarketCountUpdate(match.ID, int(mkCount))
	if err != nil {
		fmt.Printf("【盘口状态RocketMQ消息更新:%s】MarketCountUpdate,更新游戏客户端-前端赛事盘口数,Error: %s \n", match.ID, err.Error())
		return
	}

	//操盘界面-盘口数统计(待开盘,可投注,暂停,隐藏)
	mkts, err := MarketListDB(g.Ex{
		"match_id": match.ID,
		"status":   []int{MarketStatusWaitOpen, MarketStatusOpen},
	})
	if err != nil {
		fmt.Println(err.Error())
		return
	}

	counts := CalcMarketCountGet(mkts)
	mqtt.MqttNotifyMarketCountsUpdate(match.ID, counts)

	matchLog := utils.TDMatch{
		TS:                  "now",
		User:                "TY",
		Group:               "0",
		IP:                  "0",
		Menu:                "盘口结算",
		Action:              "盘口计数",
		GameID:              match.GameID,
		GameShortName:       GameName[match.GameID],
		TournamentId:        match.TournamentID,
		TournamentShortName: TournamentGetName(match.TournamentID),
		Teams:               match.MatchCnTeam,
		MatchID:             match.ID,
		Result:              fmt.Sprintf("【赛事显示】:%v 【显示盘口数量】:%d", VisibleStatus[match.Visible], mkCount),
	}
	mqtt.MqttNotifyMatchLogPub(matchLog)
}

/**
* @Description: 赔率更新
* @Author: noah
* @Date: 2021/12/17 18:53
* @LastEditTime:2021/12/17 18:53
* @LastEditors: noah
 */
func oddUpdate(pipe redis.Pipeliner, matchId, marketId string, records []OdUpdate, defaultMktId string) error {

	var strSQL string
	for i := range records {
		query, _, _ := dialect.Update(TblOdds).Set(records[i].Record).Where(records[i].Ex).ToSQL()
		strSQL = strSQL + query + ";"
	}

	dbConn, err := zkDB.Begin()
	if err != nil {
		return err
	}

	if strSQL != "" {
		_, err = dbConn.Exec(strSQL)
		if err != nil {
			_ = dbConn.Rollback()
			return err
		}
	}

	// 更新盘口缓存
	for _, rec := range records {
		utils.MarketCacheOddUpdate(pipe, matchId, marketId, rec.Record, rec.Ex, defaultMktId)
	}
	_, err = pipe.Exec()
	if err != nil {
		_ = dbConn.Rollback()
		return err
	}

	return dbConn.Commit()
}

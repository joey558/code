package zlog

import (
	"fmt"
	"github.com/bet365/jingo"
	mqtt "github.com/eclipse/paho.mqtt.golang"
	jsoniter "github.com/json-iterator/go"
	"github.com/valyala/fasthttp"
	"log"
	"net/url"
	"runtime"
	"strings"
	"time"
)

var json = jsoniter.ConfigCompatibleWithStandardLibrary

//zlog消息
type record struct {
	Cid      string `json:"cid"`
	Flags    string `json:"flags"`
	Merchant uint64 `json:"merchant"`
	Level    string `json:"level"`
	Line     string `json:"line"`
	Msg      string `json:"msg"`
	Ip       string `json:"ip"`
}

var (
	conn mqtt.Client
	uri  = "23.99.118.176:3100"
	enc  = jingo.NewStructEncoder(record{})
)

type LokiRequest struct {
	Status string `json:"status"`
	Data   struct {
		ResultType string `json:"resultType"`
		Result     []struct {
			Stream map[string]string `json:"stream"`
			Values [][]string        `json:"values"`
		} `json:"result"`
	} `json:"data"`
}

func New(hosts []string, query string) {
	uri = query
	fmt.Printf("【Zlog日志】 host[%v], uri[%s]\n", hosts, uri)
	clientOptions := mqtt.NewClientOptions().
		SetClientID(fmt.Sprintf("%d", time.Now().UnixNano())).
		SetCleanSession(false).
		SetAutoReconnect(true).
		SetKeepAlive(120 * time.Second).
		SetPingTimeout(10 * time.Second).
		SetWriteTimeout(10 * time.Second).
		SetMaxReconnectInterval(10 * time.Second)

	for _, v := range hosts {
		clientOptions.AddBroker(v)
	}

	conn = mqtt.NewClient(clientOptions)
	if conn := conn.Connect(); conn.WaitTimeout(time.Duration(10)*time.Second) && conn.Wait() && conn.Error() != nil {
		log.Fatalf("【Zlog日志】 connect, Error:%s\n", conn.Error())
	}
	fmt.Print("【log日志】 Connect finish.\n")
}

// 发送日志
func write(p record) error {

	buf := jingo.NewBufferFromPool()
	enc.Marshal(&p, buf)

	if token := conn.Publish("logger", 0, false, buf.String()); token.Wait() && token.Error() != nil {
		buf.ReturnToPool()
		return token.Error()
	}
	buf.ReturnToPool()
	return nil
}

func Notice(ctx *fasthttp.RequestCtx, flags, line, msg string, cid, merchantId uint64) uint64 {

	var id uint64

	if cid == 0 {
		id = Cputicks()
	} else {
		id = cid
	}
	tag := "NOTICE"

	data := record{
		Cid:      fmt.Sprintf("%d", id),
		Flags:    flags,
		Merchant: merchantId,
		Msg:      msg,
		Line:     line,
		Level:    tag,
		Ip:       FromRequest(ctx),
	}
	write(data)

	return id
}

func Error(ctx *fasthttp.RequestCtx, flags, line, msg string, cid interface{}, merchantId uint64) {

	id := ""
	if value, ok := cid.(string); ok {
		id = value
	}
	if value, ok := cid.(uint64); ok {
		id = fmt.Sprintf("%d", value)
	}

	tag := "ERROR"
	data := record{
		Cid:      id,
		Flags:    flags,
		Merchant: merchantId,
		Msg:      msg,
		Line:     line,
		Level:    tag,
		Ip:       "0",
	}
	if ctx != nil {
		data.Ip = FromRequest(ctx)
	}

	write(data)
}

func Info(ctx *fasthttp.RequestCtx, flags, line, msg string, cid interface{}, merchantId uint64) {

	id := ""

	if value, ok := cid.(string); ok {
		id = value
	}
	if value, ok := cid.(uint64); ok {
		id = fmt.Sprintf("%d", value)
	}
	ip := ""
	if ctx != nil {
		ip = FromRequest(ctx)
	}
	tag := "INFO"
	data := record{
		Cid:      id,
		Flags:    flags,
		Merchant: merchantId,
		Msg:      msg,
		Line:     line,
		Level:    tag,
		Ip:       ip,
	}

	if flags == "adminLogin" {
		data.Cid = msg
	}
	write(data)

}

// 查询loki log
func Search(query string, v url.Values) ([][]string, error) {

	res := [][]string{}
	if v == nil {
		v = url.Values{}
	}
	v.Add("direction", "BACKWARD")
	v.Add("query", query)

	//path := fmt.Sprintf("http://%s/loki/api/v1/query_range?%s", uri, v.Encode())
	path := fmt.Sprintf("%sloki/api/v1/query_range?%s", uri, v.Encode())
	statusCode, body, err := fasthttp.GetTimeout(nil, path, time.Duration(10)*time.Second)
	if err != nil {
		return res, err
	}

	if statusCode != fasthttp.StatusOK {
		return res, fmt.Errorf("zlog Search err: %d", statusCode)
	}

	loki := LokiRequest{}
	err = json.Unmarshal(body, &loki)
	if err != nil || len(loki.Data.Result) == 0 {
		return res, err
	}
	for _, v := range loki.Data.Result {
		res = append(res, v.Values...)
	}
	return res, nil

}

var (
	sysType = runtime.GOOS
)

// ErrFmt 格式化错误信息
func ErrFmt(err error) string {

	errStr := fmt.Sprintf("%+v", err)
	if sysType != "linux" {
		fmt.Println(errStr)
	}

	//为了页面展示
	return strings.ReplaceAll(strings.ReplaceAll(errStr, "\t", " "), "\n", "<br>")
}

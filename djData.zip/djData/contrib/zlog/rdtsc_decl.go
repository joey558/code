package zlog

func Cputicks() (t uint64)

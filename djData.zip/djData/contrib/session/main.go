package session

import (
	// "log"
	"errors"
	"fmt"
	"github.com/go-redis/redis/v7"
	"github.com/valyala/fasthttp"
)

var client *redis.Client

const (
	RedisUuid       = "S:TI%d" // 用户token key
	RedisSessionKey = "S:%s"   // 用户session key
)

func New(reddb *redis.Client) {
	client = reddb
}

func Set(ctx *fasthttp.RequestCtx, value []byte, uid uint64) (string, error) {

	uuid := fmt.Sprintf(RedisUuid, uid)
	token := fmt.Sprintf("%d", Cputicks())
	key := fmt.Sprintf(RedisSessionKey, token)

	val := client.Get(uuid).Val()
	pipe := client.TxPipeline()
	defer pipe.Close()

	if len(val) > 0 {
		// 同一个用户，一个时间段，只能登录一个
		pipe.Unlink(fmt.Sprintf(RedisSessionKey, val))
	}
	pipe.Set(uuid, token, -1)
	pipe.SetNX(key, value, defaultGCLifetime)

	_, err := pipe.Exec()

	return token, err
}

func Offline(uid uint64) {

	uuid := fmt.Sprintf(RedisUuid, uid)
	val := client.Get(uuid).Val()

	if len(val) > 0 {
		key := fmt.Sprintf(RedisSessionKey, val)
		client.Unlink(key, uuid)
	}

	return
}

func Destroy(ctx *fasthttp.RequestCtx) {

	key := string(ctx.Request.Header.Peek("token"))
	if len(key) == 0 {
		return
	}
	client.Unlink(fmt.Sprintf(RedisSessionKey, key))
	// cookie.Delete(ctx, defaultSessionKeyName)
}

func Get(ctx *fasthttp.RequestCtx) ([]byte, error) {

	key := string(ctx.Request.Header.Peek("token"))
	if len(key) == 0 {
		return nil, errors.New("does not exist")
	}

	val, err := client.Get(fmt.Sprintf(RedisSessionKey, key)).Bytes()
	if err == redis.Nil {
		return nil, errors.New("does not exist")
	} else if err != nil {
		return nil, err
	} else {
		return val, nil
	}
}

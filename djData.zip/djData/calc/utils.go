package calc

import (
	"errors"
	"strconv"
	"strings"

	"github.com/shopspring/decimal"
)

var (
	MinOddDeci    = decimal.NewFromFloat(1.01)     // 最低赔率值1.01
	MaxTwoOddDeci = decimal.NewFromFloat(31.5)     // 两项盘最高赔率值31.5
	MaxOddDeci    = decimal.NewFromFloat(9999.999) // 最高赔率值9999.999
)

// 判断字符是否为数字
func isDigit(r rune) bool {
	return '0' <= r && r <= '9'
}

// 判断字符串是不是数字
func CtypeDigit(s string) bool {

	_, err := strconv.ParseInt(s, 10, 64)
	if err != nil {
		return false
	}
	return true
}

/*
* @Description: decimal对像去尾补0
* @Author: xp
* @Date: 2021/10/17 10:08
* @LastEditTime: 2021/10/17 10:08
* @LastEditors: xp
 */
func TrimDecimal(val decimal.Decimal) string {

	s := "0.000"
	sDigit := strings.Split(val.String(), ".")
	if len(sDigit) != 2 {
		if len(sDigit) == 1 && CtypeDigit(sDigit[0]) {
			return sDigit[0] + ".000"
		}
		return s
	}

	// 浮点位数校验
	if len(sDigit[1]) <= 3 {
		return val.StringFixed(3)
	}

	return sDigit[0] + "." + sDigit[1][:3]
}

/**
* @Description: 字符串去尾补0
* @Author: xp
* @Date: 2021/10/17 10:08
* @LastEditTime: 2021/10/17 10:08
* @LastEditors: xp
 */
func TrimString(val string) string {

	dec, err := decimal.NewFromString(val)
	if err != nil {
		return val
	}

	return TrimDecimal(dec)
}

/**
* @Description: 浮点数去尾补0
* @Author: daxie
* @Date: 2021/1/9 18:51
* @LastEditTime: 2021/1/9 18:51
* @LastEditors: xp
 */
func TrimFloat(val float64) string {

	dec := decimal.NewFromFloat(val)

	return TrimDecimal(dec)
}

// ReJsonDecodeU00xx
/**
* @Description: 去除转义
* @Author: noah
* @Date: 2021/10/27 19:22
* @LastEditTime:2021/10/27 19:22
* @LastEditors: noah
 */
func ReJsonDecodeU00xx(str []byte) (res []byte, err error) {

	l := len(str)
	for i := 0; i < l; {
		if '\\' == str[i] && i+6 <= l && 'u' == str[i+1] && '0' == str[i+2] && '0' == str[i+3] {
			a, o := unhex(str[i+4])
			if !o {
				err = errors.New("error:reJsonDecodeU00xx")
				return []byte{}, err
			}
			b, o := unhex(str[i+5])
			if !o {
				err = errors.New("error:reJsonDecodeU00xx")
				return []byte{}, err
			}
			c := a*16 + b
			res = append(res, c)
			i += 6
		} else {
			res = append(res, str[i])
			i++
		}
	}

	return res, err
}

func unhex(b uint8) (v uint8, ok bool) {

	c := b
	switch {
	case '0' <= c && c <= '9':
		return c - '0', true
	case 'a' <= c && c <= 'f':
		return c - 'a' + 10, true
	case 'A' <= c && c <= 'F':
		return c - 'A' + 10, true
	}

	return
}

/**
* @Description: 检查赔率阀值
* @Author: xp
* @Date: 2021/10/14
* @LastEditTime: 2021/10/14
* @LastEditors: xp
 */
func CheckOddLimit(odd decimal.Decimal, oddTotal int) error {

	if oddTotal < 2 {
		return errors.New("errInvalidParam")
	}

	if oddTotal == 2 {
		if odd.LessThan(MinOddDeci) || odd.GreaterThan(MaxTwoOddDeci) {
			return errors.New("errOddsOutOfRange")
		}
	} else {
		if odd.LessThan(MinOddDeci) || odd.GreaterThan(MaxOddDeci) {
			return errors.New("errOddsOutOfRange9999")
		}
	}

	return nil
}

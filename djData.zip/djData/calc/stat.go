package calc

import (
	"database/sql"
	"fmt"
	"strconv"
	"strings"
	"time"

	"github.com/scylladb/go-set"

	"github.com/scylladb/go-set/strset"

	g "github.com/doug-martin/goqu/v9"
	"github.com/doug-martin/goqu/v9/exp"
	"github.com/go-redis/redis/v7"
	"github.com/jmoiron/sqlx"
)

var (
	ColMatch  = EnumFields(GameIndex{})
	ColMarket = EnumFields(Market{})
	ColOdd    = EnumFields(Odd{})
)

// 赛事统计
type MatchCountStat struct {
	Today   int `db:"today" json:"today"`     // 今日
	Live    int `db:"live" json:"live"`       // 滚球
	Early   int `db:"early" json:"early"`     // 早盘
	Complex int `db:"complex" json:"complex"` // 串关
	Champ   int `db:"champ" json:"champ"`     // 冠军
	Anchor  int `db:"anchor" json:"anchor"`   // 主播
	Total   int `db:"total" json:"total"`     // 总数
}

// 赛事统计数据
type MatchCountStatData struct {
	MerchantId uint64         `db:"merchant_id" json:"merchant_id"`
	GameId     string         `db:"game_id" json:"game_id"`
	Stats      MatchCountStat `db:"stats" json:"stats"`
	StatsAll   MatchCountStat `db:"stats_all" json:"stats_all"`
}

/**
 * @Description: 获取赛事数量
 * @Author: wesley
 * @Date: 2020/6/27 20:36
 * @LastEditTime: 2020/6/27 20:36
 * @LastEditors: wesley
 */
func matchGameIndexCount(db *sqlx.DB, ex ...exp.Expression) (int, error) {

	var count int
	query, _, _ := g.Dialect("mysql").From("tbl_matches").Select(g.COUNT(1)).Where(ex...).ToSQL()
	Println(query)
	err := db.Get(&count, query)
	if err != nil {
		Println("count matches err:", err.Error())
	}

	return count, err
}

/**
 * @Description: 获取赛事信息
 * @Author: maxic
 * @Date: 2020/8/27
 * @LastEditTime: 2020/8/27
 * @LastEditors: maxic
 **/
func matchGameIndexGet(data interface{}, db *sqlx.DB, fields []interface{}, ex ...exp.Expression) error {

	if len(fields) == 0 {
		fields = ColMatch
	}
	query, _, _ := g.Dialect("mysql").From("tbl_matches").Select(fields...).Where(ex...).ToSQL()
	Println(query)
	err := db.Select(data, query)
	if err != nil {
		Println("select matches err:", err.Error())
	}

	return err
}

/**
 * @Description: 获取赛事信息
 * @Author: maxic
 * @Date: 2020/9/16
 * @LastEditTime: 2020/9/16
 * @LastEditors: maxic
 **/
func matchGameIndexUnionGet(data interface{}, db *sqlx.DB, fields []interface{}, ex ...exp.Expression) error {

	if len(fields) == 0 {
		fields = ColMatch
	}

	var ds []*g.SelectDataset
	for _, e := range ex {
		ds = append(ds, g.Dialect("mysql").From("tbl_matches").Select(fields...).Where(e))
	}
	if len(ds) == 0 {
		return fmt.Errorf("param error")
	}
	sql := ds[0]
	for i, v := range ds {
		if i != 0 {
			sql = sql.Union(v)
		}
	}

	query, _, _ := sql.ToSQL()
	Println(query)
	err := db.Select(data, query)
	if err != nil {
		Println("select matches err:", err.Error())
	}

	return err
}

func matchGameViewGet(db *sqlx.DB, matchID string) (map[string]Market, map[string]Market, error) {

	def := map[string]Market{}
	data := map[string]Market{}

	// 获取盘口
	var markets []Market
	query, _, _ := g.Dialect("mysql").From("tbl_markets").Select(
		ColMarket...,
	).Where(g.Ex{
		"match_id": matchID,
	}).ToSQL()
	Println(query)
	err := db.Select(&markets, query)
	if err != nil {
		return def, data, err
	}

	// 获取赔率选项
	for i := range markets {
		market := &markets[i]
		market.Odds = map[string]Odd{}

		query, _, _ := g.Dialect("mysql").From("tbl_odds").Select(
			"id",
			"match_id",
			"market_id",
			"name",
			"en_name",
			"odd",
			"is_winner",
			"sort_id",
			"visible",
			"suspended",
			"team_id",
		).Where(g.Ex{
			"market_id": market.ID,
		}).ToSQL()
		var odds []Odd
		err := db.Select(&odds, query)
		if err != nil {
			return def, data, err
		}

		for _, odd := range odds {
			market.Odds["$"+odd.ID] = odd
		}
	}

	// 数据分组
	for _, market := range markets {
		if market.IsDefault == 1 {
			def["$"+market.ID] = market
		}
		data["$"+market.ID] = market
	}

	return def, data, err
}

/**
* @Description: 统计赛事盘口数
* @Author: wesley
* @Date: 2020/6/16 7:05 下午
* @LastEditTime: 2020/6/17 5:17 下午
* @LastEditors: wesley
 */
func matchMarketCount(db *sqlx.DB, ex g.Ex) (int, error) {

	var count int
	query, _, _ := g.Dialect("mysql").From("tbl_markets").Select(g.COUNT("id")).Where(ex).ToSQL()
	Println(query)
	err := db.Get(&count, query)

	return count, err
}

/**
 * @Description: 获取游戏导航类型的时间范围
 * @Author: maxic
 * @Date: 2020/9/18
 * @LastEditTime: 2020/9/18
 * @LastEditors: maxic
 **/
func GameNavTimeRangeGet(navFlag int) [2]int64 {

	t := time.Now()
	y, m, d := t.Date()
	today := time.Date(y, m, d, 0, 0, 0, 0, t.Location())
	tomorrow := today.AddDate(0, 0, 1)

	// 赛前 - 今日至30天内
	rangeEarly := [2]int64{0, tomorrow.AddDate(0, 0, 30).Unix() - 1}
	// 滚球 - 今日至30天内
	rangeLive := rangeEarly
	// 串关 - 今日至30天内
	rangeComplex := rangeEarly
	// 冠军 - 今日至5年内
	rangeChamp := [2]int64{0, tomorrow.AddDate(5, 0, 0).Unix() - 1}
	// 赛果 - 7天内至今日
	rangeResult := [2]int64{today.AddDate(0, 0, -6).Unix(), tomorrow.Unix() - 1}
	// 主播 - 今日至30天内
	rangeAnchor := [2]int64{0, tomorrow.AddDate(0, 0, 30).Unix() - 1}
	// 汇总 - 今日+赛前
	rangeAll := rangeEarly

	switch navFlag {
	case NavFlagAll:
		return rangeAll
	case NavFlagEarly:
		return rangeEarly
	case NavFlagComplex:
		return rangeComplex
	case NavFlagLive:
		return rangeLive
	case NavFlagResult:
		return rangeResult
	case NavFlagChamp:
		return rangeChamp
	case NavFlagAnchor:
		return rangeAnchor
	}

	return [2]int64{}
}

/**
 * @Description: 游戏导航赛事数，今日 滚球 赛前 串关 赛果计数
 * @Author: wesley
 * @Date: 2020/6/27 20:03
 * @LastEditTime: 2020/6/27 20:03
 * @LastEditors: wesley
 */
func GameNavMatchCountStat(pool *redis.Client, gameId string) (MatchCountStat, error) {

	result := MatchCountStat{}

	// 早盘
	setEarly, err := pool.ZRange(fmt.Sprintf(RedisGameEarly, gameId), 0, -1).Result()
	if err != nil {
		return result, err
	}
	cntEarly := len(setEarly)

	// 冠军
	setChamp, err := pool.ZRange(fmt.Sprintf(redisGameChamp, gameId), 0, -1).Result()
	if err != nil {
		return result, err
	}
	cntChamp := len(setChamp)

	// 滚球
	setLive, err := pool.ZRange(fmt.Sprintf(RedisGameLive, gameId), 0, -1).Result()
	if err != nil {
		return result, err
	}
	cntLive := len(setLive)

	// 串关
	cntComplex, err := pool.ZCard(fmt.Sprintf(RedisGameComplex, gameId)).Result()
	if err != nil {
		return result, err
	}

	// 主播
	setAnchor, err := pool.ZRange(fmt.Sprintf(redisGameAnchor, gameId), 0, -1).Result()
	if err != nil {
		return result, err
	}
	cntAnchor := len(setAnchor)

	// 汇总 - 滚球+早盘+冠军
	mapAll := map[string]bool{}
	for _, v := range setLive {
		if ok := mapAll[v]; ok {
			continue
		}
		mapAll[v] = true
	}
	for _, v := range setEarly {
		if ok := mapAll[v]; ok {
			continue
		}
		mapAll[v] = true
	}
	for _, v := range setChamp {
		if ok := mapAll[v]; ok {
			continue
		}
		mapAll[v] = true
	}
	for _, v := range setAnchor {
		if ok := mapAll[v]; ok {
			continue
		}
		mapAll[v] = true
	}

	cntAll := len(mapAll)

	// 赛事计数写入redis
	Printf("game[%v]: nav:%v, early:%v, complex:%v, live:%v, champ:%v, anchor:%v\n",
		gameId, cntAll, cntEarly, cntComplex, cntLive, cntChamp, cntAnchor)

	pipe := pool.Pipeline()
	defer pipe.Close()

	key := fmt.Sprintf(RedisGameNav, gameId)
	pipe.HSet(key, "count", cntAll)

	key = fmt.Sprintf(RedisGameNavCount, gameId)
	values := map[string]interface{}{
		"live":    cntLive,
		"early":   cntEarly,
		"complex": cntComplex,
		"champ":   cntChamp,
		"anchor":  cntAnchor,
		"total":   cntAll,
	}
	pipe.HMSet(key, values)
	_, err = pipe.Exec()
	if err != nil {
		return result, err
	}

	result.Live = cntLive
	result.Early = cntEarly
	result.Complex = int(cntComplex)
	result.Champ = cntChamp
	result.Anchor = cntAnchor
	result.Total = cntAll

	return result, err
}

/**
 * @Description: 游戏导航赛事数(通过赛事id获取游戏id, 再过滤)
 * @Author: xp
 * @Date: 2021/7/23 10:00
 * @LastEditTime: 2021/7/23 10:00
 * @LastEditors: xp
 */
func getFilteredCount(pipe redis.Pipeliner, filterSet *strset.Set) MatchCountStat {

	result := MatchCountStat{}

	// 获取赛事id,再通过赛事id获取game_id,过滤后再统计
	var cmds []*redis.StringSliceCmd
	rng := GameNavTimeRangeGet(NavFlagLive)
	val := pipe.ZRangeByScore(RedisGameLiveAll, &redis.ZRangeBy{Min: fmt.Sprintf("%d", rng[0]), Max: fmt.Sprintf("%d", rng[1])})
	cmds = append(cmds, val)

	rng = GameNavTimeRangeGet(NavFlagEarly)
	val = pipe.ZRangeByScore(RedisGameEarlyAll, &redis.ZRangeBy{Min: fmt.Sprintf("%d", rng[0]), Max: fmt.Sprintf("%d", rng[1])})
	cmds = append(cmds, val)

	rng = GameNavTimeRangeGet(NavFlagComplex)
	val = pipe.ZRangeByScore(RedisGameComplexAll, &redis.ZRangeBy{Min: fmt.Sprintf("%d", rng[0]), Max: fmt.Sprintf("%d", rng[1])})
	cmds = append(cmds, val)

	rng = GameNavTimeRangeGet(NavFlagChamp)
	val = pipe.ZRangeByScore(RedisGameChampAll, &redis.ZRangeBy{Min: fmt.Sprintf("%d", rng[0]), Max: fmt.Sprintf("%d", rng[1])})
	cmds = append(cmds, val)

	rng = GameNavTimeRangeGet(NavFlagAnchor)
	val = pipe.ZRangeByScore(RedisGameAnchorAll, &redis.ZRangeBy{Min: fmt.Sprintf("%d", rng[0]), Max: fmt.Sprintf("%d", rng[1])})
	cmds = append(cmds, val)

	_, err := pipe.Exec()
	if err != nil && err != redis.Nil {
		return result
	}

	totalAll := set.NewStringSet()
	for idx, cmdMatch := range cmds {
		matchIds, err := cmdMatch.Result()
		if err != nil && err != redis.Nil {
			return result
		}

		cmdMap := make(map[string]*redis.Cmd)
		for _, mchId := range matchIds {
			key := fmt.Sprintf(RedisGameView, mchId)
			cmdMap[mchId] = pipe.Do("JSON.GET", key, ".game_id")
		}
		_, err = pipe.Exec()
		if err != nil && err != redis.Nil {
			return result
		}

		count := 0
		for mchId, cmdInfo := range cmdMap {
			gameId, err := cmdInfo.Text()
			if err != nil {
				continue
			}

			gameId = strings.ReplaceAll(gameId, "\"", "")
			if gameId != "" && !filterSet.Has(gameId) {
				count = count + 1

				// 排除串关
				if idx != 2 {
					totalAll.Add(mchId)
				}
			}
		}

		switch idx {
		case 0:
			result.Live = count
		case 1:
			result.Early = count
		case 2:
			result.Complex = count
		case 3:
			result.Champ = count
		case 4:
			result.Anchor = count
		}
	}
	result.Total = totalAll.Size()

	return result
}

/**
 * @Description: 获取游戏导航赛事数，今日 滚球 赛前 串关 赛果计数, gameIds为空获取所有游戏
 * @Author: maxic
 * @Date: 2020/2/1
 * @LastEditTime: 2020/2/1
 * @LastEditors: maxic
 */
func GameNavMatchCountGet(pool *redis.Client, gameIds []string, filterGames *strset.Set) (MatchCountStat, error) {

	var data MatchCountStat

	pipe := pool.Pipeline()
	defer pipe.Close()

	if len(gameIds) == 0 { // 所有游戏
		data = getFilteredCount(pipe, filterGames)

	} else { // 指定游戏
		var results []*redis.SliceCmd

		for _, id := range gameIds {
			// 已过滤的游戏，不需要统计
			if filterGames.Has(id) {
				continue
			}

			key := fmt.Sprintf(RedisGameNavCount, id)
			val := pipe.HMGet(key, "live", "early", "complex", "champ", "anchor", "total")
			results = append(results, val)
		}

		_, err := pipe.Exec()
		if err != nil {
			return data, err
		}

		for _, result := range results {
			val, err := result.Result()
			if err != nil {
				return data, err
			}

			if val[0] == nil { // 对应游戏id的记录不存在
				continue
			}

			n, _ := strconv.Atoi(val[0].(string))
			data.Live += n

			n, _ = strconv.Atoi(val[1].(string))
			data.Early += n

			n, _ = strconv.Atoi(val[2].(string))
			data.Complex += n

			n, _ = strconv.Atoi(val[3].(string))
			data.Champ += n

			n, _ = strconv.Atoi(val[4].(string))
			data.Anchor += n

			n, _ = strconv.Atoi(val[5].(string))
			data.Total += n
		}
	}

	return data, nil
}

/**
 * @Description: 游戏导航赛事数，今日 滚球 赛前 串关 赛果计数
 * @Author: wesley
 * @Date: 2020/6/27 20:03
 * @LastEditTime: 2020/6/27 20:03
 * @LastEditors: wesley
 */
func GameNavMatchInit(db *sqlx.DB, pool *redis.Client, gameId string, rebuildCache bool) error {

	// 统计赛前（非滚球中）
	rang := GameNavTimeRangeGet(NavFlagEarly)
	exEarly := g.Ex{
		"status":     5, // 5-已开盘
		"game_id":    gameId,
		"visible":    1,
		"is_live":    1,                    // 1-赛前 2-滚球
		"category":   []int{1, 3, 4, 5, 6}, //  2-冠军
		"start_time": g.Op{"between": g.Range(rang[0], rang[1])},
	}

	// 统计滚球
	rang = GameNavTimeRangeGet(NavFlagLive)
	exLive := g.Ex{
		"status":       5, // 5-已开盘
		"game_id":      gameId,
		"live_support": 1,
		"visible":      1,
		"category":     []int{1, 3, 4, 5, 6}, //  2-冠军
		"start_time":   g.Op{"between": g.Range(rang[0], rang[1])},
	}

	// 统计串关
	rang = GameNavTimeRangeGet(NavFlagComplex)
	exComplex := g.Ex{
		"status":      5, // 5-已开盘
		"game_id":     gameId,
		"is_pass_off": []int{1, 2},
		"visible":     1,
		"category":    []int{1, 3, 4, 5, 6}, //  2-冠军
		"start_time":  g.Op{"between": g.Range(rang[0], rang[1])},
	}

	// 统计赛果
	rang = GameNavTimeRangeGet(NavFlagResult)
	exResult := g.Ex{
		"status":     []int{7, 9}, // 7-已结算 9-已取消
		"game_id":    gameId,
		"visible":    1,
		"start_time": g.Op{"between": g.Range(rang[0], rang[1])},
	}

	// 统计主播盘
	rang = GameNavTimeRangeGet(NavFlagEarly)
	exAnchor := g.Ex{
		"status":     5, // 5-已开盘
		"game_id":    gameId,
		"category":   5, // 主播盘
		"visible":    1,
		"start_time": g.Op{"between": g.Range(rang[0], rang[1])},
	}

	// 冠军盘已开盘时间范围： 0--5年内
	rangeChamp1 := GameNavTimeRangeGet(NavFlagChamp)

	// 冠军盘 已结算 已取消时间范围： -7 -- 当前时间
	t := time.Now()
	y, m, d := t.Date()
	today := time.Date(y, m, d, 0, 0, 0, 0, t.Location())
	startTime := today.AddDate(0, 0, -7).Unix()
	endTime := t.Unix()
	rangeChamp2 := []int64{startTime, endTime}

	exChamp := g.And(
		g.Ex{
			"game_id":  gameId,
			"category": MatchCategoryChampion, // 冠军-2
			"visible":  1,
		},
		g.Or(
			g.Ex{
				"status":     []int{MatchStatusOpened}, // 5-已开盘
				"start_time": g.Op{"between": g.Range(rangeChamp1[0], rangeChamp1[1])},
			},
			g.Ex{
				"status":     []int{MatchStatusClosed, MatchStatusSettle, MatchStatusCancel}, // 6-关盘 7-已结算 9-已取消
				"start_time": g.Op{"between": g.Range(rangeChamp2[0], rangeChamp2[1])}},
		),
	)

	exClose := g.Ex{
		"status":     6, // 6-已关盘
		"game_id":    gameId,
		"visible":    1,
		"start_time": g.Op{"between": g.Range(rang[0], rang[1])},
	}
	// 查询赛事
	var (
		earlyMatches     []MatchIndex
		liveMatches      []MatchIndex
		complexMatches   []MatchIndex
		resultMatches    []MatchIndex
		champMatches     []MatchIndex
		anchorMatches    []MatchIndex
		closeMatches     []MatchIndex
		closeMatchIdList []uint64
	)

	champMap := map[string]MatchIndex{}
	fields := []interface{}{"id", "start_time", "category", "status"}

	_ = matchGameIndexGet(&earlyMatches, db, fields, exEarly)
	_ = matchGameIndexGet(&liveMatches, db, fields, exLive)
	_ = matchGameIndexGet(&complexMatches, db, fields, exComplex)
	_ = matchGameIndexGet(&resultMatches, db, fields, exResult)
	_ = matchGameIndexGet(&champMatches, db, fields, exChamp)
	_ = matchGameIndexGet(&anchorMatches, db, fields, exAnchor)
	_ = matchGameIndexGet(&closeMatchIdList, db, []interface{}{"id"}, exClose)
	marketOpenCheck(db, fields, &earlyMatches)
	marketOpenCheck(db, fields, &liveMatches)
	marketOpenCheck(db, fields, &complexMatches)
	if len(closeMatchIdList) != 0 {
		ex := g.Ex{"status": 9, "match_id": closeMatchIdList, "visible": 1}
		ids, err := marketGetResultMatchList(db, ex)
		if err != nil {
			fmt.Println("marketGetResultMatchList err:", err.Error())
		}
		if len(ids) != 0 {
			exClose["id"] = ids
			_ = matchGameIndexGet(&closeMatches, db, fields, exClose)
		}
		for _, match := range closeMatches {
			resultMatches = append(resultMatches, match)
		}
	}

	pipe := pool.Pipeline()
	defer pipe.Close()

	// 初始化ZSet索引
	fnInitIndex := func(key, keyAll string, data []MatchIndex) {
		// 删除老数据 (函数调用前删除keyAll)
		pipe.Del(key)

		// 重新构建
		if len(data) > 0 {
			var z []*redis.Z
			for _, v := range data {
				startTime := v.StartTime
				//冠军盘
				if v.Category == MatchCategoryChampion {

					mktCount, err := matchMarketCount(db, g.Ex{"match_id": v.ID, "visible": 1})
					if err != nil {
						Println("get match market count error:", err.Error())
					}

					if mktCount == 0 { // 冠军盘  无有效显示中盘口  不统计
						continue
					}

					champMap[v.ID] = v
					if v.Status == MatchStatusClosed || v.Status == MatchStatusSettle || v.Status == MatchStatusCancel { //已结算 和已取消的 丢入zset最底部  排序使用
						startTime = v.StartTime + int64(100000000)
					}

				}

				z = append(z, &redis.Z{
					Score:  float64(startTime),
					Member: v.ID,
				})
			}
			pipe.ZAdd(key, z...)
			pipe.ZAdd(keyAll, z...)
		}
	}

	fnInitIndex(fmt.Sprintf(RedisGameEarly, gameId), RedisGameEarlyAll, earlyMatches)
	fnInitIndex(fmt.Sprintf(RedisGameLive, gameId), RedisGameLiveAll, liveMatches)
	fnInitIndex(fmt.Sprintf(RedisGameComplex, gameId), RedisGameComplexAll, complexMatches)
	fnInitIndex(fmt.Sprintf(redisGameResult, gameId), RedisGameResultAll, resultMatches)
	fnInitIndex(fmt.Sprintf(redisGameChamp, gameId), RedisGameChampAll, champMatches)
	fnInitIndex(fmt.Sprintf(redisGameAnchor, gameId), RedisGameAnchorAll, anchorMatches)

	// 计数
	// 汇总 - 滚球+赛前+冠军
	mapAll := map[string]bool{}
	for _, v := range liveMatches {
		mapAll[v.ID] = true
	}
	for _, v := range earlyMatches {
		if ok := mapAll[v.ID]; ok {
			continue
		}
		mapAll[v.ID] = true
	}
	for _, v := range champMap {
		if ok := mapAll[v.ID]; ok {
			continue
		}
		mapAll[v.ID] = true
	}
	for _, v := range anchorMatches {
		if ok := mapAll[v.ID]; ok {
			continue
		}
		mapAll[v.ID] = true
	}
	cntAll := len(mapAll)
	cntLive := len(liveMatches)
	cntEarly := len(earlyMatches)
	cntComplex := len(complexMatches)
	cntResult := len(resultMatches)
	cntChamp := len(champMap)
	cntAnchor := len(anchorMatches)

	Printf("game[%v]: nav:%v, early:%v, complex:%v, live:%v, result:%v, champ:%v, anchor:%v\n",
		gameId, cntAll, cntEarly, cntComplex, cntLive, cntResult, cntChamp, cntAnchor)

	// 赛事计数写入redis
	key := fmt.Sprintf(RedisGameNav, gameId)
	pipe.HSet(key, "count", cntAll)

	key = fmt.Sprintf(RedisGameNavCount, gameId)
	pipe.Del(key)
	values := map[string]interface{}{
		"live":    cntLive,
		"early":   cntEarly,
		"complex": cntComplex,
		"champ":   cntChamp,
		"anchor":  cntAnchor,
		"total":   cntAll,
	}
	pipe.HMSet(key, values)

	// 初始化赛事缓存
	if rebuildCache {
		var matches []GameIndex
		sTime := today.AddDate(0, 0, -10).Unix()
		exMch := g.And(
			g.Ex{
				"game_id": gameId,
			},
			g.Or(
				// 已录入、待开盘、开盘、关盘
				g.Ex{
					"status": []int{MatchStatusEntered, MatchStatusPending, MatchStatusWaitOpen, MatchStatusOpened, MatchStatusClosed, MatchStatusWaitCancel},
				},
				// 已结算、已取消 且 结算时间10天内的
				g.Ex{
					"status":   []int{MatchStatusSettle, MatchStatusCancel},
					"end_time": g.Op{"between": g.Range(sTime, endTime)},
				},
			),
		)
		err := matchGameIndexGet(&matches, db, nil, exMch)
		if err != nil {
			Println("get matches for rebuilding cache error:", err.Error())
		}

		// 更新缓存
		for _, match := range matches {
			match.Markets = map[string]Market{}

			// 查询统计赛事已开盘，已结算并且显示(visible=1)的盘口数量
			mktCount, err := matchMarketCount(db, g.Ex{"match_id": match.ID, "visible": 1, "status": []int{6, 9}})
			if err != nil {
				Println("get match market count error:", err.Error())
			}
			match.Count = mktCount

			// 更新赛事缓存
			data, err := json.Marshal(match)
			if err != nil {
				Println("marshal match error:", err.Error())
				continue
			}
			MatchCacheSet(pipe, match.ID, JPathMatch, data, true)

			// 更新默认盘口缓存
			defMarket, markets, err := matchGameViewGet(db, match.ID)
			data, err = json.Marshal(defMarket)
			if err != nil {
				Println("marshal default market error:", err.Error())
				continue
			}
			MatchCacheSet(pipe, match.ID, ".markets", data, true)

			// 更新盘口缓存
			data, err = json.Marshal(markets)
			if err != nil {
				Println("marshal market error:", err.Error())
				continue
			}
			MatchCacheSet(pipe, match.ID, ".markets", data, false)
		}
	}

	_, err := pipe.Exec()
	return err
}

// 初始化推荐赛事
func MatchRecInit(db *sqlx.DB, pool *redis.Client) error {

	pipe := pool.Pipeline()
	defer pipe.Close()

	// 查询推荐赛事
	var recMatches []MatchRec
	fields := []interface{}{"id", "rec", "start_time"}
	exRec := g.Ex{
		"rec":    g.Op{"gt": 0},
		"status": MatchStatusOpened,
	}
	err := matchGameIndexGet(&recMatches, db, fields, exRec)
	if err != nil {
		return err
	}

	// 删除旧的赛事推荐
	pipe.Del(RedisMatchRec)

	// 添加新的赛事推荐
	if len(recMatches) > 0 {
		var rz []*redis.Z
		for _, data := range recMatches {
			recScore := fmt.Sprintf("%d.%d", data.Rec, data.StartTime)
			score, err := strconv.ParseFloat(recScore, 64)
			if err != nil {
				return err
			}

			rz = append(rz, &redis.Z{
				Score:  score,
				Member: data.ID,
			})
		}
		pipe.ZAdd(RedisMatchRec, rz...)
	}

	_, err = pipe.Exec()
	return err
}

/*
* @Description: 获取已关盘有已结算盘口赛事
* @Author: noah
* @Date: 2021/6/12 14:30
* @LastEditTime: 2021/6/12 14:30
* @LastEditors: noah
 */
func marketGetResultMatchList(db *sqlx.DB, ex g.Ex) ([]uint64, error) {

	var data []uint64
	query, _, _ := dialect.From("tbl_markets").Select(g.DISTINCT("match_id")).Where(ex).ToSQL()
	err := db.Select(&data, query)

	return data, err
}

/*
* @Description: 盘口开盘检查
* @Author: noah
* @Date: 2021/6/17 14:47
* @LastEditTime: 2021/6/17 14:47
* @LastEditors: noah
 */
func marketOpenCheck(db *sqlx.DB, fields []interface{}, matches *[]MatchIndex) {

	var (
		matchIds []string
		data     []MatchIndex
	)

	if len(*matches) == 0 {
		return
	}

	for _, match := range *matches {
		matchIds = append(matchIds, match.ID)
	}
	ex := g.Ex{"status": 6, "match_id": matchIds, "visible": 1}
	ids, err := marketGetResultMatchList(db, ex)
	if err != nil {
		fmt.Println("marketGetResultMatchList err:", err.Error())
		return
	}
	if len(ids) == len(matchIds) {
		return
	}

	if len(ids) != 0 {
		_ = matchGameIndexGet(&data, db, fields, g.Ex{"id": ids})
	}
	*matches = data
}

func GameIndexFindOne(db *sqlx.DB, matchID string) (GameIndex, error) {

	data := GameIndex{}
	query, _, _ := dialect.From("tbl_matches").Where(g.Ex{"id": matchID}).Select(ColMatch...).Limit(1).ToSQL()
	err := db.Get(&data, query)
	if err == sql.ErrNoRows {
		return data, nil
	} else if err != nil {
		return data, err
	}

	// 查询统计赛事已开盘，已结算并且显示(visible=1)的盘口数量
	mktCount, err := matchMarketCount(db, g.Ex{"match_id": matchID, "visible": 1, "status": []int{6, 9}})
	if err != nil {
		Println("get match market count error:", err.Error())
	}
	data.Count = mktCount
	data.Markets = map[string]Market{}

	return data, nil
}

func MarketReJsonData(db *sqlx.DB, matchID string) (map[string]Market, map[string]Market, error) {
	def := map[string]Market{}
	data := map[string]Market{}

	// 获取盘口
	var markets []Market
	query, _, _ := g.Dialect("mysql").From("tbl_markets").Select(ColMarket...).Where(g.Ex{
		"match_id": matchID,
	}).ToSQL()
	err := db.Select(&markets, query)
	if err != nil {
		return def, data, err
	}

	var odds []Odd
	query, _, _ = g.Dialect("mysql").From("tbl_odds").Select(ColOdd...).Where(g.Ex{
		"match_id": matchID,
	}).ToSQL()
	err = db.Select(&odds, query)
	if err != nil {
		return def, data, err
	}

	mpMarketOdds := map[string][]Odd{}
	for _, o := range odds {
		mpMarketOdds[o.MarketID] = append(mpMarketOdds[o.MarketID], o)
	}

	// 获取赔率选项
	for i := range markets {
		market := &markets[i]
		market.Odds = map[string]Odd{}

		if mktOdds, ok := mpMarketOdds[market.ID]; ok {
			for _, odd := range mktOdds {
				market.Odds["$"+odd.ID] = odd
			}
		}
	}

	// 数据分组
	for _, market := range markets {
		if market.IsDefault == 1 {
			def["$"+market.ID] = market
		}
		data["$"+market.ID] = market
	}

	return def, data, err
}

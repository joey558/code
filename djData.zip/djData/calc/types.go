package calc

import "github.com/shopspring/decimal"

const (
	RedisGameNav            = "gnav:%s"           //前台游戏导航
	RedisGameNavCount       = "gnavcnt:%s"        //前台游戏导航赛事数
	RedisGameTour           = "gtour:%s"          //前台游戏联赛列表 gtour:<gameId>
	RedisGameTourMatch      = "gtour:%s:%s"       //前台游戏联赛赛事列表 gtour:<gameId>:<tourId>
	RedisGameTourChampMatch = "gtourChamp:%s:%s"  //前台游戏联赛冠军赛事列表 gtour:<gameId>:<tourId>
	redisMatchCalc          = "mch_calc:%s"       // 赛事注单统计key
	RedisRiskTagCalc        = "risk_calc:%s:%s"   // 赛事游戏风险标签统计(金额,单数) risk_calc:<match_id>:<risk_tag_id>
	RedisRiskBetCalc        = "risk_bet:%s:%s:%s" // 赛事游戏风险标签统计(人数) risk_bet:<match_id>:<member_id>:<risk_tag_id>
	RedisMatchRiskTag       = "match_risk_tag"    // 赛事游戏风险标签ID

	RedisMatchRec       = "mchRecommend" //推荐赛事Zset
	RedisGameLive       = "glive:%s"     //游戏赛事滚盘zset
	RedisGameEarly      = "gearly:%s"    //游戏赛事早盘zset
	RedisGameComplex    = "gcomplex:%s"  //游戏赛事串关zset
	redisGameResult     = "gresult:%s"   //游戏赛事赛果zset
	redisGameAnchor     = "ganchor:%s"   //游戏赛事主播盘zset
	redisGameChamp      = "gachamp:%s"   //游戏赛事冠军盘zset
	RedisGameLiveAll    = "galive"       //所有游戏赛事滚盘zset
	RedisGameEarlyAll   = "gaearly"      //所有游戏赛事早盘zset
	RedisGameComplexAll = "gacomplex"    //所有游戏赛事串关zset
	RedisGameResultAll  = "garesult"     //所有游戏赛事赛果zset
	RedisGameAnchorAll  = "ganchor"      //所有游戏赛事主播盘zset
	RedisGameChampAll   = "gachamp"      //所有游戏赛事冠军盘zset

	RedisGameIndex = "idx:%s" //前台赛事默认盘口列表rejson
	RedisGameView  = "mch:%s" //前台赛事盘口列表rejson

	JPathMatch       = "."                        // .
	JPathMatchField  = ".%s"                      // .[字段]
	JPathMarket      = ".markets.$%s"             // .markets.$[盘口ID]
	JPathMarketField = ".markets.$%s.%s"          // .markets.$[盘口ID].[字段]
	JPathOddField    = ".markets.$%s.odds.$%s.%s" // .markets.$[盘口ID].odds.$[选项ID].[字段]

	RedisMerchantFilterGame = "merchant_filter_game:%d" // 商户过滤游戏

	RedisForeCastCalc      = "forecast_calc:%s" // ForeCast Calc Key, forecast_calc:赛事id
	RedisForeCastCalcField = ".markets.$%s_%d.odds.$%s.amount[%d]"
)

// 赛事导航类型
const (
	NavFlagAll     = 0 // 0-所有
	NavFlagToday   = 1 // 1-今日
	NavFlagEarly   = 2 // 2-早盘
	NavFlagComplex = 3 // 3-滚球
	NavFlagLive    = 4 // 4-串关
	NavFlagResult  = 5 // 5-赛果
	NavFlagChamp   = 6 // 6-冠军
	NavFlagAnchor  = 7 // 7-主播
)

// 赛事类型 正常-1 冠军-2 大逃杀-3 篮球-4 主播盘-5 足球-6
const (
	MatchCategoryNormal     = 1
	MatchCategoryChampion   = 2
	MatchCategoryEscape     = 3
	MatchCategoryBasketball = 4
	MatchCategoryAnchor     = 5
	MatchCategoryFootball   = 6
)

const (
	MatchStatusEntered    = 1 // 已录入
	MatchStatusPending    = 2 // 待审核
	MatchStatusReject     = 3 // 驳回
	MatchStatusWaitOpen   = 4 // 待开盘
	MatchStatusOpened     = 5 // 开盘
	MatchStatusClosed     = 6 // 关盘
	MatchStatusSettle     = 7 // 结算
	MatchStatusWaitCancel = 8 // 待取消
	MatchStatusCancel     = 9 // 取消
)

// 盘口监控记录类型
const (
	MarketMonitorTypeSuspend = 0 // 暂停监控
	MarketMonitorTypeMonitor = 1 // 预警监控
)

// 盘口监控状态
const (
	MarketMonitorStatusWarning = 0 // 预警状态
	MarketMonitorStatusStop    = 1 // 超限状态
)

// 赔率联动常量
const (
	OddLinkageRuleMasterSlave = 1 // 1-主从
	OddLinkageRuleFixed       = 2 // 2-固定

	OddLinkageParamTypeWinRateOrDouble = 1 // 1-胜率 1-固定赔率-双倍返还率
	OddLinkageParamTypeRangeOrFixed    = 2 // 2-区间 2-固定赔率

	OddLinkageTagRange      = 1 // 1-区间参数
	OddLinkageTagAdditional = 2 // 2-附加赔率
	OddLinkageTagDouble     = 3 // 3-双倍返还率
	OddLinkageTagFixed      = 4 // 4-固定赔率
)

//盘口-玩法类型
const (
	OptionTypeWinLose         = 1  // 输赢
	OptionTypeHandicap        = 2  // 让分
	OptionTypeOverUnder       = 3  // 大小
	OptionTypePloy            = 4  // 趣味
	OptionTypeCorrectScore    = 5  // 波胆
	OptionType1X2             = 6  // 胜平负
	OptionTypeOddEven         = 7  // 单双
	OptionTypeYesNo           = 8  // 是否
	OptionTypeChampWin        = 10 // 猜冠军 单选
	OptionTypeChampWinMore    = 11 // 猜冠军 多选
	OptionTypeMix             = 12 // 复合玩法
	OptionTypePlayerWinLose   = 13 // 队员输赢
	OptionTypePlayerHandicap  = 14 // 队员让分
	OptionTypePlayerOverUnder = 15 // 队员大小
	OptionTypePlayerOddEven   = 16 // 队员单双
	OptionTypePlayerYesNo     = 17 // 队员是否
	OptionTypeHeroWinLose     = 18 // 英雄输赢
	OptionTypeHeroHandicap    = 19 // 英雄让分
	OptionTypeHeroOverUnder   = 20 // 英雄大小
	OptionTypeHeroOddEven     = 21 // 英雄单双
	OptionTypeHeroYesNo       = 22 // 英雄是否
)

// 一些数值的decimal常量
var (
	Decimal1   = decimal.NewFromInt(1)
	Decimal2   = decimal.NewFromInt(2)
	Decimal100 = decimal.NewFromInt(100)
)

type Confirm struct {
	MatchID      string
	MarketID     string
	OddID        string
	BetAmount    string
	TheoryPrize  string
	Odd          string // 注单赔率
	ExchangeRate string // 注单汇率
}

type MatchOrderCalcStat struct {
	Total  MatchTotalCalc        `json:"total"`  // 赛事总投注统计
	Risk   MatchRiskCalc         `json:"risk"`   // 赛事风险注单统计
	Market map[string]MarketCalc `json:"market"` // 盘口注单统计
}

type MatchTotalCalc struct {
	T  int     `json:"t"`  // 总投注数
	A  float64 `json:"a"`  // 总投注金额
	BC int     `json:"bc"` // 总投注数-风险标签统计
	BA float64 `json:"ba"` // 总投注金额-风险标签统计
}

type MatchRiskCalc struct {
	Pending  int `json:"pending"`  // 风险注单-待处理数
	Accepted int `json:"accepted"` // 风险注单-已接受数
	Rejected int `json:"rejected"` // 风险注单-已拒绝数
}

// 盘口统计
type MarketCalc struct {
	MarketID         string             `json:"market_id"`
	Risk             int                `json:"risk"` // 盘口风险注单数
	RealityBetAmount float64            `json:"rba"`  // 盘口总实际注单金额
	FloatBetAmount   float64            `json:"fba"`  // 盘口总浮动注单金额
	Odds             map[string]OddCalc `json:"odds"` // 盘口投注项注单统计
}

// odd统计
type OddCalc struct {
	RealityBetCount    int     `json:"rbc"`  // 实际注单数
	FloatBetCount      int     `json:"fbc"`  // 浮动注单数
	RealityBetAmount   float64 `json:"rba"`  // 实际注单金额
	FloatBetAmount     float64 `json:"fba"`  // 浮动注单金额
	RealityTheoryPrize float64 `json:"rthp"` // 实际预期盈利金额
	FloatTheoryPrize   float64 `json:"fthp"` // 浮动预期盈利金额
}

// 接受注单统计参数
type OrderAcceptCalc struct {
	MatchID          string                  // 比赛ID
	MarketID         string                  // 盘口ID
	IsStuck          int                     // 是否为卡单接受注单
	BetCount         int                     // 盘口浮动注单数
	BetCountRiskTag  int                     // 风险标签-注单数
	RiskCount        int                     // 盘口风险注单数
	BetAmount        decimal.Decimal         // 盘口浮动注单金额
	BetAmountRiskTag decimal.Decimal         // 风险标签-注单金额
	Odds             map[string]TradeOddCalc // 盘口投注项注单统计
}

// 拒绝风险注单统计参数
type OrderRefuseCalc struct {
	BetCount  int                     // 盘口浮动注单数
	BetAmount decimal.Decimal         // 盘口浮动注单金额
	Odds      map[string]TradeOddCalc // 盘口投注项注单统计
}

type TradeOddCalc struct {
	BetCount    int             // 注单数
	BetAmount   decimal.Decimal // 注单金额
	TheoryPrize decimal.Decimal // 预期盈利金额
	Odd         string          // 注单赔率
	Round       int             // 注单局数
	IsLive      int             // 1-赛前 2-滚球
	OddTypeID   string          // 玩法类型ID
}

type OddOrderCancelCalc struct {
	MatchID            string
	MarketID           string
	OddID              string // 投注项ID
	FloatCount         int
	RealityCount       int
	FloatAmount        decimal.Decimal
	RealityAmount      decimal.Decimal
	FloatTheoryPrize   decimal.Decimal
	RealityTheoryPrize decimal.Decimal
	Odd                string // 注单赔率
	Round              int    // 注单局数
	IsLive             int    // 1-赛前 2-滚球
	MatchType          int    // 赛事类型 正常-1 冠军-2 大逃杀-3 篮球-4 主播盘-5 足球-6
}

//赛事风险标签统计数据结构体
type MatchRiskTagOrderCancelData struct {
	MemberCount int             //投注人数
	BetCount    int             //投注单数
	BetAmount   decimal.Decimal //投注金额
}

//赛事风险标签统计数据结构体
type MatchRiskTagCancelTotal struct {
	BetCount  int             //风险标签-总投注单数
	BetAmount decimal.Decimal //风险标签-总投注金额
}

type MarketRiskCalc struct {
	MatchID string
	RiskNum int
}

type GameIndex struct {
	Bo                      int               `json:"bo" db:"bo"`
	Category                int               `json:"category" db:"category"`
	GameID                  string            `json:"game_id" db:"game_id"`
	ID                      string            `json:"id" db:"id"`
	SID                     string            `json:"sid" db:"sid"`
	IsLive                  int               `json:"is_live" db:"is_live"`
	IsPassOff               int               `json:"is_pass_off" db:"is_pass_off"`
	LiveSupport             int               `json:"live_support" db:"live_support"`
	MatchLevel              int               `json:"match_level" db:"match_level"`
	CreditLevel             int               `json:"credit_level" db:"credit_level"`
	MatchTeam               string            `json:"match_team" db:"match_team"`
	MatchCnTeam             string            `json:"match_cn_team" db:"match_cn_team"`
	MatchEnTeam             string            `json:"match_en_team" db:"match_en_team"`
	Rec                     int               `json:"rec" db:"rec"`
	Score                   string            `json:"score" db:"score"`
	StartTime               int64             `json:"start_time" db:"start_time"`
	CloseTime               int64             `json:"close_time" db:"close_time"`
	EndTime                 int64             `json:"end_time" db:"end_time"`
	BetDelayTime            int               `json:"bet_delay_time" db:"bet_delay_time"`
	Status                  int               `json:"status" db:"status"`
	Suspended               int               `json:"suspended" db:"suspended"`
	TeamID                  string            `json:"team_id" db:"team_id"`
	TournamentID            string            `json:"tournament_id" db:"tournament_id"`
	TournamentShortName     string            `json:"tournament_short_name" db:"tournament_short_name"`
	TournamentCnName        string            `json:"tournament_cn_name" db:"tournament_cn_name"`
	AdminVideoURL           string            `json:"admin_video_url" db:"admin_video_url"`
	UserVideoURL            string            `json:"user_video_url" db:"user_video_url"`
	Visible                 int               `json:"visible" db:"visible"`
	MbMchPrizeLimit         int               `json:"mb_mch_prize_limit" db:"mb_mch_prize_limit"`
	RndCompPrizeLimit       int               `json:"rnd_comp_prize_limit" db:"rnd_comp_prize_limit"`
	RndCompMchPrizeLimit    int               `json:"rnd_comp_mch_prize_limit" db:"rnd_comp_mch_prize_limit"`
	RndCompOddDscnt         float64           `json:"rnd_comp_odd_dscnt" db:"rnd_comp_odd_dscnt"`
	Count                   int               `json:"count"`
	VideoType               int               `json:"video_type" db:"video_type"`
	VideoLabel              int               `json:"video_label" db:"video_label"`
	MixMchPrizeLimit        int               `json:"mix_mch_prize_limit" db:"mix_mch_prize_limit"`
	MixOddDscnt             float64           `json:"mix_odd_dscnt" db:"mix_odd_dscnt"`
	MchsCompPrizeTotalLimit int               `json:"mchs_comp_prize_total_limit" db:"mchs_comp_prize_total_limit"`
	IsOpenMatch             int               `json:"is_open_match" db:"is_open_match"` 
	IsOpenVideo             int               `json:"is_open_video" db:"is_open_video"` 
	Markets                 map[string]Market `json:"markets"`
}

type MatchBrief struct {
	ID              string
	Category        int
	GameID          string
	StartTime       int64
	Status          int
	Visible         int
	LiveSupport     int
	IsLive          int // 1-赛前 2-滚球
	IsPassOff       int
	MktCount        int64   // 显示中 盘口数量
	SettledMktCount int64   // 已结算的盘口数量
	MatchLevel      int     // 赛事等级
	RateReduce      float64 // 返还率缩减
}

type Market struct {
	ID                string         `json:"id" db:"id"`
	MatchID           string         `json:"match_id" db:"match_id"`
	OddTypeID         string         `json:"odd_type_id" db:"odd_type_id"`
	CnName            string         `json:"cn_name" db:"cn_name"`
	EnName            string         `json:"en_name" db:"en_name"`
	SubMktID          string         `json:"sub_mkt_id" db:"sub_mkt_id"`
	SubOddID          string         `json:"sub_odd_id" db:"sub_odd_id"`
	Round             int            `json:"round" db:"round"`
	IsDefault         int            `json:"is_default" db:"is_default"`
	OptionType        int            `json:"option_type" db:"option_type"`
	SortCode          int            `json:"sort_code" db:"sort_code"`
	CompSubNum        int            `json:"comp_sub_num" db:"comp_sub_num"`
	Status            int            `json:"status" db:"status"`
	Suspended         int            `json:"suspended" db:"suspended"`
	Visible           int            `json:"visible" db:"visible"`
	PrizeLimit        int            `json:"prize_limit" db:"prize_limit"`
	MbMktPrizeLimit   int            `json:"mb_mkt_prize_limit" db:"mb_mkt_prize_limit"`
	WarningProfit     int            `json:"warning_profit" db:"warning_profit"`
	StopProfit        int            `json:"stop_profit" db:"stop_profit"`
	PrizeStaticProfit int            `json:"prize_static_profit" db:"prize_static_profit"`
	MchCompPrizeLimit int            `json:"mch_comp_prize_limit" db:"mch_comp_prize_limit"` //比赛串关单注赔付
	Tag               string         `json:"tag" db:"tag"`
	TagCode           int            `json:"tag_code" db:"tag_code"`
	Remark            string         `json:"remark" db:"remark"`
	IsPassOff         int            `json:"is_pass_off" db:"is_pass_off"`
	SuspendedType     int            `json:"suspended_type" db:"suspended_type"` // 暂停类型 1-手动 0-自动
	VisibleType       int            `json:"visible_type" db:"visible_type"`     // 显示类型 1-手动 0-自动
	SettleCount       int            `json:"settle_count" db:"settle_count"`
	OddLinkage        int            `json:"odd_linkage" db:"odd_linkage"` // 是否开启赔率联动
	Odds              map[string]Odd `json:"odds"`
	ScoreBenchmark    string         `json:"score_benchmark" db:"score_benchmark"` // 基准比分
}

type Odd struct {
	ID        string `json:"id" db:"id"`
	MatchID   string `json:"match_id" db:"match_id"` // 赛事ID
	MarketID  string `json:"market_id" db:"market_id"`
	Name      string `json:"name" db:"name"`
	EnName    string `json:"en_name" db:"en_name"`
	Odd       string `json:"odd" db:"odd"`
	IsWinner  int    `json:"is_winner" db:"is_winner"`
	SortID    int    `json:"sort_id" db:"sort_id"`
	Visible   int    `json:"visible" db:"visible"`
	Suspended int    `json:"suspended" db:"suspended"` // 是否暂停 1-暂停 0-取消暂停
	TeamID    string `json:"team_id" db:"team_id"`
}

// getHandicapInfo 返回结构体
type HandicapData struct {
	Matches map[string]MatchData
	Markets map[string]MarketData
	Odds    map[string]OddData
}

type MatchData struct {
	GameID                  string
	ID                      string
	SID                     string
	TeamID                  string
	TournamentID            string
	TournamentShortName     string
	TournamentCnName        string
	UserVideoURL            string
	AdminVideoURL           string
	MatchTeam               string
	MatchCnTeam             string
	MatchEnTeam             string
	Score                   string
	StartTime               int64
	CloseTime               int64
	EndTime                 int64
	CreditLevel             int
	IsLive                  int
	IsPassOff               int
	LiveSupport             int
	MatchLevel              int
	Rec                     int
	Bo                      int
	Category                int
	BetDelayTime            int
	Status                  int
	Suspended               int
	Visible                 int
	MbMchPrizeLimit         int
	RndComplexPrizeLimit    int
	RndComplexMchPrizeLimit int
	RndCompOddDscnt         float64
	VideoType               int
	VideoLabel              int
	MixPrizeLimit           int
	MixOddDscnt             float64
	MchsCompPrizeTotalLimit int64
}

type MarketData struct {
	ID                string  `json:"id" db:"id"`
	MatchID           string  `json:"match_id" db:"match_id"`
	OddTypeID         string  `json:"odd_type_id" db:"odd_type_id"`
	CnName            string  `json:"cn_name" db:"cn_name"`
	EnName            string  `json:"en_name" db:"en_name"`
	Remark            string  `json:"remark" db:"remark"`
	SubMktID          string  `json:"sub_mkt_id" db:"sub_mkt_id"`
	SubOddID          string  `json:"sub_odd_id" db:"sub_odd_id"`
	Round             int     `json:"round" db:"round"`
	IsDefault         int     `json:"is_default" db:"is_default"`
	OptionType        int     `json:"option_type" db:"option_type"`
	SortCode          int     `json:"sort_code" db:"sort_code"`
	CompSubNum        int     `json:"comp_sub_num" db:"comp_sub_num"`
	Status            int     `json:"status" db:"status"`
	Suspended         int     `json:"suspended" db:"suspended"`
	Visible           int     `json:"visible" db:"visible"`
	PrizeLimit        int     `json:"prize_limit" db:"prize_limit"`
	MbMktPrizeLimit   int     `json:"mb_mkt_prize_limit" db:"mb_mkt_prize_limit"`
	WarningProfit     int     `json:"warning_profit" db:"warning_profit"`
	StopProfit        int     `json:"stop_profit" db:"stop_profit"`
	PrizeStaticProfit int     `json:"prize_static_profit" db:"prize_static_profit"`
	Tag               string  `json:"tag" db:"tag"`
	TagCode           int     `json:"tag_code" db:"tag_code"`
	IsPassOff         int     `json:"is_pass_off" db:"is_pass_off"`
	MchCompPrizeLimit int     `json:"mch_comp_prize_limit" db:"mch_comp_prize_limit"`
	SuspendedType     int     `json:"suspended_type" db:"suspended_type"`
	VisibleType       int     `json:"visible_type" db:"visible_type"`
	SettleCount       int     `json:"settle_count" db:"settle_count"`
	OddLinkage        int     `json:"odd_linkage" db:"odd_linkage"`         // 是否开启赔率联动
	ReturnRate        float64 `json:"-" db:"return_rate"`                   // 返还率
	ScoreBenchmark    string  `json:"score_benchmark" db:"score_benchmark"` // 基准比分
}

type OddData struct {
	ID        string
	IsWinner  int
	MarketID  string
	MatchID   string
	Name      string
	EnName    string
	Odd       string
	Round     int
	SortID    int
	Visible   int
	Suspended int // 是否暂停 1-暂停 0-取消暂停
}

type MatchIndex struct {
	ID        string `db:"id"`
	Status    int    `db:"status"`
	Category  int    `db:"category"`
	StartTime int64  `db:"start_time"`
}

type MatchRec struct {
	ID        string `db:"id"`
	Rec       int64  `db:"rec"`
	StartTime int64  `db:"start_time"`
}

//盘口赔率统计
type OddStat struct {
	RealBetCount   int     //实际投注数
	TheoryBetCount int     //理论投注数
	RealBet        float64 //实际投注金额
	TheoryBet      float64 //浮动投注金额
	RealPrize      float64 //实际奖金
	TheoryPrize    float64 //浮动奖金
}

// 区间赔率特殊抽水配置表
type OddRangeDscntInfo struct {
	LowOdd     string  `json:"low_odd" db:"low_odd"`
	HighOdd    string  `json:"high_odd" db:"high_odd"`
	ReturnRate float64 `json:"return_rate" db:"return_rate"`
}

package calc

import (
	"fmt"
	g "github.com/doug-martin/goqu/v9"
	"github.com/go-redis/redis/v7"
	"github.com/jmoiron/sqlx"
	"github.com/scylladb/go-set/strset"
	"github.com/shopspring/decimal"
	"sort"
)

type MarketMixSub struct {
	ID          string `json:"id"  db:"id"`                      //主键ID
	MatchID     string `json:"match_id" db:"match_id"`           //赛事ID
	Round       int    `json:"round" db:"round"`                 //第几局
	MixMarketID string `json:"mix_market_id" db:"mix_market_id"` //复合玩法父盘口ID
	SubMarketID string `json:"sub_market_id" db:"sub_market_id"` //复合玩法子盘口ID
	Count       int    `json:"count" db:"count"`                 //子盘口数量
}

// 更新盘口赔率参数
type OddUpdateItem struct {
	MarketId     string  `json:"market_id"`      //盘口ID
	MatchId      string  `json:"match_id"`       //赛事ID
	ID           string  `json:"id"`             //投注项ID
	Odd          string  `json:"odd"`            //赔率
	Name         string  `json:"name"`           //选项名称
	PreOdd       string  `json:"pre_odd"`        //变赔前赔率
	MarketCnName string  `json:"market_cn_name"` //盘口中文名
	Round        int     `json:"round"`          //第几局
	ReturnRate   float64 `json:"return_rate"`    //返还率
}

// 投注项更新
type OdUpdate struct {
	Record g.Record
	Ex     g.Ex
}

// 复合盘口返还率
type MixMarketReturnRate struct {
	ReturnRate    string
	PreReturnRate string
}

func MarketMixSubFindAll(db *sqlx.DB, ex g.Ex) ([]MarketMixSub, error) {

	var data []MarketMixSub
	query, _, _ := dialect.From(TblMarketMixSub).Select(colMarketMixSub...).Where(ex).ToSQL()
	err := db.Select(&data, query)
	if err != nil {
		return data, err
	}

	return data, nil
}

/**
 * @Description: 批量更新复合盘口的赔率
 * @Author: awen
 * @Date: 2021-11-22 16:04
 * @LastEditTime: 2021-11-22 16:04
 * @LastEditors: awen
 **/
func BatchUpdateMixMarketOdd(db *sqlx.DB, pool *redis.Client, matchId string, matchLv int, subMarketIds []string, bUpdateRedis bool) ([]OddUpdateItem, error) {

	if len(subMarketIds) == 0 {
		return nil, nil
	}

	var data []OddUpdateItem
	//获取子盘口关联的复合盘口
	ex := g.Ex{"mix_market_id": g.Op{"in": g.L("SELECT mix_market_id FROM tbl_market_mix_sub WHERE sub_market_id in ?", subMarketIds)}}
	mixSubs, err := MarketMixSubFindAll(db, ex)
	if err != nil || len(mixSubs) == 0 {
		return data, err
	}

	mixIds := strset.New()
	subIds := strset.New()
	mpMixSubs := map[string][]string{}
	for _, mixSub := range mixSubs {
		mixIds.Add(mixSub.MixMarketID)
		subIds.Add(mixSub.SubMarketID)
		mpMixSubs[mixSub.MixMarketID] = append(mpMixSubs[mixSub.MixMarketID], mixSub.SubMarketID)
	}

	mktIds := append(mixIds.List(), subIds.List()...)
	ex = g.Ex{"id": mktIds}
	mixMarkets, err := MarketListDB(db, ex)
	if err != nil {
		return data, err
	}

	if len(mixMarkets) == 0 {
		return data, err
	}

	mpMixMarket := map[string]MarketData{}
	for _, mixMarket := range mixMarkets {
		mpMixMarket[mixMarket.ID] = mixMarket
	}

	odds, err := OddListDB(db, g.Ex{"market_id": mktIds})
	if err != nil {
		return data, err
	}

	mpMktOdds := map[string][]Odd{}
	for _, odd := range odds {
		mpMktOdds[odd.MarketID] = append(mpMktOdds[odd.MarketID], odd)
	}

	matchLvData, err := MatchLevelFindOne(db, g.Ex{"level": matchLv})
	if err != nil {
		return data, err
	}

	compDiscount := decimal.NewFromFloat(matchLvData.MixOddDscnt).Div(Decimal100)

	for mixMktID, v := range mpMixSubs {
		var records []OdUpdate
		if mixMktOdd, ok := mpMktOdds[mixMktID]; ok {
			// 排序
			sort.Slice(mixMktOdd, func(i, j int) bool {
				return mixMktOdd[j].SortID > mixMktOdd[i].SortID
			})

			// 计算复合盘口赔率
			T1OddVal, T2OddVal := Decimal1, Decimal1
			for _, vv := range v {
				if mktOdd, ok := mpMktOdds[vv]; ok {
					// 排序
					sort.Slice(mktOdd, func(i, j int) bool {
						return mktOdd[j].SortID > mktOdd[i].SortID
					})
					o1, _ := decimal.NewFromString(mktOdd[0].Odd)
					o2, _ := decimal.NewFromString(mktOdd[1].Odd)
					T1OddVal = T1OddVal.Mul(o1.Sub(Decimal1).Mul(compDiscount).Add(Decimal1))
					T2OddVal = T2OddVal.Mul(o2.Sub(Decimal1).Mul(compDiscount).Add(Decimal1))
				}
			}
			records = append(records, OdUpdate{
				Record: g.Record{"odd": TrimDecimal(T1OddVal)},
				Ex:     g.Ex{"id": mixMktOdd[0].ID},
			})
			records = append(records, OdUpdate{
				Record: g.Record{"odd": TrimDecimal(T2OddVal)},
				Ex:     g.Ex{"id": mixMktOdd[1].ID},
			})

			returnRate := MarketReturnRate([]decimal.Decimal{T1OddVal, T2OddVal})
			data = append(data, OddUpdateItem{
				MarketId:     mixMktID,
				MatchId:      matchId,
				ID:           mixMktOdd[0].ID,
				Odd:          TrimDecimal(T1OddVal),
				PreOdd:       mixMktOdd[0].Odd,
				ReturnRate:   returnRate,
				Name:         mixMktOdd[0].Name,
				MarketCnName: mpMixMarket[mixMktID].CnName,
				Round:        mpMixMarket[mixMktID].Round,
			})
			data = append(data, OddUpdateItem{
				MarketId:     mixMktID,
				MatchId:      matchId,
				ID:           mixMktOdd[1].ID,
				Odd:          TrimDecimal(T2OddVal),
				PreOdd:       mixMktOdd[1].Odd,
				ReturnRate:   returnRate,
				Name:         mixMktOdd[1].Name,
				MarketCnName: mpMixMarket[mixMktID].CnName,
				Round:        mpMixMarket[mixMktID].Round,
			})
		}

		err = MixOddUpdate(db, pool, matchId, mixMktID, records, bUpdateRedis)
		if err != nil {
			return data, err
		}
	}

	return data, nil
}

/**
* @Description: 复合盘口投注项更新
* @Author: awen
* @Date: 2021/08/21 13:36
* @LastEditTime: 2021/08/21 13:36
* @LastEditors: awen
 */
func MixOddUpdate(db *sqlx.DB, pool *redis.Client, matchId, marketId string, records []OdUpdate, bUpdateRedis bool) error {

	dbConn, err := db.Begin()
	if err != nil {
		return err
	}

	for i := range records {
		query, _, _ := dialect.Update(TblOdds).Set(records[i].Record).Where(records[i].Ex).ToSQL()
		fmt.Println(query)
		_, err := dbConn.Exec(query)
		if err != nil {
			_ = dbConn.Rollback()
			return err
		}
	}

	// 更新盘口缓存
	if bUpdateRedis {
		pipe := pool.Pipeline()
		for _, rec := range records {
			MarketCacheOddUpdate(pipe, matchId, marketId, rec.Record, rec.Ex, "0")
		}
		_, err = pipe.Exec()
		if err != nil {
			_ = dbConn.Rollback()
			return err
		}
	}

	return dbConn.Commit()
}

/**
 * @Description: 更新盘口投注项缓存字段
 * @Author: maxic
 * @Date: 2020/8/15
 * @LastEditTime: 2020/8/15
 * @LastEditors: maxic
 **/
func MarketCacheOddUpdate(pipe redis.Pipeliner, matchId, marketId string, record g.Record, ex g.Ex, defaultMarketId string) {

	cacheFields := map[string]bool{
		"odd":       true,
		"is_winner": true,
		"sort_id":   true,
		"visible":   true,
		"suspended": true,
		"name":      true,
		"en_name":   true,
	}
	fn := func(id, defaultId string) {
		for k, v := range record {
			if cacheFields[k] {
				path := fmt.Sprintf(JPathOddField, marketId, id, k)
				MatchCacheSet(pipe, matchId, path, v, marketId == defaultMarketId)
			}
		}
	}
	if id, ok := ex["id"]; ok {
		switch id.(type) {
		case string:
			fn(id.(string), defaultMarketId)
		case []string:
			for _, v := range id.([]string) {
				fn(v, defaultMarketId)
			}
		}
	}
}

package calc

import (
	"errors"
	"fmt"
	"strings"

	"github.com/shopspring/decimal"

	g "github.com/doug-martin/goqu/v9"
	"github.com/go-redis/redis/v7"
)

var (
	// 开启ForeCast统计的游戏
	ForeCastGameMap = map[string]bool{}

	// 开启ForeCast统计的玩法类型
	ForeCastOptionTypeMap = map[int]bool{}

	// 开启ForeCast统计的玩法id
	ForeCastOptionTypeIDMap = map[string]bool{}

	// 击杀总数
	ForeCastKillTotalMap = map[string]bool{}

	// A队击杀总数
	ForeCastKillTotalAMap = map[string]bool{}

	// B队击杀总数
	ForeCastKillTotalBMap = map[string]bool{}
)

// ForeCast 金额信息
type FCAmountData struct {
	BetAmount    float64 `json:"bet_amount" db:"bet_amount"`       // 纯投注额
	WinAmount    float64 `json:"win_amount" db:"win_amount"`       // 纯赔付额,不含本金
	HybridAmount float64 `json:"hybrid_amount" db:"hybrid_amount"` // 混合型金额:注单赔率小于等于2，则取该注单的投注额;注单赔率大于2，则取该注单的赔付额(扣除本金)
}

// ForeCast配置项
type ForeCastConfig struct {
	Game         []string `json:"game"`           // 开启ForeCast统计的游戏
	OptionType   []int    `json:"option_type"`    // 开启ForeCast统计的玩法类型
	OptionTypeID []string `json:"option_type_id"` // 开启ForeCast统计的玩法id
	KillTotal    []string `json:"kill_total"`     // 击杀总数
	KillTotalA   []string `json:"kill_total_a"`   // A队击杀总数
	KillTotalB   []string `json:"kill_total_b"`   // B队击杀总数
}

// ForeCast 玩法项数据
type FCOddData struct {
	OddID      string           `json:"odd_id" db:"odd_id"`
	SortID     int              `json:"sort_id" db:"sort_id"`
	FlagNumber string           `json:"flag_number" db:"flag_number"` // 让分 大小的球头 波胆的比分 胜平负标志
	Amount     *[3]FCAmountData `json:"amount" db:"amount"`           // 金额数据
}

// ForeCast 盘口统计
type FCMatchMarketData struct {
	MarketID   string               `json:"market_id"`
	OptionType int8                 `json:"option_type" db:"option_type"`
	OddTypeID  string               `json:"odd_type_id" db:"odd_type_id"`
	Round      int                  `json:"round" db:"round"` // 局数
	Odds       map[string]FCOddData `json:"odds"`             // 盘口投注项注单统计
}

// ForeCast 赛事数据统计
type FCMatchData struct {
	Bo      int                          `json:"bo"`      // 赛制
	Markets map[string]FCMatchMarketData `json:"markets"` // 盘口数据
}

// ForeCast 注单信息
type FCOrderInfo struct {
	MatchID      string  `json:"match_id" db:"match_id"`           // 赛事ID
	MarketID     string  `json:"market_id" db:"market_id"`         // 盘口ID
	OddID        string  `json:"odd_id" db:"odd_id"`               // 投注项ID
	IsLive       int     `json:"is_live" db:"is_live"`             // 1-赛前 2-滚球
	Round        int     `json:"round" db:"round"`                 // 局数
	RrgOddID     int     `json:"org_odd_id" db:"org_odd_id"`       // 小玩法id
	BetAmount    float64 `json:"bet_amount" db:"bet_amount"`       // 纯投注额
	WinAmount    float64 `json:"win_amount" db:"win_amount"`       // 纯赔付额,不含本金
	HybridAmount float64 `json:"hybrid_amount" db:"hybrid_amount"` // 混合型金额:注单赔率小于等于2，则取该注单的投注额;注单赔率大于2，则取该注单的赔付额(扣除本金)
}

// 更新ForeCast的配置项
func updateRedis(pipe redis.Pipeliner, matchID, mktID, oddID string, round, isLive int, odd, betAmount, winAmount, operate string) {

	// 加法使用“”
	if operate != "-" {
		operate = ""
	}

	// 纯赔付额,扣除本金
	decBetAmount, _ := decimal.NewFromString(betAmount)
	decWinAmount, _ := decimal.NewFromString(winAmount)
	decWinAmount = decWinAmount.Sub(decBetAmount)

	// 混合型:注单赔率小于等于2，则取该注单的投注额为货量; 注单赔率大于2，则取该注单的赔付额(扣除本金)
	decHybridAmount := decBetAmount
	decOdd, _ := decimal.NewFromString(odd)
	if decOdd.GreaterThan(Decimal2) {
		decHybridAmount = decWinAmount
	}

	foreCastKey := fmt.Sprintf(RedisForeCastCalc, matchID)
	path := fmt.Sprintf(RedisForeCastCalcField, mktID, round, oddID, isLive)
	// 总数
	pathTotal := fmt.Sprintf(RedisForeCastCalcField, mktID, round, oddID, 0)

	// decBetAmount > 0
	if decBetAmount.Sign() == 1 {
		pipe.Do("JSON.NUMINCRBY", foreCastKey, path+".bet_amount", operate+decBetAmount.String())
		pipe.Do("JSON.NUMINCRBY", foreCastKey, pathTotal+".bet_amount", operate+decBetAmount.String())
	}

	// decWinAmount > 0
	if decWinAmount.Sign() == 1 {
		pipe.Do("JSON.NUMINCRBY", foreCastKey, path+".win_amount", operate+decWinAmount.String())
		pipe.Do("JSON.NUMINCRBY", foreCastKey, pathTotal+".win_amount", operate+decWinAmount.String())
	}

	// decHybridAmount > 0
	if decHybridAmount.Sign() == 1 {
		pipe.Do("JSON.NUMINCRBY", foreCastKey, path+".hybrid_amount", operate+decHybridAmount.String())
		pipe.Do("JSON.NUMINCRBY", foreCastKey, pathTotal+".hybrid_amount", operate+decHybridAmount.String())
	}
}

// 初始化ForeCast配置
func InitForeCastConfig(config ForeCastConfig) {

	for _, v := range config.Game {
		ForeCastGameMap[v] = true
	}

	for _, v := range config.OptionType {
		ForeCastOptionTypeMap[v] = true
	}

	for _, v := range config.OptionTypeID {
		ForeCastOptionTypeIDMap[v] = true
	}

	for _, v := range config.KillTotal {
		ForeCastKillTotalMap[v] = true
	}

	for _, v := range config.KillTotalA {
		ForeCastKillTotalAMap[v] = true
	}

	for _, v := range config.KillTotalB {
		ForeCastKillTotalBMap[v] = true
	}
}

// 在redis中创建赛事的ForeCast项
func InitForeCastStat(pool *redis.Client, matchID string, info string) error {

	key := fmt.Sprintf(RedisForeCastCalc, matchID)
	return pool.Do("JSON.SET", key, ".", info).Err()
}

// 在redis中插入盘口的oreCast项
func FCMarketStatInsert(pool *redis.Client, matchID, marketKey string, marketInfo string) error {

	key := fmt.Sprintf(RedisForeCastCalc, matchID)
	return pool.Do("JSON.SET", key, ".markets."+marketKey, marketInfo).Err()
}

// 有新注单时，更新redis(只更新初盘，滚盘需要djTask确认)
func FCOrderCalcUpdate(pipe redis.Pipeliner, order g.Record, optionType int) error {

	var (
		gameID    string
		mchID     string
		mktID     string
		oddID     string
		isLive    int
		matchType int
		orderType int
		round     int
		odd       string
		ok        bool
	)
	if gameID, ok = order["game_id"].(string); !ok {
		return errors.New("gameID error")
	}
	if matchType, ok = order["match_type"].(int); !ok {
		return errors.New("matchType error")
	}
	if orderType, ok = order["order_type"].(int); !ok {
		return errors.New("orderType error")
	}
	if isLive, ok = order["is_live"].(int); !ok {
		return errors.New("is_live error")
	}

	// 普通盘，单注，输赢 让分 大小 早盘 滚球,只更新初盘，滚盘需要djTask确认
	if matchType != MatchCategoryNormal || orderType != 1 || isLive != 1 {
		return nil
	}

	// 判断游戏
	if _, ok = ForeCastGameMap[gameID]; !ok {
		return nil
	}

	// 游戏大玩法
	if _, ok = ForeCastOptionTypeMap[optionType]; !ok {
		return nil
	}

	if mchID, ok = order["match_id"].(string); !ok {
		return errors.New("match_id error")
	}
	if mktID, ok = order["market_id"].(string); !ok {
		return errors.New("market_id error")
	}
	if oddID, ok = order["odd_id"].(string); !ok {
		return errors.New("odd_id error")
	}
	if round, ok = order["round"].(int); !ok {
		return errors.New("round error")
	}
	if odd, ok = order["odd"].(string); !ok {
		return errors.New("odd error")
	}

	decBetAmount, err := decimal.NewFromString(order["bet_amount"].(string))
	if err != nil {
		return errors.New("bet_amount error")
	}

	decTheoryPrize, err := decimal.NewFromString(order["theory_prize"].(string))
	if err != nil {
		return errors.New("theory_prize error")
	}

	decExchangeRate := decimal.NewFromFloat(order["exchange_rate"].(float64))

	betAmount := TrimDecimal(decBetAmount.Div(decExchangeRate))
	theoryPrize := TrimDecimal(decTheoryPrize.Div(decExchangeRate))

	updateRedis(pipe, mchID, mktID, oddID, round, isLive, odd, betAmount, theoryPrize, "+")

	return nil
}

// 确认注单时，更新redis
func FCOrderConfirm(pipe redis.Pipeliner, mktInfo MarketData, c Confirm) {

	// 游戏大玩法
	if _, ok := ForeCastOptionTypeMap[mktInfo.OptionType]; !ok {
		return
	}

	// 游戏小玩法
	oddTypeID := strings.ReplaceAll(mktInfo.OddTypeID, "\"", "")
	if _, ok := ForeCastOptionTypeIDMap[oddTypeID]; !ok {
		return
	}

	decBetAmount, err := decimal.NewFromString(c.BetAmount)
	if err != nil {
		fmt.Println("c.BetAmount error,err:", err)
		return
	}

	decTheoryPrize, err := decimal.NewFromString(c.TheoryPrize)
	if err != nil {
		fmt.Println("c.TheoryPrize error,err:", err)
		return
	}

	decExchangeRate, err := decimal.NewFromString(c.ExchangeRate)
	if err != nil {
		fmt.Println("c.ExchangeRate error,err:", err)
		return
	}

	betAmount := TrimDecimal(decBetAmount.Div(decExchangeRate))
	theoryPrize := TrimDecimal(decTheoryPrize.Div(decExchangeRate))

	updateRedis(pipe, c.MatchID, c.MarketID, c.OddID, mktInfo.Round, 2, c.Odd, betAmount, theoryPrize, "+")
}

// 撤消注单时，更新redis
func FCOrderCancelCalc(pipe redis.Pipeliner, cancelOddOrders map[string]OddOrderCancelCalc) {

	if len(cancelOddOrders) == 0 {
		return
	}

	for _, v := range cancelOddOrders {
		// 实际注单
		if v.RealityCount == 0 {
			continue
		}

		updateRedis(pipe, v.MatchID, v.MarketID, v.OddID, v.Round, v.IsLive, v.Odd, v.RealityAmount.String(), v.RealityTheoryPrize.String(), "-")
	}
}

// 风险注单确认
func FCOrderAccept(pipe redis.Pipeliner, p OrderAcceptCalc) {

	// 更新投注项实际注单统计
	for oddID, v := range p.Odds {
		// 判断小玩法
		if ok := ForeCastOptionTypeIDMap[v.OddTypeID]; !ok {
			continue
		}

		updateRedis(pipe, p.MatchID, p.MarketID, oddID, v.Round, v.IsLive, v.Odd, v.BetAmount.String(), v.TheoryPrize.String(), "+")
	}
}

// 风险注单手动拒绝更新赛事注单统计数据
func FCMarketRiskOrderRefuse(pipe redis.Pipeliner, matchID, marketID string, p OrderRefuseCalc) {

	for k, v := range p.Odds {
		// 判断小玩法
		if ok := ForeCastOptionTypeIDMap[v.OddTypeID]; !ok {
			continue
		}

		updateRedis(pipe, matchID, marketID, k, v.Round, v.IsLive, v.Odd, v.BetAmount.String(), v.TheoryPrize.String(), "-")
	}
}

// 撤消盘口，直接把盘口的FC统计设置为0
func FCMarketCancelCalc(pipe redis.Pipeliner, matchID, marketID, oddID string, round int) {

	foreCastKey := fmt.Sprintf(RedisForeCastCalc, matchID)

	for isLive := 0; isLive < 3; isLive++ {
		path := fmt.Sprintf(RedisForeCastCalcField, marketID, round, oddID, isLive)

		pipe.Do("JSON.SET", foreCastKey, path+".bet_amount", 0)
		pipe.Do("JSON.SET", foreCastKey, path+".win_amount", 0)
		pipe.Do("JSON.SET", foreCastKey, path+".hybrid_amount", 0)
	}
}

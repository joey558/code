package calc

import (
	"bytes"
	"errors"
	"fmt"
	g "github.com/doug-martin/goqu/v9"
	"github.com/go-redis/redis/v7"
	"github.com/jmoiron/sqlx"
	"github.com/scylladb/go-set"
	"github.com/shopspring/decimal"
	"github.com/valyala/fastjson"
	"strconv"
	"strings"
)

//风险标签-统计(投注人数)
type MatchRiskTagData struct {
	MatchID   string `db:"match_id"`    // 赛事ID
	MemberID  string `db:"member_id"`   // 会员ID
	RiskTagID string `db:"risk_tag_id"` // 风险标签ID
	BetCount  int    `db:"bet_count"`   // 投注人数
}

func InitMatchStat(pool *redis.Client, matchID, matchInfo string) error {

	key := fmt.Sprintf(redisMatchCalc, matchID)
	return pool.Do("JSON.SET", key, ".", matchInfo).Err()
}

func OrderConfirm(pipe redis.Pipeliner, c Confirm, bRiskTagCalc bool) {

	decBetAmount, err := decimal.NewFromString(c.BetAmount)
	if err != nil {
		fmt.Println("c.BetAmount error,err:", err)
		return
	}

	decTheoryPrize, err := decimal.NewFromString(c.TheoryPrize)
	if err != nil {
		fmt.Println("c.TheoryPrize error,err:", err)
		return
	}

	decExchangeRate, err := decimal.NewFromString(c.ExchangeRate)
	if err != nil {
		fmt.Println("c.ExchangeRate error,err:", err)
		return
	}

	betAmount := TrimDecimal(decBetAmount.Div(decExchangeRate))
	theoryPrize := TrimDecimal(decTheoryPrize.Div(decExchangeRate))

	key := fmt.Sprintf("mch_calc:%s", c.MatchID)
	if bRiskTagCalc == true {
		// 更新赛事游戏风险标签(总投注金额/总投注注单)
		pipe.Do("JSON.NUMINCRBY", key, ".total.bc", 1)         // 总投注注单
		pipe.Do("JSON.NUMINCRBY", key, ".total.ba", betAmount) // 总投注金额
	}
	// 1.更新赛事总投注统计
	pipe.Do("JSON.NUMINCRBY", key, ".total.t", 1)
	pipe.Do("JSON.NUMINCRBY", key, ".total.a", betAmount)
	// 2.更新盘口实际投注金额
	pipe.Do("JSON.NUMINCRBY", key, ".market.$"+c.MarketID+".rba", betAmount)
	pipe.Do("JSON.NUMINCRBY", key, ".market.$"+c.MarketID+".fba", "-"+betAmount)
	// 3.更新投注项实际注单统计
	pipe.Do("JSON.NUMINCRBY", key, ".market.$"+c.MarketID+".odds.$"+c.OddID+".rbc", 1)
	pipe.Do("JSON.NUMINCRBY", key, ".market.$"+c.MarketID+".odds.$"+c.OddID+".rba", betAmount)
	pipe.Do("JSON.NUMINCRBY", key, ".market.$"+c.MarketID+".odds.$"+c.OddID+".rthp", theoryPrize)
	pipe.Do("JSON.NUMINCRBY", key, ".market.$"+c.MarketID+".odds.$"+c.OddID+".fbc", -1)
	pipe.Do("JSON.NUMINCRBY", key, ".market.$"+c.MarketID+".odds.$"+c.OddID+".fba", "-"+betAmount)
	pipe.Do("JSON.NUMINCRBY", key, ".market.$"+c.MarketID+".odds.$"+c.OddID+".fthp", "-"+theoryPrize)
}

func RiskOrderGen(pipe redis.Pipeliner, matchID, marketID string, value int) {

	key := fmt.Sprintf("mch_calc:%s", matchID)
	// 1.更新赛事总投注统计
	pipe.Do("JSON.NUMINCRBY", key, ".risk.pending", value)
	// 2.更新盘口更新注单数
	pipe.Do("JSON.NUMINCRBY", key, ".market.$"+marketID+".risk", value)
}

func GetMatchStat(pool *redis.Client, matchID string) (string, error) {

	key := fmt.Sprintf(redisMatchCalc, matchID)
	data, err := pool.Do("JSON.GET", key).Text()

	return data, err
}

func GetMarketStat(pool *redis.Client, mkts map[string]string) (map[string]string, error) {

	pipe := pool.Pipeline()
	defer pipe.Close()

	ret := map[string]string{}
	totals := map[string]*redis.Cmd{}
	risks := map[string]*redis.Cmd{}
	mktRes := map[string]*redis.Cmd{}

	for marketID, matchID := range mkts {

		key := fmt.Sprintf(redisMatchCalc, matchID)
		totals[marketID] = pipe.Do("JSON.GET", key, ".total")
		risks[marketID] = pipe.Do("JSON.GET", key, ".risk")
		mktRes[marketID] = pipe.Do("JSON.GET", key, ".market.$"+marketID)
	}

	_, err := pipe.Exec()
	if err != nil {
		return nil, err
	}

	for mktID, total := range totals {

		b := bytes.Buffer{}
		data, err := total.Text()
		if err == redis.Nil {
			continue
		}

		if err != nil {
			return nil, err
		}
		b.WriteString(`{"total":`)
		b.WriteString(data)
		b.WriteString(`,"risk":`)

		data, err = risks[mktID].Text()
		if err != nil {
			return nil, err
		}
		b.WriteString(data)
		b.WriteString(`,"market":`)

		data, err = mktRes[mktID].Text()
		if err != nil {
			return nil, err
		}

		b.WriteString(data)
		b.WriteString("}")

		ret[mktID] = b.String()
	}

	return ret, nil
}

/*
 * @Description: 风险标签-统计(投注金额,投注单数)
 * @Author: robin
 * @Date: 2021/11/7 16:19
 * @LastEditTime: 2021/11/7 16:19
 * @LastEditors: robin
 */
func RiskTagCalcConfirm(pipe redis.Pipeliner, c Confirm, riskTagId string) bool {

	decBetAmount, err := decimal.NewFromString(c.BetAmount)
	if err != nil {
		fmt.Printf("risk_tag_id[%v] bet_amount decimal.NewFromString error[%v]", c.BetAmount, err.Error())
		return false
	}

	decExchangeRate, err := decimal.NewFromString(c.ExchangeRate)
	if err != nil {
		fmt.Printf("risk_tag_id[%v] exchange_rate decimal.NewFromString error[%v]", c.ExchangeRate, err.Error())
		return false
	}

	ba, _ := decBetAmount.Div(decExchangeRate).Truncate(3).Float64()

	// 缓存处理
	key := fmt.Sprintf(RedisRiskTagCalc, c.MatchID, riskTagId)
	//投注金额
	_, err = pipe.HIncrByFloat(key, "ba", ba).Result()
	if err != nil {
		fmt.Printf("risk_tag_id[%v] redis field[ba] HIncrBy error[%v]", riskTagId, err.Error())
		return false
	}

	//投注单数
	_, err = pipe.HIncrBy(key, "bc", 1).Result()
	if err != nil {
		fmt.Printf("risk_tag_id[%v] redis field[bc] HIncrBy error[%v]", riskTagId, err.Error())
		return false
	}

	return true
}

/*
 * @Description: 风险标签-统计(投注金额,投注单数)
 * @Author: robin
 * @Date: 2021/11/6 13:13
 * @LastEditTime: 2021/11/6 13:13
 * @LastEditors: robin
 */
func RiskTagCalcUpdate(pipe redis.Pipeliner, order g.Record, riskTagId string) error {

	var (
		matchId string
		ok      bool
	)
	if matchId, ok = order["match_id"].(string); !ok {
		return errors.New("match_id error")
	}

	decBetAmount, err := decimal.NewFromString(order["bet_amount"].(string))
	if err != nil {
		return errors.New("bet_amount error")
	}

	decExchangeRate := decimal.NewFromFloat(order["exchange_rate"].(float64))

	ba, _ := decBetAmount.Div(decExchangeRate).Truncate(3).Float64()

	// 缓存处理
	key := fmt.Sprintf(RedisRiskTagCalc, matchId, riskTagId)
	//投注金额
	_, err = pipe.HIncrByFloat(key, "ba", ba).Result()
	if err != nil {
		return errors.New(fmt.Sprintf("redis field[ba] HIncrBy error[%v]", err.Error()))
	}

	//投注单数
	_, err = pipe.HIncrBy(key, "bc", 1).Result()
	if err != nil {
		return errors.New(fmt.Sprintf("redis field[bc] HIncrBy error[%v]", err.Error()))
	}

	return err
}

/*
 * @Description: 风险标签-统计(投注人数)
 * @Author: robin
 * @Date: 2021/11/6 19:59
 * @LastEditTime: 2021/11/6 19:59
 * @LastEditors: robin
 */
func RiskTagMemberCalcUpdate(pool *redis.Client, matchId, riskTagId string, memberId uint64) error {

	strMemberId := fmt.Sprintf("%d", memberId)
	key := fmt.Sprintf(RedisRiskBetCalc, matchId, strMemberId, riskTagId)
	_, err := pool.Get(key).Result()
	if err != nil && err != redis.Nil {
		return errors.New(fmt.Sprintf("redis get key error:%v", err.Error()))
	}

	if err == redis.Nil {
		err = pool.Set(key, "1", 0).Err()
		if err != nil {
			return errors.New(fmt.Sprintf("redis set key error:%v", err.Error()))
		}
		//投注人数
		key := fmt.Sprintf(RedisRiskTagCalc, matchId, riskTagId)
		_, err = pool.HIncrBy(key, "mc", 1).Result()
		if err != nil {
			return errors.New(fmt.Sprintf("redis field[mc] HIncrBy error[%v]", err.Error()))
		}
	}

	return nil
}

func OrderCalcUpdate(pipe redis.Pipeliner, order g.Record, bRiskTagCalc bool) error {

	var (
		mchID  string
		mktID  string
		oddID  string
		isLive int
		ok     bool
	)
	if mchID, ok = order["match_id"].(string); !ok {
		return errors.New("match_id error")
	}
	if mktID, ok = order["market_id"].(string); !ok {
		return errors.New("market_id error")
	}
	if oddID, ok = order["odd_id"].(string); !ok {
		return errors.New("odd_id error")
	}
	if isLive, ok = order["is_live"].(int); !ok {
		return errors.New("is_live error")
	}

	decBetAmount, err := decimal.NewFromString(order["bet_amount"].(string))
	if err != nil {
		return errors.New("bet_amount error")
	}

	decTheoryPrize, err := decimal.NewFromString(order["theory_prize"].(string))
	if err != nil {
		return errors.New("theory_prize error")
	}

	decExchangeRate := decimal.NewFromFloat(order["exchange_rate"].(float64))

	betAmount := TrimDecimal(decBetAmount.Div(decExchangeRate))
	theoryPrize := TrimDecimal(decTheoryPrize.Div(decExchangeRate))

	key := fmt.Sprintf(redisMatchCalc, mchID)
	if bRiskTagCalc == true {
		// 更新赛事游戏风险标签(总投注金额/总投注注单)
		pipe.Do("JSON.NUMINCRBY", key, ".total.bc", 1)         // 总投注注单
		pipe.Do("JSON.NUMINCRBY", key, ".total.ba", betAmount) // 总投注金额
	}
	// 初盘
	if isLive == 1 {
		// 1.更新赛事总投注统计
		pipe.Do("JSON.NUMINCRBY", key, ".total.t", 1)
		pipe.Do("JSON.NUMINCRBY", key, ".total.a", betAmount)
		// 2.更新盘口实际投注金额
		pipe.Do("JSON.NUMINCRBY", key, ".market.$"+mktID+".rba", betAmount)
		// 3.更新盘口投注项实际注单统计
		pipe.Do("JSON.NUMINCRBY", key, ".market.$"+mktID+".odds.$"+oddID+".rbc", 1)
		pipe.Do("JSON.NUMINCRBY", key, ".market.$"+mktID+".odds.$"+oddID+".rba", betAmount)
		pipe.Do("JSON.NUMINCRBY", key, ".market.$"+mktID+".odds.$"+oddID+".rthp", theoryPrize)

		return nil
	} else if isLive == 2 {
		// 1.更新盘口浮动投注金额
		pipe.Do("JSON.NUMINCRBY", key, ".market.$"+mktID+".fba", betAmount)
		// 2.更新盘口投注项浮动注单统计
		pipe.Do("JSON.NUMINCRBY", key, ".market.$"+mktID+".odds.$"+oddID+".fbc", 1)
		pipe.Do("JSON.NUMINCRBY", key, ".market.$"+mktID+".odds.$"+oddID+".fba", betAmount)
		pipe.Do("JSON.NUMINCRBY", key, ".market.$"+mktID+".odds.$"+oddID+".fthp", theoryPrize)

		return nil
	}

	return errors.New("is_live status error")
}

func OrderCancelCalcManualPrepare(pipe redis.Pipeliner, matchID, marketID string) {

	key := fmt.Sprintf(redisMatchCalc, matchID)

	pipe.Do("JSON.NUMINCRBY", key, ".risk.pending", -1)
	pipe.Do("JSON.NUMINCRBY", key, fmt.Sprintf(".market.$%s.risk", marketID), -1)
}

func OrderCancelCalcFloatBet(pipe redis.Pipeliner, matchID, marketID, oddID string, betAmount, theoryPrize string) {

	key := fmt.Sprintf(redisMatchCalc, matchID)

	// 盘口：浮动注单金额-注单金额
	pipe.Do("JSON.NUMINCRBY", key, fmt.Sprintf(".market.$%s.fba", marketID), "-"+betAmount)
	// 投注项：浮动注单数-1， 浮动注单金额-注单金额， 浮动派彩金额-注单派彩基恩
	oddPath := fmt.Sprintf(".market.$%s.odds.$%s", marketID, oddID)
	pipe.Do("JSON.NUMINCRBY", key, oddPath+".fbc", -1)
	pipe.Do("JSON.NUMINCRBY", key, oddPath+".fba", "-"+betAmount)
	pipe.Do("JSON.NUMINCRBY", key, oddPath+".fthp", "-"+theoryPrize)
}

func OrderCancelCalcRealityBet(pipe redis.Pipeliner, matchID, marketID, oddID string, betAmount, theoryPrize string) {

	key := fmt.Sprintf(redisMatchCalc, matchID)

	// 赛事：总投注数-1，总投注金额-注单金额
	pipe.Do("JSON.NUMINCRBY", key, ".total.t", -1)
	pipe.Do("JSON.NUMINCRBY", key, ".total.a", "-"+betAmount)
	// 盘口：实际总投注金额-注单金额
	pipe.Do("JSON.NUMINCRBY", key, fmt.Sprintf(".market.$%s.rba", marketID), "-"+betAmount)
	// 投注项：
	oddPath := fmt.Sprintf(".market.$%s.odds.$%s", marketID, oddID)
	pipe.Do("JSON.NUMINCRBY", key, oddPath+".rbc", -1)
	pipe.Do("JSON.NUMINCRBY", key, oddPath+".rba", "-"+betAmount)
	pipe.Do("JSON.NUMINCRBY", key, oddPath+".rthp", "-"+theoryPrize)
}

// 获取盘口各赔率选项的浮动盈亏
func MktProfitCalc(pool *redis.Client, matchID, marketID string) (map[string]decimal.Decimal, error) {
	data := map[string]decimal.Decimal{}

	key := fmt.Sprintf(redisMatchCalc, matchID)
	res, err := pool.Do("JSON.GET", key, ".market.$"+marketID).Text()
	if err == redis.Nil {
		return data, nil
	}
	if err != nil {
		return data, err
	}

	//解析
	var parse fastjson.Parser
	v, err := parse.Parse(res)
	if err != nil {
		return data, err
	}

	//解析成对象
	rba := v.GetFloat64("rba")
	fba := v.GetFloat64("fba")
	v.GetObject("odds").Visit(func(key []byte, v *fastjson.Value) {
		id := strings.TrimLeft(string(key), "$")
		rthp := v.GetFloat64("rthp")
		fthp := v.GetFloat64("fthp")
		data[id] = decimal.NewFromFloat(rba + fba - rthp - fthp)
	})

	return data, nil
}

// 获取盘口各赔率选项的浮动盈亏
func MarketProfitCalc(pool *redis.Client, matchID, marketID string) (MarketCalc, error) {

	var data MarketCalc
	key := fmt.Sprintf(redisMatchCalc, matchID)
	res, err := pool.Do("JSON.GET", key, ".market.$"+marketID).Text()
	if err == redis.Nil {
		return data, nil
	}
	if err != nil {
		return data, err
	}

	//解析
	var parse fastjson.Parser
	v, err := parse.Parse(res)
	if err != nil {
		return data, err
	}

	//解析成对象
	data.MarketID = string(v.GetStringBytes("market_id"))
	data.Risk = v.GetInt("risk")
	data.RealityBetAmount = v.GetFloat64("rba")
	data.FloatBetAmount = v.GetFloat64("fba")
	data.Odds = make(map[string]OddCalc)
	v.GetObject("odds").Visit(func(key []byte, v *fastjson.Value) {
		var item OddCalc
		id := strings.TrimLeft(string(key), "$")
		item.RealityBetCount = v.GetInt("rbc")
		item.FloatBetCount = v.GetInt("fbc")
		item.RealityBetAmount = v.GetFloat64("rba")
		item.FloatBetAmount = v.GetFloat64("fba")
		item.RealityTheoryPrize = v.GetFloat64("rthp")
		item.FloatTheoryPrize = v.GetFloat64("fthp")
		data.Odds[id] = item
	})

	return data, nil
}

func OrderAccept(pipe redis.Pipeliner, p OrderAcceptCalc) {

	key := fmt.Sprintf("mch_calc:%s", p.MatchID)
	betAmount, theoryPrize := "", ""
	if p.BetCount > 0 {
		if p.BetCountRiskTag > 0 {
			// 更新赛事游戏风险标签(总投注金额/总投注注单)
			ba := p.BetAmountRiskTag.Truncate(0).String()
			pipe.Do("JSON.NUMINCRBY", key, ".total.bc", 1)  // 总投注注单
			pipe.Do("JSON.NUMINCRBY", key, ".total.ba", ba) // 总投注金额
		}
		betAmount := p.BetAmount.StringFixed(3)
		// 1.更新赛事总投注统计
		pipe.Do("JSON.NUMINCRBY", key, ".total.t", p.BetCount)
		pipe.Do("JSON.NUMINCRBY", key, ".total.a", betAmount)
		// 2.更新盘口实际投注金额
		pipe.Do("JSON.NUMINCRBY", key, ".market.$"+p.MarketID+".rba", betAmount)
		pipe.Do("JSON.NUMINCRBY", key, ".market.$"+p.MarketID+".fba", "-"+betAmount)
	}

	// 接受风险注单需要更新赛事和盘口的风险注单统计
	if p.RiskCount > 0 {
		pipe.Do("JSON.NUMINCRBY", key, ".risk.pending", -p.RiskCount)
		pipe.Do("JSON.NUMINCRBY", key, ".risk.accepted", p.RiskCount)
		pipe.Do("JSON.NUMINCRBY", key, ".market.$"+p.MarketID+".risk", -p.RiskCount)
	}

	// 3.更新投注项实际注单统计
	for oddID, v := range p.Odds {
		betAmount = v.BetAmount.StringFixed(3)
		theoryPrize = v.TheoryPrize.StringFixed(3)
		pipe.Do("JSON.NUMINCRBY", key, ".market.$"+p.MarketID+".odds.$"+oddID+".rbc", v.BetCount)
		pipe.Do("JSON.NUMINCRBY", key, ".market.$"+p.MarketID+".odds.$"+oddID+".rba", betAmount)
		pipe.Do("JSON.NUMINCRBY", key, ".market.$"+p.MarketID+".odds.$"+oddID+".rthp", theoryPrize)

		pipe.Do("JSON.NUMINCRBY", key, ".market.$"+p.MarketID+".odds.$"+oddID+".fbc", -v.BetCount)
		pipe.Do("JSON.NUMINCRBY", key, ".market.$"+p.MarketID+".odds.$"+oddID+".fba", "-"+betAmount)
		pipe.Do("JSON.NUMINCRBY", key, ".market.$"+p.MarketID+".odds.$"+oddID+".fthp", "-"+theoryPrize)
	}
}

func MarketRiskOrderRefuse(pipe redis.Pipeliner, matchID, marketID string, p OrderRefuseCalc) {

	key := fmt.Sprintf("mch_calc:%s", matchID)

	// 1.更新赛事总投注统计
	pipe.Do("JSON.NUMINCRBY", key, ".risk.rejected", p.BetCount)
	pipe.Do("JSON.NUMINCRBY", key, ".risk.pending", -p.BetCount)
	// 2.更新盘口风险注单数和浮动注单金额
	pipe.Do("JSON.NUMINCRBY", key, ".market.$"+marketID+".risk", -p.BetCount)
	pipe.Do("JSON.NUMINCRBY", key, ".market.$"+marketID+".fba", "-"+p.BetAmount.StringFixed(3))

	// 3.盘口投注项浮动注单统计清零
	for k, v := range p.Odds {
		pipe.Do("JSON.NUMINCRBY", key, ".market.$"+marketID+".odds.$"+k+".fbc", -v.BetCount)
		pipe.Do("JSON.NUMINCRBY", key, ".market.$"+marketID+".odds.$"+k+".fba", "-"+v.BetAmount.StringFixed(3))
		pipe.Do("JSON.NUMINCRBY", key, ".market.$"+marketID+".odds.$"+k+".fthp", "-"+v.TheoryPrize.StringFixed(3))
	}
}

func OrderCancelCalc(pipe redis.Pipeliner, cancelMarketRisk map[string]MarketRiskCalc, cancelOddOrders map[string]OddOrderCancelCalc) {
	key := ""
	if len(cancelMarketRisk) > 0 {
		for mktID, v := range cancelMarketRisk {
			key = fmt.Sprintf(redisMatchCalc, v.MatchID)
			pipe.Do("JSON.NUMINCRBY", key, ".risk.pending", -v.RiskNum)
			pipe.Do("JSON.NUMINCRBY", key, fmt.Sprintf(".market.$%s.risk", mktID), -v.RiskNum)
		}
	}

	if len(cancelOddOrders) > 0 {
		for oddID, v := range cancelOddOrders {
			key = fmt.Sprintf(redisMatchCalc, v.MatchID)

			// 投注项路径
			oddPath := fmt.Sprintf(".market.$%s.odds.$%s", v.MarketID, oddID)
			// 浮动注单
			if v.FloatCount > 0 {
				pipe.Do("JSON.NUMINCRBY", key, fmt.Sprintf(".market.$%s.fba", v.MarketID), "-"+v.FloatAmount.StringFixed(3))
				// 投注项：浮动注单数-1， 浮动注单金额-注单金额， 浮动派彩金额-注单派彩金额

				pipe.Do("JSON.NUMINCRBY", key, oddPath+".fbc", -v.FloatCount)
				pipe.Do("JSON.NUMINCRBY", key, oddPath+".fba", "-"+v.FloatAmount.StringFixed(3))
				pipe.Do("JSON.NUMINCRBY", key, oddPath+".fthp", "-"+v.FloatTheoryPrize.StringFixed(3))
			}

			// 实际注单(复合玩法按串注处理，子单未全部撤销只需要更新实际预派彩金额)
			if v.RealityCount > 0 {
				// 赛事：总投注数-投注项总取消注单数，总投注金额-投注项总取消注单金额
				pipe.Do("JSON.NUMINCRBY", key, ".total.t", -v.RealityCount)
				pipe.Do("JSON.NUMINCRBY", key, oddPath+".rbc", -v.RealityCount)
			}
			if v.RealityAmount.Sign() == 1 {
				ra := v.RealityAmount.StringFixed(3)
				pipe.Do("JSON.NUMINCRBY", key, ".total.a", "-"+ra)
				// 盘口：实际总投注金额-注单金额
				pipe.Do("JSON.NUMINCRBY", key, fmt.Sprintf(".market.$%s.rba", v.MarketID), "-"+ra)
				// 投注项
				pipe.Do("JSON.NUMINCRBY", key, oddPath+".rba", "-"+ra)
			}
			if v.RealityTheoryPrize.Sign() == 1 {
				// 投注项实际预派彩金额
				pipe.Do("JSON.NUMINCRBY", key, oddPath+".rthp", "-"+v.RealityTheoryPrize.StringFixed(3))
			}
		}
	}
}

// 获取单个投注项的浮动盈亏
func OddProfitCalc(pool *redis.Client, matchID, marketID, oddID string) (OddCalc, error) {

	var data OddCalc
	key := fmt.Sprintf(redisMatchCalc, matchID)
	res, err := pool.Do("JSON.GET", key, ".market.$"+marketID+".odds.$"+oddID).Text()
	if err == redis.Nil {
		return data, nil
	}
	if err != nil {
		return data, err
	}

	//解析
	var parse fastjson.Parser
	v, err := parse.Parse(res)
	if err != nil {
		return data, err
	}

	data.RealityBetCount = v.GetInt("rbc")
	data.FloatBetCount = v.GetInt("fbc")
	data.RealityBetAmount = v.GetFloat64("fba")
	data.RealityTheoryPrize = v.GetFloat64("rthp")
	data.FloatTheoryPrize = v.GetFloat64("fthp")

	return data, nil
}

/*
 * @Description: 撤单: 赛事风险标签(投注金额,投注单注)统计
 * @Author: robin
 * @Date: 2021/11/9 22:13
 * @LastEditTime: 2021/11/9 22:13
 * @LastEditors: robin
 */
func RiskTagOrderCancelCalc(pipe redis.Pipeliner, cancelOddOrders map[string]map[string]MatchRiskTagOrderCancelData, cancelMatchTotal map[string]MatchRiskTagCancelTotal) {

	//撤单 按赛事ID进行层级统计:总投注金额,总投注单数
	if len(cancelMatchTotal) > 0 {
		for matchId, d := range cancelMatchTotal {
			key := fmt.Sprintf(redisMatchCalc, matchId)
			if d.BetCount > 0 {
				pipe.Do("JSON.NUMINCRBY", key, ".total.bc", -d.BetCount)
			}

			if d.BetAmount.Sign() == 1 {
				ba := d.BetAmount.Truncate(3).String()
				pipe.Do("JSON.NUMINCRBY", key, ".total.ba", "-"+ba)
			}
		}

		//撤单, 按赛事-风险标签ID进行层级统计: 投注金额, 投注单数
		if len(cancelOddOrders) > 0 {
			for matchId, tagIdMapData := range cancelOddOrders {
				for tagId, d := range tagIdMapData {
					key := fmt.Sprintf(RedisRiskTagCalc, matchId, tagId)
					// 缓存处理
					betAmount := d.BetAmount.StringFixed(0)
					ba, err := strconv.ParseInt(betAmount, 10, 64)
					if err != nil {
						fmt.Printf("MatchId[%v] riskTagId[%v] redis field[ba] ParseInt error[%v]", matchId, tagId, err.Error())
						return
					}
					//投注金额
					_, err = pipe.HIncrBy(key, "ba", -ba).Result()
					if err != nil {
						fmt.Printf("MatchId[%v] riskTagId[%v] redis field[ba] HIncrBy error[%v]", matchId, tagId, err.Error())
						return
					}

					//投注单数
					_, err = pipe.HIncrBy(key, "bc", int64(-d.BetCount)).Result()
					if err != nil {
						fmt.Printf("MatchId[%v] riskTagId[%v] redis field[bc] HIncrBy error[%v]", matchId, tagId, err.Error())
						return
					}
				}
			}
		}
	}
}

/*
 * @Description: 撤单: 风险标签-统计(投注人数)
 * @Author: robin
 * @Date: 2021/11/12 21:22
 * @LastEditTime: 2021/11/12 21:22
 * @LastEditors: robin
 */
func RiskTagMemberCancelCalc(dbx *sqlx.DB, pool *redis.Client, cancelOddOrders map[string]map[string]MatchRiskTagOrderCancelData, memberRiskTagsMap map[string]string) {

	matchRiskTagDataMap := map[string]MatchRiskTagData{}
	if len(cancelOddOrders) > 0 {
		matchIDSet := set.NewStringSet()
		for matchId, _ := range cancelOddOrders {
			matchIDSet.Add(matchId)
		}

		var matchRiskTagData []MatchRiskTagData
		if len(matchIDSet.List()) > 0 {
			// 风险标签-统计
			ex := g.Ex{
				"match_id":   matchIDSet.List(),
				"bet_status": []int{3, 5, 6}, // 注单状态:3-待结算,5-已中奖,6-未中奖
				"order_type": []int{1, 4},    // 注单类型:1-普通单注,4-复合玩法
				"tester":     0,
			}

			query, _, _ := dialect.From("tbl_bet_order").Select(
				"match_id", "member_id", "risk_tag_id", g.COUNT(g.C("id")).As("bet_count"),
			).GroupBy("match_id", "member_id", "risk_tag_id").Where(ex).ToSQL()
			err := dbx.Select(&matchRiskTagData, query)
			if err != nil {
				fmt.Printf("mysql select query error:%v", err.Error())
				return
			}

			for _, d := range matchRiskTagData {
				key := fmt.Sprintf(RedisRiskBetCalc, d.MatchID, d.MemberID, d.RiskTagID)
				matchRiskTagDataMap[key] = d
			}

			// 风险标签 统计(获取风险会员标签ID的注单数[待结算,已中奖,未中奖])
			if len(memberRiskTagsMap) > 0 {
				for _, matchId := range matchIDSet.List() {
					for k, _ := range memberRiskTagsMap {
						tmpSlice := strings.Split(k, ":") // 会员ID:风险标签ID
						if len(tmpSlice) != 2 {
							continue
						}
						key := fmt.Sprintf(RedisRiskBetCalc, matchId, tmpSlice[0], tmpSlice[1])
						if _, ok := matchRiskTagDataMap[key]; !ok {
							matchRiskTagDataMap[key] = MatchRiskTagData{
								MatchID:   matchId,
								MemberID:  tmpSlice[0],
								RiskTagID: tmpSlice[1],
								BetCount:  0,
							}
						}
					}
				}
			}
		}
	}

	if len(matchRiskTagDataMap) > 0 {
		for riskBetCalcKey, d := range matchRiskTagDataMap {
			if d.BetCount != 0 {
				continue
			}
			//若赛事ID:会员ID:风险标签ID:投注人数为0,则删除Key(赛事ID:会员ID:风险标签ID)
			value, err := pool.Get(riskBetCalcKey).Result()
			if err != nil && err != redis.Nil {
				fmt.Printf("redis get key error:%v", err.Error())
				return
			}

			if len(value) > 0 {
				pool.Del(riskBetCalcKey)
				//投注人数
				key := fmt.Sprintf(RedisRiskTagCalc, d.MatchID, d.RiskTagID)
				_, err = pool.HIncrBy(key, "mc", -1).Result()
				if err != nil {
					fmt.Printf("redis field[mc] HIncrBy error[%v]", err.Error())
					return
				}
			}
		}

	}
}

/*
 * @Description: 接受风险注单: 风险标签-统计(投注金额,投注单数)
 * @Author: robin
 * @Date: 2021/11/7 16:19
 * @LastEditTime: 2021/11/7 16:19
 * @LastEditors: robin
 */
func RiskTagCalcAccept(pipe redis.Pipeliner, amount, riskTagId, matchID string, exchangeRate decimal.Decimal) bool {

	betAmount, err := decimal.NewFromString(amount)
	if err != nil {
		fmt.Printf("risk_tag_id[%v] bet_amount decimal.NewFromString error[%v]", betAmount, err.Error())
		return false
	}

	ba, _ := betAmount.Div(exchangeRate).Truncate(3).Float64()

	// 缓存处理
	key := fmt.Sprintf(RedisRiskTagCalc, matchID, riskTagId)
	//投注金额
	_, err = pipe.HIncrByFloat(key, "ba", ba).Result()
	if err != nil {
		fmt.Printf("risk_tag_id[%v] redis field[ba] HIncrBy error[%v]", riskTagId, err.Error())
		return false
	}

	//投注单数
	_, err = pipe.HIncrBy(key, "bc", 1).Result()
	if err != nil {
		fmt.Printf("risk_tag_id[%v] redis field[bc] HIncrBy error[%v]", riskTagId, err.Error())
		return false
	}

	return true
}

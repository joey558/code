package calc

import (
	"database/sql"
	g "github.com/doug-martin/goqu/v9"
	"github.com/jmoiron/sqlx"
)

const (
	TblMatchLevel = "tbl_match_level" //风控赛事等级表
)

//赛事等级设置
type MatchLevel struct {
	ID                         int     `json:"id" db:"id"`                                                                                                                                   // 主键id
	Level                      int     `json:"level" db:"level"`                                                                                                                             // 等级
	CreditLevel                int     `json:"credit_level" db:"credit_level"`                                                                                                               // 信用联赛等级
	PrizeLimit                 int     `json:"prize_limit" db:"prize_limit"`                                                                                                                 // 单注赔付默认值
	MaxPrizeLimit              int     `json:"max_prize_limit" db:"max_prize_limit"`                                                                                                         // 单注赔付最大值
	MbMktPrizeLimit            int     `json:"mb_mkt_prize_limit" db:"mb_mkt_prize_limit"`                                                                                                   // 会员盘口赔付默认值
	MaxMbMktPrizeLimit         int     `json:"max_mb_mkt_prize_limit" db:"max_mb_mkt_prize_limit"`                                                                                           // 会员盘口赔付最大值
	WarningProfit              int     `json:"warning_profit" db:"warning_profit"`                                                                                                           // 预警值
	MaxWarningProfit           int     `json:"max_warning_profit" db:"max_warning_profit"`                                                                                                   // 预警值最大值
	StopProfit                 int     `json:"stop_profit" db:"stop_profit"`                                                                                                                 // 停盘值
	MaxStopProfit              int     `json:"max_stop_profit" db:"max_stop_profit"`                                                                                                         // 停盘值最大值
	MbMchPrizeLimit            int     `json:"mb_mch_prize_limit" db:"mb_mch_prize_limit"`                                                                                                   // 会员赛事赔付
	ReturnRate                 float64 `json:"return_rate" db:"return_rate"`                                                                                                                 // 返还率
	RndCompPrizeLimit          int     `json:"rnd_comp_prize_limit" db:"rnd_comp_prize_limit"`                                                                                               // 单局串关单注赔付
	RndCompMchPrizeLimit       int     `json:"rnd_comp_mch_prize_limit" db:"rnd_comp_mch_prize_limit"`                                                                                       // 单局串关赛事赔付
	RndCompOddDscnt            float64 `json:"rnd_comp_odd_dscnt" db:"rnd_comp_odd_dscnt"`                                                                                                   // 局内串关返还率
	PrizeStaticProfit          int     `json:"prize_static_profit" db:"prize_static_profit"`                                                                                                 // 单注限红默认值
	MaxPrizeStaticProfit       int     `json:"max_prize_static_profit" db:"max_prize_static_profit"`                                                                                         // 单注限红最大值
	MbMchMaxPrizeLimit         int     `json:"mb_mch_max_prize_limit" db:"mb_mch_max_prize_limit"`                                                                                           // 会员赛事最大赔付
	RndCompMaxPrizeLimit       int     `json:"rnd_comp_max_prize_limit" db:"rnd_comp_max_prize_limit"`                                                                                       // 单局串关单注最大赔付
	RndCompMchMaxPrizeLimit    int     `json:"rnd_comp_mch_max_prize_limit" db:"rnd_comp_mch_max_prize_limit"`                                                                               // 单局串关赛事最大赔付
	Status                     int     `json:"status" db:"status"`                                                                                                                           // 启用状态(0-关闭, 1-开启)
	OpTime                     int64   `json:"op_time" db:"op_time"`                                                                                                                         // 操作时间
	OpById                     int     `json:"op_by_id" db:"op_by_id"`                                                                                                                       // 操作人员id
	OpByName                   string  `json:"op_by_name" db:"op_by_name"`                                                                                                                   // 操作人员名称
	MchsCompPrizeLimit         int     `json:"mchs_comp_prize_limit" db:"mchs_comp_prize_limit" `                                                                                            // 普通串关单注赔付默认值
	MchsCompMaxPrizeLimit      int     `json:"mchs_comp_max_prize_limit" db:"mchs_comp_max_prize_limit"`                                                                                     // 普通串关单注赔付最大值
	LevelRemark                string  `json:"level_remark" db:"level_remark"`                                                                                                               // 赛事等级备注
	SortCode                   int     `json:"sort_code" db:"sort_code"`                                                                                                                     // 排序码(序号)
	MixStopProfit              int     `db:"mix_stop_profit" json:"mix_stop_profit" rule:"digit" min:"1" msg:"mix_stop_profit error" name:"mix_stop_profit"`                                 // 复合玩法停盘值
	MixMaxStopProfit           int     `db:"mix_max_stop_profit" json:"mix_max_stop_profit" rule:"digit" min:"1" msg:"mix_max_stop_profit error" name:"mix_max_stop_profit"`                 // 复合玩法停盘最大值
	MixWarningProfit           int     `db:"mix_warning_profit" json:"mix_warning_profit" rule:"digit" min:"1" msg:"mix_warning_profit error" name:"mix_warning_profit"`                     // 复合玩法预警值
	MixMaxWarningProfit        int     `db:"mix_max_warning_profit" json:"mix_max_warning_profit" rule:"digit" min:"1" msg:"mix_max_warning_profit error" name:"mix_max_warning_profit"`     // 复合玩法预警最大值
	MixPrizeLimit              int     `db:"mix_prize_limit" json:"mix_prize_limit" rule:"digit" min:"1" msg:"mix_prize_limit error" name:"mix_prize_limit"`                                 // 复合玩法单注赔付
	MixMaxPrizeLimit           int     `db:"mix_max_prize_limit" json:"mix_max_prize_limit" rule:"digit" min:"1" msg:"mix_max_prize_limit error" name:"mix_max_prize_limit"`                 // 复合玩法单注赔付最大值
	MixMchPrizeLimit           int     `db:"mix_mch_prize_limit" json:"mix_mch_prize_limit" rule:"digit" min:"1" msg:"mix_mch_prize_limit error" name:"mix_mch_prize_limit"`                 // 复合玩法赛事赔付
	MixMaxMchPrizeLimit        int     `db:"mix_mch_max_prize_limit" json:"mix_mch_max_prize_limit" rule:"digit" min:"1" msg:"mix_mch_max_prize_limit error" name:"mix_mch_max_prize_limit"` // 复合玩法赛事赔付最大值
	MixOddDscnt                float64 `db:"mix_odd_dscnt" json:"mix_odd_dscnt" rule:"amount" min:"1" max:"100" msg:"mix_odd_dscnt error" name:"mix_odd_dscnt"`                              // 复合玩法返还率
	MchsCompPrizeTotalLimit    int     `db:"mchs_comp_prize_total_limit" json:"mchs_comp_prize_total_limit"`                                                                                 // 普通串关最高赛事赔付
	MchsCompPrizeMaxTotalLimit int     `db:"mchs_comp_prize_max_total_limit" json:"mchs_comp_prize_max_total_limit"`                                                                         // 普通串关最高赛事赔付最大值
}

/**
* @Description: 查询一条赛事等级记录
* @Author:mike
* @Date: 2020/7/15 5:33 下午
* @LastEditTime:  2020/7/15 5:33 下午
* @LastEditors: mike
 */
func MatchLevelFindOne(db *sqlx.DB, ex g.Ex) (MatchLevel, error) {

	data := MatchLevel{}
	query, _, _ := dialect.Select(colMatchLevel...).From(TblMatchLevel).Where(ex).ToSQL()
	err := db.Get(&data, query)
	if err == sql.ErrNoRows {
		return data, nil
	}

	return data, err
}

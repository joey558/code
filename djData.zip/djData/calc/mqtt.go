package calc

import (
	mqtt "github.com/eclipse/paho.mqtt.golang"
)

// mqtt 服务质量参数
const (
	QoSAtMostOnce  = 0 // 最多一次
	QoSAtLeastOnce = 1 // 最少一次
	QoSAlwaysOnce  = 2 // 只一次
)

func MQTTNotify(cli mqtt.Client, topic string, qos byte, data interface{}) error {

	var (
		payload interface{}
		size    int
	)
	switch data.(type) {
	case string:
		payload = data
		size = len(data.(string))
	case []byte:
		payload = data
		size = len(data.([]byte))
	default:
		marshal, err := json.Marshal(&data)
		if err != nil {
			Printf("[MQTTNotify] marshal error. cli:%v, topic:%s, payload:%+v, err:%s\n", cli, topic, data, err.Error())
			return err
		}
		payload = marshal
		size = len(marshal)
	}

	if size > 10240 { // > 1K
		Printf("[MQTTNotify] large payload. cli:%v, topic:%s, payload:%s\n", cli, topic, payload)
	}

	if token := cli.Publish(topic, qos, false, payload); token.Wait() && token.Error() != nil {
		Printf("[MQTTNotify] fail. cli:%v, topic:%s, payload:%s, err:%s\n", cli, topic, payload, token.Error().Error())
		return token.Error()
	}

	return nil
}

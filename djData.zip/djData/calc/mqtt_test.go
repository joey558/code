package calc

import (
	"fmt"
	mqtt "github.com/eclipse/paho.mqtt.golang"
	"testing"
	"time"
)

func initMqttService(mqttCfg []string) mqtt.Client {

	clientOptions := mqtt.NewClientOptions().
		SetClientID(fmt.Sprintf("mqtt-client-%d", time.Now().Second())).
		SetCleanSession(true).
		SetAutoReconnect(false).
		SetKeepAlive(120 * time.Second).
		SetPingTimeout(10 * time.Second).
		SetWriteTimeout(10 * time.Second).
		SetMaxReconnectInterval(10 * time.Second)

	for _, v := range mqttCfg {
		clientOptions.AddBroker(v)
	}

	client := mqtt.NewClient(clientOptions)
	if conn := client.Connect(); conn.WaitTimeout(time.Duration(10)*time.Second) && conn.Wait() && conn.Error() != nil {
		Println("token:", conn.Error())
	}
	return client
}

type Node struct {
	ID          string  `json:"id"`
	Name        string  `json:"name"`
	StringFiled string  `json:"string_filed"`
	BoolField   bool    `json:"bool_field"`
	IntFiled    int     `json:"int_filed"`
	FloatField  float32 `json:"float_field"`
	SubNode     *Node   `json:"sub_node"`
}

func TestMQTTNotify(t *testing.T) {

	cli := initMqttService([]string{"tcp://23.99.118.176:1885"})

	node := Node{
		ID:          "xxx-001",
		Name:        "Parent",
		StringFiled: "I'm string",
		BoolField:   false,
		IntFiled:    111,
		FloatField:  123.456,
		SubNode: &Node{
			ID:          "xxx-xxx-001",
			Name:        "Child",
			StringFiled: "I'm string",
			BoolField:   true,
			IntFiled:    222,
			FloatField:  456.123,
		},
	}

	// large payload
	var nodes []Node
	for i := 0; i < 1000; i++ {
		nodes = append(nodes, node)
	}

	payloads := []interface{}{
		1,
		1.23,
		int64(666),
		true,
		"I'm string",
		fmt.Sprintf(`{"match_id":"%s","market_id":"%s"}`, "111", "222"),
		`{"match_id":"%s","market_id":"%s"}`,
		[]byte{1, 2, 3, 4},
		[]byte{'1', '2', '3', '4'},
		node,
		nodes,
	}

	for _, payload := range payloads {
		err := MQTTNotify(cli, "test/testTopic", payload)
		if err != nil {
			t.Log(err)
		}
	}

}

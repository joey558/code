package controller

import (
	"github.com/valyala/fasthttp"
)

type BetController struct{}

// 加扣款
func (that *BetController) Transfer(ctx *fasthttp.RequestCtx) {

	data := `{
    "code": "0000",
    "msg":"扣款成功!",
    "data": {
      "balance": 1000.01
    }
  }`
	ctx.SetStatusCode(200)
	ctx.SetContentType("application/json")

	ctx.SetBody([]byte(data))
}

// 回调转账状态
func (that *BetController) GetTransferStatus(ctx *fasthttp.RequestCtx) {

	data := `{
    "code": "0000",
    "msg":"成功!"
  }`
	ctx.SetStatusCode(200)
	ctx.SetContentType("application/json")

	ctx.SetBody([]byte(data))
}

// 回调玩家余额
func (that *BetController) GetUserBalance(ctx *fasthttp.RequestCtx) {

	data := `{
    "msg":"成功",
    "code":"0000",
    "data":99889,
    "serverTime":"1606730307842",
    "status":true
}`
	ctx.SetStatusCode(200)
	ctx.SetContentType("application/json")

	ctx.SetBody([]byte(data))
}

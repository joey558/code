#! /bin/bash

DIR=$(dirname $(readlink -f $0))
PROJECT="djData"
BRANCH="dev"
ETCDS="34.92.193.98:2379,34.92.58.208:2379"
CFG_PATH="/dj/dev/data/data.json"
LOG_DIR="/data/logs/${PROJECT}"
ADMIN_LOG_PATH=${LOG_DIR}/admin.log

if [ ! -d "$LOG_DIR" ]; then
mkdir "$LOG_DIR"
fi

if [ ! -f "$ADMIN_LOG_PATH" ]; then
touch "$ADMIN_LOG_PATH"
fi

sh "${DIR}"/build.sh $BRANCH
pkill $PROJECT
LOG_TIME=`date +'%Y.%m.%d.%H%M%S'`
mv $ADMIN_LOG_PATH $ADMIN_LOG_PATH-$LOG_TIME
nohup "${DIR}"/$PROJECT $ETCDS $CFG_PATH admin > $ADMIN_LOG_PATH 2>&1 &


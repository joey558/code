package main

import (
	"djData/contrib/apollo"
	"djData/helper/conf"
	"djData/model"
	"djData/router"
	"djData/service"
	"djData/service/common"
	"djData/service/domain_service"
	"djData/service/match_service"
	"djData/service/order_service"
	"djData/service/rocket_mq_service"
	"fmt"
	"os"
	"os/signal"
	"strings"
	"time"
)

var (
	gitReversion   = ""
	buildTime      = ""
	buildGoVersion = ""
)

func main() {

	argc := len(os.Args)
	if argc < 4 {
		fmt.Printf("%s <etcds> <cfgPath> [admin]\n", os.Args[0])
		return
	}

	etcds := os.Args[1]
	cfgPath := os.Args[2]
	runStyle := strings.ToLower(os.Args[3])

	endpoints := strings.Split(etcds, ",")
	apollo.New(endpoints)
	err := apollo.Parse(cfgPath, &conf.Cfg)
	if err != nil {
		fmt.Println(err.Error())
		return
	}

	if len(conf.Cfg.TYApiConf.PlayerUrl) == 0 {
		fmt.Println("【视频域名接口】视频播放器URL不能为空.")
		return
	}

	//初始化服务
	model.Constructor()
	b := router.BuildInfo{
		GitReversion:   gitReversion,
		BuildTime:      buildTime,
		BuildGoVersion: buildGoVersion,
	}
	var services []service.Service
	switch runStyle {
	case "admin":
		service.StartHTTPServer(b)

		// 启动后台服务
		err = common.InitOddTypeSID()
		if err != nil {
			fmt.Printf("玩法缓存初始化-InitOddTypeSID 错误[%s]...\n", err.Error())
		}
		fmt.Print("玩法缓存初始化-InitOddTypeSID 完成...\n")
		fmt.Printf("APIDomain-请求接口:%v\n", conf.Cfg.TYApiConf.LoginUrl)
		fmt.Printf("网页播放器URL:%v\n", conf.Cfg.TYApiConf.PlayerUrl)

		services = append(services, &domain_service.DomainService{})      // 视频域名接口更新
		services = append(services, &match_service.MatchService{})        // 采集赛事服务
		services = append(services, &order_service.OrderService{})        // 拉单服务
		services = append(services, &rocket_mq_service.RocketMQService{}) // 赔率变动 赛事盘口状态服务
	}

	for _, srv := range services {
		srv.Start()
	}

	fmt.Println("服务启动")

	// 监听退出
	quit := make(chan os.Signal, 1)
	signal.Notify(quit, os.Interrupt)
	<-quit

	// 停止后台服务
	for _, srv := range services {
		srv.Stop()
	}

	time.Sleep(time.Second * 8)
	model.ServerStop()
	fmt.Println("进程退出完毕.")
}

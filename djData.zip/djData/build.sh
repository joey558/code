#! /bin/bash

DIR=$(dirname $(readlink -f $0))
PROJECT="djData"
BRANCH="$1"

if [ "$BRANCH" != "dev" ] && [ "$BRANCH" != "fat" ] && [ "$BRANCH" != "master" ] ; then
    echo "usage: sh build.sh [dev|fat|master]"
    exit
fi

git fetch
git checkout $BRANCH
git pull
git submodule init
git submodule update
GitReversion=`git rev-parse HEAD`
BuildTime=`date +'%Y.%m.%d.%H%M%S'`
BuildGoVersion=`go version`
go build -ldflags "-X main.gitReversion=${GitReversion}  -X 'main.buildTime=${BuildTime}' -X 'main.buildGoVersion=${BuildGoVersion}'" -o $PROJECT

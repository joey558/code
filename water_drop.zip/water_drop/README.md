


一共就3个功能
a是当天结算
b是昨天
c是补偿原先某天

/data/waterdrop/bin/start-waterdrop.sh --config /data/waterdrop_conf/uat-dj-es-a.conf --deploy-mode client --master 'spark://10.2.19.48:7077' > /data/waterdrop_log/mkdj-pro_job.log 2>&1


/usr/local/waterdrop/bin/start-waterdrop.sh --config /data/waterdrop_conf/dev-test.conf --deploy-mode client --master 'spark://192.168.0.91:7077'


/data/waterdrop/bin/start-waterdrop.sh --config /data/waterdrop_conf/uat-es-test.conf --deploy-mode client --master 'spark://10.2.19.48:7077'


# dev es test
/usr/local/waterdrop/bin/start-waterdrop.sh --config /data/waterdrop_conf/dev-es-test.conf --deploy-mode client --master 'spark://192.168.0.91:7077'


  curl -XDELETE -u elastic:changeme http://10.170.0.4:9200/match_report
  curl -XDELETE -u elastic:changeme http://10.170.0.4:9200/test_report
  curl -XDELETE -u elastic:changeme http://10.170.0.4:9200/impack_report
  curl -XDELETE -u elastic:changeme http://10.170.0.4:9200/member_report
  curl -XDELETE -u elastic:changeme http://10.170.0.4:9200/overview_report
  curl -XDELETE -u elastic:changeme http://10.170.0.4:9200/merchant_report
  curl -XDELETE -u elastic:changeme http://10.170.0.4:9200/game_report
  curl -XDELETE -u elastic:changeme http://10.170.0.4:9200/market_report
  curl -XDELETE -u elastic:changeme http://10.170.0.4:9200/parley_report
  curl -XDELETE -u elastic:changeme http://10.170.0.4:9200/test_dev_report
  curl -XDELETE -u elastic:changeme http://10.170.0.4:9200/parent_merchant_report
  curl -XDELETE -u elastic:changeme http://10.170.0.4:9200/impact_report
  
  curl '10.170.0.4:9200/_cat/indices?v'

#!/usr/bin/env sh

# 环境变量
export JAVA_HOME=/data/jdk
export SPARK_HOME=/data/spark
export PATH=$PATH:$SPARK_HOME/bin:/data/spark/bin:$JAVA_HOME/bin

if [ $1 == "" ]
then
  s_date=`date -d 'today 0' +%s`
  e_date=`date -d 'next-day 0' +%s`
  m_date=`date -d '1 month ago 0' +%s`
else
  s_date=`date -d "$1" +%s`
  e_date=$(($s_date+86400))
  m_date=$(($s_date-2678400))
fi

echo "start_time" \"$s_date\"
echo "end_time" \"$e_date\"

start_time=`date  +"%Y/%m/%d %H:%M:%S"`
echo "Spark_begin" \"$start_time\"

/data/waterdrop/bin/start-waterdrop.sh --config /data/waterdrop_conf/uat_tidb.conf --deploy-mode client --master 'spark://10.2.19.48:7077'  -i s_date=${s_date} -i e_date=${e_date} -i m_date=${m_date}  > /data/waterdrop_log/uat.log 2>&1

end_time=`date  +"%Y/%m/%d %H:%M:%S"`
echo "Spark_end" \"$end_time\"

start_time=`date  +"%Y/%m/%d %H:%M:%S"`
echo "Tidb_begin" \"$start_time\"

mysql -udj_report -h10.2.19.21 -P3309 -p"dqDNSmDl7VKCnkGN" mkdj_rp << eof
begin;
replace into t_overview_report(mem_count, bet_count, win_count, bet_amount, win_amount, profit_amount, bet_pae, report_timestamp) select * from t_overview_report_day ;
replace into t_parent_merchant_report(merchant_id,mem_count, bet_count, win_count, bet_amount, win_amount, profit_amount, bet_pae, report_timestamp) select * from t_parent_merchant_report_day ;
replace into t_merchant_report(merchant_id, sort_level, mem_count, bet_count, win_count, bet_amount, win_amount, profit_amount, bet_pae, report_timestamp) select * from t_merchant_report_day ;
replace into t_game(game_id,top_merchant_id,merchant_id,sort_level,mem_count,bet_count,win_count,bet_amount,win_amount,profit_amount,report_timestamp) select * from t_game_day ;
replace into t_game_report(game_id, top_merchant_id, merchant_id,sort_level, is_live, mem_count, bet_count, win_count, bet_amount, win_amount, profit_amount, report_timestamp) select * from t_game_report_day ;
replace into t_tournament(game_id, top_merchant_id,merchant_id,sort_level, tournament_id, mem_count, bet_count, win_count, bet_amount, win_amount, profit_amount, report_timestamp) select * from t_tournament_day ;
replace into t_tournament_report(game_id, top_merchant_id,merchant_id,sort_level, tournament_id, is_live, mem_count, bet_count, win_count, bet_amount, win_amount, profit_amount, report_timestamp) select * from t_tournament_report_day ;
replace into t_org_odd(game_id, top_merchant_id, merchant_id,sort_level, tournament_id, org_odd_id, mem_count, bet_count, win_count, bet_amount, win_amount, profit_amount, report_timestamp) select * from t_org_odd_day ;
replace into t_org_odd_report(game_id, top_merchant_id,merchant_id,sort_level,tournament_id, org_odd_id, is_live, mem_count, bet_count, win_count, bet_amount, win_amount, profit_amount, report_timestamp) select * from t_org_odd_report_day ;
replace into t_match(match_id, game_id, tournament_id, top_merchant_id, merchant_id,sort_level, match_type, mem_count, bet_count, win_count, bet_amount, win_amount, profit_amount, report_timestamp, match_level) select * from t_match_day ;
replace into t_match_report(match_id, game_id, tournament_id, top_merchant_id,merchant_id, sort_level,is_live, match_type, mem_count, bet_count, win_count, bet_amount, win_amount, profit_amount, report_timestamp, match_level) select * from t_match_report_day ;
replace into t_parley_report(top_merchant_id,merchant_id,sort_level, mem_count, bet_count, win_count, bet_amount, win_amount, profit_amount, report_timestamp) select * from t_parley_report_day ;
replace into t_round_parley(top_merchant_id,merchant_id,sort_level, mem_count, bet_count, win_count, bet_amount, win_amount, profit_amount, report_timestamp) select * from t_round_parley_day ;
replace into t_round_parley_report(game_id,tournament_id,match_id,match_type,top_merchant_id,merchant_id,sort_level, mem_count, bet_count, win_count, bet_amount, win_amount, profit_amount, report_timestamp) select * from t_round_parley_report_day ;
replace into t_member_report(member_id, member_account, top_merchant_id, top_merchant_account,parent_merchant_id, parent_merchant_account, merchant_id, merchant_account,sort_level, bet_count, win_count, bet_amount, win_amount, profit_amount, report_timestamp) select * from t_member_report_day ;
replace into t_market(match_id, market_cn_name, top_merchant_id,merchant_id,sort_level, market_id, round, mem_count, bet_count, win_count, bet_amount, win_amount, profit_amount, report_timestamp) select * from t_market_day ;
replace into t_market_report(match_id, market_cn_name, top_merchant_id,merchant_id,sort_level, is_live, market_id, round, mem_count, bet_count, win_count, bet_amount, win_amount, profit_amount, report_timestamp) select * from t_market_report_day ;
replace into t_impact_report(top_merchant_id, merchant_id,sort_level,impact_amount,report_timestamp) select * from t_impact_report_day;
replace into t_merchant(id,account,parent_merchant_id,parent_merchant_account,top_merchant_id,top_merchant_account,sort_level) select * from t_merchants;
commit;
eof

end_time=`date  +"%Y/%m/%d %H:%M:%S"`
echo "Tidb_end" \"$end_time\"



#!/usr/bin/env sh

# 环境变量
export JAVA_HOME=/data/jdk
export SPARK_HOME=/data/spark
export PATH=$PATH:$SPARK_HOME/bin:/data/spark/bin:$JAVA_HOME/bin

if [ $1 == "" ]; then
  s_date=$(date -d 'today 0' +%s)
  e_date=$(date -d 'next-day 0' +%s)
  m_date=$(date -d '1 month ago 0' +%s)
else
  s_date=$(date -d "$1" +%s)
  e_date=$(($s_date + 86400))
  m_date=$(($s_date - 2678400))
fi

echo "start_time" \"$s_date\"
echo "end_time" \"$e_date\"

start_time=$(date +"%Y/%m/%d %H:%M:%S")
echo "Spark_begin" \"$start_time\"

/data/waterdrop/bin/start-waterdrop.sh --config /data/waterdrop_conf/dev_tidb.conf --deploy-mode client --master 'spark://10.170.0.9:7077' -i s_date=${s_date} -i e_date=${e_date} -i m_date=${m_date} >/data/waterdrop_log/dev.log 2>&1

end_time=$(date +"%Y/%m/%d %H:%M:%S")
echo "Spark_end" \"$end_time\"

start_time=$(date +"%Y/%m/%d %H:%M:%S")
echo "Tidb_begin" \"$start_time\"

mysql -udj_app -h34.92.193.98 -P3306 -p"SKsho232SL9S" mkdj_rp <<eof
begin;
delete from t_front_statistics_report where report_timestamp = ${s_date};
replace into t_front_statistics_report(top_merchant_id, merchant_id,sort_level,device,online_interval,click_tab,click_number,report_timestamp) select * from t_front_statistics_day;
commit;
eof

end_time=$(date +"%Y/%m/%d %H:%M:%S")
echo "Tidb_end" \"$end_time\"

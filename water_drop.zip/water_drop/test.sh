#!/usr/bin/env sh

if [ $1 == "" ]
then
  s_date=`date -d 'today 0' +%s`
  e_date=`date -d 'next-day 0' +%s`
  m_date=`date -d '1 month ago 0' +%s`
else
  s_date=`date -d "$1" +%s`
  e_date=$(($s_date+86400))
  m_date=$(($s_date-2678400))
fi

echo "start_time" \"$s_date\"
echo "end_time" \"$e_date\"

start_time=`date  +"%Y/%m/%d %H:%M:%S"`
echo "Spark_begin" \"$start_time\"

/data/waterdrop/bin/start-waterdrop.sh --config /data/waterdrop_conf/test.conf --deploy-mode client --master 'spark://10.170.0.9:7077' -i s_date=${s_date} -i e_date=${e_date} -i m_date=${m_date} > /data/waterdrop_log/test.log 2>&1

end_time=`date  +"%Y/%m/%d %H:%M:%S"`
echo "Spark_end" \"$end_time\"
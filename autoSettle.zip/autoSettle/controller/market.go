package controller

import (
	"autoSettle/contrib/validator"
	"autoSettle/helper"
	"autoSettle/model"
	odds "autoSettle/model/odds/pull"
	"fmt"
	g "github.com/doug-martin/goqu/v9"
	"github.com/valyala/fasthttp"
	"time"
)

type MarketController struct{}

type MarketSettleParam struct {
	DataSource   int    `rule:"digit" name:"data_source" default:"0" min:"1" max:"5" msg:"data_source错误"`
	GameID       int    `rule:"digit" name:"game_id" default:"0"  msg:"game_id错误"`
	TournamentID int    `rule:"digit" name:"tournament_id" default:"0"  msg:"tournament_id错误"`
	StartTime    string `rule:"dateTime" default:"2020-01-01 00:00:00" msg:"start_time格式不正确" name:"start_time"`
	EndTime      string `rule:"dateTime" default:"2020-01-01 00:00:00" msg:"end_time格式不正确" name:"end_time"`
	Page         uint   `rule:"digit" name:"page" default:"1" msg:"illegal page"`
	PageSize     uint   `rule:"digit" name:"page_size" default:"20" msg:"illegal page_size"`
}

type MarketResultConfirmParam struct {
	MatchID    string `rule:"digit" name:"match_id" default:"0"  msg:"match_id错误"`
	MarketID   string `rule:"digit" name:"market_id" default:"0"  msg:"market_id错误"`
	DataSource int    `rule:"digit" name:"data_source" default:"0" min:"1" max:"5" msg:"data_source错误"`
}

func (that *MarketController) MarketResultConfirmInput(ctx *fasthttp.RequestCtx) {

	var param MarketResultConfirmParam
	err := validator.Bind(ctx, &param)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	relatedMch, err := model.MatchRelatedFindOne(g.Ex{"match_id": param.MatchID, "data_source": model.ODDS})
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	if relatedMch.SourceMatchID == 0 {
		helper.Print(ctx, "false", fmt.Sprintf("获取比赛[%s]%s数据源关联比赛失败", param.MatchID, model.DataSourceName[model.ODDS]))
		return
	}

	mrc, err := model.MarketResultFindOne(g.Ex{"match_id": param.MatchID, "market_id": param.MarketID, "data_source": param.DataSource})
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	// 总控比赛信息
	tradeMatch, err := model.TradeMatchFindOne(g.Ex{"id": relatedMch.MatchID})
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	data := &model.MarketResultConfirm{
		MatchID:     param.MatchID,
		MarketID:    param.MarketID,
		DataSource:  param.DataSource,
		ConfirmTime: time.Now().Unix(),
	}

	oddID, oddName, err := odds.OddsMarketResult(relatedMch, tradeMatch, param.MarketID)
	if err != nil {
		data.WinOddID = "0"
		data.Remark = err.Error()
	} else {
		data.Status = 1
		data.WinOddID = oddID
		data.WinOddName = oddName
		data.Remark = "数据源赛果匹配成功"
	}

	if mrc.ID == 0 { // 新增
		data.ID = helper.Cputicks()
		err = model.MarketResultInsert(data)
	} else {
		v := g.Record{
			"win_odd_id":   data.WinOddID,
			"win_odd_name": data.WinOddName,
			"status":       data.Status,
			"confirm_time": data.ConfirmTime,
			"remark":       data.Remark,
		}
		err = model.MarketResultUpdate(v, g.Ex{"id": mrc.ID})
	}

	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}
	helper.Print(ctx, "true", "数据源赛果匹配成功")
}

package controller

import (
	"autoSettle/contrib/jingo"
	"autoSettle/contrib/validator"
	"autoSettle/helper"
	"autoSettle/model"
	g "github.com/doug-martin/goqu/v9"
	"github.com/valyala/fasthttp"
	"time"
)

type MatchController struct{}

var listEncoder = jingo.NewStructEncoder(model.MatchData{})

// 列表参数
type MatchListParam struct {
	DataSource   int    `rule:"digit" name:"data_source" default:"0" min:"1" max:"5" msg:"data_source错误"`
	GameID       int    `rule:"digit" name:"game_id" default:"0"  msg:"game_id错误"`
	TournamentID int    `rule:"digit" name:"tournament_id" default:"0"  msg:"tournament_id错误"`
	StartTime    string `rule:"dateTime" default:"2020-01-01 00:00:00" msg:"start_time格式不正确" name:"start_time"`
	EndTime      string `rule:"dateTime" default:"2020-01-01 00:00:00" msg:"end_time格式不正确" name:"end_time"`
	Page         uint   `rule:"digit" name:"page" default:"1" msg:"illegal page"`
	PageSize     uint   `rule:"digit" name:"page_size" default:"20" msg:"illegal page_size"`
}

/**
 * @Description: 获取赛事列表
 * @Author: Daxie
 * @Date: 2020/10/22 21:32
 * @LastEditTime: 2020/10/22 21:32
 * @LastEditors: Daxie
 */
func (that *MatchController) List(ctx *fasthttp.RequestCtx) {

	var param MatchListParam
	err := validator.Bind(ctx, &param)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	if param.DataSource != model.ABIOS && param.DataSource != model.ODDS {
		helper.Print(ctx, "false", "数据源参数错误")
		return
	}

	//查询参数处理
	ex := g.Ex{
		"data_source": param.DataSource,
	}

	if param.GameID > 0 {
		ex["game_id"] = param.GameID
	}
	if param.TournamentID > 0 {
		ex["tournament_id"] = param.TournamentID
	}

	if param.StartTime == "2020-01-01 00:00:00" && param.EndTime == "2020-01-01 00:00:00" {
		t := ctx.Time()
		st := time.Date(t.Year(), t.Month(), t.Day(), 0, 0, 0, 0, t.Location())
		et := st.AddDate(0, 0, 1)

		ex["start_time"] = g.Op{"between": g.Range(st.Unix(), et.Unix()-1)}

	} else {
		startTime := helper.StrToTime(param.StartTime).Unix()
		endTime := helper.StrToTime(param.EndTime).Unix()
		ex["start_time"] = g.Op{"between": g.Range(startTime, endTime)}
	}

	offset := param.PageSize * (param.Page - 1)
	data, err := model.MatchesPageList(offset, param.PageSize, ex)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	buf := jingo.NewBufferFromPool()
	listEncoder.Marshal(&data, buf)
	helper.PrintJson(ctx, "true", buf.String())
	buf.ReturnToPool()

}

func (that *MatchController) EsList(ctx *fasthttp.RequestCtx) {

	var param model.EsMatchListParam
	err := validator.Bind(ctx, &param)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	if param.GameID == 0 {
		helper.Print(ctx, "false", "参数错误，游戏id不能为空")
		return
	}
	if param.TournamentName == "" {
		helper.Print(ctx, "false", "参数错误，联赛名称不能为空")
		return
	}
	if param.TeamName == "" {
		helper.Print(ctx, "false", "参数错误，战队不能为空")
		return
	}
	if param.StartTime == "2020-01-01 00:00:00" {
		helper.Print(ctx, "false", "参数错误，比赛开始时间不能为空")
		return
	}

	data, err := model.EsMatchList(param)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}
	helper.Print(ctx, "true", data)
}


func (that *MatchController) SubscriptionLive(ctx *fasthttp.RequestCtx) {

	var param model.MatchLiveParam
	err := validator.Bind(ctx, &param)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	err = model.MatchLiveData(param)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}
	helper.Print(ctx, "true", "订阅成功")
}
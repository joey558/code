package controller

import (
	"autoSettle/contrib/validator"
	"autoSettle/helper"
	"autoSettle/model"

	g "github.com/doug-martin/goqu/v9"
	"github.com/valyala/fasthttp"
)

type GameController struct {}

type GameListParam struct {
	DataSource int `name:"data_source" rule:"digit" min:"1" max:"5" msg:"数据源错误"`
}

/**
 * @Description: 根据数据源标识获取数据源游戏列表
 * @Author: awen
 * @Date: 2020/10/22 22:32
 * @LastEditTime: 2020/10/22 22:32
 * @LastEditors: awen
 */
func (that *GameController) GameList(ctx *fasthttp.RequestCtx) {

	param := GameListParam{}
	err := validator.Bind(ctx, &param)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	ex := g.Ex{
		"data_source": param.DataSource,
	}

	data, err := model.GameFindAll(ex)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	helper.Print(ctx, "true", data)
}

package controller

import (
	"autoSettle/contrib/validator"
	"autoSettle/helper"
	"autoSettle/model"

	g "github.com/doug-martin/goqu/v9"
	"github.com/valyala/fasthttp"
)

type TournamentController struct{}

type TournamentListParam struct {
	DataSource int `name:"data_source" rule:"digit" min:"1" max:"5" msg:"数据源错误"`
	GameID     int `name:"game_id" rule:"digit" min:"1" msg:"游戏ID错误"`
}

/**
 * @Description: 根据数据源标识和游戏ID获取数据源联赛列表
 * @Author: awen
 * @Date: 2020/10/22 22:51
 * @LastEditTime: 2020/10/22 22:51
 * @LastEditors: awen
 */
func (that *TournamentController) TournamentList(ctx *fasthttp.RequestCtx) {

	param := TournamentListParam{}
	err := validator.Bind(ctx, &param)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	ex := g.Ex{
		"data_source": param.DataSource,
		"game_id":     param.GameID,
	}

	// 只查询联赛开始时间范围在 3个月前-2天后的联赛
	now := ctx.Time()
	startTime := now.AddDate(0,-3,0)
	endTime := now.AddDate(0,0,2)
	rangeEx := g.C("start_time").Between(g.Range(startTime.Unix(), endTime.Unix()))

	data, err := model.TournamentFindAll(ex, rangeEx)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	helper.Print(ctx, "true", data)
}

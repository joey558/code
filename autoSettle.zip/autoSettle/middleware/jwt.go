package middleware

import (
	"github.com/valyala/fasthttp"
)

func CheckTokenMiddleware(ctx *fasthttp.RequestCtx) error {

	return nil
	//path := string(ctx.Path())
	//allows := map[string]bool{
	//	"/autoSettle/version": true,
	//	"/debug/pprof/":       true,
	//	"/debug/pprof/block":  true,
	//	"/debug/pprof/allocs": true,
	//	//"/debug/allocs":             true,
	//	"/debug/pprof/cmdline":      true,
	//	"/debug/pprof/goroutine":    true,
	//	"/debug/pprof/heap":         true,
	//	"/debug/pprof/profile":      true,
	//	"/debug/pprof/trace":        true,
	//	"/debug/pprof/threadcreate": true,
	//
	//	"/autoSettle/game/list":       true,
	//	"/autoSettle/tournament/list": true,
	//}
	//
	//if _, ok := allows[path]; ok {
	//	return nil
	//}
	//
	//data, err := session.Get(ctx)
	//if err != nil {
	//	return errors.New(`{"status":"false","data":"token"}`)
	//}
	//
	//ctx.SetUserValue("sess", data)
	//return nil
}

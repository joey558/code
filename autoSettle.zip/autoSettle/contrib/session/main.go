package session

import (
	"errors"
	// "log"
	"fmt"
	"github.com/go-redis/redis/v7"
	"github.com/valyala/fasthttp"
)

var (
	client *redis.Client
)

func New(reddb *redis.Client) {
	client = reddb
}

func Set(ctx *fasthttp.RequestCtx, value []byte) (string, bool) {

	key := fmt.Sprintf("%d", Cputicks())
	err := client.SetNX(key, value, defaultGCLifetime).Err()
	if err != nil {
		return key, false
	}

	// cookie := NewCookie()
	// cookie.Set(ctx, defaultSessionKeyName, []byte(key), "", defaultExpires, defaultSecure)
	return key, true
}

func Destroy(ctx *fasthttp.RequestCtx) {

	key := string(ctx.Request.Header.Peek("token"))
	if len(key) == 0 {
		return
	}
	client.Unlink(string(key))
	// cookie.Delete(ctx, defaultSessionKeyName)
}

func Get(ctx *fasthttp.RequestCtx) ([]byte, error) {

	key := string(ctx.Request.Header.Peek("token"))
	if len(key) == 0 {
		return nil, errors.New("header missing token")
	}

	val, err := client.Get(key).Bytes()
	if err == redis.Nil {
		return nil, fmt.Errorf("session:%s missing in the redis", key)
	} else if err != nil {
		return nil, err
	} else {
		return val, nil
	}
}

/*
func Replace(key string) interface{} {
	//return s.data.Get(key)
}
*/

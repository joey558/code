package zlog

import (
	"fmt"
	jsoniter "github.com/json-iterator/go"
	"github.com/valyala/fasthttp"

	"github.com/bet365/jingo"
	mqtt "github.com/eclipse/paho.mqtt.golang"
	"log"
	"net/url"
	"strconv"
	"time"
)

var json = jsoniter.ConfigCompatibleWithStandardLibrary

//zlog消息
type record struct {
	Cid      string `json:"cid"`
	Flags    string `json:"flags"`
	Merchant uint64 `json:"merchant"`
	Level    string `json:"level"`
	Line     string `json:"line"`
	Msg      string `json:"msg"`
	Ip       string `json:"ip"`
}

var (
	conn mqtt.Client
	uri  = "23.99.118.176:3100"
	enc  = jingo.NewStructEncoder(record{})
)

type LokiRequest struct {
	Status string `json:"status"`
	Data   struct {
		ResultType string `json:"resultType"`
		Result     []struct {
			Stream map[string]string `json:"stream"`
			Values [][]string        `json:"values"`
		} `json:"result"`
	} `json:"data"`
}

func New(hosts []string, query string) {
	uri = query

	clientOptions := mqtt.NewClientOptions().
		SetClientID(fmt.Sprintf("%d", time.Now().UnixNano())).
		SetCleanSession(false).
		SetAutoReconnect(true).
		SetKeepAlive(120 * time.Second).
		SetPingTimeout(10 * time.Second).
		SetWriteTimeout(10 * time.Second).
		SetMaxReconnectInterval(10 * time.Second)

	for _, v := range hosts {
		clientOptions.AddBroker(v)
	}

	conn = mqtt.NewClient(clientOptions)
	if conn := conn.Connect(); conn.WaitTimeout(time.Duration(10)*time.Second) && conn.Wait() && conn.Error() != nil {
		log.Fatalf("token: %s", conn.Error())
	}

}

// 发送日志
func write(p record) error {

	buf := jingo.NewBufferFromPool()
	enc.Marshal(&p, buf)

	if token := conn.Publish("logger", 0, false, buf.String()); token.Wait() && token.Error() != nil {
		buf.ReturnToPool()
		return token.Error()
	}
	buf.ReturnToPool()
	return nil
}

func Notice(ctx *fasthttp.RequestCtx, flags, line, msg string, cid interface{}, merchantId uint64) {

	id := ""
	if value, ok := cid.(string); ok {
		id = value
	}
	if value, ok := cid.(uint64); ok {
		id = fmt.Sprintf("%d", value)
	}

	tag := "NOTICE"
	data := record{
		Cid:      id,
		Flags:    flags,
		Merchant: merchantId,
		Msg:      msg,
		Line:     line,
		Level:    tag,
		Ip:       "0",
	}

	if ctx != nil {
		data.Ip = FromRequest(ctx)
	}
	write(data)
}

func Error(ctx *fasthttp.RequestCtx, flags, line, msg string, cid interface{}, merchantId uint64) {

	id := ""
	if value, ok := cid.(string); ok {
		id = value
	}
	if value, ok := cid.(uint64); ok {
		id = fmt.Sprintf("%d", value)
	}

	tag := "ERROR"
	data := record{
		Cid:      id,
		Flags:    flags,
		Merchant: merchantId,
		Msg:      msg,
		Line:     line,
		Level:    tag,
		Ip:       "0",
	}
	if ctx != nil {
		data.Ip = FromRequest(ctx)
	}

	write(data)
}

func Info(ctx *fasthttp.RequestCtx, flags, line, msg string, cid interface{}, merchantId uint64) {

	id := ""
	if value, ok := cid.(string); ok {
		id = value
	}
	if value, ok := cid.(uint64); ok {
		id = fmt.Sprintf("%d", value)
	}

	tag := "INFO"
	data := record{
		Cid:      id,
		Flags:    flags,
		Merchant: merchantId,
		Msg:      msg,
		Line:     line,
		Level:    tag,
		Ip:       "0",
	}
	if ctx != nil {
		data.Ip = FromRequest(ctx)
	}

	write(data)
}

// 查询loki log
func Search(cid, flags string, start, end int64, limit int) ([][]string, error) {

	var res [][]string
	query := fmt.Sprintf(`{cid="%s",flags="%s"}`, cid, flags)
	if limit == 0 {
		limit = 50
	}

	v := url.Values{}
	v.Add("direction", "BACKWARD")
	v.Add("limit", strconv.Itoa(limit))
	v.Add("query", query)
	v.Add("start", fmt.Sprintf("%d000000000", start))
	v.Add("end", fmt.Sprintf("%d000000000", end))

	path := fmt.Sprintf("http://%s/loki/api/v1/query_range?%s", uri, v.Encode())

	statusCode, body, err := fasthttp.GetTimeout(nil, path, time.Duration(10)*time.Second)
	if err != nil {
		return res, err
	}

	if statusCode != fasthttp.StatusOK {
		return res, fmt.Errorf("zlog Search 服务错误: %d", statusCode)
	}

	loki := LokiRequest{}
	err = json.Unmarshal(body, &loki)
	if err != nil {
		return res, err
	}

	return loki.Data.Result[0].Values, nil
}

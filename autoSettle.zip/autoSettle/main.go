package main

import (
	"autoSettle/contrib/session"
	"autoSettle/middleware"
	"autoSettle/model/abios/live"
	"fmt"
	"log"
	"os"
	"strings"
	"time"

	"github.com/valyala/fasthttp"

	"autoSettle/contrib/apollo"
	"autoSettle/contrib/zlog"
	"autoSettle/helper"
	"autoSettle/model"
	abios "autoSettle/model/abios/pull"
	odds "autoSettle/model/odds/pull"
	"autoSettle/router"

	"github.com/beanstalkd/go-beanstalk"
	_ "github.com/doug-martin/goqu/v9/dialect/mysql"
	mqtt "github.com/eclipse/paho.mqtt.golang"
	"github.com/go-redis/redis/v7"
	_ "github.com/go-sql-driver/mysql"
	"github.com/jmoiron/sqlx"
	"github.com/olivere/elastic/v7"
	cpool "github.com/silenceper/pool"
	_ "go.uber.org/automaxprocs"
)

type Conf struct {
	AutoSettle struct {
		HTTP string `json:"http"`
	} `json:"auto_settle"`
	FusionDb struct {
		Db          string `json:"db"`
		MaxIdleConn int    `json:"max_idle_conn"`
		MaxOpenConn int    `json:"max_open_conn"`
	} `json:"fusion_db"`
	TradeDb struct {
		Db          string `json:"db"`
		MaxIdleConn int    `json:"max_idle_conn"`
		MaxOpenConn int    `json:"max_open_conn"`
	} `json:"trade_db"`
	RedisMaster struct {
		Addr     []string `json:"addr"`
		Password string   `json:"password"`
		Sentinel string   `json:"sentinel"`
	} `json:"redis_master"`
	RedisSlave struct {
		Addr     string `json:"addr"`
		Password string `json:"password"`
	} `json:"redis_slave"`
	Mqtt      []string `json:"mqtt"`
	Beanstalk string   `json:"beanstalk"`
	Zlog      struct {
		Brokers []string `json:"brokers"`
		URI     string   `json:"uri"`
	} `json:"zlog"`
	Oss struct {
		Endpoint string `json:"endpoint"`
		URL      string `json:"url"`
	} `json:"oss"`
	Fts struct {
		Addr string `json:"addr"`
	} `json:"fts"`
	Elasticsearch struct {
		Host        []string `json:"host"`
		IndexPrefix string   `json:"index_prefix"`
	} `json:"elasticsearch"`
	Merchants []model.MerchantConf `json:"merchants"`
	PoolSize  int                  `json:"pool_size"`
}

var (
	gitReversion   = ""
	buildTime      = ""
	buildGoVersion = ""
)

func main() {

	argc := len(os.Args)
	if argc < 4 {
		fmt.Printf("%s <etcds> <cfgPath> http\n", os.Args[0])
		return
	}

	etcds := os.Args[1]
	cfgPath := os.Args[2]

	cfg := Conf{}
	endpoints := strings.Split(etcds, ",")

	apollo.New(endpoints)
	apollo.Parse(cfgPath, &cfg)
	//fmt.Println(cfg)

	cons := model.Construct{
		SettleMerch: cfg.Merchants,
		EsPrefix:    cfg.Elasticsearch.IndexPrefix,
		PoolSize:    cfg.PoolSize,
	}
	cons.Pool = InitRedisMaster(cfg.RedisMaster.Addr, cfg.RedisMaster.Password, cfg.RedisMaster.Sentinel, 5)
	cons.PoolSlave = InitRedisSlave(cfg.RedisSlave.Addr, cfg.RedisSlave.Password, 5)
	cons.DB = initDB(cfg.FusionDb.Db, cfg.FusionDb.MaxIdleConn, cfg.FusionDb.MaxOpenConn)
	cons.Es = InitES(cfg.Elasticsearch.Host)
	cons.BeanPool = initBeanstalk(cfg.Beanstalk)
	cons.MqttCli = InitMqttService(cfg.Mqtt)

	// 初始化比赛实时数据队列协程池
	//live.BPoolLive, _ = ants.NewPoolWithFunc(50, func(payload interface{}) {
	//
	//	if fn, ok := payload.(live.BeansFnParam); ok {
	//		//消费到任务后就删除job，避免重复启动订阅协程
	//		_ = fn.Conn.Delete(fn.ID)
	//		//结算
	//		live.CustomizeWebSocketSubscription(fn.M)
	//	}
	//})

	model.Constructor(cons)
	session.New(cons.Pool)
	zlog.New(cfg.Zlog.Brokers, cfg.Zlog.URI)

	defer func() {
		cons.DB.Close()
		cons.Pool.Close()
		cons.PoolSlave.Close()
	}()

	switch os.Args[3] {
	case "http":

		tradeDB := initDB(cfg.TradeDb.Db, cfg.TradeDb.MaxIdleConn, cfg.TradeDb.MaxOpenConn)
		traderPool := InitRedisMaster(cfg.RedisMaster.Addr, cfg.RedisMaster.Password, cfg.RedisMaster.Sentinel, 0)
		traderPoolSlave := InitRedisSlave(cfg.RedisSlave.Addr, cfg.RedisSlave.Password, 0)
		model.ConstructorHttp(tradeDB, traderPool, traderPoolSlave)

		defer func() {
			tradeDB.Close()
			traderPool.Close()
			traderPoolSlave.Close()
		}()
		b := router.BuildInfo{
			GitReversion:   gitReversion,
			BuildTime:      buildTime,
			BuildGoVersion: buildGoVersion,
		}

		app := router.SetupHTTPRouter(b)
		srv := &fasthttp.Server{
			Handler:            middleware.Use(app.Handler),
			ReadTimeout:        5 * time.Second,
			WriteTimeout:       10 * time.Second,
			Name:               "autoSettle",
			MaxRequestBodySize: 51 * 1024 * 1024,
		}

		//attr := live.BeansWatcherAttr{
		//	TubeName:       "AbiosLiveData",
		//	ReserveTimeOut: 5 * time.Second,
		//	Pool:           live.BPoolLive,
		//}
		// 结算队列
		//go live.BeanstalkWatcher(cons.BeanPool, attr)

		fmt.Println("autoSettle http running", cfg.AutoSettle.HTTP)
		if err := srv.ListenAndServe(cfg.AutoSettle.HTTP); err != nil {
			log.Fatalf("Error in ListenAndServe: %s", err)
		}

	case "initPull":
		fmt.Println("-----------开始拉取并格式化数据源数据-----------")
		if len(os.Args) == 5 {
			switch os.Args[4] {
			case "game":
				abios.GamesConn()
				odds.LeagueConn(true)
			case "team":
				abios.TeamsConn()
			case "player":
				abios.PlayersConn()
			case "tournament":
				abios.TournamentsConn()
			case "match":
				abios.SeriesConn()
				odds.MatchConn(true)
			}
		} else {
			//abios.GamesConn()
			//abios.TournamentsConn()
			//odds.LeagueConn(false)
			//abios.TeamsConn()
			//abios.PlayersConn()
			//abios.SeriesConn()
			odds.MatchConn(false)
		}

		fmt.Println("数据源数据拉取与格式化成功！")
	case "liveSub": // abios比赛实时订阅
		live.PoolLive = cons.Pool
		//live.BeanPoolLive = cons.BeanPool
		live.MqttLive = cons.MqttCli
		defer func() {
			live.PoolLive.Close()
		}()
		fmt.Println("开始订阅abios比赛实时数据...")
		live.SubscriptionMatchLive()
		select {}
	case "autoPull": //
		abios.AbiosAutoPull()
		odds.OddsAutoPull()
		select {}
	}

}

func initDB(dsn string, maxIdleConn, maxOpenConn int) *sqlx.DB {

	db, err := sqlx.Connect("mysql", dsn)
	if err != nil {
		fmt.Println(err)
		return db
	}

	db.SetMaxOpenConns(maxOpenConn)
	db.SetMaxIdleConns(maxIdleConn)
	db.SetConnMaxLifetime(time.Second * 30)
	err = db.Ping()
	if err != nil {
		log.Fatalf("initDB failed: %s", err.Error())
	}

	return db
}

/**
* @Description: 初始化redis master
* @Author: brandon
* @Date: 2020/6/30 11:20 上午
* @LastEditTime: 2020/6/30 11:20 上午
* @LastEditors: brandon
 */
func InitRedisMaster(dsn []string, psd, name string, db int) *redis.Client {

	reddb := redis.NewFailoverClient(&redis.FailoverOptions{
		MasterName:    name,
		SentinelAddrs: dsn,
		Password:      psd, // no password set
		DB:            db,  // use default DB
		DialTimeout:   10 * time.Second,
		ReadTimeout:   30 * time.Second,
		WriteTimeout:  30 * time.Second,
		PoolSize:      10,
		PoolTimeout:   30 * time.Second,
		MaxRetries:    2,
		IdleTimeout:   5 * time.Minute,
	})
	pong, err := reddb.Ping().Result()
	if err != nil {
		log.Fatalf("initRedisMaster failed: %s", err.Error())
	}
	fmt.Println(pong, err)

	return reddb
}

/**
* @Description: 初始化redis slave
* @Author: brandon
* @Date: 2020/6/30 11:20 上午
* @LastEditTime: 2020/6/30 11:20 上午
* @LastEditors: brandon
 */
func InitRedisSlave(dsn, psd string, db int) *redis.Client {

	reddb := redis.NewClient(&redis.Options{
		Addr:         dsn,
		Password:     psd, // no password set
		DB:           db,  // use default DB
		DialTimeout:  10 * time.Second,
		ReadTimeout:  30 * time.Second,
		WriteTimeout: 30 * time.Second,
		PoolSize:     10,
		PoolTimeout:  30 * time.Second,
		MaxRetries:   2,
		IdleTimeout:  5 * time.Minute,
	})
	pong, err := reddb.Ping().Result()
	if err != nil {
		log.Fatalf("initRedisSlave failed: %s", err.Error())
	}
	fmt.Println(pong, err)

	return reddb
}

/**
 * @Description: 初始化mqtt
 * @Author: wesley
 * @Date: 2020/6/15 13:35
 * @LastEditTime: 2020/6/15 13:35
 * @LastEditors: wesley
 */
func InitMqttService(mqttCfg []string) mqtt.Client {

	clientOptions := mqtt.NewClientOptions().
		SetClientID(fmt.Sprintf("%d", helper.Cputicks())).
		SetCleanSession(false).
		SetAutoReconnect(true).
		SetKeepAlive(120 * time.Second).
		SetPingTimeout(10 * time.Second).
		SetWriteTimeout(10 * time.Second).
		SetMaxReconnectInterval(10 * time.Second)

	for _, v := range mqttCfg {
		clientOptions.AddBroker(v)
	}

	client := mqtt.NewClient(clientOptions)
	if conn := client.Connect(); conn.WaitTimeout(time.Duration(10)*time.Second) && conn.Wait() && conn.Error() != nil {
		log.Fatalf("token: %s", conn.Error())
	}
	return client
}

func initBeanstalk(beanstalkConn string) cpool.Pool {

	factory := func() (interface{}, error) { return beanstalk.Dial("tcp", beanstalkConn) }
	closed := func(v interface{}) error { return v.(*beanstalk.Conn).Close() }
	poolConfig := &cpool.Config{
		InitialCap:  5,  // 资源池初始连接数
		MaxIdle:     20, // 最大空闲连接数
		MaxCap:      30, // 最大并发连接数
		Factory:     factory,
		Close:       closed,
		IdleTimeout: 15 * time.Second,
	}

	beanPool, err := cpool.NewChannelPool(poolConfig)
	if err != nil {
		log.Fatalf("initBeanstalk failed: %s", err.Error())
	}

	return beanPool
}

/**
 * @Description: 初始化es
 * @Author: noah
 * @Date: 2020/9/4 17:28
 * @LastEditTime: 2020/9/4 17:28
 * @LastEditors: noah
 */
func InitES(url []string) *elastic.Client {

	client, err := elastic.NewClient(elastic.SetSniff(false), elastic.SetURL(url...))
	if err != nil {
		log.Fatal(err)
	}

	return client
}

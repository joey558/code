package calc

const (
	RedisGameNav      = "gnav:%s"    //前台游戏导航
	RedisGameNavCount = "gnavcnt:%s" //前台游戏导航赛事数

	redisMatchCalc = "mch_calc:%s" // 赛事注单统计key

	RedisMatchRec       = "mchRecommend" //推荐赛事Zset
	RedisGameLive       = "glive:%s"     //游戏赛事滚盘zset
	RedisGameToday      = "gtoday:%s"    //游戏赛事今日zset
	RedisGameEarly      = "gearly:%s"    //游戏赛事早盘zset
	RedisGameComplex    = "gcomplex:%s"  //游戏赛事串关zset
	redisGameResult     = "gresult:%s"   //游戏赛事赛果zset
	RedisGameLiveAll    = "galive"       //所有游戏赛事滚盘zset
	RedisGameTodayAll   = "gatoday"      //所有游戏赛事今日zset
	RedisGameEarlyAll   = "gaearly"      //所有游戏赛事早盘zset
	RedisGameComplexAll = "gacomplex"    //所有游戏赛事串关zset
	RedisGameResultAll  = "garesult"     //所有游戏赛事赛果zset

	RedisGameIndex = "idx:%s" //前台赛事默认盘口列表rejson
	RedisGameView  = "mch:%s" //前台赛事盘口列表rejson

	JPathMatch       = "."                        // .
	JPathMatchField  = ".%s"                      // .[字段]
	JPathMarket      = ".markets.$%s"             // .markets.$[盘口ID]
	JPathMarketField = ".markets.$%s.%s"          // .markets.$[盘口ID].[字段]
	JPathOddField    = ".markets.$%s.odds.$%s.%s" // .markets.$[盘口ID].odds.$[选项ID].[字段]
)

// 赛事导航类型
const (
	NavFlagAll     = 0 // 0-所有
	NavFlagToday   = 1 // 1-今日
	NavFlagEarly   = 2 // 2-早盘
	NavFlagComplex = 3 // 3-滚球
	NavFlagLive    = 4 // 4-串关
	NavFlagResult  = 5 // 5-赛果
)

type Confirm struct {
	MatchID     string
	MarketID    string
	OddID       string
	BetAmount   string
	TheoryPrize string
}

type MatchOrderCalcStat struct {
	Total  MatchTotalCalc        `json:"total"`  // 赛事总投注统计
	Risk   MatchRiskCalc         `json:"risk"`   // 赛事风险注单统计
	Market map[string]MarketCalc `json:"market"` // 盘口注单统计
}

type MatchTotalCalc struct {
	T int     `json:"t"` // 总投注数
	A float64 `json:"a"` // 总投注金额
}

type MatchRiskCalc struct {
	Pending  int `json:"pending"`  // 风险注单-待处理数
	Accepted int `json:"accepted"` // 风险注单-已接受数
	Rejected int `json:"rejected"` // 风险注单-已拒绝数
}

// 盘口统计
type MarketCalc struct {
	MarketID         string             `json:"market_id"`
	Risk             int                `json:"risk"` // 盘口风险注单数
	RealityBetAmount int                `json:"rba"`  // 盘口总实际注单金额
	FloatBetAmount   int                `json:"fba"`  // 盘口总浮动注单金额
	Odds             map[string]OddCalc `json:"odds"` // 盘口投注项注单统计
}

// odd统计
type OddCalc struct {
	RealityBetCount    int     `json:"rbc"`  // 实际注单数
	FloatBetCount      int     `json:"fbc"`  // 浮动注单数
	RealityBetAmount   int     `json:"rba"`  // 实际注单金额
	FloatBetAmount     int     `json:"fba"`  // 浮动注单金额
	RealityTheoryPrize string `json:"rthp"` // 实际预期盈利金额
	FloatTheoryPrize   string `json:"fthp"` // 浮动预期盈利金额
}

// 接受注单统计参数
type OrderAcceptCalc struct {
	MatchID        string             // 比赛ID
	MarketID       string             // 盘口ID
	IsStuck        int                // 是否为卡单接受注单
	FloatBetCount  int                // 盘口浮动注单数
	FloatBetAmount int                // 盘口浮动注单金额
	Odds           map[string]OddCalc // 盘口投注项注单统计
}

type GameIndex struct {
	Bo                  int               `json:"bo" db:"bo"`
	Category            int               `json:"category" db:"category"`
	GameID              string            `json:"game_id" db:"game_id"`
	ID                  string            `json:"id" db:"id"`
	IsLive              int               `json:"is_live" db:"is_live"`
	IsPassOff           int               `json:"is_pass_off" db:"is_pass_off"`
	LiveSupport         int               `json:"live_support" db:"live_support"`
	MatchLevel          int               `json:"match_level" db:"match_level"`
	MatchTeam           string            `json:"match_team" db:"match_team"`
	Rec                 int               `json:"rec" db:"rec"`
	Score               string            `json:"score" db:"score"`
	StartTime           int64             `json:"start_time" db:"start_time"`
	EndTime             int64             `json:"end_time" db:"end_time"`
	BetDelayTime        int               `json:"bet_delay_time" db:"bet_delay_time"`
	Status              int               `json:"status" db:"status"`
	Suspended           int               `json:"suspended" db:"suspended"`
	TeamID              string            `json:"team_id" db:"team_id"`
	TournamentID        string            `json:"tournament_id" db:"tournament_id"`
	TournamentShortName string            `json:"tournament_short_name" db:"tournament_short_name"`
	UserVideoURL        string            `json:"user_video_url" db:"user_video_url"`
	Visible             int               `json:"visible" db:"visible"`
	Count               int               `json:"count"`
	Markets             map[string]Market `json:"markets"`
}

type MatchBrief struct {
	ID          string
	GameID      string
	StartTime   int64
	Status      int
	Visible     int
	LiveSupport int
	IsLive      int // 1-赛前 2-滚球
	IsPassOff   int
}

type Market struct {
	ID              string         `json:"id" db:"id"`
	MatchID         string         `json:"match_id" db:"match_id"`
	OddTypeID       string         `json:"odd_type_id" db:"odd_type_id"`
	CnName          string         `json:"cn_name" db:"cn_name"`
	EnName          string         `json:"en_name" db:"en_name"`
	Round           int            `json:"round" db:"round"`
	IsDefault       int            `json:"is_default" db:"is_default"`
	OptionType      int            `json:"option_type" db:"option_type"`
	SortCode        int            `json:"sort_code" db:"sort_code"`
	Status          int            `json:"status" db:"status"`
	Suspended       int            `json:"suspended" db:"suspended"`
	Visible         int            `json:"visible" db:"visible"`
	PrizeLimit      int            `json:"prize_limit" db:"prize_limit"`
	MbMktPrizeLimit int            `json:"mb_mkt_prize_limit" db:"mb_mkt_prize_limit"`
	MbMchPrizeLimit int            `json:"mb_mch_prize_limit" db:"mb_mch_prize_limit"`
	Odds            map[string]Odd `json:"odds"`
}

type Odd struct {
	ID       string `json:"id" db:"id"`
	MarketID string `json:"market_id" db:"market_id"`
	Name     string `json:"name" db:"name"`
	Odd      string `json:"odd" db:"odd"`
	IsWinner int    `json:"is_winner" db:"is_winner"`
	SortID   int    `json:"sort_id" db:"sort_id"`
	Visible  int    `json:"visible" db:"visible"`
}

// getHandicapInfo 返回结构体
type HandicapData struct {
	Matches map[string]MatchData
	Markets map[string]MarketData
	Odds    map[string]OddData
}

type MatchData struct {
	GameID              string
	ID                  string
	TeamID              string
	TournamentID        string
	TournamentShortName string
	UserVideoURL        string
	MatchTeam           string
	Score               string
	StartTime           int64
	EndTime             int64
	IsLive              int
	IsPassOff           int
	LiveSupport         int
	MatchLevel          int
	Rec                 int
	Bo                  int
	Category            int
	BetDelayTime        int
	Status              int
	Suspended           int
	Visible             int
}

type MarketData struct {
	ID              string
	MatchID         string
	OddTypeID       string
	CnName          string
	EnName          string
	Round           int
	IsDefault       int
	OptionType      int
	SortCode        int
	Status          int
	Suspended       int
	Visible         int
	PrizeLimit      int
	MbMktPrizeLimit int
	MbMchPrizeLimit int
}

type OddData struct {
	ID       string
	IsWinner int
	MarketID string
	MatchID  string
	Name     string
	Odd      string
	Round    int
	SortID   int
	Visible  int
}

type MatchIndex struct {
	ID        string `db:"id"`
	StartTime int64  `db:"start_time"`
}

type MatchRec struct {
	ID  string `db:"id"`
	Rec int64  `db:"rec"`
}

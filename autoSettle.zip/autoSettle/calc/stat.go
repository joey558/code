package calc

import (
	"encoding/json"
	"fmt"
	g "github.com/doug-martin/goqu/v9"
	"github.com/doug-martin/goqu/v9/exp"
	"github.com/go-redis/redis/v7"
	"github.com/jmoiron/sqlx"
	"time"
)

var (
	gameIndexFields = []interface{}{
		"bo",
		"category",
		"game_id",
		"id",
		"is_live",
		"is_pass_off",
		"live_support",
		"match_level",
		"match_team",
		"rec",
		"score",
		"start_time",
		"end_time",
		"bet_delay_time",
		"status",
		"suspended",
		"team_id",
		"tournament_id",
		"tournament_short_name",
		"user_video_url",
		"visible",
	}
	gameViewFields = []interface{}{
		"id",
		"match_id",
		"odd_type_id",
		"cn_name",
		"en_name",
		"round",
		"is_default",
		"option_type",
		"sort_code",
		"status",
		"suspended",
		"visible",
		"prize_limit",
		"mb_mkt_prize_limit",
		"mb_mch_prize_limit",
	}
)

// 赛事统计
type MatchCountStat struct {
	Today   int `db:"today" json:"today"`
	Live    int `db:"live" json:"live"`
	Early   int `db:"early" json:"early"`
	Complex int `db:"complex" json:"complex"`
	Result  int `db:"result" json:"result"`
}

/**
 * @Description: 获取赛事数量
 * @Author: wesley
 * @Date: 2020/6/27 20:36
 * @LastEditTime: 2020/6/27 20:36
 * @LastEditors: wesley
 */
func matchGameIndexCount(db *sqlx.DB, ex ...exp.Expression) (int, error) {

	var count int
	query, _, _ := g.Dialect("mysql").From("tbl_matches").Select(g.COUNT(1)).Where(ex...).ToSQL()
	fmt.Println(query)
	err := db.Get(&count, query)
	if err != nil {
		fmt.Println("count matches err:", err.Error())
	}

	return count, err
}

/**
 * @Description: 获取赛事信息
 * @Author: maxic
 * @Date: 2020/8/27
 * @LastEditTime: 2020/8/27
 * @LastEditors: maxic
 **/
func matchGameIndexGet(data interface{}, db *sqlx.DB, fields []interface{}, ex ...exp.Expression) error {

	if len(fields) == 0 {
		fields = gameIndexFields
	}
	query, _, _ := g.Dialect("mysql").From("tbl_matches").Select(fields...).Where(ex...).ToSQL()
	fmt.Println(query)
	err := db.Select(data, query)
	if err != nil {
		fmt.Println("select matches err:", err.Error())
	}

	return err
}

/**
 * @Description: 获取赛事信息
 * @Author: maxic
 * @Date: 2020/9/16
 * @LastEditTime: 2020/9/16
 * @LastEditors: maxic
 **/
func matchGameIndexUnionGet(data interface{}, db *sqlx.DB, fields []interface{}, ex ...exp.Expression) error {

	if len(fields) == 0 {
		fields = gameIndexFields
	}

	var ds []*g.SelectDataset
	for _, e := range ex {
		ds = append(ds, g.Dialect("mysql").From("tbl_matches").Select(fields...).Where(e))
	}
	if len(ds) == 0 {
		return fmt.Errorf("param error")
	}
	sql := ds[0]
	for i, v := range ds {
		if i != 0 {
			sql = sql.Union(v)
		}
	}

	query, _, _ := sql.ToSQL()
	fmt.Println(query)
	err := db.Select(data, query)
	if err != nil {
		fmt.Println("select matches err:", err.Error())
	}

	return err
}

func matchGameViewGet(db *sqlx.DB, matchID string) (map[string]Market, map[string]Market, error) {

	def := map[string]Market{}
	data := map[string]Market{}

	// 获取盘口
	var markets []Market
	query, _, _ := g.Dialect("mysql").From("tbl_markets").Select(
		gameViewFields...
	).Where(g.Ex{
		"match_id": matchID,
	}).ToSQL()
	fmt.Println(query)
	err := db.Select(&markets, query)
	if err != nil {
		return def, data, err
	}

	// 获取赔率选项
	for i := range markets {
		market := &markets[i]
		market.Odds = map[string]Odd{}

		query, _, _ := g.Dialect("mysql").From("tbl_odds").Select(
			"id",
			"market_id",
			"name",
			"odd",
			"is_winner",
			"sort_id",
			"visible",
		).Where(g.Ex{
			"market_id": market.ID,
		}).ToSQL()
		fmt.Println(query)
		var odds []Odd
		err := db.Select(&odds, query)
		if err != nil {
			return def, data, err
		}

		for _, odd := range odds {
			market.Odds["$"+odd.ID] = odd
		}
	}

	// 数据分组
	for _, market := range markets {
		if market.IsDefault == 1 {
			def["$"+market.ID] = market
		}
		data["$"+market.ID] = market
	}

	return def, data, err
}

/**
 * @Description: 获取游戏导航类型的时间范围
 * @Author: maxic
 * @Date: 2020/9/18
 * @LastEditTime: 2020/9/18
 * @LastEditors: maxic
 **/
func GameNavTimeRangeGet(navFlag int) [2]int64 {

	t := time.Now()
	y, m, d := t.Date()
	today := time.Date(y, m, d, 0, 0, 0, 0, t.Location())
	tomorrow := today.AddDate(0, 0, 1)

	// 今日 - 今日及之前
	rangeToday := [2]int64{0, tomorrow.Unix() - 1}
	// 赛前 - 次日至7天内
	rangeEarly := [2]int64{tomorrow.Unix(), tomorrow.AddDate(0, 0, 7).Unix() - 1}
	// 滚球 - 今日至7天内
	rangeLive := [2]int64{rangeToday[0], rangeEarly[1]}
	// 串关 - 今日至7天内
	rangeComplex := rangeLive
	// 赛果 - 7天内至今日
	rangeResult := [2]int64{today.AddDate(0, 0, -6).Unix(), tomorrow.Unix() - 1}
	// 汇总 - 今日+赛前
	rangeAll := [2]int64{rangeToday[0], rangeEarly[1]}

	switch navFlag {
	case NavFlagAll:
		return rangeAll
	case NavFlagToday:
		return rangeToday
	case NavFlagEarly:
		return rangeEarly
	case NavFlagComplex:
		return rangeComplex
	case NavFlagLive:
		return rangeLive
	case NavFlagResult:
		return rangeResult
	}

	return [2]int64{}
}

/**
 * @Description: 游戏导航赛事数，今日 滚球 赛前 串关 赛果计数
 * @Author: wesley
 * @Date: 2020/6/27 20:03
 * @LastEditTime: 2020/6/27 20:03
 * @LastEditors: wesley
 */
func GameNavMatchCountStat(pool *redis.Client, gameId string) error {

	// 今日
	setToday, err := pool.ZRange(fmt.Sprintf(RedisGameToday, gameId), 0, -1).Result()
	if err != nil {
		return err
	}
	cntToday := len(setToday)

	// 早盘
	setEarly, err := pool.ZRange(fmt.Sprintf(RedisGameEarly, gameId), 0, -1).Result()
	if err != nil {
		return err
	}
	cntEarly := len(setEarly)

	// 滚球
	cntLive, err := pool.ZCard(fmt.Sprintf(RedisGameLive, gameId)).Result()
	if err != nil {
		return err
	}

	// 串关
	cntComplex, err := pool.ZCard(fmt.Sprintf(RedisGameComplex, gameId)).Result()
	if err != nil {
		return err
	}

	// 汇总 - 今日+赛前
	mapAll := map[string]bool{}
	for _, v := range setToday {
		mapAll[v] = true
	}
	for _, v := range setEarly {
		if ok := mapAll[v]; ok {
			continue
		}
		mapAll[v] = true
	}
	cntAll := len(mapAll)

	// 赛事计数写入redis
	fmt.Printf("game[%v]: nav:%v, today:%v, early:%v, complex:%v, live:%v\n",
		gameId, cntAll, cntToday, cntEarly, cntComplex, cntLive)

	pipe := pool.Pipeline()
	defer pipe.Close()

	key := fmt.Sprintf(RedisGameNav, gameId)
	pipe.HSet(key, "count", cntAll)

	key = fmt.Sprintf(RedisGameNavCount, gameId)
	values := map[string]interface{}{
		"today":   cntToday,
		"live":    cntLive,
		"early":   cntEarly,
		"complex": cntComplex,
	}
	pipe.HMSet(key, values)

	_, err = pipe.Exec()
	return err
}

/**
 * @Description: 游戏导航赛事数，今日 滚球 赛前 串关 赛果计数
 * @Author: wesley
 * @Date: 2020/6/27 20:03
 * @LastEditTime: 2020/6/27 20:03
 * @LastEditors: wesley
 */
func GameNavMatchInit(db *sqlx.DB, pool *redis.Client, gameId string, rebuildCache bool) error {

	// 统计今日（或者滚球中）
	rang := GameNavTimeRangeGet(NavFlagToday)
	exToday1 := g.Ex{
		"game_id":    gameId,
		"status":     5, // 5-已开盘
		"visible":    1,
		"start_time": g.Op{"between": g.Range(rang[0], rang[1])},
	}
	exToday2 := g.Ex{
		"game_id": gameId,
		"status":  5, // 5-已开盘
		"visible": 1,
		"is_live": 2, // 2-滚球
	}

	// 统计赛前（非滚球中）
	rang = GameNavTimeRangeGet(NavFlagEarly)
	exEarly := g.Ex{
		"status":     5, // 5-已开盘
		"game_id":    gameId,
		"visible":    1,
		"is_live":    1, // 1-赛前 2-滚球
		"start_time": g.Op{"between": g.Range(rang[0], rang[1])},
	}

	// 统计滚球
	rang = GameNavTimeRangeGet(NavFlagLive)
	exLive := g.Ex{
		"status":       5, // 5-已开盘
		"game_id":      gameId,
		"live_support": 1,
		"visible":      1,
		"start_time":   g.Op{"between": g.Range(rang[0], rang[1])},
	}

	// 统计串关
	rang = GameNavTimeRangeGet(NavFlagComplex)
	exComplex := g.Ex{
		"status":      5, // 5-已开盘
		"game_id":     gameId,
		"is_pass_off": 1,
		"visible":     1,
		"start_time":  g.Op{"between": g.Range(rang[0], rang[1])},
	}

	// 统计赛果
	rang = GameNavTimeRangeGet(NavFlagResult)
	exResult := g.Ex{
		"status":     []int{7, 9}, // 7-已结算 9-已取消
		"game_id":    gameId,
		"visible":    1,
		"start_time": g.Op{"between": g.Range(rang[0], rang[1])},
	}

	// 查询赛事
	var todayMatches []MatchIndex
	var earlyMatches []MatchIndex
	var liveMatches []MatchIndex
	var complexMatches []MatchIndex
	var resultMatches []MatchIndex

	fields := []interface{}{"id", "start_time"}

	_ = matchGameIndexUnionGet(&todayMatches, db, fields, exToday1, exToday2)
	_ = matchGameIndexGet(&earlyMatches, db, fields, exEarly)
	_ = matchGameIndexGet(&liveMatches, db, fields, exLive)
	_ = matchGameIndexGet(&complexMatches, db, fields, exComplex)
	_ = matchGameIndexGet(&resultMatches, db, fields, exResult)

	pipe := pool.Pipeline()
	defer pipe.Close()

	// 初始化ZSet索引
	fnInitIndex := func(key, keyAll string, data []MatchIndex) {
		// 删除老数据 (函数调用前删除keyAll)
		pipe.Del(key)

		// 重新构建
		if len(data) > 0 {
			var z []*redis.Z
			for _, v := range data {
				z = append(z, &redis.Z{
					Score:  float64(v.StartTime),
					Member: v.ID,
				})
			}
			pipe.ZAdd(key, z...)
			pipe.ZAdd(keyAll, z...)
		}
	}

	fnInitIndex(fmt.Sprintf(RedisGameToday, gameId), RedisGameTodayAll, todayMatches)
	fnInitIndex(fmt.Sprintf(RedisGameEarly, gameId), RedisGameEarlyAll, earlyMatches)
	fnInitIndex(fmt.Sprintf(RedisGameLive, gameId), RedisGameLiveAll, liveMatches)
	fnInitIndex(fmt.Sprintf(RedisGameComplex, gameId), RedisGameComplexAll, complexMatches)
	fnInitIndex(fmt.Sprintf(redisGameResult, gameId), RedisGameResultAll, resultMatches)

	// 计数
	// 汇总 - 今日+赛前
	mapAll := map[string]bool{}
	for _, v := range todayMatches {
		mapAll[v.ID] = true
	}
	for _, v := range earlyMatches {
		if ok := mapAll[v.ID]; ok {
			continue
		}
		mapAll[v.ID] = true
	}
	cntAll := len(mapAll)
	cntToday := len(todayMatches)
	cntLive := len(liveMatches)
	cntEarly := len(earlyMatches)
	cntComplex := len(complexMatches)
	cntResult := len(resultMatches)
	fmt.Printf("game[%v]: nav:%v, today:%v, early:%v, complex:%v, live:%v, result:%v\n",
		gameId, cntAll, cntToday, cntEarly, cntComplex, cntLive, cntResult)

	// 赛事计数写入redis
	key := fmt.Sprintf(RedisGameNav, gameId)
	pipe.HSet(key, "count", cntAll)

	key = fmt.Sprintf(RedisGameNavCount, gameId)
	values := map[string]interface{}{
		"today":   cntToday,
		"live":    cntLive,
		"early":   cntEarly,
		"complex": cntComplex,
	}
	pipe.HMSet(key, values)

	// 初始化赛事缓存
	if rebuildCache {
		matches := []GameIndex{}
		err := matchGameIndexGet(&matches, db, nil, g.Ex{"game_id": gameId})
		if err != nil {
			fmt.Println("get matches for rebuilding cache error:", err.Error())
		}

		// 更新缓存
		for _, match := range matches {
			match.Markets = map[string]Market{}

			// 更新赛事缓存
			data, err := json.Marshal(match)
			if err != nil {
				fmt.Println("marshal match error:", err.Error())
				continue
			}
			MatchCacheSet(pipe, match.ID, JPathMatch, data, true)

			// 更新默认盘口缓存
			defMarket, markets, err := matchGameViewGet(db, match.ID)
			data, err = json.Marshal(defMarket)
			if err != nil {
				fmt.Println("marshal default market error:", err.Error())
				continue
			}
			MatchCacheSet(pipe, match.ID, ".markets", data, true)

			// 更新盘口缓存
			data, err = json.Marshal(markets)
			if err != nil {
				fmt.Println("marshal market error:", err.Error())
				continue
			}
			MatchCacheSet(pipe, match.ID, ".markets", data, false)
		}
	}

	_, err := pipe.Exec()
	return err
}

// 初始化推荐赛事
func MatchRecInit(db *sqlx.DB, pool *redis.Client) error {

	pipe := pool.Pipeline()
	defer pipe.Close()

	// 查询推荐赛事
	var recMatches []MatchRec
	fields := []interface{}{"id", "rec"}
	exRec := g.Ex{
		"rec": g.Op{"gt": 0},
	}
	err := matchGameIndexGet(&recMatches, db, fields, exRec)
	if err != nil {
		return err
	}

	// 删除旧的赛事推荐
	pipe.Del(RedisMatchRec)

	// 添加新的赛事推荐
	if len(recMatches) > 0 {
		var rz []*redis.Z
		for _, data := range recMatches {
			rz = append(rz, &redis.Z{
				Score:  float64(data.Rec),
				Member: data.ID,
			})
		}
		pipe.ZAdd(RedisMatchRec, rz...)
	}

	_, err = pipe.Exec()
	return err
}

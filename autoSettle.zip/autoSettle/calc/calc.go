package calc

import (
	"bytes"
	"errors"
	"fmt"
	g "github.com/doug-martin/goqu/v9"
	"github.com/go-redis/redis/v7"
	"github.com/shopspring/decimal"
)

func InitMatchStat(pool *redis.Client, matchID, matchInfo string) error {

	key := fmt.Sprintf(redisMatchCalc, matchID)
	return pool.Do("JSON.SET", key, ".", matchInfo).Err()
}

func OrderConfirm(pipe redis.Pipeliner, c Confirm) {

	key := fmt.Sprintf("mch_calc:%s", c.MatchID)
	// 1.更新赛事总投注统计
	pipe.Do("JSON.NUMINCRBY", key, ".total.t", 1)
	pipe.Do("JSON.NUMINCRBY", key, ".total.a", c.BetAmount)
	// 2.更新盘口实际投注金额
	pipe.Do("JSON.NUMINCRBY", key, ".market.$"+c.MarketID+".rba", c.BetAmount)
	pipe.Do("JSON.NUMINCRBY", key, ".market.$"+c.MarketID+".fba", "-"+c.BetAmount)
	// 3.更新投注项实际注单统计
	pipe.Do("JSON.NUMINCRBY", key, ".market.$"+c.MarketID+".odds.$"+c.OddID+".rbc", 1)
	pipe.Do("JSON.NUMINCRBY", key, ".market.$"+c.MarketID+".odds.$"+c.OddID+".rba", c.BetAmount)
	pipe.Do("JSON.NUMINCRBY", key, ".market.$"+c.MarketID+".odds.$"+c.OddID+".rthp", c.TheoryPrize)
	pipe.Do("JSON.NUMINCRBY", key, ".market.$"+c.MarketID+".odds.$"+c.OddID+".fbc", -1)
	pipe.Do("JSON.NUMINCRBY", key, ".market.$"+c.MarketID+".odds.$"+c.OddID+".fba", "-"+c.BetAmount)
	pipe.Do("JSON.NUMINCRBY", key, ".market.$"+c.MarketID+".odds.$"+c.OddID+".fthp", "-"+c.TheoryPrize)
}

func RiskOrderGen(pipe redis.Pipeliner, matchID, marketID string, value int) {

	key := fmt.Sprintf("mch_calc:%s", matchID)
	// 1.更新赛事总投注统计
	pipe.Do("JSON.NUMINCRBY", key, ".risk.pending", value)
	// 2.更新盘口更新注单数
	pipe.Do("JSON.NUMINCRBY", key, ".market.$"+marketID+".risk", value)
}

func RiskOrderAccept(pipe redis.Pipeliner, matchID, marketID, total string, n int, mpOFC map[string]int, mpOFA, mpOFT map[string]decimal.Decimal) {

	key := fmt.Sprintf("mch_calc:%s", matchID)

	// 1.更新赛事总投注统计
	pipe.Do("JSON.NUMINCRBY", key, ".total.t", n)
	pipe.Do("JSON.NUMINCRBY", key, ".total.a", total)
	pipe.Do("JSON.NUMINCRBY", key, ".risk.pending", -n)
	pipe.Do("JSON.NUMINCRBY", key, ".risk.accepted", n)
	// 2.更新盘口风险注单数和注单金额
	pipe.Do("JSON.NUMINCRBY", key, ".market.$"+marketID+".risk", -n)
	pipe.Do("JSON.NUMINCRBY", key, ".market.$"+marketID+".fba", "-"+total)
	pipe.Do("JSON.NUMINCRBY", key, ".market.$"+marketID+".rba", total)

	// 3.更新盘口投注项注单统计
	for k, v := range mpOFA {
		pipe.Do("JSON.NUMINCRBY", key, ".market.$"+marketID+".odds.$"+k+".rbc", mpOFC[k])
		pipe.Do("JSON.NUMINCRBY", key, ".market.$"+marketID+".odds.$"+k+".rba", v.String())
		pipe.Do("JSON.NUMINCRBY", key, ".market.$"+marketID+".odds.$"+k+".rthp", mpOFT[k].String())

		pipe.Do("JSON.NUMINCRBY", key, ".market.$"+marketID+".odds.$"+k+".fbc", -mpOFC[k])
		pipe.Do("JSON.NUMINCRBY", key, ".market.$"+marketID+".odds.$"+k+".fba", "-"+v.String())
		pipe.Do("JSON.NUMINCRBY", key, ".market.$"+marketID+".odds.$"+k+".fthp", "-"+mpOFT[k].String())
	}
}

func RiskOrderRefuse(pipe redis.Pipeliner, matchID, marketID string, n int, mpOddID map[string]string) {

	key := fmt.Sprintf("mch_calc:%s", matchID)

	// 1.更新赛事总投注统计
	pipe.Do("JSON.NUMINCRBY", key, ".risk.rejected", n)
	pipe.Do("JSON.NUMINCRBY", key, ".risk.pending", n*-1)
	// 2.更新盘口风险注单数和浮动注单金额
	pipe.Do("JSON.SET", key, ".market.$"+marketID+".risk", 0)
	pipe.Do("JSON.SET", key, ".market.$"+marketID+".fba", 0)

	// 3.盘口投注项浮动注单统计清零
	for k := range mpOddID {
		pipe.Do("JSON.SET", key, ".market.$"+marketID+".odds.$"+k+".fbc", 0)
		pipe.Do("JSON.SET", key, ".market.$"+marketID+".odds.$"+k+".fba", 0)
		pipe.Do("JSON.SET", key, ".market.$"+marketID+".odds.$"+k+".fthp", 0)
	}
}

func GetMatchStat(pool *redis.Client, matchID string) (string, error) {

	key := fmt.Sprintf(redisMatchCalc, matchID)
	data, err := pool.Do("JSON.GET", key).Text()

	return data, err
}

func GetMarketStat(pool *redis.Client, matchID, marketID string) (string, error) {

	b := bytes.Buffer{}
	pipe := pool.Pipeline()
	defer pipe.Close()

	key := fmt.Sprintf(redisMatchCalc, matchID)
	total := pipe.Do("JSON.GET", key, ".total")
	risk := pipe.Do("JSON.GET", key, ".risk")
	mkt := pipe.Do("JSON.GET", key, ".market.$"+marketID)
	_, err := pipe.Exec()
	if err != nil {
		return "", err
	}

	data, err := total.Text()
	if err != nil {
		return "", err
	}
	b.WriteString(`{"total":`)
	b.WriteString(data)
	b.WriteString(`,"risk":`)

	data, err = risk.Text()
	if err != nil {
		return "", err
	}
	b.WriteString(data)
	b.WriteString(`,"market":`)

	data, err = mkt.Text()
	if err != nil {
		return "", err
	}

	b.WriteString(data)
	b.WriteString("}")

	return b.String(), nil
}

func OrderCalcUpdate(pipe redis.Pipeliner, order g.Record) error {

	var (
		mchID       string
		mktID       string
		oddID       string
		betAmount   string
		theoryPrize string
		isLive      int
		ok          bool
	)
	if mchID, ok = order["match_id"].(string); !ok {
		return errors.New("match_id error")
	}
	if mktID, ok = order["market_id"].(string); !ok {
		return errors.New("market_id error")
	}
	if oddID, ok = order["odd_id"].(string); !ok {
		return errors.New("odd_id error")
	}
	if betAmount, ok = order["bet_amount"].(string); !ok {
		return errors.New("bet_amount error")
	}
	if theoryPrize, ok = order["theory_prize"].(string); !ok {
		return errors.New("theory_prize error")
	}
	if isLive, ok = order["is_live"].(int); !ok {
		return errors.New("is_live error")
	}

	key := fmt.Sprintf(redisMatchCalc, mchID)
	// 初盘
	if isLive == 1 {
		// 1.更新赛事总投注统计
		pipe.Do("JSON.NUMINCRBY", key, ".total.t", 1)
		pipe.Do("JSON.NUMINCRBY", key, ".total.a", betAmount)
		// 2.更新盘口实际投注金额
		pipe.Do("JSON.NUMINCRBY", key, ".market.$"+mktID+".rba", betAmount)
		// 3.更新盘口投注项实际注单统计
		pipe.Do("JSON.NUMINCRBY", key, ".market.$"+mktID+".odds.$"+oddID+".rbc", 1)
		pipe.Do("JSON.NUMINCRBY", key, ".market.$"+mktID+".odds.$"+oddID+".rba", betAmount)
		pipe.Do("JSON.NUMINCRBY", key, ".market.$"+mktID+".odds.$"+oddID+".rthp", theoryPrize)

		return nil
	} else if isLive == 2 {
		// 1.更新盘口浮动投注金额
		pipe.Do("JSON.NUMINCRBY", key, ".market.$"+mktID+".fba", betAmount)
		// 2.更新盘口投注项浮动注单统计
		pipe.Do("JSON.NUMINCRBY", key, ".market.$"+mktID+".odds.$"+oddID+".fbc", 1)
		pipe.Do("JSON.NUMINCRBY", key, ".market.$"+mktID+".odds.$"+oddID+".fba", betAmount)
		pipe.Do("JSON.NUMINCRBY", key, ".market.$"+mktID+".odds.$"+oddID+".fthp", theoryPrize)

		return nil
	}

	return errors.New("is_live status error")
}

func OrderCancelCalcManualPrepare(pipe redis.Pipeliner, matchID, marketID string) {

	key := fmt.Sprintf(redisMatchCalc, matchID)

	pipe.Do("JSON.NUMINCRBY", key, ".risk.pending", -1)
	pipe.Do("JSON.NUMINCRBY", key, fmt.Sprintf(".market.$%s.risk", marketID), -1)
}

func OrderCancelCalcFloatBet(pipe redis.Pipeliner, matchID, marketID, oddID string, betAmount, theoryPrize string) {

	key := fmt.Sprintf(redisMatchCalc, matchID)

	// 盘口：浮动注单金额-注单金额
	pipe.Do("JSON.NUMINCRBY", key, fmt.Sprintf(".market.$%s.fba", marketID), "-"+betAmount)
	// 投注项：浮动注单数-1， 浮动注单金额-注单金额， 浮动派彩金额-注单派彩基恩
	oddPath := fmt.Sprintf(".market.$%s.odds.$%s", marketID, oddID)
	pipe.Do("JSON.NUMINCRBY", key, oddPath+".fbc", -1)
	pipe.Do("JSON.NUMINCRBY", key, oddPath+".fba", "-"+betAmount)
	pipe.Do("JSON.NUMINCRBY", key, oddPath+".fthp", "-"+theoryPrize)
}

func OrderCancelCalcRealityBet(pipe redis.Pipeliner, matchID, marketID, oddID string, betAmount, theoryPrize string) {

	key := fmt.Sprintf(redisMatchCalc, matchID)

	// 赛事：总投注数-1，总投注金额-注单金额
	pipe.Do("JSON.NUMINCRBY", key, ".total.t", -1)
	pipe.Do("JSON.NUMINCRBY", key, ".total.a", "-"+betAmount)
	// 盘口：实际总投注金额-注单金额
	pipe.Do("JSON.NUMINCRBY", key, fmt.Sprintf(".market.$%s.rba", marketID), "-"+betAmount)
	// 投注项：
	oddPath := fmt.Sprintf(".market.$%s.odds.$%s", marketID, oddID)
	pipe.Do("JSON.NUMINCRBY", key, oddPath+".rbc", -1)
	pipe.Do("JSON.NUMINCRBY", key, oddPath+".rba", "-"+betAmount)
	pipe.Do("JSON.NUMINCRBY", key, oddPath+".rthp", "-"+theoryPrize)
}

func OrderAccept(pipe redis.Pipeliner, p OrderAcceptCalc) {

	key := fmt.Sprintf("mch_calc:%s", p.MatchID)
	// 1.更新赛事总投注统计
	pipe.Do("JSON.NUMINCRBY", key, ".total.t", p.FloatBetCount)
	pipe.Do("JSON.NUMINCRBY", key, ".total.a", p.FloatBetAmount)
	// 接受风险注单需要更新赛事和盘口的风险注单统计
	if p.IsStuck == 0 {
		pipe.Do("JSON.NUMINCRBY", key, ".risk.pending", -p.FloatBetCount)
		pipe.Do("JSON.NUMINCRBY", key, ".risk.accepted", p.FloatBetCount)
		pipe.Do("JSON.NUMINCRBY", key, ".market.$"+p.MarketID+".risk", -p.FloatBetCount)
	}
	// 2.更新盘口实际投注金额
	pipe.Do("JSON.NUMINCRBY", key, ".market.$"+p.MarketID+".rba", p.FloatBetAmount)
	pipe.Do("JSON.NUMINCRBY", key, ".market.$"+p.MarketID+".fba", -p.FloatBetAmount)
	// 3.更新投注项实际注单统计
	for oddID, v := range p.Odds {
		pipe.Do("JSON.NUMINCRBY", key, ".market.$"+p.MarketID+".odds.$"+oddID+".rbc", v.FloatBetCount)
		pipe.Do("JSON.NUMINCRBY", key, ".market.$"+p.MarketID+".odds.$"+oddID+".rba", v.FloatBetAmount)
		pipe.Do("JSON.NUMINCRBY", key, ".market.$"+p.MarketID+".odds.$"+oddID+".rthp", v.FloatTheoryPrize)

		pipe.Do("JSON.NUMINCRBY", key, ".market.$"+p.MarketID+".odds.$"+oddID+".fbc", -v.FloatBetCount)
		pipe.Do("JSON.NUMINCRBY", key, ".market.$"+p.MarketID+".odds.$"+oddID+".fba", -v.FloatBetAmount)
		pipe.Do("JSON.NUMINCRBY", key, ".market.$"+p.MarketID+".odds.$"+oddID+".fthp", "-"+v.FloatTheoryPrize)
	}
}

func MarketRiskOrderRefuse(pipe redis.Pipeliner, matchID, marketID string, n int, mktRefuseStatistics MarketCalc) {

	key := fmt.Sprintf("mch_calc:%s", matchID)

	// 1.更新赛事总投注统计
	pipe.Do("JSON.NUMINCRBY", key, ".risk.rejected", n)
	pipe.Do("JSON.NUMINCRBY", key, ".risk.pending", n*-1)
	// 2.更新盘口风险注单数和浮动注单金额
	pipe.Do("JSON.NUMINCRBY", key, ".market.$"+marketID+".risk", -mktRefuseStatistics.Risk)
	pipe.Do("JSON.NUMINCRBY", key, ".market.$"+marketID+".fba", -mktRefuseStatistics.FloatBetAmount)

	// 3.盘口投注项浮动注单统计清零
	for k, v := range mktRefuseStatistics.Odds {
		pipe.Do("JSON.NUMINCRBY", key, ".market.$"+marketID+".odds.$"+k+".fbc", -v.FloatBetCount)
		pipe.Do("JSON.NUMINCRBY", key, ".market.$"+marketID+".odds.$"+k+".fba", -v.FloatBetAmount)
		pipe.Do("JSON.NUMINCRBY", key, ".market.$"+marketID+".odds.$"+k+".fthp", "-"+v.FloatTheoryPrize)
	}
}

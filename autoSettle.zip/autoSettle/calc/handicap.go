package calc

import (
	"fmt"
	"github.com/go-redis/redis/v7"
	"github.com/valyala/fastjson"
	"strings"
	"time"
)

/**
* @Description: 设置赛事/盘口缓存
* @Author: maxic
* @Date: 2020/8/19
* @LastEditTime: 2020/8/19
* @LastEditors: maxic
**/
func MatchCacheSet(pipe redis.Pipeliner, matchId, path string, data interface{}, updateIndex bool) {

	var value interface{}
	var msg interface{}
	switch data.(type) {
	case float32:
		value = fmt.Sprintf("%0.3f", data.(float32))
		msg = value
	case float64:
		value = fmt.Sprintf("%0.3f", data.(float64))
		msg = value
	case string:
		value = `"` + data.(string) + `"`
		msg = value
	case []byte:
		value = data
		msg = string(data.([]byte))
	default:
		value = data
		msg = value
	}

	key := fmt.Sprintf(RedisGameView, matchId)
	err := pipe.Do("JSON.SET", key, path, value).Err()
	if err != nil {
		fmt.Println("[ JSON.SET", key, path, msg, "] fail:", err.Error())
	} else {
		fmt.Println("[ JSON.SET", key, path, msg, "]")
	}

	if updateIndex {
		key := fmt.Sprintf(RedisGameIndex, matchId)
		err = pipe.Do("JSON.SET", key, path, value).Err()
		if err != nil {
			fmt.Println("[ JSON.SET", key, path, msg, "] fail:", err.Error())
		} else {
			fmt.Println("[ JSON.SET", key, path, msg, "]")
		}
	}
}

/**
 * @Description: 赛事zset维护
 * @Author: maxic
 * @Date: 2020/8/19
 * @LastEditTime: 2020/8/19
 * @LastEditors: maxic
 **/
func MatchZSetUpdate(pipe redis.Pipeliner, match MatchBrief) {

	keyToday := fmt.Sprintf(RedisGameToday, match.GameID)
	keyLive := fmt.Sprintf(RedisGameLive, match.GameID)
	keyEarly := fmt.Sprintf(RedisGameEarly, match.GameID)
	keyComplex := fmt.Sprintf(RedisGameComplex, match.GameID)
	keyResult := fmt.Sprintf(redisGameResult, match.GameID)

	// 删除旧key
	pipe.ZRem(keyToday, match.ID)
	pipe.ZRem(keyLive, match.ID)
	pipe.ZRem(keyEarly, match.ID)
	pipe.ZRem(keyComplex, match.ID)
	pipe.ZRem(keyResult, match.ID)

	pipe.ZRem(RedisGameTodayAll, match.ID)
	pipe.ZRem(RedisGameLiveAll, match.ID)
	pipe.ZRem(RedisGameEarlyAll, match.ID)
	pipe.ZRem(RedisGameComplexAll, match.ID)
	pipe.ZRem(RedisGameResultAll, match.ID)

	// 指定时间范围
	rangeToday := GameNavTimeRangeGet(NavFlagToday)
	rangeEarly := GameNavTimeRangeGet(NavFlagEarly)
	rangeLive := GameNavTimeRangeGet(NavFlagLive)
	rangeComplex := GameNavTimeRangeGet(NavFlagComplex)
	rangeResult := GameNavTimeRangeGet(NavFlagResult)

	record := &redis.Z{
		Score:  float64(match.StartTime),
		Member: match.ID,
	}

	fnBetween := func(time int64, ranges [2]int64) bool {
		if time >= ranges[0] && time <= ranges[1] {
			return true
		}
		return false
	}

	fnIn := func(status int, ranges []int) bool {
		for _, r := range ranges {
			if status == r {
				return true
			}
		}
		return false
	}

	// 赛事状态: 待录入-1 待审核-2 已驳回-3 待开盘-4 已开盘-5 已关盘-6 已结算-7 待取消-8 比赛取消-9
	// 今日（或者滚球中）
	if (fnBetween(match.StartTime, rangeToday) || match.IsLive == 2) && match.Status == 5 && match.Visible == 1 {
		pipe.ZAdd(keyToday, record)
		pipe.ZAdd(RedisGameTodayAll, record)
	}
	// 赛前（非滚球中）
	if (fnBetween(match.StartTime, rangeEarly) && match.IsLive == 1) && match.Status == 5 && match.Visible == 1 {
		pipe.ZAdd(keyEarly, record)
		pipe.ZAdd(RedisGameEarlyAll, record)
	}
	// 滚球
	if fnBetween(match.StartTime, rangeLive) && match.Status == 5 && match.Visible == 1 && match.LiveSupport == 1 {
		pipe.ZAdd(keyLive, record)
		pipe.ZAdd(RedisGameLiveAll, record)
	}
	// 串关
	if fnBetween(match.StartTime, rangeComplex) && match.Status == 5 && match.Visible == 1 && match.IsPassOff == 1 {
		pipe.ZAdd(keyComplex, record)
		pipe.ZAdd(RedisGameComplexAll, record)
	}
	// 赛果
	if fnBetween(match.StartTime, rangeResult) && fnIn(match.Status, []int{7, 9}) && match.Visible == 1 {
		pipe.ZAdd(keyResult, record)
		pipe.ZAdd(RedisGameResultAll, record)
	}
}

/**
 * @Description: 删除赛事缓存
 * @Author: maxic
 * @Date: 2020/8/20
 * @LastEditTime: 2020/8/20
 * @LastEditors: maxic
 **/
func MatchCacheDel(pipe redis.Pipeliner, gameId, matchId string) {

	// 删除缓存对应分类
	keyToday := fmt.Sprintf(RedisGameToday, gameId)
	keyLive := fmt.Sprintf(RedisGameLive, gameId)
	keyEarly := fmt.Sprintf(RedisGameEarly, gameId)
	keyComplex := fmt.Sprintf(RedisGameComplex, gameId)
	keyResult := fmt.Sprintf(redisGameResult, gameId)
	pipe.ZRem(keyToday, matchId)
	pipe.ZRem(keyLive, matchId)
	pipe.ZRem(keyEarly, matchId)
	pipe.ZRem(keyComplex, matchId)
	pipe.ZRem(keyResult, matchId)

	// 删除缓存数据
	keys := []string{
		fmt.Sprintf(RedisGameView, matchId),
		fmt.Sprintf(RedisGameIndex, matchId),
	}
	pipe.Del(keys...)
}

/**
 * @Description: 删除盘口缓存
 * @Author: maxic
 * @Date: 2020/8/18
 * @LastEditTime: 2020/8/18
 * @LastEditors: maxic
 **/
func MarketCacheDel(pipe redis.Pipeliner, matchId, marketId string, updateIndex bool) {

	key := fmt.Sprintf(RedisGameView, matchId)
	path := fmt.Sprintf(JPathMarket, marketId)
	pipe.Do("JSON.DEL", key, path)

	if updateIndex {
		key = fmt.Sprintf(RedisGameIndex, matchId)
		path = fmt.Sprintf(JPathMarket, marketId)
		pipe.Do("JSON.DEL", key, path)
	}
}

func parseMatch(v *fastjson.Value, matches map[string]MatchData) {

	m := MatchData{}

	m.Bo = v.GetInt("bo")
	m.Visible = v.GetInt("visible")
	m.Status = v.GetInt("status")
	m.IsLive = v.GetInt("is_live")
	m.Category = v.GetInt("category")
	m.Suspended = v.GetInt("suspended")
	m.StartTime = v.GetInt64("start_time")
	m.EndTime = v.GetInt64("end_time")
	m.MatchLevel = v.GetInt("match_level")
	m.IsPassOff = v.GetInt("is_pass_off")
	m.LiveSupport = v.GetInt("live_support")
	m.BetDelayTime = v.GetInt("bet_delay_time")
	m.Rec = v.GetInt("rec")

	m.ID = string(v.GetStringBytes("id"))
	m.TeamID = string(v.GetStringBytes("team_id"))
	m.GameID = string(v.GetStringBytes("game_id"))
	m.MatchTeam = string(v.GetStringBytes("match_team"))
	m.Score = string(v.GetStringBytes("score"))
	m.UserVideoURL = string(v.GetStringBytes("user_video_url"))
	m.TournamentID = string(v.GetStringBytes("tournament_id"))
	m.TournamentShortName = string(v.GetStringBytes("tournament_short_name"))

	matches[m.ID] = m
}

func parseMarket(value *fastjson.Value, markets map[string]MarketData, odds map[string]OddData) {

	o := value.GetObject("markets")
	o.Visit(func(k []byte, v *fastjson.Value) {

		_ = k
		m := MarketData{
			ID:              string(v.GetStringBytes("id")),
			MatchID:         string(v.GetStringBytes("match_id")),
			OddTypeID:       string(v.GetStringBytes("odd_type_id")),
			CnName:          string(v.GetStringBytes("cn_name")),
			EnName:          string(v.GetStringBytes("en_name")),
			Round:           v.GetInt("round"),
			IsDefault:       v.GetInt("is_default"),
			OptionType:      v.GetInt("option_type"),
			SortCode:        v.GetInt("sort_code"),
			Status:          v.GetInt("status"),
			Suspended:       v.GetInt("suspended"),
			Visible:         v.GetInt("visible"),
			PrizeLimit:      v.GetInt("prize_limit"),
			MbMktPrizeLimit: v.GetInt("mb_mkt_prize_limit"),
			MbMchPrizeLimit: v.GetInt("mb_mch_prize_limit"),
		}

		markets[m.ID] = m

		odd := v.GetObject("odds")
		odd.Visit(func(kk []byte, vv *fastjson.Value) {

			_ = kk

			d := OddData{
				ID:       string(vv.GetStringBytes("id")),
				IsWinner: vv.GetInt("visible"),
				MatchID:  string(v.GetStringBytes("match_id")),
				MarketID: string(vv.GetStringBytes("market_id")),
				Name:     string(vv.GetStringBytes("name")),
				Odd:      string(vv.GetStringBytes("odd")),
				SortID:   vv.GetInt("sort_id"),
				Visible:  vv.GetInt("visible"),
			}

			odds[d.ID] = d
		})
	})

}

func HandicapMatchInfo(pool *redis.Client, matchID []string) (map[string]MatchData, error) {

	matches := map[string]MatchData{}

	var cmds []*redis.Cmd
	pipe := pool.TxPipeline()
	for _, v := range matchID {
		key := fmt.Sprintf(RedisGameView, v)
		cmds = append(cmds, pipe.Do("JSON.GET", key, "NOESCAPE", "."))
	}

	_, _ = pipe.Exec()

	for _, cmd := range cmds {

		val, err := cmd.Result()
		if err != nil {
			continue
		}

		if val == nil {
			continue
		}

		var p fastjson.Parser
		v, err := p.Parse(val.(string))
		if err != nil {
			continue
		}

		parseMatch(v, matches)
	}

	return matches, nil
}

func HandicapMarketInfo(pool *redis.Client, matchID, marketID string) (MarketData, []OddData, error) {

	var (
		market MarketData
		odds   []OddData
		p      fastjson.Parser
	)
	key := fmt.Sprintf(RedisGameView, matchID)
	res, err := pool.Do("JSON.GET", key, "NOESCAPE", ".markets.$"+marketID).Text()
	if err != nil {
		return market, nil, err
	}
	v, err := p.Parse(res)
	if err != nil {
		return market, nil, err
	}
	obj, err := v.Object()
	if err != nil {
		return market, nil, err
	}

	round, _ := obj.Get("round").Int()
	isDefault, _ := obj.Get("is_default").Int()
	optionType, _ := obj.Get("option_type").Int()
	sortCode, _ := obj.Get("sort_code").Int()
	status, _ := obj.Get("status").Int()
	suspended, _ := obj.Get("suspended").Int()
	visible, _ := obj.Get("visible").Int()
	prizeLimit, _ := obj.Get("prize_limit").Int()
	mktLimit, _ := obj.Get("mb_mkt_prize_limit").Int()
	mchLimit, _ := obj.Get("mb_mch_prize_limit").Int()

	market = MarketData{
		ID:              obj.Get("id").String(),
		MatchID:         obj.Get("match_id").String(),
		OddTypeID:       obj.Get("odd_type_id").String(),
		CnName:          obj.Get("cn_name").String(),
		EnName:          obj.Get("en_name").String(),
		Round:           round,
		IsDefault:       isDefault,
		OptionType:      optionType,
		SortCode:        sortCode,
		Status:          status,
		Suspended:       suspended,
		Visible:         visible,
		PrizeLimit:      prizeLimit,
		MbMktPrizeLimit: mktLimit,
		MbMchPrizeLimit: mchLimit,
	}

	odd := obj.Get("odds").GetObject()
	odd.Visit(func(kk []byte, vv *fastjson.Value) {

		_ = kk
		odds = append(odds, OddData{
			ID:       string(vv.GetStringBytes("id")),
			IsWinner: vv.GetInt("visible"),
			MatchID:  string(v.GetStringBytes("match_id")),
			MarketID: string(vv.GetStringBytes("market_id")),
			Name:     string(vv.GetStringBytes("name")),
			Odd:      string(vv.GetStringBytes("odd")),
			SortID:   vv.GetInt("sort_id"),
			Visible:  vv.GetInt("visible"),
		})
	})

	return market, odds, nil
}

func HandicapInfo(pool *redis.Client, matchID []string) (HandicapData, error) {

	hd := HandicapData{}
	hd.Matches = map[string]MatchData{}
	hd.Markets = map[string]MarketData{}
	hd.Odds = map[string]OddData{}

	var cmds []*redis.Cmd
	pipe := pool.TxPipeline()
	for _, v := range matchID {
		key := fmt.Sprintf(RedisGameView, v)
		cmds = append(cmds, pipe.Do("JSON.GET", key, "NOESCAPE", "."))
	}

	_, _ = pipe.Exec()

	for _, cmd := range cmds {

		val, err := cmd.Result()
		if err != nil {
			continue
		}

		if val == nil {
			continue
		}

		var p fastjson.Parser
		v, err := p.Parse(val.(string))
		if err != nil {
			continue
		}

		parseMatch(v, hd.Matches)
		parseMarket(v, hd.Markets, hd.Odds)
	}

	return hd, nil
}

/**
 * @Description: 获取用户前端index主页数据
 * @Author: maxic
 * @Date: 2020/8/15
 * @LastEditTime: 2020/8/15
 * @LastEditors: maxic
 **/
func GameIndexGet(pool *redis.Client, gameIds string, flag, day int, pageSize int64, now time.Time) (interface{}, error) {

	var keys []string
	min, max, limit, reverse := gameIndexGetRange(flag, day, now)

	if gameIds == "0" { //取全部游戏
		switch flag {
		case 1: // 1:今日
			keys = append(keys, RedisGameTodayAll)
		case 2: // 2:赛前
			keys = append(keys, RedisGameEarlyAll)
		case 3: // 3:滚盘
			keys = append(keys, RedisGameLiveAll)
		case 4: // 4:串关
			keys = append(keys, RedisGameComplexAll)
		case 5: // 5:赛果
			keys = append(keys, RedisGameResultAll)
		case 6: // 6:筛选（所有: 今日+早盘+赛果）
			keys = append(keys, RedisGameTodayAll, RedisGameEarlyAll, RedisGameResultAll)
		}
	} else {
		ids := strings.Split(gameIds, ",")
		for _, v := range ids {
			switch flag {
			case 1: // 1:今日
				keys = append(keys, fmt.Sprintf(RedisGameToday, v))
			case 2: // 2:赛前
				keys = append(keys, fmt.Sprintf(RedisGameEarly, v))
			case 3: // 3:滚盘
				keys = append(keys, fmt.Sprintf(RedisGameLive, v))
			case 4: // 4:串关
				complexKey := fmt.Sprintf(RedisGameComplex, v)
				keys = append(keys, complexKey)
			case 5: // 5:赛果
				keys = append(keys, fmt.Sprintf(redisGameResult, v))
			case 6: // 6:筛选（所有: 今日+早盘+赛果）
				keys = append(keys, fmt.Sprintf(RedisGameToday, v), fmt.Sprintf(RedisGameEarly, v), fmt.Sprintf(redisGameResult, v))
			}
		}
	}

	zRangeBy := redis.ZRangeBy{
		Min: min,
		Max: max,
	}

	if limit {
		zRangeBy = redis.ZRangeBy{
			Min:    min,
			Max:    max,
			Offset: 0,
			Count:  pageSize,
		}
	}

	var (
		res      []interface{}
		cmds     []*redis.Cmd
		matchIds []string
	)

	mpKeys := map[string]int{}
	for _, v := range keys {

		var res []string
		var err error
		if reverse {
			res, err = pool.ZRevRangeByScore(v, &zRangeBy).Result()
		} else {
			res, err = pool.ZRangeByScore(v, &zRangeBy).Result()
		}

		if err != nil {
			return "", err
		}
		for _, vv := range res {
			if _, ok := mpKeys[vv]; !ok {
				matchIds = append(matchIds, vv)
				mpKeys[vv] = 1
			}
		}
	}

	pipe := pool.TxPipeline()
	for _, matchId := range matchIds {
		key := fmt.Sprintf(RedisGameIndex, matchId)
		cmds = append(cmds, pool.Do("JSON.GET", key, "NOESCAPE", "."))
	}

	pipe.Exec()

	for _, cmd := range cmds {

		val, err := cmd.Result()
		if err != nil {
			continue
		}

		if val != nil {
			res = append(res, val.(string))
		}
	}

	return res, nil
}

func gameIndexGetRange(flag, day int, now time.Time) (string, string, bool, bool) {

	var (
		limit   bool
		reverse bool
	)
	y, m, d := now.Date()
	today := time.Date(y, m, d, 0, 0, 0, 0, now.Location())
	tomorrow := today.AddDate(0, 0, 1)
	min, max := "-inf", "+inf"

	switch flag {
	case 1: // 1:今日
		min = "0"
		max = fmt.Sprintf("%d", tomorrow.Add(time.Hour).Unix()-1) // 有可能存在滚球跨天的情况所以这里需要加一个小时
	case 2: // 2:赛前
		// 赛前 - 次日至7天内
		date := today.AddDate(0, 0, day)
		min = fmt.Sprintf("%d", date.Unix())
		max = fmt.Sprintf("%d", date.AddDate(0, 0, 1).Unix()-1)
		limit = true
	case 3, 4: // 3:滚盘 4:串关
		// 滚球， 串关 - 今日至7天内
		min = "0"
		max = fmt.Sprintf("%d", tomorrow.AddDate(0, 0, 7).Unix()-1)
	case 5: // 5:赛果
		// 赛果 - 7天内至今日
		date := tomorrow.AddDate(0, 0, -day)
		min = fmt.Sprintf("%d", date.AddDate(0, 0, -1).Unix())
		max = fmt.Sprintf("%d", date.Unix()-1)
		limit = true
		reverse = true
	}

	return min, max, limit, reverse
}

/**
* @Description: 根据matchID获取赛事index rejson
* @Author: brandon
* @Date: 2020/8/17 8:00 下午
* @LastEditTime: 2020/8/17 8:00 下午
* @LastEditors: brandon
 */
func MatchIndexGet(pool *redis.Client, mchIds []string) ([]interface{}, error) {

	var res []interface{}
	var cmds []*redis.Cmd
	pipe := pool.TxPipeline()
	for _, v := range mchIds {
		key := fmt.Sprintf(RedisGameIndex, v)
		cmds = append(cmds, pool.Do("JSON.GET", key, "NOESCAPE", "."))
	}

	pipe.Exec()

	for _, cmd := range cmds {

		val, err := cmd.Result()
		if err != nil {
			continue
		}

		if val != nil {
			res = append(res, val.(string))
		}
	}

	return res, nil
}

/**
 * @Description: 获取用户前端view赛事详情数据
 * @Author: maxic
 * @Date: 2020/8/15
 * @LastEditTime: 2020/8/15
 * @LastEditors: maxic
 **/
func GameViewGet(pool *redis.Client, matchId string) (interface{}, error) {

	key := fmt.Sprintf(RedisGameView, matchId)
	return pool.Do("JSON.GET", key, "NOESCAPE", ".markets").Result()
}

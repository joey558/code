package calc

import (
	"fmt"
	"github.com/valyala/fastjson"
	"testing"
)

func TestProduce(t *testing.T) {

	hd := HandicapData{}
	s := `{
  "bo": 3,
  "category": 1,
  "game_id": "257289795134339",
  "id": "234164332437223",
  "is_live": 1,
  "is_pass_off": 0,
  "live_support": 0,
  "match_level": 3,
  "match_team": "Lao&nbsp;Wang,lg2",
  "rec": 0,
  "score": "0:0",
  "start_time": 1597493946,
  "status": 1,
  "suspended": 0,
  "team_id": "16352944538960273,15493763740913963",
  "tournament_id": "18842139850009",
  "tournament_short_name": "National&nbsp;Cybersport&nbsp;League",
  "user_video_url": "",
  "visible": 1,
  "count": 0,
  "markets": {
    "$238006988872735": {
      "id": "238006988872735",
      "match_id": "234164332437223",
      "odd_type_id": "15493971491429412",
      "cn_name": "\u00e8\u0083\u009c\u00e8\u00b4\u009f",
      "en_name": "",
      "round": 0,
      "is_default": 1,
      "option_type": 1,
      "sort_code": 1,
      "status": 5,
      "suspended": 0,
      "visible": 1,
      "prize_limit":0,
      "mb_mkt_prize_limit":0,
      "mb_mch_prize_limit":0,
      "odds": {
        "$238006990730041": {
          "id": "238006990730041",
          "market_id": "238006988872735",
          "name": "Lao&nbsp;Wang",
          "odd": "1.500",
          "is_winner": 0,
          "sort_id": 0,
          "visible": 1
        },
        "$238006991022465": {
          "id": "238006991022465",
          "market_id": "238006988872735",
          "name": "lg2",
          "odd": "2.591",
          "is_winner": 0,
          "sort_id": 1,
          "visible": 1
        }
      }
    },
    "$238007167926447": {
      "id": "238007167926447",
      "match_id": "234164332437223",
      "odd_type_id": "15494104326820699",
      "cn_name": "\u00e8\u00b6\u00a3\u00e5\u0091\u00b3",
      "en_name": "",
      "round": 0,
      "is_default": 0,
      "option_type": 4,
      "sort_code": 1,
      "status": 5,
      "suspended": 0,
      "visible": 1,
      "prize_limit":0,
      "mb_mkt_prize_limit":0,
      "mb_mch_prize_limit":0,
      "odds": {
        "$238007168213530": {
          "id": "238007168213530",
          "market_id": "238007167926447",
          "name": "@T1",
          "odd": "1.500",
          "is_winner": 0,
          "sort_id": 0,
          "visible": 1
        },
        "$238007168263621": {
          "id": "238007168263621",
          "market_id": "238007167926447",
          "name": "@T2",
          "odd": "2.591",
          "is_winner": 0,
          "sort_id": 1,
          "visible": 1
        }
      }
    },
    "$238068814561778": {
      "id": "238068814561778",
      "match_id": "234164332437223",
      "odd_type_id": "15494166545128629",
      "cn_name": "\u00e8\u00ae\u00a9\u00e5\u0088\u0086",
      "en_name": "",
      "round": 1,
      "is_default": 0,
      "option_type": 2,
      "sort_code": 1,
      "status": 5,
      "suspended": 0,
      "visible": 1,
      "prize_limit":0,
      "mb_mkt_prize_limit":0,
      "mb_mch_prize_limit":0,
      "odds": {
        "$238068814841270": {
          "id": "238068814841270",
          "market_id": "238068814561778",
          "name": "@T1&nbsp;+1.5",
          "odd": 3.5470000000000002,
          "is_winner": 0,
          "sort_id": 0,
          "visible": 1
        },
        "$238068814919937": {
          "id": "238068814919937",
          "market_id": "238068814561778",
          "name": "@T2&nbsp;-1.5",
          "odd": 1.2969999999999999,
          "is_winner": 0,
          "sort_id": 1,
          "visible": 1
        }
      }
    },
    "$238068815005159": {
      "id": "238068815005159",
      "match_id": "234164332437223",
      "odd_type_id": "15494166545128629",
      "cn_name": "\u00e8\u00ae\u00a9\u00e5\u0088\u0086",
      "en_name": "",
      "round": 2,
      "is_default": 0,
      "option_type": 2,
      "sort_code": 1,
      "status": 5,
      "suspended": 0,
      "visible": 1,
      "prize_limit":0,
      "mb_mkt_prize_limit":0,
      "mb_mch_prize_limit":0,
      "odds": {
        "$238068815305898": {
          "id": "238068815305898",
          "market_id": "238068815005159",
          "name": "@T1&nbsp;+1.5",
          "odd": "3.500",
          "is_winner": 0,
          "sort_id": 0,
          "visible": 1
        },
        "$238068815407280": {
          "id": "238068815407280",
          "market_id": "238068815005159",
          "name": "@T2&nbsp;-1.5",
          "odd": "1.304",
          "is_winner": 0,
          "sort_id": 1,
          "visible": 1
        }
      }
    },
    "$238068815481071": {
      "id": "238068815481071",
      "match_id": "234164332437223",
      "odd_type_id": "15494166545128629",
      "cn_name": "\u00e8\u00ae\u00a9\u00e5\u0088\u0086",
      "en_name": "",
      "round": 3,
      "is_default": 0,
      "option_type": 2,
      "sort_code": 1,
      "status": 5,
      "suspended": 0,
      "visible": 1,
      "prize_limit":0,
      "mb_mkt_prize_limit":0,
      "mb_mch_prize_limit":0,
      "odds": {
        "$238068818172311": {
          "id": "238068818172311",
          "market_id": "238068815481071",
          "name": "@T1&nbsp;+1.5",
          "odd": "3.500",
          "is_winner": 0,
          "sort_id": 0,
          "visible": 1
        },
        "$238068818687405": {
          "id": "238068818687405",
          "market_id": "238068815481071",
          "name": "@T2&nbsp;-1.5",
          "odd": "1.304",
          "is_winner": 0,
          "sort_id": 1,
          "visible": 1
        }
      }
    },
    "$238555771602856": {
      "id": "238555771602856",
      "match_id": "234164332437223",
      "odd_type_id": "15494166545128629",
      "cn_name": "\u00e8\u00ae\u00a9\u00e5\u0088\u0086",
      "en_name": "",
      "round": 1,
      "is_default": 0,
      "option_type": 2,
      "sort_code": 2,
      "status": 5,
      "suspended": 0,
      "visible": 1,
      "prize_limit":0,
      "mb_mkt_prize_limit":0,
      "mb_mch_prize_limit":0,
      "odds": {
        "$238555771860795": {
          "id": "238555771860795",
          "market_id": "238555771602856",
          "name": "@T1&nbsp;+2.5",
          "odd": "3.500",
          "is_winner": 0,
          "sort_id": 0,
          "visible": 1
        },
        "$238555771905795": {
          "id": "238555771905795",
          "market_id": "238555771602856",
          "name": "@T2&nbsp;-2.5",
          "odd": "1.304",
          "is_winner": 0,
          "sort_id": 1,
          "visible": 1
        }
      }
    }
  }
}`
	hd.Matches = map[string]MatchData{}
	hd.Markets = map[string]MarketData{}
	hd.Odds = map[string]OddData{}

	var p fastjson.Parser
	v, err := p.Parse(s)
	if err != nil {
		t.Error(err)
	}

	parseMatch(v, hd.Matches)
	parseMarket(v, hd.Markets, hd.Odds)

	t.Log(hd.Matches)
	t.Log(hd.Markets)
	t.Log(hd.Odds)
}

func TestMarketInfo(t *testing.T) {

	s := `{
  "bo": 3,
  "category": 1,
  "game_id": "257289795134339",
  "id": "234164332437223",
  "is_live": 1,
  "is_pass_off": 0,
  "live_support": 0,
  "match_level": 3,
  "match_team": "Lao&nbsp;Wang,lg2",
  "rec": 0,
  "score": "0:0",
  "start_time": 1597493946,
  "status": 1,
  "suspended": 0,
  "team_id": "16352944538960273,15493763740913963",
  "tournament_id": "18842139850009",
  "tournament_short_name": "National&nbsp;Cybersport&nbsp;League",
  "user_video_url": "",
  "visible": 1,
  "count": 0,
  "markets": {
    "$238555771602856": {
      "id": "238555771602856",
      "match_id": "234164332437223",
      "odd_type_id": "15494166545128629",
      "cn_name": "\u00e8\u00ae\u00a9\u00e5\u0088\u0086",
      "en_name": "",
      "round": 1,
      "is_default": 0,
      "option_type": 2,
      "sort_code": 2,
      "status": 5,
      "suspended": 0,
      "visible": 1,
      "prize_limit":0,
      "mb_mkt_prize_limit":0,
      "mb_mch_prize_limit":0,
      "odds": {
        "$238555771860795": {
          "id": "238555771860795",
          "market_id": "238555771602856",
          "name": "@T1&nbsp;+2.5",
          "odd": "3.500",
          "is_winner": 0,
          "sort_id": 0,
          "visible": 1
        },
        "$238555771905795": {
          "id": "238555771905795",
          "market_id": "238555771602856",
          "name": "@T2&nbsp;-2.5",
          "odd": "1.304",
          "is_winner": 0,
          "sort_id": 1,
          "visible": 1
        }
      }
    }
  }
}`

	var market MarketData
	var odds []OddData
	var p fastjson.Parser
	v, err := p.Parse(s)
	if err != nil {
		t.Error(err)
	}

	obj:= v.GetObject("markets")
	obj.Visit(func(k []byte, v *fastjson.Value) {
		_ = k
		market = MarketData{
			ID:              string(v.GetStringBytes("id")),
			MatchID:         string(v.GetStringBytes("match_id")),
			OddTypeID:       string(v.GetStringBytes("odd_type_id")),
			CnName:          string(v.GetStringBytes("cn_name")),
			EnName:          string(v.GetStringBytes("en_name")),
			Round:           v.GetInt("round"),
			IsDefault:       v.GetInt("is_default"),
			OptionType:      v.GetInt("option_type"),
			SortCode:        v.GetInt("sort_code"),
			Status:          v.GetInt("status"),
			Suspended:       v.GetInt("suspended"),
			Visible:         v.GetInt("visible"),
			PrizeLimit:      v.GetInt("prize_limit"),
			MbMktPrizeLimit: v.GetInt("mb_mkt_prize_limit"),
			MbMchPrizeLimit: v.GetInt("mb_mch_prize_limit"),
		}

		odd := v.GetObject("odds")
		odd.Visit(func(kk []byte, vv *fastjson.Value) {

			_ = kk
			odds = append(odds, OddData{
				ID:       string(vv.GetStringBytes("id")),
				IsWinner: vv.GetInt("visible"),
				MatchID:  string(v.GetStringBytes("match_id")),
				MarketID: string(vv.GetStringBytes("market_id")),
				Name:     string(vv.GetStringBytes("name")),
				Odd:      string(vv.GetStringBytes("odd")),
				SortID:   vv.GetInt("sort_id"),
				Visible:  vv.GetInt("visible"),
			})
		})
	})

	fmt.Printf("%+v\n",market)
	fmt.Println("****************")
	fmt.Printf("%+v\n",odds)
}

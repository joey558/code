package helper

import (
	"fmt"
	"github.com/valyala/fasthttp"
	"time"
)

func GetDailyTimeBegin(ctx *fasthttp.RequestCtx, n int) string {

	year, month, day := ctx.Time().AddDate(0, 0, n).Date()

	ts := time.Date(year, month, day, 0, 0, 0, 0, ctx.Time().Location()).Unix()

	return fmt.Sprintf("%d", ts)
}

func GetDailyTimeEnd(ctx *fasthttp.RequestCtx, n int) string {

	year, month, day := ctx.Time().AddDate(0, 0, n).Date()

	ts := time.Date(year, month, day, 23, 59, 59, 0, ctx.Time().Location()).Unix()

	return fmt.Sprintf("%d", ts)
}

func DailyEndTime(ctx *fasthttp.RequestCtx, n int) time.Time {

	year, month, day := ctx.Time().AddDate(0, 0, n).Date()

	end := time.Date(year, month, day, 23, 59, 59, 0, ctx.Time().Location())

	return end
}

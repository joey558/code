package router

import (
	"fmt"
	"runtime/debug"
	"time"

	"autoSettle/controller"

	"github.com/buaazp/fasthttprouter"
	"github.com/valyala/fasthttp"
	"github.com/valyala/fasthttp/pprofhandler"
)

type BuildInfo struct {
	GitReversion   string
	BuildTime      string
	BuildGoVersion string
}

var (
	apiTimeoutMsg = `{"status": "error","message": "服务器响应超时，请稍后重试","data":null}`
	apiTimeout    = time.Second * 30
	router        *fasthttprouter.Router
	buildInfo     BuildInfo
)

func apiServerPanic(ctx *fasthttp.RequestCtx, rcv interface{}) {

	err := rcv.(error)
	fmt.Println(err)
	debug.PrintStack()

	if r := recover(); r != nil {
		fmt.Println("recovered failed", r)
	}

	ctx.SetStatusCode(500)
	return
}

func initHTTPRouter() {

	// 游戏
	gameCtl := new(controller.GameController)
	// 联赛
	tournamentCtl := new(controller.TournamentController)

	matchCtl := new(controller.MatchController)

	marketCtl := new(controller.MarketController)

	get("/autoSettle/game/list", gameCtl.GameList)

	get("/autoSettle/tournament/list", tournamentCtl.TournamentList)
	// 赛事列表
	get("/autoSettle/match/list", matchCtl.List)
	get("/autoSettle/match/esList", matchCtl.EsList)
	// 订阅赛事实时数据
	post("/autoSettle/match/subscription", matchCtl.SubscriptionLive)
	//
	post("/autoSettle/market/resultGet", marketCtl.MarketResultConfirmInput)
}

// SetupRouter 设置路由列表
func SetupHTTPRouter(b BuildInfo) *fasthttprouter.Router {

	router = fasthttprouter.New()
	//版本号
	buildInfo = b
	get("/autoSettle/version", Version)
	// 性能测试
	get("/debug/pprof/", pprofhandler.PprofHandler)
	get("/debug/pprof/block", pprofhandler.PprofHandler)
	get("/debug/pprof/allocs", pprofhandler.PprofHandler)
	get("/debug/pprof/cmdline", pprofhandler.PprofHandler)
	get("/debug/pprof/goroutine", pprofhandler.PprofHandler)
	get("/debug/pprof/heap", pprofhandler.PprofHandler)
	get("/debug/pprof/profile", pprofhandler.PprofHandler)
	get("/debug/pprof/trace", pprofhandler.PprofHandler)
	get("/debug/pprof/threadcreate", pprofhandler.PprofHandler)
	// 初始化路由
	initHTTPRouter()

	return router
}

func Version(ctx *fasthttp.RequestCtx) {
	ctx.SetContentType("text/html; charset=utf-8")
	fmt.Fprintf(ctx, "autoSettle<br />Git reversion = %s<br />Build Time = %s<br />Go version = %s<br />System Time = %s<br />",
		buildInfo.GitReversion, buildInfo.BuildTime, buildInfo.BuildGoVersion, ctx.Time())
}

// get is a shortcut for router.GET(path string, handle fasthttp.RequestHandler)
func get(path string, handle fasthttp.RequestHandler) {
	router.GET(path, fasthttp.TimeoutHandler(handle, apiTimeout, apiTimeoutMsg))
}

// head is a shortcut for router.HEAD(path string, handle fasthttp.RequestHandler)
func head(path string, handle fasthttp.RequestHandler) {
	router.HEAD(path, fasthttp.TimeoutHandler(handle, apiTimeout, apiTimeoutMsg))
}

// options is a shortcut for router.OPTIONS(path string, handle fasthttp.RequestHandler)
func options(path string, handle fasthttp.RequestHandler) {
	router.OPTIONS(path, fasthttp.TimeoutHandler(handle, apiTimeout, apiTimeoutMsg))
}

// post is a shortcut for router.POST(path string, handle fasthttp.RequestHandler)
func post(path string, handle fasthttp.RequestHandler) {
	router.POST(path, fasthttp.TimeoutHandler(handle, apiTimeout, apiTimeoutMsg))
}

// put is a shortcut for router.PUT(path string, handle fasthttp.RequestHandler)
func put(path string, handle fasthttp.RequestHandler) {
	router.PUT(path, fasthttp.TimeoutHandler(handle, apiTimeout, apiTimeoutMsg))
}

// patch is a shortcut for router.PATCH(path string, handle fasthttp.RequestHandler)
func patch(path string, handle fasthttp.RequestHandler) {
	router.PATCH(path, fasthttp.TimeoutHandler(handle, apiTimeout, apiTimeoutMsg))
}

// delete is a shortcut for router.DELETE(path string, handle fasthttp.RequestHandler)
func delete(path string, handle fasthttp.RequestHandler) {
	router.DELETE(path, fasthttp.TimeoutHandler(handle, apiTimeout, apiTimeoutMsg))
}

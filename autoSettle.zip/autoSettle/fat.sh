#! /bin/bash

DIR=$(dirname $(readlink -f $0))
PROJECT="autoSettle"
BRANCH="fat"
ETCDS="34.92.193.98:2379,34.92.58.208:2379"
CFG_PATH="/dj/fat/fusion/auto_settle.json"

git fetch
git checkout $BRANCH
git pull
git submodule init
git submodule update
go build -o $PROJECT

pkill $PROJECT
#mkdir log 2>/dev/null
#chmod +x $PROJECT
nohup ${DIR}/$PROJECT $ETCDS $CFG_PATH http > ${DIR}/log/a.log 2>&1 &
nohup ${DIR}/$PROJECT $ETCDS $CFG_PATH liveSub > ${DIR}/log/live.log 2>&1 &
package model

import (
	"fmt"
	g "github.com/doug-martin/goqu/v9"
)

type Odd struct {
	ID         string `json:"id" db:"id"`                   // 投注项ID
	MatchID    string `json:"match_id" db:"match_id"`       // 赛事ID
	MarketID   string `json:"market_id" db:"market_id"`     // 盘口ID
	Name       string `json:"name" db:"name"`               // 选项名称
	Odd        string `json:"odd" db:"odd"`                 // 赔率
	OrgOdd     string `json:"org_odd" db:"org_odd"`         // 初始赔率
	Round      int    `json:"round" db:"round"`             // 赛事局数
	IsWinner   int    `json:"is_winner" db:"is_winner"`     // 是否获胜 1-是 0-否
	SortID     int    `json:"sort_id" db:"sort_id"`         // 排序码
	Visible    int    `json:"visible" db:"visible"`         // 是否显示 1-显示 0-隐藏
	TargetID   int64  `db:"target_id" json:"target_id"`     // 数据源id
	DataSource int    `db:"data_source" json:"data_source"` // 数据源
}

/**
 * @Description: 新增盘口投注项
 * @Author: awen
 * @Date: 2020/11/06 16:38
 * @LastEditTime: 2020/11/06 16:38
 * @LastEditors: awen
 */
func OddInsert(data *Odd) error {

	// 开启事务
	dbConn, err := Db.Begin()
	if err != nil {
		return err
	}
	// 写入数据库
	dialect := g.Dialect("mysql")
	query, _, _ := dialect.Insert("tbl_odd").Rows(data).ToSQL()
	fmt.Println(query)
	_, err = dbConn.Exec(query)
	if err != nil {
		_ = dbConn.Rollback()
		return err
	}

	return dbConn.Commit()
}

/**
 * @Description: 修改盘口投注项
 * @Author: awen
 * @Date: 2020/10/06 16:45
 * @LastEditTime: 2020/10/06 16:45
 * @LastEditors: awen
 */
func OddUpdate(record g.Record, ex g.Ex) error {

	dialect := g.Dialect("mysql")
	query, _, _ := dialect.Update("tbl_odd").Set(record).Where(ex).ToSQL()
	fmt.Println(query)
	_, err := Db.Exec(query)
	return err
}

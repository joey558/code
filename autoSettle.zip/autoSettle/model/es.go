package model

import (
	"autoSettle/helper"

	"context"
	"errors"
	"fmt"
	"github.com/olivere/elastic/v7"
)

// 赛事结构体
type EsMatches struct {
	ID             string `json:"id"`              // 主键id
	DataSource     int    `json:"data_source"`     // 来源
	GameID         string `json:"game_id"`         // 游戏id
	TournamentID   int64  `json:"tournament_id"`   // 联赛id
	TournamentName string `json:"tournament_name"` // 联赛名称
	TeamID         string `json:"team_id"`         // 战队id
	TeamName       string `json:"team_name"`       // 战队名称
	Bo             int    `json:"bo"`              // 赛制 全局-0  B01-1 B02-2 B03-3
	Tier           int64  `json:"tier"`            // 赛事等级
	StartTime      int64  `json:"start_time"`      // 比赛开始时间
	EndTime        int64  `json:"end_time"`        // 比赛结束时间
	Score          string `json:"score"`           // 赛事比分
	TargetID       int64  `json:"target_id"`       // 数据源主键
	IDX            string `json:"idx"`             // queryString 查询数据
}

type EsMatchTeams struct {
	ID       string `json:"id"`
	MatchID  string `json:"match_id"`
	TeamID   string `json:"team_id"`
	TeamName string `json:"team_name"`
	IDX      string `json:"idx"` // queryString 查询数据
}

/**
 * @Description: 创建es索引
 * @Author: Daxie
 * @Date: 2020/10/25 19:54
 * @LastEditTime: 2020/10/25 19:54
 * @LastEditors: Daxie
 */
func CreateIndex(index, body string) error {

	ctx := context.Background()
	//判断索引是否存在
	exists, err := Es.IndexExists(index).Do(ctx)
	if err != nil {
		return err
	}

	//索引不存在 新增索引
	if !exists {
		_, err := Es.CreateIndex(index).BodyString(body).Do(ctx)
		if err != nil {
			return err
		}
	}

	return nil
}

/**
 * @Description: 写入数据
 * @Author: Daxie
 * @Date: 2020/10/25 19:54
 * @LastEditTime: 2020/10/25 19:54
 * @LastEditors: Daxie
 */
func CreateData(index string, id string, data interface{}) error {

	ctx := context.Background()
	// 写入
	_, err := Es.Index().
		Index(index).
		Id(id).
		BodyJson(data).
		Refresh("wait_for"). //sync方式的写入
		Do(ctx)

	if err != nil {
		return err
	}

	return nil
}

/**
 * @Description: 更新数据
 * @Author: Daxie
 * @Date: 2020/10/25 19:54
 * @LastEditTime: 2020/10/25 19:54
 * @LastEditors: Daxie
 */
func UpdateData(index, id string, data interface{}) error {

	ctx := context.Background()
	// id存在 则修改 否则 新增
	_, err := Es.Update().
		Index(index).
		Id(id).
		Refresh("wait_for"). //sync方式的写入
		Doc(data).
		DocAsUpsert(true).
		Do(ctx)

	if err != nil {
		return err
	}

	return nil
}

/**
 * @Description: 批量写入赛事数据
 * @Author: Daxie
 * @Date: 2020/10/25 19:54
 * @LastEditTime: 2020/10/25 19:54
 * @LastEditors: Daxie
 */
func CreateAllData(index string, data []EsMatches) error {

	ctx := context.Background()
	bulkRequest := Es.Bulk()
	for _, d := range data {
		doc := elastic.NewBulkUpdateRequest().Index(index).Id(fmt.Sprintf("%d", d.ID)).Doc(d).DocAsUpsert(true)
		bulkRequest = bulkRequest.Add(doc)
	}

	response, err := bulkRequest.Do(ctx)
	if err != nil {
		return err
	}

	failed := response.Failed()
	l := len(failed)
	if l > 0 {
		return errors.New(fmt.Sprintf("Error(%d)", l, response.Errors))
	}

	return nil
}

/**
 * @Description: 删除数据
 * @Author: Daxie
 * @Date: 2020/10/25 19:54
 * @LastEditTime: 2020/10/25 19:54
 * @LastEditors: Daxie
 */
func DeleteData(index, id string) error {

	ctx := context.Background()
	res, err := Es.Delete().
		Index(index).
		Id(id).
		Refresh("wait_for").
		Do(ctx)

	if err != nil {
		return err
	}

	if res.Result == "deleted" {
		return errors.New("Document 1: deleted")
	}

	return nil
}

/**
 * @Description: 数据查询按指定键排序
 * @Author: Daxie
 * @Date: 2020/10/25 19:54
 * @LastEditTime: 2020/10/25 19:54
 * @LastEditors: Daxie
 */
func SearchOrderData(index string, boolQuery *elastic.BoolQuery, sort string, ascending bool, start, size int) (*elastic.SearchResult, error) {

	//打印es查询json
	searchJson, err := boolQuery.Source()
	if err != nil {
		return nil, err
	}

	PrintQueryJson(searchJson)
	fsc := elastic.NewFetchSourceContext(true)

	if sort == "" {
		return nil, errors.New("illegal sort")
	}

	return Es.Search().
		FetchSourceContext(fsc).
		Query(boolQuery).
		From(start).Size(size).
		TrackTotalHits(true).
		Index(index).
		Sort(sort, ascending).
		Do(context.Background())

}

/**
 * @Description: 数据查询
 * @Author: Daxie
 * @Date: 2020/10/25 19:54
 * @LastEditTime: 2020/10/25 19:54
 * @LastEditors: Daxie
 */
func SearchData(index string, boolQuery *elastic.BoolQuery, start, size int) (*elastic.SearchResult, error) {

	//打印es查询json
	searchJson, err := boolQuery.Source()
	if err != nil {
		return nil, err
	}

	PrintQueryJson(searchJson)
	fsc := elastic.NewFetchSourceContext(true)

	return Es.Search().
		FetchSourceContext(fsc).
		Query(boolQuery).
		From(start).Size(size).
		TrackTotalHits(true).
		Index(index).
		Do(context.Background())

}

/**
 * @Description: QueryString数据查询
 * @Author: Daxie
 * @Date: 2020/10/25 19:54
 * @LastEditTime: 2020/10/25 19:54
 * @LastEditors: Daxie
 */
func QueryStringSearch(index, q, fields string, start, size int) (*elastic.SearchResult, error) {

	fmt.Println(index, q, fields)
	query := elastic.NewQueryStringQuery(q)
	if len(fields) > 0 {
		query = query.DefaultField(fields)
	}
	//打印es查询json
	searchJson, err := query.Source()
	if err != nil {
		return nil, err
	}

	PrintQueryJson(searchJson)

	return Es.Search().
		Index(index).
		Query(query).
		From(start).Size(size).
		Pretty(true).
		Do(context.Background()) // 执行

}

/**
 * @Description: 打印es查询json
 * @Author: Daxie
 * @Date: 2020/10/25 19:54
 * @LastEditTime: 2020/10/25 19:54
 * @LastEditors: Daxie
 */
func PrintQueryJson(src interface{}) {

	data, err := helper.MarshalToString(src)
	if err != nil {
		fmt.Println(err.Error())
	}

	fmt.Println(data)
}

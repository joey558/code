package model

import (
	"fmt"

	g "github.com/doug-martin/goqu/v9"
)

type Game struct {
	ID         string `db:"id" rule:"none" json:"id"`
	Name       string `db:"name" json:"name"`
	ShortName  string `db:"short_name" json:"short_name"`
	CnName     string `db:"cn_name" json:"cn_name"`
	CreateTime int64  `db:"create_time" json:"create_time"`
	UpdateTime int64  `db:"update_time" json:"update_time"`
	TargetID   int64  `db:"target_id" json:"target_id"`
	DataSource int    `db:"data_source" json:"data_source"`
}

type SimpleGame struct {
	ID   int64  `db:"target_id" json:"id"`
	Name string `db:"name" json:"name"`
}

/**
 * @Description: 游戏新增
 * @Author: awen
 * @Date: 2020/10/21 21:32
 * @LastEditTime: 2020/10/21 21:32
 * @LastEditors: awen
 */
func GameInsert(data *Game) error {

	// 开启事务
	dbConn, err := Db.Begin()
	if err != nil {
		return err
	}

	// 写入数据库
	query, _, _ := g.Dialect("mysql").Insert("tbl_game").Rows(data).ToSQL()
	_, err = dbConn.Exec(query)
	if err != nil {
		_ = dbConn.Rollback()
		return err
	}

	pipe := Pool.TxPipeline()
	pipe.Set(fmt.Sprintf(RedisKeyGameFusion, data.DataSource, data.TargetID), data.ID, 0)
	pipe.Set(fmt.Sprintf(RedisKeyGameName, data.DataSource, data.TargetID), data.Name, 0)
	_, err = pipe.Exec()
	if err != nil {
		_ = dbConn.Rollback()
		return err
	}

	return dbConn.Commit()
}

/**
 * @Description: 游戏修改
 * @Author: awen
 * @Date: 2020/10/24 14:26
 * @LastEditTime: 2020/10/24 14:26
 * @LastEditors: awen
 */
func GameUpdate(v g.Record, ex g.Ex) error {

	// 写入数据库
	query, _, _ := g.Dialect("mysql").Update("tbl_game").Set(v).Where(ex).ToSQL()
	_, err := Db.Exec(query)
	return err
}

func GameFindAll(ex g.Ex) ([]SimpleGame, error) {

	var data []SimpleGame
	dialect := g.Dialect("mysql")
	query, _, _ := dialect.From("tbl_game").Select("target_id", "name").Where(ex).ToSQL()
	err := Db.Select(&data, query)
	return data, err
}

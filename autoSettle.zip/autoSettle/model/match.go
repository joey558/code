package model

import (
	"database/sql"
	"fmt"
	"reflect"
	"strings"

	"autoSettle/helper"
	"autoSettle/model/abios"

	g "github.com/doug-martin/goqu/v9"
)

//  赛事数据库表结构体
type Matches struct {
	ID             string `db:"id" json:"id"`
	Title          string `db:"title" json:"title"`                     // 比赛名称
	GameID         int64  `db:"game_id" json:"game_id"`                 // 游戏id
	TournamentID   int64  `db:"tournament_id" json:"tournament_id"`     // 联赛id
	TournamentName string `db:"tournament_name" json:"tournament_name"` // 联赛名称
	TeamID         string `db:"team_id" json:"team_id"`                 // 战队id，多个战队用 , 隔开
	TeamName       string `db:"team_name" json:"team_name"`             // 战队名称，多个战队用 , 隔开
	Bo             int    `db:"bo" json:"bo"`                           // 赛制
	Tier           int64  `db:"tier" json:"tier"`                       // 赛事等级
	Score          string `db:"score" json:"score"`                     // 赛事比分
	IsDelete       int    `db:"is_delete" json:"is_delete"`             // 是否删除
	StartTime      int64  `db:"start_time" json:"start_time"`           // 比赛开始时间
	EndTime        int64  `db:"end_time" json:"end_time"`               // 比赛结束时间
	CreatedAt      int64  `db:"created_at" json:"created_at"`           // 创建时间
	UpdatedAt      int64  `db:"updated_at" json:"updated_at"`           // 更新时间
	TargetID       int64  `db:"target_id" json:"target_id"`             // 数据源id
	DataSource     int    `db:"data_source" json:"data_source"`         // 数据源
}

type MatchRelated struct {
	ID             string `db:"id" json:"id"`
	MatchID        int64  `db:"match_id" json:"match_id"`
	SourceMatchID  int64  `db:"source_match_id" json:"source_match_id"`
	TournamentName string `db:"tournament_name" json:"tournament_name"`
	//HomeTeam       string `db:"home_team" json:"home_team"`
	//AwayTeam       string `db:"away_team" json:"away_team"`
	MatchTeam    string `db:"match_team" json:"match_team"`
	DiffSorted   int    `db:"diff_sorted" json:"diff_sorted"` // 数据源战队主客顺序是否一致 0-不一致 1-一致
	StartTime    int    `db:"start_time" json:"start_time"`
	DataSource   int    `db:"data_source" json:"data_source"`
	CreateAt     int64  `db:"create_at" json:"create_at"` // 创建时间
	UpdateAt     int64  `db:"update_at" json:"update_at"`
	CreateByID   int64  `db:"create_by_id" json:"create_by_id"`
	UpdateByID   int64  `db:"update_by_id" json:"update_by_id"`
	CreateByName string `db:"create_by_name" json:"create_by_name"`
	UpdateByName string `db:"update_by_name" json:"update_by_name"`
}

type MatchData struct {
	D []Matches `json:"d"`
	T int64     `json:"t"`
}

type EsMatchListParam struct {
	GameID         int    `rule:"digit" name:"game_id" default:"0"  msg:"game_id错误"`
	TournamentName string `rule:"none" name:"tournament_name" default:"0"  msg:"tournament_id错误"`
	StartTime      string `rule:"dateTime" default:"2020-01-01 00:00:00" msg:"start_time格式不正确" name:"start_time"`
	TeamName       string `rule:"none" name:"team_name" default:"" msg:"illegal team_name"`
}

type MatchLiveParam struct {
	GameID  int   `rule:"digit" name:"game_id" min:"0"  msg:"game_id错误"`
	MatchID int64 `rule:"digit" name:"match_id" min:"0"  msg:"match_id错误"`
}

// 总控trade Match赛事结构体
type TradeMatch struct {
	ID                  string `json:"id" db:"id" rule:"none" name:"id"`
	GameID              string `json:"game_id" db:"game_id" rule:"digit" min:"1" msg:"game_id error" name:"game_id"`
	CreateByName        string `json:"create_by_name" db:"create_by_name" rule:"none" name:"create_by_name"`
	UpdateByName        string `json:"update_by_name" db:"update_by_name" rule:"none" name:"update_by_name"`
	CreateTime          int64  `json:"create_time" db:"create_time" rule:"none" name:"create_time"`
	UpdateTime          int64  `json:"update_time" db:"update_time" rule:"none" name:"update_time"`
	StartTime           int64  `json:"start_time" db:"start_time" rule:"none" name:"start_time"`
	CloseTime           int64  `json:"close_time" db:"close_time" rule:"none"   name:"close_time"`
	EndTime             int64  `json:"end_time" db:"end_time" rule:"none" name:"end_time"`
	BetDelayTime        int64  `json:"bet_delay_time" db:"bet_delay_time" rule:"none" name:"bet_time"`
	MatchTeam           string `json:"match_team" db:"match_team" rule:"none" name:"match_team"`
	TournamentShortName string `json:"tournament_short_name" db:"tournament_short_name" rule:"alNumSpace" min:"2" max:"60" msg:"tournament_short_name错误[2-60]" name:"tournament_short_name"`
	UserVideoUrl        string `json:"user_video_url" db:"user_video_url" rule:"none" min:"2" max:"120" msg:"video_src_url错误" name:"user_video_url"`
	AdminVideoUrl       string `json:"admin_video_url" db:"admin_video_url" rule:"none" min:"2" max:"120" msg:"live_src错误" name:"admin_video_url"`
	Title               string `json:"title" db:"title" rule:"none" name:"title"`
	TournamentID        string `json:"tournament_id" db:"tournament_id" rule:"digit" min:"1" msg:"TournamentID error" name:"tournament_id"`
	Score               string `json:"score" db:"score" rule:"none"`
	Category            int    `json:"category" db:"category" rule:"none" name:"category"`
	Bo                  int    `json:"bo" db:"bo" rule:"digit" min:"1" max:"100" msg:"bo error" name:"bo"`
	MatchLevel          int    `json:"match_level" db:"match_level" rule:"none" name:"match_level"`
	Visible             int    `json:"visible" db:"visible" rule:"none" name:"visible"`
	Suspended           int    `json:"suspended" db:"suspended" rule:"none" name:"suspended"`
	LiveSupport         int    `json:"live_support" db:"live_support" rule:"none" name:"live_support"`
	IsPassOff           int    `json:"is_pass_off" db:"is_pass_off" rule:"none" name:"is_pass_off"`
	Status              int    `json:"status" db:"status" rule:"none" name:"status"`
	IsLive              int    `json:"is_live" db:"is_live" rule:"none" name:"is_live"`
	Rec                 int    `json:"rec" db:"rec" rule:"digit" min:"0" max:"20" msg:"rec error" name:"rec"`
}

/**
 * @Description: 获取单个比赛
 * @Author: Daxie
 * @Date: 2020/10/22 16:23
 * @LastEditTime: 2020/10/22 16:23
 * @LastEditors: Daxie
 */
func MatchesFindOne(ex g.Ex) (Matches, error) {

	var data Matches
	dialect := g.Dialect("mysql")
	query, _, _ := dialect.From("tbl_matches").Where(ex).Limit(1).ToSQL()
	fmt.Println(query)
	err := Db.Get(&data, query)
	if err == sql.ErrNoRows {
		return data, nil
	}

	return data, err
}

/**
 * @Description: 新增比赛
 * @Author: Daxie
 * @Date: 2020/10/22 16:24
 * @LastEditTime: 2020/10/22 16:24
 * @LastEditors: Daxie
 */
func MatchesInsert(data *Matches) error {

	// 开启事务
	dbConn, err := Db.Begin()
	if err != nil {
		return err
	}

	// 写入数据库
	dialect := g.Dialect("mysql")
	query, _, _ := dialect.Insert("tbl_matches").Rows(data).ToSQL()
	fmt.Println(query)
	_, err = dbConn.Exec(query)
	if err != nil {
		_ = dbConn.Rollback()
		return err
	}
	_, err = Pool.Set(fmt.Sprintf(RedisKeyMatchFusion, data.DataSource, data.TargetID), data.ID, 0).Result()
	if err != nil {
		_ = dbConn.Rollback()
		return err
	}

	return dbConn.Commit()
}

/**
 * @Description: 比赛修改
 * @Author: Daxie
 * @Date: 2020/10/22 16:25
 * @LastEditTime: 2020/10/22 16:25
 * @LastEditors: Daxie
 */
func MatchesUpdate(ex g.Ex, record g.Record) error {

	dialect := g.Dialect("mysql")
	query, _, _ := dialect.Update("tbl_matches").Set(record).Where(ex).ToSQL()
	fmt.Println(query)
	_, err := Db.Exec(query)
	return err
}

/**
 * @Description: 赛事列表
 * @Author: Daxie
 * @Date: 2020/10/22 21:21
 * @LastEditTime: 2020/10/22 21:21
 * @LastEditors: Daxie
 */
func MatchesPageList(offset, limit uint, ex g.Ex) (MatchData, error) {

	data := MatchData{}
	dialect := g.Dialect("mysql")
	queryCount, _, _ := dialect.From("tbl_matches").Where(ex).Select(g.COUNT("*")).ToSQL()
	queryPage, _, _ := dialect.From("tbl_matches").Where(ex).Order(g.C("start_time").Asc()).Limit(limit).Offset(offset).ToSQL()

	fmt.Println(queryCount)
	err := Db.Get(&data.T, queryCount)
	if err != nil {
		return data, nil
	}

	fmt.Println(queryPage)
	err = Db.Select(&data.D, queryPage)

	return data, err
}

/**
 * @Description: es查询赛事数据
 * @Author: Daxie
 * @Date: 2020/10/25 17:46
 * @LastEditTime: 2020/10/25 17:46
 * @LastEditors: Daxie
 */
func EsMatchList(param EsMatchListParam) (map[string][]EsMatches, error) {

	data := map[string][]EsMatches{}

	//queryString 查询语句组装
	for k, v := range DataSourceName {

		if k == 0 {
			continue
		}

		searchIDX := fmt.Sprintf("data_source:%d game_id:%d start_time:%d idx:%s %s", k, param.GameID, helper.StrToTime(param.StartTime).Unix(), param.TournamentName, param.TeamName)
		key := EsPrefix + fmt.Sprintf(MatchIndex, k)
		//查询数据
		results, err := QueryStringSearch(key, searchIDX, "", 0, 5)
		if err != nil {
			return data, err
		}

		if results.TotalHits() > 0 {
			for _, item := range results.Each(reflect.TypeOf(data)) {
				if _, ok := item.(EsMatches); ok {
					data[v] = append(data[v], item.(EsMatches))
				}
			}
		}
	}

	return data, nil
}

func MatchLiveData(param MatchLiveParam) error {

	channelName := abios.AbiosGameChannel[param.GameID]
	fmt.Println(channelName)
	//return BeansPutLiveSubTask(channelName, param.MatchID)
	return nil
}

var abiosGameMapping = map[int64]string{
	1:  "257289795134339",
	2:  "257154660915053",
	5:  "257578064923863",
	14: "257561197207055",
}

var oddsGameMapping = map[int64]string{
	3286: "257578064923863",
	3296: "257289795134339",
	3280: "257154660915053",
	3319: "257561197207055",
}

// 处理es数据
func HandleEsMatches(match *Matches) EsMatches {

	esMatch := EsMatches{
		ID:             match.ID,
		DataSource:     match.DataSource,
		TournamentID:   match.TournamentID,
		TournamentName: match.TournamentName,
		TeamID:         match.TeamID,
		TeamName:       match.TeamName,
		Bo:             match.Bo,
		Tier:           match.Tier,
		StartTime:      match.StartTime,
		EndTime:        match.EndTime,
		Score:          match.Score,
		TargetID:       match.TargetID,
		IDX:            fmt.Sprintf("%s %s", match.TournamentName, match.TeamName),
	}

	// 将数据源游戏ID转化为本平台游戏ID
	switch match.DataSource {
	case 1:
		esMatch.GameID = abiosGameMapping[match.GameID]
	case 2:
		esMatch.GameID = oddsGameMapping[match.GameID]
	}
	return esMatch
}

func HandleEsMatchTeams(matchID, teamID, teamName string) []EsMatchTeams {

	teamIDs := strings.Split(teamID, ",")
	teamNames := strings.Split(teamName, ",")

	if len(teamIDs) < 2 || len(teamNames) < 2 {
		return nil
	}

	var data []EsMatchTeams
	for i, _ := range teamNames {
		data = append(data, EsMatchTeams{ID: fmt.Sprintf("%s%s", matchID, teamID), MatchID: matchID, TeamID: teamIDs[i], TeamName: teamNames[i]})
	}

	return data
}

func MatchRelatedFindOne(ex g.Ex) (MatchRelated, error) {

	data := MatchRelated{}
	dialect := g.Dialect("mysql")
	query, _, _ := dialect.From("tbl_match_related").Where(ex).Limit(1).ToSQL()
	fmt.Println(query)
	err := TradeDd.Get(&data, query)
	if err == sql.ErrNoRows {
		return data, nil
	}

	return data, err
}

func TradeMatchFindOne(ex g.Ex) (TradeMatch, error) {

	data := TradeMatch{}
	dialect := g.Dialect("mysql")
	query, _, _ := dialect.From("tbl_matches").Where(ex).Select(mchColumns...).Limit(1).ToSQL()
	fmt.Println(query)
	err := TradeDd.Get(&data, query)
	if err == sql.ErrNoRows {
		return data, nil
	}

	return data, err
}

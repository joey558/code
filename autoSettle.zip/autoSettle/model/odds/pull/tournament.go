package pull

import (
	"autoSettle/helper"
	"autoSettle/model"
	"fmt"
	g "github.com/doug-martin/goqu/v9"
	"github.com/go-redis/redis/v7"
	"time"
)

type Tournament struct {
	ID         int64  `json:"Id"`         // 联赛ID
	Name       string `json:"Name"`       // 赛事名称
	CategoryID int64  `json:"CategoryId"` // 游戏ID
}

func TournamentsSave(data []*Tournament) {

	for _, tm := range data {
		tournament, err := tournamentHelperFormat(tm)
		if err != nil {
			fmt.Println("odds 数据源联赛数据格式化错误：", err)
			continue
		}

		tmtID, err := model.Pool.Get(fmt.Sprintf(model.RedisKeyTournamentFusion, model.ODDS, tournament.TargetID)).Result()
		if err == redis.Nil {  // 数据源联赛不存在则新增联赛，忽略redis nil error
			err = model.TournamentInsert(tournament)
			if err != nil {
				fmt.Println("odds 新增联赛数据错误：", err)
			}
			continue
		}

		if err != nil {
			fmt.Println("odds 获取数据源联赛关联联赛ID错误:", err)
			continue
		}

		// 更新联赛数据
		if tmtID != "" {
			v := g.Record{
				"game_id":     tournament.GameID,
				"name":        tournament.Name,
				"short_name":  tournament.ShortName,
				"update_time": time.Now().Unix(),
			}
			err = model.TournamentUpdate(v, g.Ex{"id": tmtID})
			if err != nil {
				fmt.Println("odds 修改联赛数据错误：", err)
				continue
			}
		}
	}
}

func tournamentHelperFormat(datum *Tournament) (*model.Tournament, error) {
	tournament := &model.Tournament{
		ID:         fmt.Sprintf("%d", helper.Cputicks()),
		GameID:     fmt.Sprintf("%d", datum.CategoryID),
		Name:       datum.Name,
		ShortName:  datum.Name,
		CnName:     "",
		CreateTime: time.Now().Unix(),
		UpdateTime: time.Now().Unix(),
		DataSource: model.ODDS,
	}

	if datum.ID > 0 {
		tournament.TargetID = datum.ID
	}

	return tournament, nil
}

package pull

import (
	"autoSettle/helper"
	"autoSettle/model"
	"fmt"
	g "github.com/doug-martin/goqu/v9"
	"github.com/go-redis/redis/v7"
	"time"
)

type Game struct {
	ID           int64         `json:"Id"`           // 游戏ID
	CategoryName string        `json:"CategoryName"` // 游戏名称(Dota 2)
	SportID      int64         `json:"SportId"`      // 运动Id
	Tournaments  []*Tournament `json:"Tournaments"`  // 联赛
}

func LeagueConn(isUpdate bool) {
	url := "https://api.odds.gg/Leagues/Categories"
	req := map[string]interface{}{
		"categoryIds": []int{
			3296, //DOTA2
			3280, //LoL
			3286, //CS:GO
			3319, //KoG
			//3320, //FIFA
			//3307, //StarCraft 2
			//3315, //Warcraft 3
		},
	}
	var leagues []*Game
	err := publicPostFastHttpHelper(url, isUpdate, req, &leagues, defaultTimeout)
	if err != nil {
		fmt.Println("odds 数据源游戏数据拉取错误：", err)
		return
	}

	for _, league := range leagues {
		game, err := gamesHelperFormat(league)
		if err != nil {
			fmt.Println("odds 数据源游戏数据格式化错误：", err)
			continue
		}

		gmID, err := model.Pool.Get(fmt.Sprintf(model.RedisKeyGameFusion, model.ODDS, game.TargetID)).Result()
		if err == redis.Nil {  // 数据源游戏不存在则新增游戏，忽略redis nil error
			err = model.GameInsert(game)
			if err != nil {
				fmt.Println("odds 新增游戏数据错误：", err)
			}
			continue
		}

		if err != nil {
			fmt.Println("odds 获取数据源游戏关联游戏ID错误:", err)
			continue
		}

		if gmID != "" {
			v := g.Record{
				"name":        game.Name,
				"short_name":  game.ShortName,
				"update_time": time.Now().Unix(),
			}
			err = model.GameUpdate(v, g.Ex{"id": gmID})
			if err != nil {
				fmt.Println("odds 修改游戏数据错误：", err)
				continue
			}
		}

		TournamentsSave(league.Tournaments)

	}
}

func gamesHelperFormat(datum *Game) (*model.Game, error) {
	game := &model.Game{
		ID:         fmt.Sprintf("%d", helper.Cputicks()),
		Name:       datum.CategoryName,
		ShortName:  datum.CategoryName,
		CnName:     "",
		CreateTime: time.Now().Unix(),
		UpdateTime: time.Now().Unix(),
		DataSource: model.ODDS,
	}

	if datum.ID > 0 {
		game.TargetID = datum.ID
	}

	return game, nil
}

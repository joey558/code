package pull

import (
	"autoSettle/helper"
	"fmt"
	"github.com/valyala/fasthttp"
	"net/http"
	"strconv"
	"time"
)

var (
	apiKey                = "f91780ba-880a-4063-8104-2a6bd4731cb6"
	defaultTimeout        = 180 * time.Second
	errStatusNoOK         = fmt.Errorf("未正确获取信息")
	RFC3339DateTimeFormat = "2006-01-02T15:04:05"
)

func publicGetFastHttpHelper(url string, isUpdate bool, resp interface{}, timeOut time.Duration) error {
	headers := map[string]string{
		"Api-Key":  apiKey,
		"isUpdate": strconv.FormatBool(isUpdate),
		"Accept":   "application/json",
	}
	data, status, err := helper.HttpDoTimeout(nil, fasthttp.MethodGet, url, headers, timeOut)
	if err != nil {
		return err
	}
	if status != http.StatusOK {
		return errStatusNoOK
	}

	err = helper.JsonUnmarshal(data, &resp)
	if err != nil {
		return err
	}
	return nil
}

func publicPostFastHttpHelper(url string, isUpdate bool, req, resp interface{}, timeOut time.Duration) error {
	headers := map[string]string{
		"Api-Key":      apiKey,
		"isUpdate":     strconv.FormatBool(isUpdate),
		"Accept":       "application/json",
		"Content-Type": "application/json",
	}
	requestBody, err := helper.JsonMarshal(req)
	if err != nil {
		return err
	}
	data, status, err := helper.HttpDoTimeout(requestBody, fasthttp.MethodPost, url, headers, timeOut)
	if err != nil {
		return err
	}
	if status != http.StatusOK {
		return errStatusNoOK
	}

	err = helper.JsonUnmarshal(data, &resp)
	if err != nil {
		return err
	}
	return nil
}

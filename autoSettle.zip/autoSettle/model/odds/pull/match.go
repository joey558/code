package pull

import (
	"autoSettle/helper"
	"autoSettle/model"
	"fmt"
	g "github.com/doug-martin/goqu/v9"
	"github.com/go-redis/redis/v7"
	"strconv"
	"time"
)

// odds比赛
type Match struct {
	ID           int64       `json:"Id"`
	SportID      int64       `json:"SportId"`      // 运动ID
	TournamentID int64       `json:"TournamentId"` // 比赛ID
	HomeTeamId   interface{} `json:"HomeTeamId"`   // 主场队伍ID (如果是直接匹配，则为null。)
	HomeTeamName interface{} `json:"HomeTeamName"` // 主场队伍名称
	AwayTeamId   interface{} `json:"AwayTeamId"`   // 客场队伍ID (如果是直接匹配，则为null。)
	AwayTeamName interface{} `json:"AwayTeamName"` // 客场队伍名称
	Score        string      `json:"Score"`        // 分数(如果比赛是实时的，分数将随着比赛的进展而更新。)
	Status       int         `json:"Status"`       // 状态 0 = NotStarted, 1 = InPlay, 2 = Finished, 3 = Canceled
	StreamUrl    string      `json:"StreamUrl"`    // 直播流地址
	Visible      bool        `json:"Visible"`      // 是否可见(true 可见,用户可以下注 ,false 前端不可见 或 不允许下注)
	Suspended    bool        `json:"Suspended"`    // 暂停 (如果为 true ,则用户不能下注)
	OutrightName interface{} `json:"OutrightName"` // 胜出队伍
	StartTime    string      `json:"StartTime"`    // 比赛的开始时间 (组织者有可能会改变此时间)
	EndTime      interface{} `json:"EndTime"`      // 如果 type 是 outright 则必须有一个结束时间, 之后不允许下注
	Type         int         `json:"Type"`         // 1 = PreMatch, 2 = Live, 3 = OutRight
}

// odds比赛状态与我们平台比赛状态映射关系
var oddsMatchStatusForm = map[int]int{
	0: 3, //NotStarted 未开始0-待开盘3
	1: 4, //InPlay 比赛中1-已开盘4
	2: 5, //Finished 已结束2-已关盘5
	3: 9, //Canceled 已取消3-比赛取消9
}

func MatchConn(isUpdate bool) {
	url := "https://api.odds.gg/Matches/Categories"
	req := map[string]interface{}{
		"categoryIds": []int{
			3296, //DOTA2
			3280, //LoL
			3286, //CS:GO
			3319, //KoG
			//3320, //FIFA
			//3307, //StarCraft 2
			//3315, //Warcraft 3
		},
	}
	var matches []*Match
	err := publicPostFastHttpHelper(url, isUpdate, req, &matches, defaultTimeout)
	if err != nil {
		fmt.Println("odds 数据源比赛数据拉取错误：", err)
		return
	}

	for _, v := range matches {
		mch, err := matchHelperFormat(v)
		if err != nil {
			fmt.Println("odds 数据源比赛数据格式化错误：", err)
			continue
		}

		if mch == nil {
			fmt.Println("format match is nil")
			continue
		}

		mchID, err := model.Pool.Get(fmt.Sprintf(model.RedisKeyMatchFusion, model.ODDS, mch.TargetID)).Result()
		if err == redis.Nil {  // 数据源比赛不存在则新增比赛，忽略redis nil error
			mch.ID = fmt.Sprintf("%d", helper.Cputicks())
			err = model.MatchesInsert(mch)
			if err != nil {
				fmt.Println("odds 新增比赛数据错误：", err)
				continue
			}
		}

		if err != nil {
			fmt.Println("odds 获取数据源比赛关联比赛ID错误:", err)
			continue
		}

		if mchID != "" {
			record := g.Record{
				"title":           mch.Title,
				"game_id":         mch.GameID,
				"tournament_id":   mch.TournamentID,
				"tournament_name": mch.TournamentName,
				"team_id":         mch.TeamID,
				"team_name":       mch.TeamName,
				"score":           mch.Score,
				"start_time":      mch.StartTime,
				"end_time":        mch.EndTime,
				"updated_at":      mch.UpdatedAt,
			}
			err = model.MatchesUpdate(g.Ex{"id": mchID}, record)
			if err != nil {
				fmt.Printf("odds赛事更新失败:%s \n", err)
				continue
			}

			mch.ID = mchID
		}

		esMatch := model.HandleEsMatches(mch)

		// es索引检查
		index := model.EsPrefix + fmt.Sprintf(model.MatchIndex, model.ODDS)
		err = model.CreateIndex(index, model.AutoSettleMatchData)
		if err != nil {
			fmt.Printf("索引创建失败:%s \n", err)
			continue
		}

		// es 数据写入
		err = model.UpdateData(index, esMatch.ID, esMatch)
		if err != nil {
			fmt.Printf("es数据写入失败:%s \n", err)
		}

		// 将比赛比赛写入es，用于赛事模糊匹配
		//err = model.CreateIndex(model.EsPrefix + model.MatchTeamIndex, model.AutoSettleMatchTeamData)
		//if err != nil {
		//	fmt.Printf("比赛比赛索引创建失败:%s \n", err)
		//}
		//
		//esMatchTeams := model.HandleEsMatchTeams(mchID, mch.TeamID, mch.TeamName)
		//// es 数据写入
		//for _, v := range esMatchTeams {
		//	err = model.UpdateData(model.EsPrefix + model.MatchTeamIndex, fmt.Sprintf("%d-%s", mch.TargetID, strings.ReplaceAll(mch.TeamID, ",", "-")), v)
		//	if err != nil {
		//		fmt.Printf("es比赛比赛数据写入失败:%s \n", err)
		//	}
		//}
	}
}

func matchHelperFormat(datum *Match) (*model.Matches, error) {
	match := &model.Matches{
		TournamentID: datum.TournamentID, // 联赛id
		Score:        datum.Score,        // 比赛比分
		TargetID:     datum.ID,           // 数据源id
		DataSource:   model.ODDS,        // 数据源
		CreatedAt:    time.Now().Unix(),
		UpdatedAt:    time.Now().Unix(),
	}

	// 赛事标题(完整名称)
	if datum.OutrightName != nil {
		match.Title = datum.OutrightName.(string)
	}

	sGmID, err := model.Pool.Get(fmt.Sprintf(model.RedisKeyOddTournamentGameID, datum.TournamentID)).Result()
	if err != nil {
		fmt.Println(err)
		return nil, err
	}

	match.GameID, err = strconv.ParseInt(sGmID, 10, 64)
	if err != nil {
		fmt.Println(err)
		return nil, err
	}

	// 联赛名称获取
	key := fmt.Sprintf(model.RedisKeyTournamentName, match.DataSource, match.TournamentID)
	tournamentName, err := model.Pool.Get(key).Result()
	if err != nil {
		match.TournamentName = ""
	} else {
		match.TournamentName = tournamentName
	}

	// 转换比赛开始时间
	if datum.StartTime != "" {
		s, err := time.Parse(RFC3339DateTimeFormat, datum.StartTime)
		if err != nil {
			fmt.Println("MatchHelperFormat time parse err :", datum.StartTime)
			return nil, err
		}
		//s = s.Add(8 * time.Hour)
		match.StartTime = s.Unix()
	}

	// 转换比赛结束时间
	if datum.EndTime != nil {
		if endTime, ok := datum.EndTime.(string); ok {
			s, err := time.Parse(RFC3339DateTimeFormat, endTime)
			if err != nil {
				fmt.Println("MatchHelperFormat time parse err :", endTime)
				return nil, err
			}
			s = s.Add(8 * time.Hour)
			match.EndTime = s.Unix()
		}
	}

	// 转换比赛比赛ID
	if datum.HomeTeamId != nil && datum.AwayTeamId != nil {
		match.TeamID = fmt.Sprintf("%d,%d", int(datum.HomeTeamId.(float64)), int(datum.AwayTeamId.(float64)))
	}

	// 转换比赛比赛名
	if datum.HomeTeamName != nil && datum.AwayTeamName != nil {
		match.TeamName = fmt.Sprintf("%s,%s", datum.HomeTeamName.(string), datum.AwayTeamName.(string))
	}

	return match, nil
}

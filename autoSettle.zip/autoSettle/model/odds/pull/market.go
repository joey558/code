package pull

import (
	"autoSettle/calc"
	"autoSettle/helper"
	"autoSettle/model"
	"fmt"
	g "github.com/doug-martin/goqu/v9"
	"regexp"
	"strconv"
	"strings"
	"time"
)

// 盘口
type Market struct {
	ID        int64  `json:"Id"`        // 比赛ID
	MatchID   int64  `json:"MatchId"`   // 比赛ID
	Name      string `json:"Name"`      // 场次名称
	IsLive    bool   `json:"IsLive"`    // 是否直播 true 直播 , false 非直播(prematch)
	Status    int    `json:"Status"`    // 状态 0 = Active, 1 = Suspended, 2 = Canceled, 3 = Resulted
	Visible   bool   `json:"Visible"`   // 是否可见 (true 可见,用户可以下注 ,false 前端不可见 或 不允许下注)
	Suspended bool   `json:"Suspended"` // 暂停 (如果为 true ,则用户不能下注)
	Odds      []*Odd `json:"Odds"`
}

var marketVisibleValue = map[bool]int8{
	false: 0,
	true:  1,
}

var marketSuspendedValue = map[bool]int8{
	false: 0,
	true:  1,
}

var mktNameMapping = map[string]string{
	"获胜":     "Match Winner",      //全局获胜
	"地图让分":   "Map Advantage",     //全局地图让分
	"地图总数大小": "Total Maps Played", //全局地图总数大小
	"胜平负": "",
	"正确地图比分": "Correct Score",     //全局波胆

	// ----------CSGO特有盘口----------
	"回合总数大小":      "Total Rounds (Map %d)",            //单局回合总数大小
	"回合让分":        "Round Advantage (Map %d)",         //单局回合让分
	"第一手枪局获胜":     "1st Pistol Round Winner (Map %d)", //单局第一手枪局获胜
	"第二手枪局获胜":     "2nd Pistol Round Winner (Map %d)", //单局第二手枪局获胜
	"@T1&nbsp;队伍回合总数大小": "[HomeTeam] Total Rounds (Map %d)", //单局主队回合总数大小
	"@T2&nbsp;队伍回合总数大小": "[AwayTeam] Total Rounds (Map %d)", //单局客队回合总数大小
	"回合总数单双":      "Odd/Even Rounds (Map %d)",         //单局回合总数单双

	// ----------MOBA 通用盘口----------
	"获胜者":             "Winner Map %d",            //单局获胜者
	"击杀让分":            "Kills Advantage (Map %d)", //单局击杀让分
	"击杀总数大小":          "Total Kills (Map %d)",
	"@T1&nbsp;击杀总数大小": "[HomeTeam] Total Kills (Map %d)", //单局主队击杀总数大小
	"@T2&nbsp;击杀总数大小": "[AwayTeam] Total Kills (Map %d)", //单局客队击杀总数大小
	"比赛时间大小":          "Total Time (Map %d)",             //单局比赛时间大小
	"击杀总数单双":          "Odd / Even Kills (Map %d)",       //单局击杀总数单双
	"第一滴血":            "First Blood (Map %d)",            //单局第一滴血
	"首先获得五杀":"First to 5 Kills (Map %d)",
	"首先获得十杀":          "First to 10 Kills (Map %d)",      //单局首先获得十杀
	"摧毁首座防御塔":  "Destroy First Tower (Map %d)",     //单局摧毁首座防御塔
	"摧毁防御塔总数大小":"Total Towers Destroyed (Map %d)",
	//"摧毁防御塔总数单双":"",

	// ----------LoL特有盘口----------
	"摧毁首座水晶": "Destroy First Inhibitor (Map %d)",
	"击杀元素巨龙总数大小":"Total Elemental Dragons Slain (Map %d)",
	"击杀首条元素巨龙":"Kill First Dragon (Map %d)",
	"首条元素巨龙属性":"First Elemental Dragon (Map %d)",
	"击杀首条纳什男爵":"Kill First Baron (Map %d)",
	"击杀纳什男爵总数大小":"Total Barons Slain (Map %d)",
	"击杀首条峡谷先锋":"Kill First Rift Herald (Map %d)",


	// ----------Dota2特有盘口----------
	"摧毁首座兵营":   "Destroy First Barracks (Map %d)", //单局摧毁首座兵营
	"击杀首个肉山":   "Kill First Roshan (Map %d)",       //单局击杀首个肉山
	"击杀肉山总数大小": "Total Roshans Slain (Map %d)",     //单局击杀肉山总数大小
}

// 玩法类型 1-输赢 2-让分 3-大小 4趣味 5-波胆 6-胜负平 7-单双 8-是否 9-复合
var optionTypeMapping = map[string]int8{
	"Winner":        1,
	"Advantage":     2,
	"Total":         3,
	"Correct Score": 5,
	"Odd / Even":    7,
}

func MarketOfMatchesConn(isUpdate bool, matchID int64) {

	url := "https://api.odds.gg/Markets/Matches"
	req := map[string]interface{}{
		"matchIds": []int64{matchID},
	}
	var markets []*Market
	err := publicPostFastHttpHelper(url, isUpdate, req, &markets, defaultTimeout)
	if err != nil {
		fmt.Println(err)
		return
	}

	var mkts []*model.Market
	for _, v := range markets {
		mkt, err := marketHelperFormat(v)
		if err != nil {
			fmt.Println(err)
			continue
		}

		if mkt == nil {
			fmt.Println("format match is nil")
			continue
		}

		mkts = append(mkts, mkt)
	}
}

func OddsMarketResult(relatedMch model.MatchRelated, tradeMatch model.TradeMatch, marketID string) (string, string, error) {

	mkt, odds, err := calc.HandicapMarketInfo(model.TraderPoolSlave, fmt.Sprintf("%d", relatedMch.MatchID), marketID)
	if err != nil {
		return "", "", err
	}

	if mkt.CnName == "" {
		return "", "", fmt.Errorf("盘口英文名为空，无法匹配数据源盘口")
	}

	if len(odds) == 0 {
		return "", "", fmt.Errorf("盘口投注项信息为空")
	}

	oddsMktName := mktNameMapping[strings.ReplaceAll(mkt.CnName, "\"", "")]
	if mkt.Round > 0 {
		oddsMktName = fmt.Sprintf(oddsMktName, mkt.Round)
	}

	if oddsMktName == "" {
		return "", "", fmt.Errorf("该盘口暂时无法自动结算")
	}

	//oddsMktName = strings.ToUpper(oddsMktName)

	url := "https://api.odds.gg/Markets/Matches"
	req := map[string]interface{}{
		"matchIds": []int64{relatedMch.SourceMatchID},
	}
	var markets []*Market
	err = publicPostFastHttpHelper(url, false, req, &markets, defaultTimeout)
	if err != nil {
		return "", "", err
	}

	if len(markets) == 0 {
		return "", "", fmt.Errorf("未获取到数据源比赛盘口数据，odds比赛ID:%d", relatedMch.SourceMatchID)
	}

	// 数据源比赛信息
	mch, err := model.MatchesFindOne(g.Ex{"target_id": relatedMch.SourceMatchID, "data_source": model.ODDS})
	if err != nil {
		return "", "", err
	}

	sourceTeams := strings.Split(mch.TeamName, ",")
	if len(sourceTeams) < 2 {
		return "", "", fmt.Errorf("数据源比赛战队信息不足, 无法自动结算")
	}
	mpSourceTeam := map[string]string{
		"1": sourceTeams[0],
		"2": sourceTeams[1],
	}

	teamNames := strings.Split(tradeMatch.MatchTeam, ",")
	if len(teamNames) < 2 {
		return "", "", fmt.Errorf("比赛战队数少于2, 无法自动结算")
	}

	// 本平台比赛战队与数据源比赛战队映射关系
	mpTeam := map[string]string{
		"1": teamNames[0],
		"2": teamNames[1],
	}

	// 主客队顺序与数据源是否一致，不一致需要调换主客队顺序
	if relatedMch.DiffSorted == 0 {
		mpTeam["1"] = teamNames[1]
		mpTeam["2"] = teamNames[0]
		if strings.Contains(oddsMktName, "[HomeTeam]") {
			oddsMktName = strings.Replace(oddsMktName, "[HomeTeam]", "[AwayTeam]", 1)
		} else if strings.Contains(oddsMktName, "[AwayTeam]") {
			oddsMktName = strings.Replace(oddsMktName, "[AwayTeam]", "[HomeTeam]", 1)
		}
	}

	var (
		winOddID   string
		winOddName string
	)
	for _, v := range markets {
		if v.Name != oddsMktName {
			continue
		}

		for _, o := range v.Odds {
			// 忽略不是获胜状态的投注项
			if o.Status != OddStatusWin {
				continue
			}

			//玩法类型 1-输赢 2-让分 3-大小 4趣味 5-波胆 6-胜负平 7-单双 8-是否 9-复合
			switch mkt.OptionType {
			case 1:
				winOddName = mpTeam[o.Name]
			case 2:
				// 检查让分盘获胜投注项中的战队名
				//if teamSorted {
				//	if o.Name == "1" {
				//		winOddName = strings.Replace(o.Title, mpTeam[o.Name]+" ", "@T1&nbsp;", 1)
				//	} else {
				//		winOddName = strings.Replace(o.Title, mpTeam[o.Name]+" ", "@T2&nbsp;", 1)
				//	}
				//} else {
				//	if o.Name == "1" {
				//		winOddName = strings.Replace(o.Title, mpTeam[o.Name]+" ", "@T2&nbsp;", 1)
				//	} else {
				//		winOddName = strings.Replace(o.Title, mpTeam[o.Name]+" ", "@T1&nbsp;", 1)
				//	}
				//}
				var replaceStr string
				if mpTeam[o.Name] == teamNames[0] {
					replaceStr = "@T1&nbsp;"
				} else if mpTeam[o.Name] == teamNames[1] {
					replaceStr = "@T2&nbsp;"
				}
				winOddName = strings.Replace(o.Title, mpSourceTeam[o.Name]+" ", replaceStr, 1)

			case 3:
				winOddName = strings.Replace(o.Title, o.Name+" ", oddMapping[o.Name], 1)
			case 4: //趣味玩法的盘口，每个都需要单独处理
				// 趣味-单双
				if o.Name == "Odd" || o.Name == "Even" {
					winOddName = strings.ReplaceAll(o.Title, o.Name, oddMapping[o.Name])
				}
				// 趣味-首条元素巨龙属性
				if o.Name == "Infernal Dragon" || o.Name == "Mountain Dragon" || o.Name == "Ocean Dragon" || o.Name == "Cloud Dragon"  {
					winOddName = oddMapping[o.Name]
				}
			case 5:
				// 战队
				if relatedMch.DiffSorted == 1 {
					winOddName = strings.ReplaceAll(o.Name, ":", "-")
				} else {
					oNames := strings.Split(o.Name, ":")
					winOddName = oNames[1] + "-" + oNames[0]
				}

			case 6:
			case 7:
				winOddName = strings.ReplaceAll(o.Title, o.Name, oddMapping[o.Name])
			}
			for _, od := range odds {
				if od.Name == winOddName {
					winOddID = od.ID
					break
				}
			}
			if winOddID != "" {
				return winOddID, winOddName, nil
			}
		}
	}

	if winOddName == "" {
		return "", "", fmt.Errorf("数据源无该盘口数据")
	}

	if winOddID == "" {
		return "", "", fmt.Errorf("获胜投注项[%s]不存在", winOddName)
	}

	return winOddID, winOddName, nil
}

func marketHelperFormat(datum *Market) (*model.Market, error) {
	market := &model.Market{
		ID:         fmt.Sprintf("%d", helper.Cputicks()),
		MatchID:    fmt.Sprintf("%d", datum.MatchID),
		EnName:     datum.Name,
		CnName:     "",
		Visible:    marketVisibleValue[datum.Visible],
		Suspended:  marketSuspendedValue[datum.Suspended],
		CreateTime: time.Now().Unix(),
		UpdateTime: time.Now().Unix(),
		DataSource: model.ODDS,
	}

	if datum.ID > 0 {
		market.TargetID = datum.ID
	}

	for k, v := range optionTypeMapping {
		if strings.Contains(datum.Name, k) {
			market.OptionType = v
			break
		}
	}

	// 判断盘口是全局还是单局
	rgx := regexp.MustCompile(`\((Map\s[1-9][0-9]?)\)`)
	if rgx == nil { //解释失败，默认为全局盘口
		market.Round = 0
	} else {
		mktMark := rgx.FindStringSubmatch(datum.Name)[1]
		round, err := strconv.Atoi(strings.Split(mktMark, " ")[1])
		if err != nil {
			return market, nil
		}

		market.Round = int8(round)
	}

	return market, nil
}

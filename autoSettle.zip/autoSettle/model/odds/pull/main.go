package pull

import (
	"time"
)

func OddsAutoPull()  {

	// 联赛 每10分钟更新一次
	go func() {
		for {
			LeagueConn(false)
			time.Sleep(10 * time.Minute)
		}
	}()

	// 比赛 每2分钟更新一次
	go func() {
		for  {
			MatchConn(false)
			time.Sleep(2 * time.Minute)
		}
	}()
}
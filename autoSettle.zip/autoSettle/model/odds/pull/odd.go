package pull

import (
	"autoSettle/helper"
	"autoSettle/model"
	"fmt"
	g "github.com/doug-martin/goqu/v9"
	"github.com/go-redis/redis/v7"
	"time"
)

const (
	OddStatusNotResulted = 0 //
	OddStatusWin         = 1
	OddStatusLoss        = 2
	OddStatusHalfWin     = 3
	OddStatusHalfLoss    = 4
	OddStatusRefund      = 5
	OddStatusCanceled    = 6
)

// 赔率
type Odd struct {
	ID              int64       `json:"Id"`
	MatchID         int64       `json:"MatchId"`         // 比赛ID
	MarketID        int64       `json:"MarketId"`        // 盘口ID
	Name            string      `json:"Name"`            // 队名
	Title           string      `json:"Title"`           // 标题(包含让分)
	Value           float64     `json:"Value"`           // 赔率值
	Status          int         `json:"Status"`          // 0 = NotResulted, 1 = Win, 2 = Loss, 3 = HalfWin, 4 = HalfLoss, 5 = Refund, 6 = Canceled
	Visible         bool        `json:"Visible"`         // 是否可见(true 可见,用户可以下注 ,false 前端不可见 或 不允许下注)
	Suspended       bool        `json:"Suspended"`       // 暂停 (如果为 true ,则用户不能下注)
	SpecialBetValue interface{} `json:"SpecialBetValue"` // 让分 如果此属性中有值，您可以使用它来按其分组赔率。通常它包括在标题中。它可以动态更改(标题也会更改)。
	Rank            interface{} `json:"Rank"`            // 排名
}

var oddMapping = map[string]string{
	"Over":            "大于&gt;",
	"Under":           "小于&lt;",
	"Odd":             "单",
	"Even":            "双",
	"Infernal Dragon": "火",
	"Mountain Dragon": "土",
	"Ocean Dragon":    "水",
	"Cloud Dragon":    "风",
}

var oddVisibleValue = map[bool]int{
	false: 0,
	true:  1,
}

func OddSave(data []*Odd, round int) {

	for _, v := range data {
		odd, err := oddHelperFormat(v)
		if err != nil {
			fmt.Println("odds 数据源投注项数据格式化错误：", err)
			continue
		}

		if odd == nil {
			fmt.Println("format odd is nil")
			continue
		}

		oddID, err := model.Pool.Get(fmt.Sprintf(model.RedisKeyOddFusion, model.ODDS, odd.TargetID)).Result()
		if err == redis.Nil { // 数据源投注项不存在则新增投注项，忽略redis nil error
			err = model.OddInsert(odd)
			if err != nil {
				fmt.Println("odds 新增投注项数据错误：", err)
			}
			continue
		}

		if err != nil {
			fmt.Println("odds 获取数据源投注项关联投注项ID错误:", err)
			continue
		}

		// 更新投注项数据
		if oddID != "" {
			record := g.Record{
				"name":        odd.Name,
				"odd":         odd.Odd,
				"round":       odd.Round,
				"is_winner":   odd.IsWinner,
				"update_time": time.Now().Unix(),
			}
			err = model.OddUpdate(record, g.Ex{"id": oddID})
			if err != nil {
				fmt.Printf("odds 投注项更新失败:%s \n", err)
				continue
			}
		}
	}
}

func oddHelperFormat(datum *Odd) (*model.Odd, error) {
	odd := &model.Odd{
		ID:         fmt.Sprintf("%d", helper.Cputicks()),
		MatchID:    fmt.Sprintf("%d", datum.MatchID),
		MarketID:   fmt.Sprintf("%d", datum.MarketID),
		Name:       datum.Name,
		Odd:        fmt.Sprintf("%f", datum.Value),
		Visible:    oddVisibleValue[datum.Visible],
		DataSource: model.ODDS,
	}

	if datum.ID > 0 {
		odd.TargetID = datum.ID
	}

	switch datum.Status {
	case OddStatusWin:
		odd.IsWinner = 1
	case OddStatusLoss:
		odd.IsWinner = 0
	}

	return odd, nil
}

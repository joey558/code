package model

import (
	//odds "autoSettle/model/odds/pull"
	"database/sql"
	"fmt"
	g "github.com/doug-martin/goqu/v9"
	"github.com/go-redis/redis/v7"
)

type Market struct {
	ID         string `json:"id" db:"id"`
	MatchID    string `json:"match_id" db:"match_id"`
	OddTypeID  string `json:"odd_type_id" db:"odd_type_id"`
	EnName     string `json:"en_name" db:"en_name"`
	CnName     string `json:"cn_name" db:"cn_name"`
	Remark     string `json:"remark" db:"remark"`
	Round      int8   `json:"round" db:"round"`
	OptionType int8   `json:"option_type" db:"option_type"`
	Suspended  int8   `json:"suspended" db:"suspended"`
	Visible    int8   `json:"visible" db:"visible"`
	CreateTime int64  `json:"create_time" db:"create_time"`
	UpdateTime int64  `json:"update_time" db:"update_time"`
	TargetID   int64  `db:"target_id" json:"target_id"`     // 数据源id
	DataSource int    `db:"data_source" json:"data_source"` // 数据源
}

// 数据源盘口赛果确认表
type MarketResultConfirm struct {
	ID          uint64 `db:"id" json:"id"`
	MatchID     string `db:"match_id" json:"match_id"`
	MarketID    string `db:"market_id" json:"market_id"`
	Status      int    `db:"status" json:"status"`
	WinOddID    string `db:"win_odd_id" json:"win_odd_id"`
	WinOddName  string `db:"win_odd_name" json:"win_odd_name"`
	DataSource  int    `db:"data_source" json:"data_source"`
	ConfirmTime int64  `db:"confirm_time" json:"confirm_time"`
	Remark      string `db:"remark" json:"remark"`
}

func MarketPullSave(mkts []*Market) {

	for _, v := range mkts {

		mktID, err := Pool.Get(fmt.Sprintf(RedisKeyMarketFusion, ODDS, v.TargetID)).Result()
		if err != nil {
			// 数据源比赛不存在则新增
			if err == redis.Nil {
				err = MarketInsert(v)
				if err != nil {
					fmt.Println(err)
				}
				continue
			}
			fmt.Println(err)
			continue
		}

		if mktID != "" {
			record := g.Record{
				"match_id":    v.MatchID,
				"en_name":     v.EnName,
				"round":       v.Round,
				"option_type": v.OptionType,
				"suspended":   v.Suspended,
				"visible":     v.Visible,
			}
			err = MarketUpdate(record, g.Ex{"id": mktID})
			if err != nil {
				fmt.Printf("盘口更新失败:%s \n", err)
			}
		}
	}
}

/**
 * @Description: 新增盘口
 * @Author: awen
 * @Date: 2020/11/06 16:38
 * @LastEditTime: 2020/11/06 16:38
 * @LastEditors: awen
 */
func MarketInsert(data *Market) error {

	// 开启事务
	dbConn, err := Db.Begin()
	if err != nil {
		return err
	}
	// 写入数据库
	dialect := g.Dialect("mysql")
	query, _, _ := dialect.Insert("tbl_market").Rows(data).ToSQL()
	fmt.Println(query)
	_, err = dbConn.Exec(query)
	if err != nil {
		_ = dbConn.Rollback()
		return err
	}

	return dbConn.Commit()
}

/**
 * @Description: 修改盘口
 * @Author: awen
 * @Date: 2020/10/06 16:45
 * @LastEditTime: 2020/10/06 16:45
 * @LastEditors: awen
 */
func MarketUpdate(record g.Record, ex g.Ex) error {

	dialect := g.Dialect("mysql")
	query, _, _ := dialect.Update("tbl_market").Set(record).Where(ex).ToSQL()
	fmt.Println(query)
	_, err := Db.Exec(query)
	return err
}

/**
 * @Description: 根据条件从数据库获取一个盘口数据
 * @Author: wesley
 * @Date: 2020/6/23 11:28
 * @LastEditTime: 2020/6/23 11:28
 * @LastEditors: wesley
 */
func MarketFindOne(ex g.Ex) (Market, error) {

	data := Market{}
	query, _, _ := g.Dialect("mysql").From("tbl_markets").Where(ex).Limit(1).ToSQL()
	err := TradeDd.Get(&data, query)
	if err == sql.ErrNoRows {
		return data, nil
	}

	return data, err
}

/**
 * @Description: 根据条件从数据库获取一个盘口赛果
 * @Author: wesley
 * @Date: 2020/6/23 11:28
 * @LastEditTime: 2020/6/23 11:28
 * @LastEditors: wesley
 */
func MarketResultFindOne(ex g.Ex) (MarketResultConfirm, error) {

	data := MarketResultConfirm{}
	query, _, _ := g.Dialect("mysql").From("tbl_market_result_confirm").Where(ex).Limit(1).ToSQL()
	err := TradeDd.Get(&data, query)
	if err == sql.ErrNoRows {
		return data, nil
	}

	return data, err
}

/**
 * @Description: 新增盘口数据源赛果数据
 * @Author: awen
 * @Date: 2020/11/11 21:33
 * @LastEditTime: 2020/11/11 21:33
 * @LastEditors: awen
 */
func MarketResultInsert(data *MarketResultConfirm) error {
	// 写入数据库
	query, _, _ := g.Dialect("mysql").Insert("tbl_market_result_confirm").Rows(data).ToSQL()
	fmt.Println(query)
	_, err := TradeDd.Exec(query)

	return err
}

/**
 * @Description: 更新盘口数据源赛果数据
 * @Author: awen
 * @Date: 2020/11/11 21:36
 * @LastEditTime: 2020/11/11 21:36
 * @LastEditors: awen
 */
func MarketResultUpdate(record g.Record, ex g.Ex) error {
	// 写入数据库
	query, _, _ := g.Dialect("mysql").Update("tbl_market_result_confirm").Set(record).Where(ex).ToSQL()
	fmt.Println(query)
	_, err := TradeDd.Exec(query)
	return err
}

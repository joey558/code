package model

import (
	"fmt"
	"time"

	"github.com/beanstalkd/go-beanstalk"
)

const (
	BeanstalkLiveSubTube    = "sub_live_%d"
)

type BeansProducerAttr struct {
	Tube    string        //tube 名称
	Message string        //job body
	Delay   time.Duration //延迟ready的秒数
	TTR     time.Duration //允许worker执行的最大秒数
	PRI     uint32        //优先级
}

/**
 * @Description:追加结算任务
 * @Author: wesley
 * @Date: 2020/10/11 0:12
 * @LastEditTime: 2020/10/11 0:12
 * @LastEditors: wesley
 */
func BeansPutLiveSubTask(channel string, seriesID int) error {

	message := fmt.Sprintf("channel=%s&series_id=%d", channel, seriesID)

	data := BeansProducerAttr{
		Tube:    "AbiosLiveData",
		Message: message,
		Delay:   0,
		PRI:     1,
		TTR:     60 * time.Second,
	}

	if err := BPool.Invoke(data); err != nil {
		return fmt.Errorf("比赛ID: %d 实时数据订阅失败:%s", seriesID, err.Error())
	}

	return nil
}

func BeansAddTask(data BeansProducerAttr) error {

	v, err := BeanPool.Get()
	if err != nil {
		return err
	}

	if conn, ok := v.(*beanstalk.Conn); ok {

		tube := &beanstalk.Tube{Conn: conn, Name: data.Tube}
		_, err = tube.Put([]byte(data.Message), data.PRI, data.Delay, data.TTR)
		if err != nil {
			return err
		}
	}

	//将连接放回连接池中
	return BeanPool.Put(v)
}

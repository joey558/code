package model

import (
	mqtt "github.com/eclipse/paho.mqtt.golang"
	"github.com/go-redis/redis/v7"
	"github.com/jmoiron/sqlx"
	"github.com/olivere/elastic/v7"
	"github.com/panjf2000/ants/v2"
	cpool "github.com/silenceper/pool"
)

var (
	Pool            *redis.Client      // 总控fusion redis主库
	PoolSlave       *redis.Client      // 总控fusion redis从库
	TraderPool      *redis.Client      // 总控trader redis主库
	TraderPoolSlave *redis.Client      // 总控trader redis从库
	Db              *sqlx.DB           // 总控fusion db主库
	TradeDd         *sqlx.DB           // 总控trader db主库
	Es              *elastic.Client    // elasticsearch客户端
	EsPrefix        string             // es索引前缀
	Cli             mqtt.Client        // mqtt客户端
	BeanPool        cpool.Pool         // beanstalk
	SettleMerch     []MerchantConf     //
	BPool           *ants.PoolWithFunc // 协程池
	PoolSize        int                // 协程池大小
	TokenString     string
)

type Construct struct {
	DB              *sqlx.DB      // 总控数据融合Mysql
	//TradeDB         *sqlx.DB      // 总控trade
	Pool            *redis.Client // 总控Redis-master
	PoolSlave       *redis.Client // 总控Redis-master
	//TraderPool      *redis.Client // 总控trader redis主库
	//TraderPoolSlave *redis.Client // 总控trader redis从库
	Es              *elastic.Client    // elasticSearch
	EsPrefix        string             // es 索引前缀
	MqttCli         mqtt.Client        // mqtt客户端
	BeanPool        cpool.Pool         // beanstalk
	BPool           *ants.PoolWithFunc // 协程池
	PoolSize        int                // 协程池大小
	SettleMerch     []MerchantConf     //需要结算的商户列表
}

// 数据源标识
type DataSource int

const (
	MASTER DataSource = 0
	ABIOS             = 1
	ODDS              = 2
)

var DataSourceName = map[DataSource]string{
	0: "MASTER",
	1: "ABIOS",
	2: "ODDS",
}

type MerchantConf struct {
	ID      uint64 `json:"id"`
	Account string `json:"account"`
}

//Token
type Token struct {
	AccessToken string `json:"access_token"`
}

func Constructor(cons Construct) {

	Db = cons.DB                   // 总控fusion数据库
	//TradeDd = cons.TradeDB         // 总控trader
	Pool = cons.Pool               // 总控主redis
	PoolSlave = cons.PoolSlave     // 总控从redis
	Es = cons.Es                   // es 服务
	EsPrefix = cons.EsPrefix       // es 索引前缀
	BeanPool = cons.BeanPool       // beanstalk pool
	Cli = cons.MqttCli             // mqtt client
	SettleMerch = cons.SettleMerch // 结算商户
	PoolSize = cons.PoolSize

	// 初始化beanstalk协程池
	//BPool, _ = ants.NewPoolWithFunc(500, func(payload interface{}) {
	//	if b, ok := payload.(BeansProducerAttr); ok {
	//		err := BeansAddTask(b)
	//		if err != nil {
	//			log.Fatal(err)
	//		}
	//	}
	//})
}

func ConstructorHttp(traderDB *sqlx.DB, traderPool *redis.Client, traderPoolSlave *redis.Client)  {
	TradeDd = traderDB
	TraderPool = traderPool
	TraderPoolSlave = traderPoolSlave
}

var (
	matchRelatedColumns = []interface{}{
		"id",
		"match_id",
		"source_match_id",
		"tournament_name",
		"team_name",
		"start_time",
		"data_source",
	}
	mchColumns = []interface{}{
		"id",
		"game_id",               //游戏ID
		"tournament_id",         //联赛ID
		"tournament_short_name", //联赛简称
		"match_team",            //战队信息
		"category",              //赛事类型 正常-1 冠军-2 大逃杀-3
		"title",                 //标题
		"bo",                    //赛制
		"start_time",            //开始时间
		"end_time",              //结束时间
		"user_video_url",        //直播源地址
		"admin_video_url",       //操盘直播源地址
		"match_level",           //赛事等级 1-M1 2-M2 3-M3 4-M4
		"status",                //待录入-1 待审核-2 已驳回-3 待开盘-4 已开盘-5 已关盘-6 已结算-7 待取消-8 比赛取消-9
		"is_live",               //赛事阶段 1-初盘 2-滚盘
		"live_support",          //是否滚球 1-是 0-否
		"is_pass_off",           //是否串关 1-是 0-否
		"suspended",             //是否暂停  1-暂停 0-非暂停
		"visible",               //是否显示  1-显示 0-隐藏
		"bet_delay_time",        //注单确认时间
		"close_time",            //赛事关闭时间
		"score",                 //赛事比分
		"create_time",           //创建人ID
		"update_time",           //更新人ID
		"create_by_name",        //创建人名
		"update_by_name",        //更新人名
		"rec",                   //推荐序号
	}
)

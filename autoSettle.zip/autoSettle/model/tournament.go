package model

import (
	"fmt"

	g "github.com/doug-martin/goqu/v9"
)

// Tournament 联赛数据库表结构体
type Tournament struct {
	ID         string `db:"id" json:"id"`
	GameID     string `db:"game_id" json:"game_id"`         // 游戏id
	Name       string `db:"name" json:"name"`               // 联赛英文名
	ShortName  string `db:"short_name" json:"short_name"`   // 联赛简称
	CnName     string `db:"cn_name" json:"cn_name"`         // 联赛中文名
	MatchLevel int    `db:"match_level" json:"match_level"` // 默认赛事等级
	StartTime  int64  `db:"start_time" json:"start_time"`
	EndTime    int64  `db:"end_time" json:"end_time"`
	CreateTime int64  `db:"create_time" json:"create_time"` // 创建时间
	UpdateTime int64  `db:"update_time" json:"update_time"` // 更新时间
	TargetID   int64  `db:"target_id" json:"target_id"`
	DataSource int    `db:"data_source" json:"data_source"`
}

type SimpleTournament struct {
	ID   int64  `db:"target_id" json:"id"`
	Name string `db:"name" json:"name"`
}

/**
 * @Description: 联赛新增
 * @Author: awen
 * @Date: 2020/10/21 23:08
 * @LastEditTime: 2020/10/21 23:08
 * @LastEditors: awen
 */
func TournamentInsert(data *Tournament) error {

	// 开启事务
	dbConn, err := Db.Begin()
	if err != nil {
		return err
	}

	// 写入数据库
	query, _, _ := g.Dialect("mysql").Insert("tbl_tournament").Rows(data).ToSQL()
	_, err = dbConn.Exec(query)
	if err != nil {
		_ = dbConn.Rollback()
		return err
	}

	pipe := Pool.TxPipeline()
	pipe.Set(fmt.Sprintf(RedisKeyOddTournamentGameID, data.TargetID), data.GameID, 0)
	pipe.Set(fmt.Sprintf(RedisKeyTournamentFusion, data.DataSource, data.TargetID), data.ID, 0)
	pipe.Set(fmt.Sprintf(RedisKeyTournamentName, data.DataSource, data.TargetID), data.Name, 0)
	_, err = pipe.Exec()
	if err != nil {
		_ = dbConn.Rollback()
		return err
	}

	return dbConn.Commit()

}

/**
 * @Description: 联赛修改
 * @Author: awen
 * @Date: 2020/10/24 14:26
 * @LastEditTime: 2020/10/24 14:26
 * @LastEditors: awen
 */
func TournamentUpdate(v g.Record, ex g.Ex) error {

	// 写入数据库
	query, _, _ := g.Dialect("mysql").Update("tbl_tournament").Set(v).Where(ex).ToSQL()
	_, err := Db.Exec(query)
	return err
}

/**
 * @Description: 数据联赛精简结构查询
 * @Author: awen
 * @Date: 2020/10/21 23:08
 * @LastEditTime: 2020/10/21 23:08
 * @LastEditors: awen
 */
func TournamentFindAll(ex g.Ex, rangeEx g.Expression) ([]SimpleTournament, error) {

	var data []SimpleTournament
	dialect := g.Dialect("mysql")
	query, _, _ := dialect.From("tbl_tournament").Select("target_id", "name").Where(ex, rangeEx).ToSQL()
	err := Db.Select(&data, query)
	return data, err
}
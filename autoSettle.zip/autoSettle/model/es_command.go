package model

// es 索引
const (
	MatchIndex     = `mch_index_%d`                 // 赛事索引
	MarketIndex    = `auto_settle_market_index`     // 盘口索引
	FuseMatchIndex = `auto_settle_fuse_match_index` // 融合赛事索引
	MatchTeamIndex = `auto_settle_match_team_index` // 赛事战队索引
)

// es 数据格式
const (
	AutoSettleMatchData = `{
    "mappings":{
        "properties":{
            "id":{
                "type":"text"
            },
            "data_source":{
                "type":"long"
            },
            "game_id":{
                "type":"text"
            },
            "tournament_id":{
                "type":"long"
            },
            "tournament_name":{
                "type":"text"
            },
            "team_id":{
                "type":"text"
            },
            "team_name":{
                "type":"text"
            },
            "bo":{
                "type":"long"
            },
            "tier":{
                "type":"long"
            },
            "start_time":{
                "type":"long"
            },
            "end_time":{
                "type":"long"
            },
            "score":{
                "type":"text"
            },
            "target_id":{
                "type":"long"
            },
		    "idx":{
				"type":"text"
		    }
        }
    }
}`
	AutoSettleMatchTeamData = `{
    "mappings":{
        "properties":{
			"id":{
                "type":"text"
            },
            "match_id":{
                "type":"text"
            },
            "team_id":{
                "type":"long"
            },
            "team_name":{
                "type":"text"
            }
        }
    }
}`
)

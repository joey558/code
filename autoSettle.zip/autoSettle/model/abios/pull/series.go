package pull

import (
	"autoSettle/helper"
	"fmt"
	"github.com/go-redis/redis/v7"
	"strings"
	"time"

	"autoSettle/model"

	g "github.com/doug-martin/goqu/v9"

	"github.com/AbiosGaming/go-sdk-v2/v3/structs"
)

func SeriesConn() {

	url := "https://api.abiosgaming.com/v2/series"

	page := int64(0)
	currentTime := time.Now()
	startsAfter := currentTime.AddDate(0, 0, -3).Format("2006-01-02T00:00:00Z")
	for {

		page++
		// 暂且是拉取Dota 2,LoL,CS:GO的联赛数据
		req := map[string]interface{}{
			"page":         page,
			"starts_after": startsAfter,
			"games[]":      "1&games[]=2&games[]=5",
			"with[]":       "matches",
		}
		resp := structs.PaginatedSeries{}
		err := seriesPull(url, req, &resp)
		if err != nil {
			fmt.Println(err)
		}

		// 当前页是最后一页停止循环
		if page >= resp.LastPage {
			return
		}
	}

}

func seriesPull(url string, req map[string]interface{}, resp *structs.PaginatedSeries) error {

	err := publicGetFastHttpHelper(url, req, &resp, defaultTimeout)
	if err != nil {
		fmt.Println("abios 数据源比赛数据拉取错误：", err)
		return err
	}

	for _, datum := range resp.Data {
		series, err := SeriesHelperFormat(datum)
		if err != nil {
			fmt.Println("abios 数据源比赛数据格式化错误：", err)
			continue
		}

		if series == nil {
			fmt.Println("format series is nil")
			continue
		}

		mchID, err := model.Pool.Get(fmt.Sprintf(model.RedisKeyMatchFusion, model.ABIOS, series.TargetID)).Result()
		if err == redis.Nil {  // 数据源比赛不存在则新增比赛，忽略redis nil error
			series.ID = fmt.Sprintf("%d", helper.Cputicks())
			err = model.MatchesInsert(series)
			if err != nil {
				fmt.Println(err)
				continue
			}
		}

		if err != nil {
			fmt.Println("abios 获取数据源比赛关联比赛ID错误:", err)
			continue
		}

		if mchID != "" { // 更新数据
			record := g.Record{
				"title":           series.Title,
				"game_id":         series.GameID,
				"tournament_id":   series.TournamentID,
				"tournament_name": series.TournamentName,
				"team_id":         series.TeamID,
				"team_name":       series.TeamName,
				"bo":              series.Bo,
				"tier":            series.Tier,
				"score":           series.Score,
				"is_delete":       series.IsDelete,
				"start_time":      series.StartTime,
				"end_time":        series.EndTime,
				"updated_at":      series.UpdatedAt,
			}
			err = model.MatchesUpdate(g.Ex{"id": mchID}, record)
			if err != nil {
				fmt.Println("赛事更新失败:", err)
				continue
			}

			series.ID = mchID
		}

		esMatch := model.HandleEsMatches(series)
		// es索引检查
		index := model.EsPrefix + fmt.Sprintf(model.MatchIndex, model.ABIOS)
		err = model.CreateIndex(index, model.AutoSettleMatchData)
		if err != nil {
			fmt.Printf("abios比赛数据 索引创建失败:%s \n", err)
			continue
		}

		// es 数据写入
		err = model.UpdateData(index, esMatch.ID, esMatch)
		if err != nil {
			fmt.Printf("es数据写入失败:%s \n", err)
		}
	}

	return nil
}

/*
 * abios 比赛数据融合转换
 */
func SeriesHelperFormat(datum structs.Series) (*model.Matches, error) {

	series := &model.Matches{
		Title:        datum.Title,        // 联赛名称
		TournamentID: datum.TournamentId, // 联赛id
		Bo:           int(datum.BestOf),  // 赛制
		TargetID:     datum.Id,           // 数据源id
		DataSource:   model.ABIOS,        // 数据源
		CreatedAt:    time.Now().Unix(),
		UpdatedAt:    time.Now().Unix(),
	}
	// 赛事等级
	if datum.Tier != nil {
		series.Tier = *datum.Tier
	}
	// 游戏id
	if datum.Game.Id != 0 {
		series.GameID = datum.Game.Id
	}

	// 联赛名称获取
	key := fmt.Sprintf(model.RedisKeyTournamentName, series.DataSource, series.TournamentID)
	tournamentName, err := model.Pool.Get(key).Result()
	if err != nil {
		series.TournamentName = ""
	} else {
		series.TournamentName = tournamentName
	}

	// 转换主队/客队 的id、弃权状态、比分
	if len(datum.Rosters) > 0 {

		var (
			teamId   []string
			teamName []string
			score    []string
		)

		for _, roster := range datum.Rosters {
			teamId = append(teamId, fmt.Sprintf("%d", roster.Id)) // 战队id
			teamName = append(teamName, roster.Teams[0].Name)     // 战队名称
		}
		// 比分处理
		s := *datum.Scores
		for i := 0; i < len(teamId); i++ {
			if v, ok := s[teamId[i]]; ok {
				score = append(score, fmt.Sprintf("%d", v))
			}
		}

		series.Score = strings.Join(score, ":")
		series.TeamID = strings.Join(teamId, ",")
		series.TeamName = strings.Join(teamName, ",")
	}

	// 转换开始时间
	if datum.Start != nil {
		s, err := time.Parse(defaultTimeFormat, *datum.Start)
		if err != nil {
			fmt.Println("SeriesHelperFormat time parse err :", *datum.Start)
			return nil, err
		}

		series.StartTime = s.Unix()
	}

	// 转换结束时间
	if datum.End != nil {
		s, err := time.Parse(defaultTimeFormat, *datum.End)
		if err != nil {
			fmt.Println("SeriesHelperFormat time parse err :", *datum.End)
			return nil, err
		}

		series.EndTime = s.Unix()
	}

	// 是否删除
	if datum.DeletedAt != nil {
		series.IsDelete = 1
	}

	return series, nil
}

package pull

import (
	"fmt"
	"time"

	"autoSettle/helper"
	"autoSettle/model"

	"github.com/AbiosGaming/go-sdk-v2/v3/structs"
	g "github.com/doug-martin/goqu/v9"
	"github.com/go-redis/redis/v7"
)

func PlayersConn() {
	url := "https://api.abiosgaming.com/v2/players"

	page := int64(1)
	// 暂且只拉取Dota 2,LoL,CS:GO的玩家数据
	req := map[string]interface{}{
		"page":    page,
		"games[]": "1&games[]=2&games[]=5",
		"with[]":  "game&with[]=team",
	}
	data := structs.PaginatedPlayers{}
	err := playerPull(url, req, &data)
	if err != nil {
		fmt.Println(err)
		return
	}

	if page >= data.LastPage {
		return
	}

	for {
		page++
		req["page"] = page
		resp := structs.PaginatedPlayers{}
		err = playerPull(url, req, &resp)
		if err != nil {
			fmt.Println(err)
			continue
		}

		// 当前页是最后一页停止循环
		if page >= resp.LastPage {
			return
		}
	}
	//pool, _ := ants.NewPoolWithFunc(model.PoolSize, func(payload interface{}) {
	//
	//})
	//
	//defer pool.Release()
}

func playerPull(url string, req map[string]interface{}, resp *structs.PaginatedPlayers) error {

	err := publicGetFastHttpHelper(url, req, &resp, defaultTimeout)
	if err != nil {
		fmt.Println("abios 数据源选手数据拉取错误：", err)
		return err
	}

	for _, v := range resp.Data {
		player, err := playersHelperFormat(v)
		if err != nil {
			fmt.Println("abios 数据源选手数据格式化错误：", err)
			continue
		}

		playerID, err := model.Pool.Get(fmt.Sprintf(model.RedisKeyPlayerFusion, model.ABIOS, player.TargetID)).Result()
		if err == redis.Nil {  // 数据源选手不存在则新增选手，忽略redis nil error
			err = model.PlayerInsert(&player)
			if err != nil {
				fmt.Println("abios 新增选手数据错误：", err)
			}
			continue
		}

		if err != nil {
			fmt.Println("abios 获取数据源选手关联选手ID错误:", err)
			continue
		}

		// 更新玩家数据
		if playerID != "" {
			v := g.Record{
				"game_id":     player.GameID,
				"team_id":     player.TeamID,
				"first_name":  player.FirstName,
				"last_name":   player.LastName,
				"nick_name":   player.NickName,
				"update_time": time.Now().Unix(),
			}
			err = model.PlayerUpdate(v, g.Ex{"id": playerID})
			if err != nil {
				fmt.Println("abios 修改选手数据错误：", err)
				continue
			}
		}
	}

	//TODO 此处逻辑需要优化
	return nil
}

func playersHelperFormat(datum structs.Player) (model.Player, error) {

	player := model.Player{
		ID:         fmt.Sprintf("%d", helper.Cputicks()),
		FirstName:  datum.FirstName,
		LastName:   datum.LastName,
		NickName:   datum.Nickname,
		GameID:     fmt.Sprintf("%d", datum.Game.Id),
		TeamID:     "0",
		CreateTime: time.Now().Unix(),
		UpdateTime: time.Now().Unix(),
		TargetID:   datum.Id,
		DataSource: model.ABIOS,
	}

	if datum.Team != nil {
		player.TeamID = fmt.Sprintf("%d", datum.Team.Id)
	}

	return player, nil
}

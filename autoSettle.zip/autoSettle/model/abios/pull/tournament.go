package pull

import (
	"fmt"
	"time"

	"autoSettle/helper"
	"autoSettle/model"

	"github.com/AbiosGaming/go-sdk-v2/v3/structs"
	g "github.com/doug-martin/goqu/v9"
	"github.com/go-redis/redis/v7"
)

var tmtPage int64

func TournamentsConn() {
	url := "https://api.abiosgaming.com/v2/tournaments"

	tmtPage = 1
	// 暂且是拉取Dota 2,LoL,CS:GO的联赛数据
	req := map[string]interface{}{
		"page":    tmtPage,
		"games[]": "1&games[]=2&games[]=5",
		"is_over": false,
	}
	data := structs.PaginatedTournaments{}
	err := tournamentPull(url, req, &data)
	if err != nil {
		fmt.Println(err)
		return
	}

	if tmtPage >= data.LastPage {
		return
	}

	//var wg sync.WaitGroup
	//p, _ := ants.NewPoolWithFunc(10, func(i interface{}) {
	//	resp := structs.PaginatedTournaments{}
	//	_ = tournamentPull1(url, req, &resp)
	//	wg.Done()
	//})
	//
	//defer p.Release()
	//for {
	//	wg.Add(1)
	//	err = p.Invoke(1)
	//	if err != nil {
	//		fmt.Println(err)
	//	}
	//	if atomic.LoadInt64(&tmtPage) >= data.LastPage {
	//		fmt.Println("-------------联赛数据拉取完毕-------------")
	//		break
	//	}
	//}
	//
	//wg.Wait()
	for {

		tmtPage++
		req["page"] = tmtPage
		resp := structs.PaginatedTournaments{}
		err := tournamentPull(url, req, &resp)
		if err != nil {
			fmt.Println(err)
			continue
		}

		// 当前页是最后一页停止循环
		if tmtPage >= data.LastPage {
			return
		}
	}
}

func tournamentPull1(url string, req map[string]interface{}, resp *structs.PaginatedTournaments) error {
	//atomic.AddInt64(&tmtPage, 1)
	//fmt.Println("开始拉取第", atomic.LoadInt64(&tmtPage), "页联赛数据...")
	//req["page"] = atomic.LoadInt64(&tmtPage)
	//fmt.Println("page:", req["page"])

	err := publicGetFastHttpHelper(url, req, &resp, defaultTimeout)
	if err != nil {
		fmt.Println(err)
	}

	for _, v := range resp.Data {
		tournament, err := tournamentsHelperFormat(v)
		if err != nil {
			fmt.Println(err)
			continue
		}

		tmtID, err := model.Pool.Get(fmt.Sprintf(model.RedisKeyTournamentFusion, model.ABIOS, tournament.TargetID)).Result()
		if err != nil {
			// 数据源联赛不存在则新增
			if err == redis.Nil {
				err = model.TournamentInsert(&tournament)
				if err != nil {
					fmt.Println(err)
				}
				continue
			}
			fmt.Println(err)
			continue
		}

		// 更新联赛数据
		if tmtID != "" {
			v := g.Record{
				"game_id":     tournament.GameID,
				"name":        tournament.Name,
				"short_name":  tournament.ShortName,
				"match_level": tournament.MatchLevel,
				"start_time":  tournament.StartTime,
				"end_time":    tournament.EndTime,
				"update_time": time.Now().Unix(),
			}
			err = model.TournamentUpdate(v, g.Ex{"id": tmtID})
			if err != nil {
				fmt.Println(err)
				continue
			}
		}
	}

	//TODO 此处逻辑需要优化
	return nil
}

func tournamentPull(url string, req map[string]interface{}, resp *structs.PaginatedTournaments) error {

	err := publicGetFastHttpHelper(url, req, &resp, defaultTimeout)
	if err != nil {
		fmt.Println("abios 数据源联赛数据拉取错误：", err)
		return err
	}

	for _, v := range resp.Data {
		tournament, err := tournamentsHelperFormat(v)
		if err != nil {
			fmt.Println("abios 数据源联赛数据格式化错误：", err)
			continue
		}

		tmtID, err := model.Pool.Get(fmt.Sprintf(model.RedisKeyTournamentFusion, model.ABIOS, tournament.TargetID)).Result()
		if err == redis.Nil {  // 数据源联赛不存在则新增联赛，忽略redis nil error
			err = model.TournamentInsert(&tournament)
			if err != nil {
				fmt.Println("abios 新增联赛数据错误：", err)
			}
			continue
		}

		if err != nil {
			fmt.Println("abios 获取数据源联赛关联联赛ID错误:", err)
			continue
		}

		// 更新联赛数据
		if tmtID != "" {
			v := g.Record{
				"game_id":     tournament.GameID,
				"name":        tournament.Name,
				"short_name":  tournament.ShortName,
				"match_level": tournament.MatchLevel,
				"start_time":  tournament.StartTime,
				"end_time":    tournament.EndTime,
				"update_time": time.Now().Unix(),
			}
			err = model.TournamentUpdate(v, g.Ex{"id": tmtID})
			if err != nil {
				fmt.Println(err)
				continue
			}
		}
	}

	//TODO 此处逻辑需要优化
	return nil
}

func tournamentsHelperFormat(datum structs.Tournament) (model.Tournament, error) {

	data := model.Tournament{
		ID:         fmt.Sprintf("%d", helper.Cputicks()),
		GameID:     fmt.Sprintf("%d", datum.Game.Id),
		Name:       datum.Title,
		ShortName:  datum.ShortTitle,
		CnName:     "",
		MatchLevel: int(datum.Tier),
		CreateTime: time.Now().Unix(),
		UpdateTime: time.Now().Unix(),
		TargetID:   datum.Id,
		DataSource: model.ABIOS,
	}

	if datum.Start != nil && *datum.Start != "" {
		timeStart, err := time.Parse(defaultDateFormat, *datum.Start)
		if err != nil {
			fmt.Println("tournamentHelperFormat start_time parse err :", *datum.Start)
			return data, err
		} else {
			//timeStart = timeStart.Add(8 * time.Hour)
			data.StartTime = timeStart.Unix()
		}
	}
	if datum.End != nil && *datum.End != "" {
		timeEnd, err := time.Parse(defaultDateFormat, *datum.End)
		if err != nil {
			fmt.Println("tournamentHelperFormat end_time parse err :", *datum.End)
			return data, err
		} else {
			//timeEnd = timeEnd.Add(8 * time.Hour)
			data.EndTime = timeEnd.Unix()
		}
	}

	return data, nil
}

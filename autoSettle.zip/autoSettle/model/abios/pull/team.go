package pull

import (
	"fmt"
	"time"

	"autoSettle/helper"
	"autoSettle/model"

	"github.com/AbiosGaming/go-sdk-v2/v3/structs"
	g "github.com/doug-martin/goqu/v9"
	"github.com/go-redis/redis/v7"
)

func TeamsConn() {
	url := "https://api.abiosgaming.com/v2/teams"

	page := int64(1)
	// 暂且是拉取Dota 2,LoL,CS:GO的战队数据
	req := map[string]interface{}{
		"page":    page,
		"games[]": "1&games[]=2&games[]=5",
		"with[]":  "game",
	}
	data := structs.PaginatedTeams{}
	err := teamPull(url, req, &data)
	if err != nil {
		fmt.Println(err)
		return
	}

	if page >= data.LastPage {
		return
	}

	for {
		page++
		req["page"] = page
		resp := structs.PaginatedTeams{}
		err = teamPull(url, req, &resp)
		if err != nil {
			fmt.Println(err)
			continue
		}

		// 当前页是最后一页停止循环
		if page >= resp.LastPage {
			return
		}
	}
	//pool, _ := ants.NewPoolWithFunc(model.PoolSize, func(payload interface{}) {
	//
	//})
	//
	//defer pool.Release()
}

func teamPull(url string, req map[string]interface{}, resp *structs.PaginatedTeams) error {

	err := publicGetFastHttpHelper(url, req, &resp, defaultTimeout)
	if err != nil {
		fmt.Println("abios 数据源战队数据拉取错误：", err)
		return err
	}

	for _, v := range resp.Data {
		team, err := teamsHelperFormat(v)
		if err != nil {
			fmt.Println("abios 数据源战队数据格式化错误：", err)
			continue
		}

		tmID, err := model.Pool.Get(fmt.Sprintf(model.RedisKeyTeamFusion, model.ABIOS, team.TargetID)).Result()
		if err == redis.Nil {  // 数据源战队不存在则新增战队，忽略redis nil error
			err = model.TeamInsert(&team)
			if err != nil {
				fmt.Println("abios 新增战队数据错误：", err)
			}
			continue
		}

		if err != nil {
			fmt.Println("abios 获取数据源战队关联战队ID错误:", err)
			continue
		}

		// 更新战队数据
		if tmID != "" {
			v := g.Record{
				"game_id":     team.GameID,
				"name":        team.Name,
				"short_name":  team.ShortName,
				"update_time": time.Now().Unix(),
			}
			err = model.TeamUpdate(v, g.Ex{"id": tmID})
			if err != nil {
				fmt.Println("abios 修改战队数据错误：", err)
				continue
			}
		}
	}

	//TODO 此处逻辑需要优化
	return nil
}

func teamsHelperFormat(datum structs.Team) (model.Team, error) {

	team := model.Team{
		ID:         fmt.Sprintf("%d", helper.Cputicks()),
		Name:       datum.Name,
		ShortName:  datum.ShortName,
		CnName:     "",
		GameID:     fmt.Sprintf("%d", datum.Game.Id),
		CreateTime: time.Now().Unix(),
		UpdateTime: time.Now().Unix(),
		TargetID:   datum.Id,
		DataSource: model.ABIOS,
	}

	return team, nil
}

package pull

import (
	"fmt"
	"time"

	"autoSettle/helper"
	"autoSettle/model"

	"github.com/AbiosGaming/go-sdk-v2/v3/structs"
	g "github.com/doug-martin/goqu/v9"
	"github.com/go-redis/redis/v7"
)

func GamesConn() {
	url := "https://api.abiosgaming.com/v2/games"

	resp := structs.PaginatedGames{}
	err := publicGetFastHttpHelper(url, nil, &resp, defaultTimeout)
	if err != nil {
		fmt.Println("abios 数据源游戏数据拉取错误：", err)
		return
	}

	for _, v := range resp.Data {
		game, err := gamesHelperFormat(v)
		if err != nil {
			fmt.Println("abios 数据源游戏数据格式化错误：", err)
			continue
		}

		gmID, err := model.Pool.Get(fmt.Sprintf(model.RedisKeyGameFusion, model.ABIOS, game.TargetID)).Result()
		if err == redis.Nil { // 数据源游戏不存在则新增游戏，忽略redis nil error
			err = model.GameInsert(&game)
			if err != nil {
				fmt.Println("abios 新增游戏数据错误：", err)
			}
			continue
		}

		if err != nil {
			fmt.Println("abios 获取数据源游戏关联游戏ID错误:", err)
			continue
		}

		// 更新游戏数据
		if gmID != "" {
			v := g.Record{
				"name":        game.Name,
				"short_name":  game.ShortName,
				"update_time": time.Now().Unix(),
			}
			err = model.GameUpdate(v, g.Ex{"id": gmID})
			if err != nil {
				fmt.Println("abios 修改游戏数据错误：", err)
				continue
			}
		}
	}
}

func gamesHelperFormat(datum structs.Game) (model.Game, error) {
	game := model.Game{
		ID:         fmt.Sprintf("%d", helper.Cputicks()),
		Name:       datum.LongTitle,
		ShortName:  datum.Title,
		CnName:     "",
		CreateTime: time.Now().Unix(),
		UpdateTime: time.Now().Unix(),
		TargetID:   datum.Id,
		DataSource: model.ABIOS,
	}

	return game, nil
}

package pull

import (
	"fmt"
	"net/http"
	"sync"
	"time"

	"autoSettle/helper"
	"autoSettle/model/abios"

	"github.com/valyala/fasthttp"
)

var (
	apiUrl        = "https://api.abiosgaming.com/v2"
	errStatusNoOK = fmt.Errorf("未正确获取信息")
)

const (

	defaultTimeout    = 30 * time.Second
	defaultDateFormat = "2006-01-02"
	defaultTimeFormat = "2006-01-02 15:04:05"
)

type Oauth struct {
	AccessToken string `json:"access_token"`
	ExpiresIn   int    `json:"expires_in"`
	TokenType   string `json:"token_type"`
}

func getAccessToken() *Oauth {
again:
	token, err := OauthAccessToken()
	if err != nil {
		fmt.Println("OauthAccessToken error:", err)
		time.Sleep(100 * time.Millisecond)
		goto again
	}
	abios.AccessToken = token.AccessToken
	return token
}

func OauthAccessToken() (*Oauth, error) {
	url := apiUrl + "/oauth/access_token"

	req := map[string]string{
		"grant_type":    abios.Status,
		"client_id":     abios.ClientID,
		"client_secret": abios.ClientSecret,
	}
	resp := new(Oauth)
	err := publicPostFastHttpHelper(url, req, resp, defaultTimeout)
	return resp, err
}

func publicGetFastHttpHelper(url string, req map[string]interface{}, resp interface{}, timeOut time.Duration) error {
	reqStr := ""
	for s, s2 := range req {
		if reqStr != "" {
			reqStr += "&"
		}
		reqStr += fmt.Sprintf("%v=%v", s, s2)
	}

	fn := func() ([]byte, int, error) {
		reader := fmt.Sprintf("?access_token=%v", abios.AccessToken)
		if reqStr != "" {
			reader += "&" + reqStr
		}

		return helper.HttpDoTimeout(nil, fasthttp.MethodGet, url+reader, nil, timeOut)
	}
tautology:
	data, status, err := fn()
	if err != nil {
		return err
	}

	if status != http.StatusOK {
		if status == http.StatusUnauthorized {
			// token失效重新获取并重试
			getAccessToken()
			data, status, err = fn()
			if err != nil {
				return err
			}
		} else if status == http.StatusTooManyRequests {
			time.Sleep(time.Duration(5) * time.Millisecond)
			goto tautology
		} else {
			return errStatusNoOK
		}
	}

	err = helper.JsonUnmarshal(data, &resp)
	if err != nil {
		return err
	}
	return nil
}

func publicPostFastHttpHelper(url string, req map[string]string, resp interface{}, timeOut time.Duration) error {

	reqStr := ""
	for s, s2 := range req {
		if reqStr != "" {
			reqStr += "&"
		}
		reqStr += fmt.Sprintf("%v=%v", s, s2)
	}

	headers := map[string]string{
		"Content-Type": "application/x-www-form-urlencoded",
	}

	data, status, err := helper.HttpDoTimeout([]byte(reqStr), fasthttp.MethodPost, url, headers, timeOut)
	if err != nil {
		return err
	}
	if status != http.StatusOK {
		return errStatusNoOK
	}

	return helper.JsonUnmarshal(data, &resp)
}

// 协程加速
func publicChanSpeedup(url string, fn func(url string, currentPage int64) int64) {

	flagCh := make(chan int64, 5)
	wg := &sync.WaitGroup{}
	conn := func(currentPage int64, flagCh <-chan int64) (pageSize int64) {
		wg.Add(1)
		defer func() {
			<-flagCh
			wg.Done()
		}()
		return fn(url, currentPage)
	}

	flagCh <- 1
	pageSize := conn(1, flagCh)

	if pageSize >= 2 {
		for i := int64(2); i <= pageSize; i++ {
			flagCh <- i
			go conn(i, flagCh)
		}
	}
	wg.Wait()
}

func AbiosAutoPull()  {
	// 游戏、战队、选手静态数据每天更新一次
	go func() {
		for  {
			GamesConn()
			TeamsConn()
			PlayersConn()
			time.Sleep(24 *time.Hour)
		}
	}()

	//// 联赛 每10分钟更新一次
	go func() {
		for {
			TournamentsConn()
			time.Sleep(10 * time.Minute)
		}
	}()

	// 比赛 每5分钟更新一次
	go func() {
		for  {
			SeriesConn()
			time.Sleep(5 * time.Minute)
		}
	}()
}
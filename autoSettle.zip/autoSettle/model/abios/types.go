package abios

// abios 游戏
var AbiosGame = map[int]uint64{
	1: 257289795134339, // dota2
	2: 257154660915053, // lol
	5: 257578064923863, // cs:go
}

const (
	DOTA_GAME_ID = 1
	LOL_GAME_ID  = 2
	CSGO_GAME_ID = 5
)

// abios lol地图精英怪
const (
	AbiosLolEliteAirDragon   = 8  // 风龙
	AbiosLolEliteWaterDragon = 10 // 水龙
	AbiosLolEliteFireDragon  = 11 // 火龙
	AbiosLolEliteBaronDragon = 12 // 男爵（大龙）
	AbiosLolEliteEarthDragon = 13 // 土龙
)

var AbiosGameChannel = map[int]string{
	1: "live_dota",
	2: "live_lol",
	5: "live_csgo",
}

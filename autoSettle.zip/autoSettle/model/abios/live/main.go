package live

import (
	"bytes"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io/ioutil"
	"net/http"
	"net/url"
	"os"
	"strings"
	"time"

	//"autoSettle/model"
	"autoSettle/model/abios"

	mqtt "github.com/eclipse/paho.mqtt.golang"
	"github.com/go-redis/redis/v7"
	"github.com/gofrs/uuid"
	"github.com/gorilla/websocket"
	"github.com/panjf2000/ants/v2"
	cpool "github.com/silenceper/pool"
)

var (
	ReconnectTokenFlag        = flag.String("reconnect-token", "", "Use token to reconnect to previous subscriber state")
	Token              string = ""
	CurrReconnectToken uuid.UUID
	Keep               = map[string]int{} //控制心跳错误退出
	PoolLive           *redis.Client
	BeanPoolLive       cpool.Pool
	BPoolLive          *ants.PoolWithFunc
	MqttLive           mqtt.Client // mqtt客户端
)

const (
	grantType             = "client_credentials"
	clientId              = "kaihongman"
	clientSecret          = "dba33908b1ece1af45cddd9725acd8a8d6fc365647a4ec7171"
	TimestampMillisFormat = "2006-01-02 15:04:05.000"
)

const (
	CloseMissingAccessToken    = 4000 // Missing access token in ws setup request
	CloseInvalidAccessToken    = 4001 // Invalid access token in ws setup request
	CloseNotAuthorized         = 4002 // Client account does not have access to the push API
	CloseMaxNumSubscribers     = 4003 // Max number of concurrent subscribers connected for client id
	CloseMaxNumSubscriptions   = 4004 // Max number of registered subscriptions exist for client id
	CloseInvalidReconnectToken = 4005 // Invalid reconnect token in ws setup request
	CloseMissingSubscriptionID = 4006 // Missing subscription id in ws setup request
	CloseUnknownSubscriptionID = 4007 // The supplied subscriber id in ws setup request does not exist in server
	CloseInternalError         = 4500 // Unspecified error due to problem in server
)

//获取Token
func requestAccessToken(clientID string, clientSecret string) (string, error) {
	URL := "https://api.abiosgaming.com/v2/oauth/access_token"
	form := url.Values{}
	form.Add("client_id", clientID)
	form.Add("client_secret", clientSecret)
	form.Add("grant_type", "client_credentials")

	req, err := http.NewRequest("POST", URL, strings.NewReader(form.Encode()))
	if err != nil {
		return "", err
	}
	req.Header.Add("Content-Type", "application/x-www-form-urlencoded")

	client := http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()

	respBody, _ := ioutil.ReadAll(resp.Body)

	if resp.StatusCode != http.StatusOK {
		return "", errors.New("")
	}

	var g abios.AuthResp
	_ = json.Unmarshal(respBody, &g)

	return g.AccessToken, nil
}

func startWebSocket(sub abios.Subscription) *websocket.Conn {

	var err error
	if Token == "" {
		Token, err = requestAccessToken(clientId, clientSecret)
		if err != nil {
			fmt.Println("获取token错误", err.Error())
			return nil
		}
	}
	subscription, b, err := registerSubscription(Token, sub)
	if err != nil {
		fmt.Println(err.Error())
		return nil
	}
	//如果返回True则需要重置UUID
	if b {
		sub.ID = subscription
		subscription, _, err = updateSubscription(Token, sub)
		if err != nil {
			fmt.Printf("%s [ERROR]: Subscription updateSubscription request failed. Error='%s'\n",
				time.Now().Format(TimestampMillisFormat), err.Error())
			return nil
		}
	}
	reconnectToken, _ := uuid.FromString(*ReconnectTokenFlag)
	// 注册订阅服务

	//获取主连接
	conn := setupPushServiceConnection(Token, reconnectToken, subscription.String())
	if conn == nil {
		//Wg.Done()
		return nil
	}

	if sub.Filters != nil && sub.Filters[0].MatchID != 0 {
		Keep[fmt.Sprintf("%v", conn)] = sub.Filters[0].MatchID
		return conn
	}

	//Keep[fmt.Sprintf("%v", conn)] = sub.Filters[0].SeriesID
	return conn
}
func registerSubscription(accessToken string, sub abios.Subscription) (uuid.UUID, bool, error) {

	URL := "https://ws.abiosgaming.com/v0/subscription?access_token=" + accessToken
	j, _ := json.Marshal(sub)
	req, err := http.NewRequest("POST", URL, bytes.NewBuffer(j))
	if err != nil {
		return uuid.Nil, false, err
	}

	req.Header.Add("Content-Type", "application/json")
	client := http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		return uuid.Nil, false, err
	}

	defer resp.Body.Close()
	respBody, _ := ioutil.ReadAll(resp.Body)
	//订阅POST端点响应具有2个正常状态代码：*不可处理实体（422）如果客户端尝试使用已经在服务器上注册的名称注册订阅，则服务器将返回此状态代码。 * OK（200）//如果注册成功
	if resp.StatusCode == http.StatusUnprocessableEntity {
		var existingID uuid.UUID

		// 如果我们收到HTTP响应代码422，则服务器还使用现有订阅的ID设置了“ Location”标头
		if resp.Header.Get("Location") != "" {
			existingID, err = uuid.FromString(resp.Header.Get("Location"))
			if err != nil {
				// 位置标头不包含有效的UUID
				return uuid.Nil, true, err
			}

			return existingID, true, nil
		}

		return uuid.Nil, true, fmt.Errorf("Subscription with name already exists, but failed to retrieve ID")
	} else if resp.StatusCode != http.StatusOK {
		return uuid.Nil, false, fmt.Errorf("Unexpected status code: %d", resp.StatusCode)
	}

	var s struct {
		ID uuid.UUID `json:"id"`
	}
	err = json.Unmarshal(respBody, &s)

	return s.ID, false, err
}

//更新UUID
func updateSubscription(accessToken string, sub abios.Subscription) (uuid.UUID, bool, error) {

	URL := "https://ws.abiosgaming.com/v0/subscription/" + sub.ID.String() + "?access_token=" + accessToken
	j, _ := json.Marshal(sub)

	req, err := http.NewRequest("PUT", URL, bytes.NewBuffer(j))
	if err != nil {
		return uuid.Nil, false, err
	}
	req.Header.Add("Content-Type", "application/json")

	client := http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		return uuid.Nil, false, err
	}
	defer resp.Body.Close()

	respBody, _ := ioutil.ReadAll(resp.Body)

	if resp.StatusCode == http.StatusUnprocessableEntity {
		return uuid.Nil, true, nil
	} else if resp.StatusCode != http.StatusOK {
		return uuid.Nil, false, fmt.Errorf("Unexpected status code: %d", resp.StatusCode)
	}

	var s struct {
		ID uuid.UUID `json:"id"`
	}
	err = json.Unmarshal(respBody, &s)

	return s.ID, false, err
}

func setupPushServiceConnection(accessToken string, reconnectToken uuid.UUID, subscriptionIDOrName string) *websocket.Conn {

	// 连接网络套接字以开始接收与我们之前设置的订阅过滤器匹配的事件
	conn := websocketConnectLoop(accessToken, reconnectToken, subscriptionIDOrName)

	// 从服务器读取“ init”消息并处理任何websocket设置错误
	initMsg, err := readInitMessage(conn)
	if err != nil {
		os.Exit(1)
	}

	// 初始化消息包含一个重新连接令牌，请存储它，以防我们以后需要重新连接
	var m abios.InitResponseMessage
	_ = json.Unmarshal(initMsg, &m)
	CurrReconnectToken = m.ReconnectToken

	return conn
}

func websocketConnectLoop(accessToken string, reconnectToken uuid.UUID, subscriptionIDOrName string) *websocket.Conn {
	var conn *websocket.Conn
	for {
		var err error
		conn, err = connectToWebsocket(reconnectToken, accessToken, subscriptionIDOrName)
		if err != nil {
			switch v := err.(type) {
			case *abios.WebsocketSetupHTTPError:
				if v.HttpStatus == http.StatusUnauthorized {
					fmt.Printf("%s [INFO]: Access token was not valid, requesting new.\n",
						time.Now().Format(TimestampMillisFormat))
					accessToken, err = requestAccessToken(clientId, clientSecret)
					if err != nil {
						fmt.Printf("%s [ERROR]: Access token request failed. Error='%s'\n",
							time.Now().Format(TimestampMillisFormat), err.Error())
						os.Exit(1)
					}
				} else if v.HttpStatus == http.StatusTooManyRequests {
					// 客户端已限制速率，请稍等片刻再试
					backoffSeconds := 30
					fmt.Printf("%s [INFO]: Client is rate-limited, retrying in %d seconds. Error='%s'\n",
						time.Now().Format(TimestampMillisFormat), backoffSeconds, err.Error())
					time.Sleep(time.Second * time.Duration(backoffSeconds))
				}
			default:
				// 无法连接，请稍后重试
				backoffSeconds := 5
				fmt.Printf("%s [INFO]: Retrying in %d seconds. Error='%s'\n",
					time.Now().Format(TimestampMillisFormat), backoffSeconds, err.Error())
				time.Sleep(time.Second * time.Duration(backoffSeconds))
			}
		} else {
			// 连接成功
			break
		}
	}

	return conn
}

func connectToWebsocket(reconnectToken uuid.UUID, accessToken string, subscriptionIDOrName string) (*websocket.Conn, error) {

	URL := "wss://ws.abiosgaming.com/v0?access_token=" + accessToken + "&subscription_id=" + subscriptionIDOrName
	if reconnectToken != uuid.Nil {
		URL = URL + "&reconnect_token=" + reconnectToken.String()
	}
	var dialer *websocket.Dialer
	conn, resp, err := dialer.Dial(URL, nil)
	if err == websocket.ErrBadHandshake {
		fmt.Printf("%s [ERROR]: Failed to connect to WS url. Handshake status='%d'\n",
			time.Now().Format(TimestampMillisFormat), resp.StatusCode)
		return nil, &abios.WebsocketSetupHTTPError{HttpStatus: resp.StatusCode}
	} else if err != nil {
		fmt.Printf("%s [ERROR]: Failed to connect to WS url. Error='%s'\n",
			time.Now().Format(TimestampMillisFormat), err.Error())
		return nil, err
	}

	return conn, nil
}

func readInitMessage(conn *websocket.Conn) ([]byte, error) {

	// 推送api服务器将在websocket 设置过程中验证很多事情，例如验证访问令牌是否有效，用户是否获得授权等。如果任何验证失败，则服务器将关闭websocket并设置自定义错误代码。
	_, message, err := conn.ReadMessage()
	if closeErr, ok := err.(*websocket.CloseError); ok {
		var errMsg string
		switch closeErr.Code {
		case CloseUnknownSubscriptionID:
			errMsg = fmt.Sprintf("该订阅ID未在服务器上注册") //该订阅ID未在服务器上注册
		case CloseMissingSubscriptionID:
			errMsg = "设置请求中缺少订阅ID或名称" //设置请求中缺少订阅ID或名称
		case CloseMaxNumSubscribers:
			errMsg = "已超过该帐户的最大并发订户数" //已超过该帐户的最大并发订户数
		case CloseMaxNumSubscriptions:
			errMsg = "已超过该帐户的最大注册订阅数" //已超过该帐户的最大注册订阅数
		case CloseInternalError:
			errMsg = "未知的服务器错误" //未知的服务器错误
		default:
			errMsg = fmt.Sprintf("服务器发送了无法识别的错误代码: %d", closeErr.Code)
		}

		fmt.Printf("%s 服务器关闭连接: %s\n",
			time.Now().Format(TimestampMillisFormat), errMsg)
		return nil, err
	} else if err != nil {
		// Websocket读取遇到其他错误，我们不会尝试恢复
		fmt.Printf("%s [ERROR]: 无法读取“ init”消息。错误='%s'\n",
			time.Now().Format(TimestampMillisFormat), err.Error())
		return nil, err
	}

	return message, nil
}

//这将从服务器读取消息并将其打印到标准输出。 //如果websocket关闭，它将使用重新连接令牌自动重新建立连接，以确保//在断开连接期间不会丢失任何消息。
func messageReadLoop(conn *websocket.Conn) {

	//从这里开始，我们将开始接收与订阅过滤器匹配的推送事件
	if conn != nil {
		for {
			_, message, err := conn.ReadMessage()
			//如果websocket错误，我们需要重新连接
			if err != nil {
				sub := abios.Subscription{
					Name:        "live-series",
					Description: "Listens to all events from series and match channels, for all games account has access to",
					Filters:     []abios.SubscriptionFilter{},
				}
				sub.Filters = append(sub.Filters, abios.SubscriptionFilter{Channel: "live_lol"})
				sub.Filters = append(sub.Filters, abios.SubscriptionFilter{Channel: "live_csgo"})
				conn := startWebSocket(sub)
				go keepAliveLoop(conn)
				go messageReadLoop(conn)
				return
			}

			//健全检查以确保可以将JSON编组为正确的消息格式
			_, err = tryUnmarshalJSONAsPushMessage(message)
			if err != nil {
				fmt.Printf("%s [ERROR]: Failed to unmarshal to message struct. Error='%s', Message='%s'\n",
					time.Now().Format(TimestampMillisFormat), err.Error(), message)

				// 忽略消息并继续从websocket阅读
				continue
			}

			printJsonWithTag(message)
		}
	}
}

//心跳
func keepAliveLoop(conn *websocket.Conn) {

	time.Sleep(time.Second * 30)
	if conn != nil {
		for {
			err := conn.WriteControl(websocket.PingMessage, []byte{}, time.Now().Add(3*time.Second))
			if err != nil {
				fmt.Println("心跳错误:", err.Error())
				return
			}
		}
	}
}

func tryUnmarshalJSONAsPushMessage(jsonMsg []byte) (abios.PushMessage, error) {
	var msg abios.PushMessage
	err := json.Unmarshal(jsonMsg, &msg)
	if err != nil {
		e := fmt.Errorf("Error when unmarshalling incoming json.\nError=%s\nJSON:%d",
			err.Error(), jsonMsg)
		return abios.PushMessage{}, e
	}

	return msg, nil
}

func printJsonWithTag(msg []byte) {

	var o map[string]interface{}
	err := json.Unmarshal(msg, &o)
	if err != nil {
		fmt.Printf("%s [ERROR]: Failed to unmarshal message. Error=%s\nmsg=%+v\n",
			time.Now().Format(TimestampMillisFormat), err.Error(), o)
		return
	}
	if channel, ok := o["channel"].(string); ok {
		if channel != "system" {
			err = unMessage(channel, msg)
			if err != nil {
				fmt.Println("error:"+err.Error(), string(msg))
			}
		}
	}
}

func unMessage(channel string, msg []byte) error {

	var msgResult string
	switch channel {

	case "live_dota":
		//dotaMsg := abios.DOTAAutoGenerated{}
		//err := json.Unmarshal(msg, &dotaMsg)
		//if err != nil {
		//	fmt.Println(err.Error())
		//	return err
		//}
		//marshal, err := json.Marshal(dotaMsg.Payload)
		//if err != nil {
		//	fmt.Println(err.Error())
		//	return err
		//}
		//fmt.Println(string(marshal))

	case "live_lol":
		lolMsg := abios.LOLAutoGenerated{}
		err := json.Unmarshal(msg, &lolMsg)
		if err != nil {
			fmt.Println(err.Error())
			return err
		}

		var (
			killType   string
			killerName string
			killedName string
			matchTime  int
		)

		matchTime = lolMsg.Payload.State.MatchTime // 比赛时长

		for _, kill := range lolMsg.Payload.Kills {
			// 击杀玩家
			killerName = PoolLive.Get(fmt.Sprintf("fusion:player:name:1:%d", kill.KillerID)).Val()
			//死亡玩家 、建筑物 、大型野怪
			if kill.KilledID.Type == "player" {
				killType = "击杀【玩家】"
				killedName = PoolLive.Get(fmt.Sprintf("fusion:player:name:1:%d", kill.KilledID)).Val()
			} else if kill.KilledID.Type == "elite" {
				killType = "击杀【野怪】"
				killedName = LOLEliteVal[kill.KilledID.Subtype]
			} else if kill.KilledID.Type == "structure" {
				killType = "摧毁【建筑物】"
				killedName = LOLEliteVal[kill.KilledID.Subtype]
			}
			msgResult = fmt.Sprintf("时间:%d %s %s %s \n", matchTime, killerName, killType, killedName)
		}

		var ev string
		for _, event := range lolMsg.Payload.Events {
			switch event {
			case "match_ended":
				ev += fmt.Sprintf("比赛结束，比分：%d-%d", lolMsg.Payload.State.Blue.Kills, lolMsg.Payload.State.Red.Kills)
			case "match_started":
				ev += "比赛开始... "
			}
		}
		if len(ev) > 0 {
			msgResult += fmt.Sprintf("事件:%s \n", ev)
		}

		if len(msgResult) > 0 {
			fmt.Printf("LoL[%d]: %s", lolMsg.Payload.State.Series, msgResult)
			_ = MqttNotifyMatchLiveData(lolMsg.Payload.State.Series, msgResult)
		}

	case "live_csgo":
		csgoMsg := abios.CSGOAutoGenerated{}
		err := json.Unmarshal(msg, &csgoMsg)
		if err != nil {
			fmt.Println(err.Error())
			return err
		}

		var (
			killType   string
			killerName string
			killedName string
			round      int
			matchTime  int
		)
		round = csgoMsg.Payload.State.RoundNr
		matchTime = csgoMsg.Payload.State.MatchTime
		for _, kill := range csgoMsg.Payload.Kills {
			killerName = PoolLive.Get(fmt.Sprintf("fusion:player:name:1:%d", kill.KillerID)).Val()
			killedName = PoolLive.Get(fmt.Sprintf("fusion:player:name:1:%d", kill.KilledID)).Val()
			if kill.KillType == "headshot" {
				killType = "【爆头】"
			}
			msgResult = fmt.Sprintf("[第%d回合]剩余时间:%d %s 使用%s 击杀%s%s \n", round, matchTime, killerName, kill.Weapon.Name, killedName, killType)
		}

		var ev string
		for _, event := range csgoMsg.Payload.Events {
			switch event {
			case "match_ended":
				ev += fmt.Sprintf("比赛结束，比分：%d[%s]-%d[%s]", csgoMsg.Payload.State.Left.Score, csgoMsg.Payload.State.Left.Side, csgoMsg.Payload.State.Right.Score, csgoMsg.Payload.State.Right.Side)
			case "round-ended":
				ev += fmt.Sprintf("%s,比分：%d[%s]-%d[%s]", CSGOEventVal[event], csgoMsg.Payload.State.Left.Score, csgoMsg.Payload.State.Left.Side, csgoMsg.Payload.State.Right.Score, csgoMsg.Payload.State.Right.Side)
			default:
				ev += CSGOEventVal[event] + " "
			}
		}
		if len(ev) > 0 {
			msgResult += fmt.Sprintf("[第%d回合]剩余时间:%d, 事件:%s \n", csgoMsg.Payload.State.RoundNr, csgoMsg.Payload.State.MatchTime, ev)
		}

		if len(msgResult) > 0 {
			fmt.Printf("CSGO[%d]: %s", csgoMsg.Payload.State.Series, msgResult)
			_ = MqttNotifyMatchLiveData(csgoMsg.Payload.State.Series, msgResult)
		}

	default:
	}

	return nil
}

func SubscriptionMatchLive() {

	sub := abios.Subscription{
		Name:        "live-series",
		Description: "Listens to all events from series and match channels, for all games account has access to",
		Filters:     []abios.SubscriptionFilter{},
	}
	sub.Filters = append(sub.Filters, abios.SubscriptionFilter{Channel: "live_lol"})
	sub.Filters = append(sub.Filters, abios.SubscriptionFilter{Channel: "live_csgo"})
	conn := startWebSocket(sub)
	go keepAliveLoop(conn)
	go messageReadLoop(conn)
}

package live

import (
	"fmt"

	"autoSettle/helper"
)

const (
	topicMatchLiveData = "/match/live/%d" // 比赛变更滚球状态
)

// mqtt 服务质量参数
const (
	QoSAtMostOnce  = 0 // 最多一次
	QoSAtLeastOnce = 1 // 最少一次
	QoSAlwaysOnce  = 2 // 只一次
)

func mqttNotify(topic string, data interface{}) error {
	payload, err := helper.JsonMarshal(&data)
	if err != nil {
		return err
	}

	if token := MqttLive.Publish(topic, QoSAlwaysOnce, false, payload); token.Wait() && token.Error() != nil {
		return token.Error()
	}

	return nil
}

// 比赛实时数据推送
func MqttNotifyMatchLiveData(matchID int, msg string) error {

	msgID := fmt.Sprintf("%d", helper.Cputicks())
	return mqttNotify(fmt.Sprintf(topicMatchLiveData, matchID), map[string]interface{}{
		"id":       msgID,
		"match_id": matchID,
		"message":  msg,
	})
}

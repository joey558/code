package live

import (
	"fmt"
	"net/url"
	"strings"
	"time"

	"github.com/beanstalkd/go-beanstalk"
	"github.com/panjf2000/ants/v2"
	cpool "github.com/silenceper/pool"
)

type BeansFnParam struct {
	Conn *beanstalk.Conn
	ID   uint64
	M    url.Values
}

type BeansWatcherAttr struct {
	TubeName       string
	ReserveTimeOut time.Duration
	Pool           *ants.PoolWithFunc
}

//beanstalk 通用消费方法
func BeanstalkWatcher(beansPool cpool.Pool, attr BeansWatcherAttr) {

	//循环监听
	for {

		v, err := beansPool.Get()
		if err != nil {
			_ = beansPool.Put(v)
			continue
		}

		if conn, ok := v.(*beanstalk.Conn); ok {

			c := beanstalk.NewTubeSet(conn, attr.TubeName)
			id, msg, err := c.Reserve(attr.ReserveTimeOut)
			//无job时会返回timeout ,不打印日志，不处理
			if err != nil {

				if strings.Contains(err.Error(), "deadline soon") {
					//超时,续期
					_ = conn.Touch(id)
				} else if !strings.Contains(err.Error(), "timeout") {
					fmt.Printf("beanstalk tube: %s reserve error: %s \n",attr.TubeName, err.Error())
				}

				_ = beansPool.Put(v)
				continue
			}

			message := string(msg)
			//记录日志
			fmt.Printf("beanstalk tube: %s msg: %s  running \n",attr.TubeName, message)
			//避免过期，增加续约机制
			_ = conn.Touch(id)
			// 获取参数
			data, err := url.ParseQuery(message)
			if err != nil {
				fmt.Printf("beanstalk tube: %s msg: %s parse error, deleted!!! err: %s \n",attr.TubeName, message, err.Error())
				_ = conn.Delete(id)
				_ = beansPool.Put(v)
				continue
			}

			fn := BeansFnParam{
				Conn: conn,
				ID:   id,
				M:    data,
			}

			// 注单自动确认
			if err := attr.Pool.Invoke(fn); err != nil {
				fmt.Printf("beanstalk invoke error: %s \n", err.Error())
				_ = beansPool.Put(v)
				continue
			}
		}

		_ = beansPool.Put(v)
	}
}

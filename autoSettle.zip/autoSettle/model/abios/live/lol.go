package live

var LOLEliteVal = map[string]string{
	"Air Dragon":   "风龙",
	"Water Dragon": "水龙",
	"Fire Dragon":  "火龙",
	"Baron Nashor": "男爵",
	"Earth Dragon": "土龙",
	"Inhibitor":    "水晶",
	"Turret":       "防御塔",
	"Rift Herald":  "峡谷先锋",
}

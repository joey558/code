package live

var CSGOEventVal = map[string]string{
	"match_started":      "比赛开始...",
	"match_ended":        "比赛结束",
	"bomb-planted":       "C4炸弹安放",
	"round-started":      "回合开始",
	"round-ended":        "回合结束",
	"target-bombed":      "C4爆炸",
	"bomb-defused":       "C4被拆除",
	"timeout":            "加时",
	"t_eliminated":       "恐怖分子被消灭",
	"ct_eliminated":      "反恐精英被消灭",
	"unknown-win-reason": "未知获胜原因",
}

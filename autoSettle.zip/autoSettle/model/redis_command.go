package model

// Redis KEY 统一定义在这里
const (
	// 数据源游戏ID和本地游戏ID关联: 数据源标识:数据源ID
	RedisKeyGameFusion    = "fusion:gm:%d:%d"
	// 数据源联赛ID和本地联赛ID关联: 数据源标识:数据源ID
	RedisKeyTournamentFusion    = "fusion:tmt:%d:%d"
	// 数据源战队ID和本地游戏ID关联: 数据源标识:数据源ID
	RedisKeyTeamFusion    = "fusion:tm:%d:%d"
	// 数据源选手ID和本地游戏ID关联: 数据源标识:数据源ID
	RedisKeyPlayerFusion    = "fusion:player:%d:%d"
	// 数据源联赛名: 数据源标识:数据源ID
	RedisKeyGameName = "fusion:gm:name:%d:%d"
	// 数据源联赛名: 数据源标识:数据源ID
	RedisKeyTournamentName = "fusion:tmt:name:%d:%d"
	// 数据源战队名: 数据源标识:数据源ID
	RedisKeyTeamName = "fusion:tm:name:%d:%d"
	// 数据源选手名(昵称): 数据源标识:数据源ID
	RedisKeyPlayerName = "fusion:player:name:%d:%d"
	// 数据源比赛ID和本地比赛ID关联: 数据源标识:数据源ID
	RedisKeyMatchFusion    = "fusion:mch:%d:%d"
	// Odds数据源根据联赛ID获取游戏ID
	RedisKeyOddTournamentGameID = "fusion:tmt:gm:%d"
	// 数据源盘口ID和本地盘口ID关联: 数据源标识:数据源ID
	RedisKeyMarketFusion    = "fusion:mkt:%d:%d"
	// 数据源投注项ID和本地投注项ID关联: 数据源标识:数据源ID
	RedisKeyOddFusion    = "fusion:odd:%d:%d"
)

// 公用哈希获取
func RedisHMGet(keyName string, fields []string) (map[string]string, error) {

	total := len(fields)
	data := map[string]string{}
	value, err := Pool.HMGet(keyName, fields...).Result()
	if err != nil {
		return data, err
	}

	for i := 0; i < total; i++ {
		// 取出interface{}类型数据，转换时类型断言
		if v, ok := value[i].(string); ok {
			data[fields[i]] = v
		} else {
			data[fields[i]] = ""
		}
	}

	return data, nil
}

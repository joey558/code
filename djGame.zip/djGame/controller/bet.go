package controller

import (
	"errors"
	"fmt"
	"game/contrib/session"
	"game/contrib/zlog"
	"game/helper"
	"game/lang"
	"game/mRejson"
	"game/model"
	"game/utils"
	fund "game/wallet"
	"net/url"
	"sort"
	"strconv"
	"strings"
	"time"

	g "github.com/doug-martin/goqu/v9"
	"github.com/scylladb/go-set/strset"
	"github.com/shopspring/decimal"
	"github.com/valyala/fasthttp"
)

type BetOrderController struct{}

func checkScope(str string, min, max uint32) (uint32, bool) {

	v, err := strconv.ParseUint(str, 10, 32)
	if err != nil {
		return 0, false
	}

	val := uint32(v)
	if val < min {
		return val, false
	}

	if val > max {
		return val, false
	}

	return val, true
}

// 单注校验
func checkSimpleBetValid(member fund.Member, simples []*model.SimpleBetContent, res utils.HandicapData, lan string) error {

	var (
		oddDeci decimal.Decimal
		err     error
	)
	for i, v := range simples {
		oddDeci, err = checkBetValid(member, v.Data, res, v.Flags, lan)
		if err != nil {
			return err
		}
		simples[i].Data.Odd = oddDeci
	}

	return nil
}

// 串注校验
func checkComplexBetValid(member fund.Member, comps []*model.ComplexBetContent, res utils.HandicapData, lan string) error {

	var (
		err     error
		ok      bool
		mkt     utils.MarketData
		oddDeci decimal.Decimal
	)

	for i, v := range comps {
		if len(v.Data) < 2 || v.ParleyType < 2 {
			return errors.New(lang.Text(lan, "msgLeastTwoHandicap"))
		}
		complexRds := map[int]int8{}
		complexOddTypes := map[string]int8{}
		complexOddTypeTag := map[string]int8{}
		for j, vv := range v.Data {
			oddDeci, err = checkBetValid(member, vv, res, v.Flags, lan)
			if err != nil {
				return err
			}

			// 局内串关校验
			if v.Flags == model.OrderTypeRoundComplex {
				mkt = res.Markets[vv.MarketID]
				if mkt.Round == 0 {
					return errors.New(lang.Text(lan, "msgGlobalHandicapNoSeries"))
				}
				if len(complexRds) > 0 {
					if _, ok = complexRds[mkt.Round]; !ok {
						return errors.New(lang.Text(lan, "msgDifferentRoundNoSeries"))
					}
				}
				if _, ok = complexOddTypes[mkt.OddTypeID]; ok {
					return errors.New(lang.Text(lan, "msgSameRoundSameNameNoSeries"))
				}

				// 相同类型盘口标签 效验
				if mkt.Tag != "0" {
					if _, ok = complexOddTypeTag[mkt.Tag]; ok {
						return errors.New(lang.Text(lan, "msgSameRoundSameSeriesOnlyOne"))
					}
					complexOddTypeTag[mkt.Tag] = 1
				}
				complexRds[mkt.Round] = 1
				complexOddTypes[mkt.OddTypeID] = 1
			}
			// 设置串注子单最新赔率
			comps[i].Data[j].Odd = oddDeci
		}
	}

	return nil
}

// 投注信息校验
func checkBetValid(member fund.Member, content model.BetContent, res utils.HandicapData, orderType int, lan string) (decimal.Decimal, error) {

	ok := false
	mch := utils.MatchData{}
	// 赛事不存在
	if mch, ok = res.Matches[content.MatchID]; !ok {
		return content.Odd, errors.New(lang.Text(lan, "msgMatchInvalid"))
	}
	// 信用网暂时关闭FIFA和NBA2k游戏的投注
	if member.Tester == model.UserTypeCredit {
		for _, gmID := range model.MTGet().Config.Credit.DisableGame {
			if mch.GameID == gmID {
				return content.Odd, errors.New(lang.Text(lan, "msgGameMaintenance"))
			}
		}
	}

	// 赛事未开赛
	if mch.Status != 5 {
		return content.Odd, errors.New(lang.Text(lan, "msgMatchNotStarted"))
	}
	// 赛事暂停状态判断
	if mch.Suspended != 0 {
		return content.Odd, errors.New(lang.Text(lan, "msgMatchSuspended"))
	}
	// 赛事显示隐藏判断
	if mch.Visible != 1 || mch.IsOpenMatch == 0 {
		return content.Odd, errors.New(lang.Text(lan, "msgMatchInvalid"))
	}
	mkt := utils.MarketData{}
	// 盘口不存在
	if mkt, ok = res.Markets[content.MarketID]; !ok {
		return content.Odd, errors.New(lang.Text(lan, "msgHandicapAbsence"))
	}
	// 盘口未开盘
	if mkt.Status != 6 {
		return content.Odd, errors.New(lang.Text(lan, "msgHandicapNotOpen"))
	}
	// 盘口暂停状态判断
	if mkt.Suspended != 0 {
		return content.Odd, errors.New(lang.Text(lan, "msgHandicapSuspended"))
	}
	// 盘口显示隐藏判断
	if mkt.Visible != 1 {
		return content.Odd, errors.New(lang.Text(lan, "msgHandicapAbsence"))
	}
	// 盘口赛事id错误,盘口不属于当前赛事
	if mkt.MatchID != mch.ID {
		return content.Odd, errors.New(lang.Text(lan, "msgHandicapAbsence"))
	}
	odd := utils.OddData{}
	// 盘口投注项不存在
	if odd, ok = res.Odds[content.Oid]; !ok {
		return content.Odd, errors.New(lang.Text(lan, "msgHandicapAbsence"))
	}
	// 盘口投注项隐藏
	if odd.Visible != 1 {
		return content.Odd, errors.New(lang.Text(lan, "msgHandicapAbsence"))
	}
	if odd.MarketID != content.MarketID {
		return content.Odd, errors.New(lang.Text(lan, "msgBetNotMatchHandicap"))
	}

	if len(mch.SID) > 0 && mch.SID != "0" {
		if member.Tester != model.UserTypeNormal {
			// 体育赛事，只能正常用户投注
			return content.Odd, errors.New(lang.Text(lan, "msgGameMaintenance"))
		}

		// 体育赛事需要判断上一个注单的状态
		redisKey := fmt.Sprintf(model.RedisMTSBetLock, member.UID)
		bExists, err := model.RedisKeyExists(redisKey)
		if err != nil {
			return content.Odd, err
		}

		if bExists {
			return content.Odd, errors.New(lang.Text(lan, "msgLastBetConfirmed"))
		}
	}

	switch orderType {
	case model.OrderTypeSimple:
		if res.Markets[content.MarketID].OptionType == model.OptionTypeMix {
			return content.Odd, errors.New(lang.Text(lan, "errMixBetOrderType"))
		}
	case model.OrderTypeComplex: //是否支持串注校验
		if res.Matches[content.MatchID].IsPassOff == model.MatchSimple {
			return content.Odd, errors.New(lang.Text(lan, "msgHaveNonSeriesMatch"))
		}

		if mch.IsPassOff == model.MatchSimple {
			return content.Odd, errors.New(lang.Text(lan, "msgIncNonMatch"))
		}

		if mkt.IsPassOff == model.MatchSimple {
			return content.Odd, errors.New(lang.Text(lan, "msgIncNonHandicap"))
		}

		if res.Markets[content.MarketID].OptionType == model.OptionTypeMix {
			return content.Odd, errors.New(lang.Text(lan, "msgMixNonSeries"))
		}
	case model.OrderTypeRoundComplex: // 是否支持局内串关
		if res.Matches[content.MatchID].IsPassOff != model.MatchRoundComplex {
			return content.Odd, errors.New(lang.Text(lan, "msgMatchNonRoundSeries"))
		}

		if mch.IsPassOff != model.MatchRoundComplex {
			return content.Odd, errors.New(lang.Text(lan, "msgIncNonRoundSeriesMatch"))
		}

		if mkt.IsPassOff != model.MatchRoundComplex {
			return content.Odd, errors.New(lang.Text(lan, "msgIncNonRoundSeriesHandicap"))
		}
		if res.Markets[content.MarketID].OptionType == model.OptionTypeMix {
			return content.Odd, errors.New(lang.Text(lan, "msgMixNonRoundSeries"))
		}
	case model.OrderTypeMix:
		if res.Markets[content.MarketID].OptionType != model.OptionTypeMix {
			return content.Odd, errors.New(lang.Text(lan, "msgBetOrderNonMix"))
		}
	}

	// 盘口投注项赔率错误
	oddDecimal, err := decimal.NewFromString(odd.Odd)
	if err != nil {
		return content.Odd, errors.New(lang.Text(lan, "errOdds"))
	}
	// 客户端赔率与服务器最新赔率不一致时
	// 会员设置自动接受最新赔率，使用服务器最新赔率
	// 局内串关注单永远使用服务器最新赔率
	if !oddDecimal.Equal(content.Odd) && member.OddUpdateType != 1 && orderType != model.OrderTypeRoundComplex {
		// 会员设置自动接受更高赔率，如果客户端赔率比服务器赔率小，则使用更高的服务器最新赔率
		if member.OddUpdateType == 2 {
			if content.Odd.LessThan(oddDecimal) {
				return oddDecimal, nil
			} else {
				return content.Odd, errors.New(lang.Text(lan, "errOdds"))
			}
		} else {
			return content.Odd, errors.New(lang.Text(lan, "errOdds"))
		}
	} else {
		return oddDecimal, nil
	}
}

//单注
func simpleBet(m url.Values, flag int, lan string) (model.SimpleBetContent, error) {

	var err error
	data := model.SimpleBetContent{
		Flags: flag,
	}
	if _, err = strconv.ParseUint(m.Get("mch"), 10, 64); err == nil {
		data.Data.MatchID = m.Get("mch")
	} else {
		return data, err
	}

	if _, err = strconv.ParseUint(m.Get("mkt"), 10, 64); err == nil {
		data.Data.MarketID = m.Get("mkt")
	} else {
		return data, err
	}

	if _, err = strconv.ParseUint(m.Get("oid"), 10, 64); err == nil {
		data.Data.Oid = m.Get("oid")
	} else {
		return data, err
	}

	data.Data.Odd, err = decimal.NewFromString(m.Get("odd"))
	if err != nil {
		return data, err
	}
	data.Data.OrgOdd = data.Data.Odd

	data.Amount, err = decimal.NewFromString(m.Get("a"))
	if err != nil {
		return data, errors.New(lang.Text(lan, "errAmount"))
	}

	data.Data.ScoreBenchmark = m.Get("score_benchmark")

	return data, nil
}

//串关
func complexBet(m url.Values, flag int, lan string) (model.ComplexBetContent, error) {

	var (
		err error
		t   int
	)
	complexMchs := map[string]int8{}

	data := model.ComplexBetContent{
		Flags: flag,
	}
	data.Amount, err = decimal.NewFromString(m.Get("a"))
	if err != nil {
		return data, errors.New(lang.Text(lan, "errAmount"))
	}

	b := m.Get("b")
	if t, err = strconv.Atoi(m.Get("t")); err != nil {
		return data, err
	}

	if t > model.ParleyTypeMaxValue {
		return data, errors.New(lang.Text(lan, "msgExceedSeries"))
	}

	bs := strings.Split(b, "|")
	if len(bs) != t {
		return data, errors.New(lang.Text(lan, "errParlay"))
	}

	num, err := strconv.Atoi(m.Get("num"))
	if err != nil {
		return data, err
	}

	data.ParleyType = t
	data.ParleyNum = num
	for _, v := range bs {
		bc := strings.Split(v, ",")
		if len(bc) != 4 {
			return data, errors.New(lang.Text(lan, "errParlay"))
		}
		if !helper.CtypeDigit(bc[0]) {
			return data, errors.New(lang.Text(lan, "errParlay"))
		}
		if !helper.CtypeDigit(bc[1]) {
			return data, errors.New(lang.Text(lan, "errParlay"))
		}
		if !helper.CtypeDigit(bc[2]) {
			return data, errors.New(lang.Text(lan, "errParlay"))
		}
		if flag == model.OrderTypeComplex {
			// 非法注单校验
			if _, ok := complexMchs[bc[0]]; ok {
				return data, errors.New(lang.Text(lan, "msgNoSameMatchDiffHandicap"))
			}
		}

		complexMchs[bc[0]] = 1

		content := model.BetContent{
			MatchID:  bc[0],
			MarketID: bc[1],
			Oid:      bc[2],
		}
		content.Odd, err = decimal.NewFromString(bc[3])
		if err != nil {
			return data, err
		}
		content.OrgOdd = content.Odd
		data.Data = append(data.Data, content)
	}

	// 局内串关非法注单校验
	if flag == model.OrderTypeRoundComplex && len(complexMchs) > 1 {
		return data, errors.New(lang.Text(lan, "msgRoundOnlyOneMatch"))
	}

	return data, nil
}

// 解析请求参数，获取单注和串关
func parseBetContent(str, lan string) (interface{}, int, error) {

	if str == "" {
		return nil, 0, errors.New("bet empty")
	}

	m, err := url.ParseQuery(str)
	if err != nil {
		return nil, 0, err
	}

	_, err = strconv.ParseInt(m.Get("a"), 10, 64)
	if err != nil {
		return nil, 0, errors.New(lang.Text(lan, "errAmount"))
	}

	flag, err := strconv.Atoi(m.Get("bt"))
	if err != nil {
		return nil, 0, err
	}
	if flag == model.OrderTypeSimple || flag == model.OrderTypeMix {
		res, err := simpleBet(m, flag, lan)
		if err != nil {
			return nil, 0, err
		}

		return res, flag, err

	} else if flag == model.OrderTypeComplex || flag == model.OrderTypeRoundComplex {
		res, err := complexBet(m, flag, lan)
		if err != nil {
			return nil, 0, err
		}

		return res, flag, err
	}

	return nil, 0, errors.New("flag error")
}

//判断赛事风险标签ID,是否包括会员的风险标签ID
func checkMatchRiskTagId(riskTagId string, handicapData utils.HandicapData) string {

	for _, mch := range handicapData.Matches {
		var (
			riskTagSlice []string
		)
		riskTagIds, _ := model.MatchRiskTagIdGet(mch.ID)
		if len(riskTagIds) > 0 {
			riskTagSlice = strings.Split(riskTagIds, ",")
			for _, tagId := range riskTagSlice {
				if riskTagId == tagId {
					return mch.ID
				}
			}
			return ""
		}
	}
	return ""
}

func (that *BetOrderController) Bet(ctx *fasthttp.RequestCtx) {

	lan := string(ctx.Request.Header.Peek("lang"))

	//获取用户信息
	member, err := model.GetTokenData(ctx)
	if err != nil {
		helper.Print(ctx, "false", lang.Text(lan, "msgBetFail")+err.Error())
		return
	}

	// 同一个用户ID，限制同时投注
	userLockKey := fmt.Sprintf("%s%d", model.UserBetRedisKey, member.UID)
	err = model.Lock(userLockKey, 60*time.Second)
	if err != nil {
		helper.Print(ctx, "false", lang.Text(lan, "msgSubmitOften"))
		return
	}
	defer model.UnLock(userLockKey)

	c := string(ctx.PostArgs().Peek("c"))          // 注数
	d := string(ctx.Request.Header.Peek("device")) // 设备

	// TODO 串注复式，最大单数 56 + 单注自定义投注，30 可能不够
	total, ok := checkScope(c, 1, 66)
	if !ok {
		helper.Print(ctx, "false", lang.Text(lan, "errBetCount"))
		return
	}

	device, ok := checkScope(d, 1, 4)
	if !ok {
		helper.Print(ctx, "false", lang.Text(lan, "msgIllegalDevice"))
		return
	}

	//用戶IP获取及校验
	clientIP := helper.FromRequest(ctx)
	ips := strings.Split(clientIP, ",")
	ipLen := len(ips)
	if ipLen > 1 {
		clientIP = strings.TrimSpace(ips[ipLen-1])
	}
	ip, err := helper.Ip2long(clientIP)
	if err != nil {
		fmt.Printf("Ip2long fail, ip:%s, remoteAddr:%s error:%s\n", clientIP, ctx.RemoteAddr().String(), err.Error())
		helper.Print(ctx, "false", lang.Text(lan, "msgBetFail")+err.Error())
		return
	}

	var (
		oddIds    *strset.Set
		matchIds  *strset.Set
		marketIds *strset.Set
		simples   []*model.SimpleBetContent
		comps     []*model.ComplexBetContent
	)
	isDuplexMap := map[int]int{}
	prizeTotal := map[string]decimal.Decimal{}

	exchangeRate := decimal.NewFromInt(1)
	if member.CurrencyCode != model.DefaultCurrencyCode && member.CurrencyCode != 0 {
		r, err := model.GetRate(member.CurrencyCode)
		if err != nil {
			helper.Print(ctx, "false", lang.Text(lan, "msgBetFail")+err.Error())
			return
		}

		exchangeRate = decimal.NewFromFloat(r)
	}
	ratef, _ := exchangeRate.Float64()
	if member.ParentMerchantID == 0 {
		helper.Print(ctx, "false", lang.Text(lan, "msgLackBetPriv"))
		return
	}

	//商户校验
	merch, err := model.MerchantFindOne(member.MerchantID)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	if merch.Status == 0 {
		helper.Print(ctx, "false", lang.Text(lan, "msgMerchantInactive"))
		return
	}

	//投注是否开启校验
	allow, err := model.RiskBetLockCheck()
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}
	if !allow {
		helper.Print(ctx, "false", lang.Text(lan, "msgPlatformMaintenance"))
		return
	}

	oddIds = strset.NewWithSize(10)
	matchIds = strset.NewWithSize(10)
	marketIds = strset.NewWithSize(10)
	mpMatchMarketID := map[string]string{}

	defer func() {
		oddIds.Clear()
		matchIds.Clear()
		marketIds.Clear()
	}()

	//读取风控基本参数
	risks, err := model.GetRiskSetting(0, model.RedisBasicSettingsForRisk, lan, model.RiskSettingFields)
	if err != nil {
		helper.Print(ctx, "false", lang.Text(lan, "msgBetFail")+err.Error())
		return
	}

	var (
		theoryPrize          decimal.Decimal //预期派彩金额(理论奖金)
		simpleRiskFlag       bool            //单注风控标识
		complexRiskFlag      bool            //串注风控标识
		roundComplexRiskFlag bool            //局内串关风控标识
		agent                mRejson.AgentCache
		memberRiskStatus     bool
		betType              int // 投注类型
		keyCountMap          = make(map[string]int)
		limitVal             model.MarketRiskLimit
	)

	cost := decimal.NewFromInt(0)
	for i := uint32(0); i < total; i++ {
		key := fmt.Sprintf("b[%d]", i)
		val := string(ctx.PostArgs().Peek(key))
		// 解析注单数据
		content, flag, err := parseBetContent(val, lan)
		if err != nil {
			helper.Print(ctx, "false", err.Error())
			return
		}

		// 现在同一次投注只能是相同的投注类型
		if betType != 0 && betType != flag {
			helper.Print(ctx, "false", lang.Text(lan, "errBetData"))
			return
		}
		betType = flag
		switch flag {
		case model.OrderTypeSimple, model.OrderTypeMix:
			if total > 1 {
				helper.Print(ctx, "false", lang.Text(lan, "errBetCount"))
				return
			}
			minBet := risks["simple_min_bet"].Mul(exchangeRate).Ceil()
			s := content.(model.SimpleBetContent)
			//单注最低投注校验
			if minBet.GreaterThan(s.Amount) {
				helper.Print(ctx, "false", fmt.Sprintf(lang.Text(lan, "msgMinBet"), minBet.String()))
				return
			}
			simples = append(simples, &s)
			cost = cost.Add(s.Amount)
			oddIds.Add(s.Data.Oid)
			matchIds.Add(s.Data.MatchID)
			marketIds.Add(s.Data.MarketID)
			mpMatchMarketID[s.Data.MarketID] = s.Data.MatchID
			// 是否需要单注风控
			if !simpleRiskFlag {
				simpleRiskFlag = true
			}
		case model.OrderTypeComplex, model.OrderTypeRoundComplex:
			c := content.(model.ComplexBetContent)
			minBet := risks["complex_min_bet"].Mul(exchangeRate).Ceil()
			//串注最低投注校验
			if minBet.GreaterThan(c.Amount) {
				helper.Print(ctx, "false", fmt.Sprintf(lang.Text(lan, "msgMinBet"), minBet.String()))
				return
			}

			comps = append(comps, &c)
			if c.ParleyNum > 1 {
				if _, ok := isDuplexMap[c.ParleyNum]; !ok {
					isDuplexMap[c.ParleyNum] = c.ParleyType
				}
				if isDuplexMap[c.ParleyNum] < c.ParleyType {
					isDuplexMap[c.ParleyNum] = c.ParleyType
				}
			}
			cost = cost.Add(c.Amount)
			arrKey := []string{}

			for _, v := range c.Data {
				oddIds.Add(v.Oid)
				matchIds.Add(v.MatchID)
				marketIds.Add(v.MarketID)
				mpMatchMarketID[v.MarketID] = v.MatchID

				arrKey = append(arrKey, fmt.Sprintf("%s_%s_%s", v.MatchID, v.MarketID, v.Oid))
			}

			// arrKey排序
			sort.Slice(arrKey, func(i, j int) bool {
				return arrKey[j] > arrKey[i]
			})
			countKey := helper.GetMD5Hash(strings.Join(arrKey, "_"))
			count := keyCountMap[countKey] + 1

			complexRiskFlag = true
			if flag == model.OrderTypeRoundComplex { // 是否需要局内串关风控
				// 局内串关：组合键最多只能出现1次
				if count > 1 {
					helper.Print(ctx, "false", lang.Text(lan, "errBetCount"))
					return
				}

				roundComplexRiskFlag = true
			}

			// 赛事串关：组合键最多只能出现2次
			if flag == model.OrderTypeComplex && count > 2 {
				helper.Print(ctx, "false", lang.Text(lan, "errBetCount"))
				return
			}
			keyCountMap[countKey] = count
		}
	}

	// 获取盘口信息
	handicapInfo, err := model.HandicapInfo(mpMatchMarketID)
	if err != nil {
		helper.Print(ctx, "false", lang.Text(lan, "msgBetFail")+err.Error())
		return
	}

	// 判断注单是否有被过滤的游戏
	err = model.CheckBetFilterGame(member.MerchantID, handicapInfo, lan)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	// 检查提交上来的单注盘口信息准确性
	err = checkSimpleBetValid(member, simples, handicapInfo, lan)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	// 检查提交上来的串注盘口信息准确性
	err = checkComplexBetValid(member, comps, handicapInfo, lan)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	//查找ID的风险会员
	riskTagMatchId := ""
	riskTagId := ""
	bSportsGame := false
	if len(handicapInfo.Matches) == 1 {
		riskTagId, err = model.GetRiskMemberTagId(member.UID)
		if err != nil {
			helper.Print(ctx, "false", err.Error())
			return
		}

		//判断该赛事的风险标签,是否含有会员风险标签
		if riskTagId != "" {
			riskTagMatchId = checkMatchRiskTagId(riskTagId, handicapInfo)
		}
	}

	for _, mch := range handicapInfo.Matches {
		bSportsGame = utils.CheckSportsGameID(mch.GameID)
		break
	}

	// 校验重复提交
	exist := model.BetHashExists(ctx, member, simples, comps)
	if exist {
		helper.Print(ctx, "false", lang.Text(lan, "msgNoSubmitTwice"))
		return
	}

	// 余额不足
	_, enough := model.BetBalanceCheck(member, cost)
	if !enough {
		helper.Print(ctx, "false", lang.Text(lan, "msgLackBalance"))
		return
	}

	if member.Tester == model.UserTypeNormal {
		// 投注风控
		if !bSportsGame { //非虚拟体育
			limitVal, err = riskChange(member, matchIds, marketIds, simpleRiskFlag, complexRiskFlag, roundComplexRiskFlag, risks, comps, simples, handicapInfo, exchangeRate, lan)
			if err != nil {
				helper.Print(ctx, "false", err.Error())
				return
			}
		}
	} else if member.Tester == model.UserTypeCredit {
		agent, err = model.GetAgent(member.AgentID)
		if err != nil {
			helper.Print(ctx, "false", err.Error())
			return
		}

		memberRiskStatus, err = model.GetMemberLimitStatus(member.UID)
		if err != nil {
			helper.Print(ctx, "false", err.Error())
			return
		}
	}

	simpleMp := map[uint64]g.Record{}                // 单注注单
	complexMp := map[uint64]g.Record{}               // 串关注单
	compDetailMp := map[uint64]map[uint64]g.Record{} // 串关注单详情
	transfers := map[uint64]model.BetTransfer{}      // 账变参数
	delay := map[uint64]model.OrderDelay{}           // 滚盘注单
	defaultMarket := map[interface{}]int{}
	orderOptionType := map[uint64]int{}                       // 注单玩法类型
	creditSimpleSum := map[string]decimal.Decimal{}           //信用盘单注注单金额统计
	creditComplexSum := map[string]decimal.Decimal{}          //信用盘串注注单金额统计
	mchMixGlobalTotal := map[string]decimal.Decimal{}         // 复合玩法赛事全局赔付统计
	mchRandGlobalTotal := map[string]decimal.Decimal{}        // 局内玩法赛事全局赔付统计
	mchCompGlobalTotal := map[string]decimal.Decimal{}        // 普通赛事串注全局赔付统计
	mchGlobalTotal := map[string]decimal.Decimal{}            // 赛事全局赔付统计
	mktGlobalTotal := map[string]map[string]decimal.Decimal{} // 盘口全局赔付统计
	additionalMap := map[uint64]model.BetAdditionalInfo{}

	dailyTotal, err := model.GetMemberDailyTotal(member.MerchantID, member.UID)
	if err != nil {
		helper.Print(ctx, "false", lang.Text(lan, "msgGetDailyTotalError")+err.Error())
		return
	}

	// 只有单注和复合玩法时，才会统计操盘货量，才需要用到会员藏单值
	hideAmountRate := model.GetHideAmountRate(member)
	decHideAmountRate := decimal.NewFromFloat(hideAmountRate)

	var match utils.MatchData
	for _, v := range simples {
		//信用盘单注限额校验
		if member.Tester == model.UserTypeCredit {
			if memberRiskStatus || agent.LimitMode != 0 {
				// 投注风控
				_, err = riskChange(member, matchIds, marketIds, simpleRiskFlag, complexRiskFlag, roundComplexRiskFlag, risks, comps, simples, handicapInfo, exchangeRate, lan)
				if err != nil {
					helper.Print(ctx, "false", err.Error())
					return
				}
			}

			if v.Flags == model.OrderTypeSimple {
				err = (&model.CreditLimit{}).CheckCreditSimpleLimit(ctx.ID(), agent.ID, member.UID, v.Data.MatchID, v.Data.MarketID, lan, v.Data.Odd, handicapInfo, v.Amount, exchangeRate, creditSimpleSum)
				if err != nil {
					helper.Print(ctx, "false", err.Error())
					return
				}

			} else {
				parleyType := handicapInfo.Markets[v.Data.MarketID].CompSubNum
				err = (&model.CreditLimit{}).CheckCreditComplexLimit(ctx.ID(), agent.ID, member.UID, parleyType, v.Amount, v.Data.Odd, exchangeRate, creditComplexSum, lan)
				if err != nil {
					helper.Print(ctx, "false", err.Error())
					return
				}
			}
		}

		orderID := helper.GenId()
		match = handicapInfo.Matches[v.Data.MatchID]

		// 调用体育赛事限红
		oddTypeID := handicapInfo.Markets[v.Data.MarketID].OddTypeID
		err = model.TYCheckLimit(member.UID, member.Account, match.SID, v.Data.MarketID, v.Data.Oid, oddTypeID, bSportsGame, match.IsLive, v.Amount, exchangeRate, lan)
		if err != nil {
			helper.Print(ctx, "false", err.Error())
			return
		}

		theoryPrize = v.Amount.Mul(v.Data.Odd)
		var (
			oddCnName string
			oddEnName string
		)
		oddCnName = handicapInfo.Odds[v.Data.Oid].Name
		oddEnName = handicapInfo.Odds[v.Data.Oid].EnName
		if handicapInfo.Markets[v.Data.MarketID].OptionType == model.OptionTypePlayerHandicap ||
			handicapInfo.Markets[v.Data.MarketID].OptionType == model.OptionTypeHeroHandicap { //队员让分 英雄让分
			oddCnName = strings.Replace(oddCnName, "$$", " ", 1)
			oddEnName = strings.Replace(oddEnName, "$$", " ", 1)
		}
		order := g.Record{
			"id":                      orderID,
			"member_id":               member.UID,
			"member_account":          member.Account,
			"merchant_id":             member.MerchantID,
			"merchant_account":        member.MerchantAccount,
			"parent_merchant_id":      member.ParentMerchantID,
			"parent_merchant_account": member.ParentMerchantAccount,
			"top_merchant_id":         member.TopMerchantId,
			"top_merchant_account":    member.TopMerchantAccount,
			"sort_level":              member.SortLevel,
			"deph":                    member.Deph,
			"game_id":                 match.GameID,
			"tournament_id":           match.TournamentID,
			"match_id":                v.Data.MatchID,
			"market_id":               v.Data.MarketID,
			"odd_id":                  v.Data.Oid,
			"org_odd_id":              handicapInfo.Markets[v.Data.MarketID].OddTypeID,
			"odd":                     handicapInfo.Odds[v.Data.Oid].Odd,
			"org_odd":                 handicapInfo.Odds[v.Data.Oid].Odd,
			"odd_name":                oddCnName,
			"odd_en_name":             oddEnName,
			"odd_discount":            1,
			"bet_amount":              v.Amount.String(),
			"win_amount":              "0",
			"theory_prize":            utils.TrimDecimal(theoryPrize),
			"bet_time":                g.L("UNIX_TIMESTAMP(NOW(3))*1000"),
			"device":                  device,
			"order_type":              v.Flags,
			"bet_ip":                  ip,
			"is_live":                 match.IsLive,
			"market_cn_name":          handicapInfo.Markets[v.Data.MarketID].CnName,
			"market_en_name":          handicapInfo.Markets[v.Data.MarketID].EnName,
			"match_start_time":        match.StartTime,
			"parley_type":             1,
			"confirm_type":            1,
			"match_type":              match.Category,
			"round":                   handicapInfo.Markets[v.Data.MarketID].Round,
			"team_names":              match.MatchTeam,
			"team_cn_names":           match.MatchCnTeam,
			"team_en_names":           match.MatchEnTeam,
			"team_id":                 match.TeamID,
			"tester":                  member.Tester,
			"update_time":             time.Now().Unix(),
			"settle_time":             0,
			"settle_count":            0,
			"risk_tag_id":             0, //风险标签ID
			"ty_match_sid":            match.SID,
			"score_benchmark":         v.Data.ScoreBenchmark,
			"currency_code":           member.CurrencyCode,
			"exchange_rate":           ratef,
			"hide_amount_rate":        hideAmountRate,
			"batch_no":                match.BatchNo,
			"round_no":                match.RoundNo,
		}

		if handicapInfo.Markets[v.Data.MarketID].IsDefault == 1 {
			defaultMarket[v.Data.MarketID] = 1
		}
		if member.Tester == model.UserTypeCredit {
			order["agent_id"] = member.AgentID
			order["agent_account"] = member.AgentAccount
		}
		if riskTagId != "" {
			order["risk_tag_id"] = riskTagId
		}

		if v.Flags == model.OrderTypeMix {
			order["odd_discount"] = utils.TrimDecimal(decimal.NewFromFloat(match.MixOddDscnt).Div(model.DeciHundred))
			order["parley_type"] = handicapInfo.Markets[v.Data.MarketID].CompSubNum
			subMktIDs := strings.Split(handicapInfo.Markets[v.Data.MarketID].SubMktID, ",")
			subOddIDs := strings.Split(handicapInfo.Markets[v.Data.MarketID].SubOddID, ",")
			if len(subMktIDs) != len(subOddIDs) {
				helper.Print(ctx, "false", lang.Text(lan, "errHandicap"))
				return
			}

			var subOdd utils.OddData
			oddSum := decimal.Decimal{}
			mixOddMap := map[uint64]decimal.Decimal{}
			detail := map[uint64]g.Record{}
			for i, mktID := range subMktIDs {
				subMktOddIDs := strings.Split(subOddIDs[i], "|")
				if len(subMktOddIDs) < 2 {
					helper.Print(ctx, "false", lang.Text(lan, "errHandicap"))
					return
				}
				if subOdd, ok = handicapInfo.Odds[subMktOddIDs[handicapInfo.Odds[v.Data.Oid].SortID]]; !ok {
					fmt.Printf("match[%s] mix market[%s]. odd[%s] not exist! \n", match.ID, mktID, subMktOddIDs[handicapInfo.Odds[v.Data.Oid].SortID])
					helper.Print(ctx, "false", lang.Text(lan, "errHandicap"))
					return
				}

				odId := helper.GenId()
				mixOd := g.Record{
					"id":               odId,
					"order_id":         orderID,
					"member_id":        member.UID,
					"member_account":   member.Account,
					"game_id":          match.GameID,
					"tournament_id":    match.TournamentID,
					"match_id":         match.ID,
					"market_id":        mktID,
					"odd_id":           subOdd.ID,
					"org_odd_id":       handicapInfo.Markets[mktID].OddTypeID,
					"odd_name":         subOdd.Name,
					"odd_en_name":      subOdd.EnName,
					"odd":              subOdd.Odd,
					"bet_time":         g.L("UNIX_TIMESTAMP(NOW(3))*1000"),
					"is_live":          match.IsLive,
					"market_en_name":   handicapInfo.Markets[mktID].EnName,
					"market_cn_name":   handicapInfo.Markets[mktID].CnName,
					"match_start_time": match.StartTime,
					"match_type":       match.Category,
					"round":            handicapInfo.Markets[mktID].Round,
					"team_names":       match.MatchTeam,
					"team_cn_names":    match.MatchCnTeam,
					"team_en_names":    match.MatchEnTeam,
					"team_id":          match.TeamID,
					"update_time":      time.Now().Unix(),
					"status":           1,
					"flag":             1,
					"currency_code":    member.CurrencyCode,
					"exchange_rate":    ratef,
				}

				detail[odId] = mixOd
				odd, _ := decimal.NewFromString(subOdd.Odd)
				oddSum = oddSum.Add(odd)
				mixOddMap[odId] = odd
			}
			for odId := range detail {
				usedLimit := (mixOddMap[odId].Div(oddSum).Mul(theoryPrize.Sub(v.Amount))).Div(exchangeRate).Round(3)
				detail[odId]["used_limit"] = usedLimit
				if match.Category != model.MatchCategoryChampion {
					mchMixGlobalTotal[match.ID] = mchMixGlobalTotal[match.ID].Add(usedLimit)
					mchGlobalTotal[match.ID] = mchGlobalTotal[match.ID].Add(usedLimit)
				}
			}
			complexMp[orderID] = order
			compDetailMp[orderID] = detail
		} else {
			simpleMp[orderID] = order
			if match.Category != model.MatchCategoryChampion {
				usedLimit := (theoryPrize.Sub(v.Amount)).Div(exchangeRate)
				mchGlobalTotal[match.ID] = mchGlobalTotal[match.ID].Add(usedLimit)
				if _, ok := mktGlobalTotal[match.ID]; !ok {
					mktGlobalTotal[match.ID] = map[string]decimal.Decimal{}
				}
				mktGlobalTotal[match.ID][v.Data.MarketID] = mktGlobalTotal[match.ID][v.Data.MarketID].Add(usedLimit)
			}
		}
		if match.SID != "0" {
			order["bet_status"] = model.BetStatusWaitConfirm // 体育注单全部为待确认
		} else {
			betDelayTime := match.BetDelayTime
			// 单注 && (滚盘 && 投注确认时间大于0 || hideAmountRate < 1)
			if v.Flags == model.OrderTypeSimple && match.IsLive == 2 && betDelayTime > 0 && decHideAmountRate.LessThan(utils.Decimal1) {
				order["bet_status"] = model.BetStatusWaitConfirm
				orderDelay := model.OrderDelay{
					MatchID:        v.Data.MatchID,
					MarketID:       v.Data.MarketID,
					OddId:          v.Data.Oid,
					BetAmount:      utils.TrimDecimal(v.Amount),
					TheoryPrize:    utils.TrimDecimal(theoryPrize),
					BetDelayTime:   betDelayTime,
					Odd:            v.Data.Odd.String(),
					ExchangeRate:   exchangeRate.String(),
					HideAmountRate: hideAmountRate,
				}
				delay[orderID] = orderDelay
			} else {
				order["bet_status"] = model.BetStatusWaitSettle
			}
			if v.Flags == model.OrderTypeSimple {
				// 今日会员单关限额赔付校验
				theoryAmount := (theoryPrize.Sub(v.Amount)).Div(exchangeRate).Round(3)
				simpleMinBet := risks["simple_min_bet"]
				if member.CurrencyCode != model.DefaultCurrencyCode && member.CurrencyCode != 0 {
					simpleMinBet = simpleMinBet.Mul(exchangeRate).Ceil()
				}
				if dailyTotal[model.MemberSinglePrizeTotal].LessThan(theoryAmount) && v.Amount.GreaterThan(simpleMinBet) {
					helper.Print(ctx, "false", lang.Text(lan, "msgSinglePrizeOverrun"))
					return
				}

				prizeTotal[model.MemberSinglePrizeTotal] = prizeTotal[model.MemberSinglePrizeTotal].Add(theoryAmount)
			}
		}

		// 组装账变参数
		param := map[string]interface{}{
			"order_no":                fmt.Sprintf("%d", orderID),
			"member_id":               member.UID,
			"member_account":          member.Account,
			"merchant_id":             member.MerchantID,
			"merchant_account":        member.MerchantAccount,
			"parent_merchant_id":      member.ParentMerchantID,
			"parent_merchant_account": member.ParentMerchantAccount,
			"top_merchant_id":         member.TopMerchantId,
			"top_merchant_account":    member.TopMerchantAccount,
			"sort_level":              member.SortLevel,
			"deph":                    member.Deph,
			"tester":                  member.Tester,
			"agent_id":                member.AgentID,
			"agent_account":           member.AgentAccount,
			"currency_code":           member.CurrencyCode,
			"exchange_rate":           ratef,
		}
		transferParam := model.BetTransfer{
			BetAmount: v.Amount,
			Param:     param,
		}

		transfers[orderID] = transferParam
		orderOptionType[orderID] = handicapInfo.Markets[v.Data.MarketID].OptionType
		if _, ok = additionalMap[orderID]; !ok {
			additionalMap[orderID] = model.BetAdditionalInfo{
				TYPlaceNum:  handicapInfo.Markets[v.Data.MarketID].TYPlaceNum,
				MarketValue: handicapInfo.Markets[v.Data.MarketID].MarketValue,
			}
		}
	}

	parentId := helper.GenId()
	err = model.IsDuplex(&isDuplexMap, lan)
	if err != nil {
		helper.Print(ctx, "false", lang.Text(lan, "msgBetFail")+err.Error())
		return
	}

	// 处理串注
	for k, v := range comps {

		odd := decimal.NewFromInt32(1)
		oddDiscount := decimal.NewFromFloat(handicapInfo.Matches[v.Data[0].MatchID].RndCompOddDscnt).Div(model.DeciHundred)
		orderID := helper.GenId()
		model.AddLog(model.LogInfo, model.LogFlag, ctx.ID(), "order:%d, param:%+v", orderID, v)

		detail := map[uint64]g.Record{}
		for kk, vv := range v.Data {
			if handicapInfo.Markets[vv.MarketID].OptionType == model.OptionTypeMix {
				helper.Print(ctx, "false", lang.Text(lan, "msgMixBetFail"))
				return
			}
			var (
				oddCnName string
				oddEnName string
			)
			oddCnName = handicapInfo.Odds[vv.Oid].Name
			oddEnName = handicapInfo.Odds[vv.Oid].EnName
			if handicapInfo.Markets[vv.MarketID].OptionType == model.OptionTypePlayerHandicap ||
				handicapInfo.Markets[vv.MarketID].OptionType == model.OptionTypeHeroHandicap { //队员让分 英雄让分
				oddCnName = strings.Replace(oddCnName, "$$", " ", 1)
				oddEnName = strings.Replace(oddEnName, "$$", " ", 1)
			}
			odId := helper.GenId()
			od := g.Record{
				"id":               odId,
				"order_id":         orderID,
				"member_id":        member.UID,
				"member_account":   member.Account,
				"game_id":          handicapInfo.Matches[vv.MatchID].GameID,
				"tournament_id":    handicapInfo.Matches[vv.MatchID].TournamentID,
				"match_id":         vv.MatchID,
				"market_id":        vv.MarketID,
				"odd_id":           vv.Oid,
				"org_odd_id":       handicapInfo.Markets[vv.MarketID].OddTypeID,
				"odd_name":         oddCnName,
				"odd_en_name":      oddEnName,
				"odd":              utils.TrimDecimal(vv.Odd),
				"bet_time":         g.L("UNIX_TIMESTAMP(NOW(3))*1000"),
				"is_live":          handicapInfo.Matches[vv.MatchID].IsLive,
				"market_en_name":   handicapInfo.Markets[vv.MarketID].EnName,
				"market_cn_name":   handicapInfo.Markets[vv.MarketID].CnName,
				"match_start_time": handicapInfo.Matches[vv.MatchID].StartTime,
				"match_type":       handicapInfo.Matches[vv.MatchID].Category,
				"round":            handicapInfo.Markets[vv.MarketID].Round,
				"team_names":       handicapInfo.Matches[vv.MatchID].MatchTeam,
				"team_cn_names":    handicapInfo.Matches[vv.MatchID].MatchCnTeam,
				"team_en_names":    handicapInfo.Matches[vv.MatchID].MatchEnTeam,
				"team_id":          handicapInfo.Matches[vv.MatchID].TeamID,
				"update_time":      time.Now().Unix(),
				"status":           1,
				"bet_amount":       v.Amount.String(),
				"used_limit":       0,
				"currency_code":    member.CurrencyCode,
				"exchange_rate":    ratef,
			}

			if v.Flags == model.OrderTypeRoundComplex {
				// 局内串关单个投注项实际赔率：(投注项赔率-1)*局内串关返还率+1
				odd = odd.Mul(vv.Odd.Sub(model.DeciOne).Mul(oddDiscount).Add(model.DeciOne))
			} else {
				odd = odd.Mul(vv.Odd)
			}
			detail[odId] = od
			if handicapInfo.Markets[vv.MarketID].IsDefault == 1 {
				defaultMarket[vv.MarketID] = 1
			}
			comps[k].OddSum = comps[k].OddSum.Add(vv.Odd)
			comps[k].Data[kk].OdId = odId
		}
		order := g.Record{
			"id":                      orderID,
			"member_id":               member.UID,
			"member_account":          member.Account,
			"merchant_id":             member.MerchantID,
			"merchant_account":        member.MerchantAccount,
			"parent_merchant_id":      member.ParentMerchantID,
			"parent_merchant_account": member.ParentMerchantAccount,
			"top_merchant_id":         member.TopMerchantId,
			"top_merchant_account":    member.TopMerchantAccount,
			"sort_level":              member.SortLevel,
			"deph":                    member.Deph,
			"game_id":                 "0",
			"tournament_id":           "0",
			"match_id":                "0",
			"market_id":               "0",
			"odd_id":                  "0",
			"org_odd_id":              "0",
			"odd_name":                "",
			"odd_en_name":             "",
			"odd_discount":            1,
			"bet_amount":              v.Amount.String(),
			"win_amount":              "0",
			"bet_time":                g.L("UNIX_TIMESTAMP(NOW(3))*1000"),
			"device":                  device,
			"order_type":              v.Flags,
			"bet_status":              model.BetStatusWaitSettle,
			"bet_ip":                  ip,
			"is_live":                 0,
			"market_en_name":          "",
			"market_cn_name":          "",
			"match_start_time":        0,
			"parley_type":             v.ParleyType,
			"confirm_type":            1,
			"match_type":              0,
			"round":                   0,
			"team_names":              "",
			"team_cn_names":           "",
			"team_en_names":           "",
			"team_id":                 "",
			"tester":                  member.Tester,
			"update_time":             time.Now().Unix(),
			"settle_time":             0,
			"settle_count":            0,
			"risk_tag_id":             0, //风险标签ID
			"currency_code":           member.CurrencyCode,
			"exchange_rate":           ratef,
			"hide_amount_rate":        0, // 串注不统计操盘货量，所以这里为0
		}
		if v.Flags == model.OrderTypeRoundComplex {
			mchID := v.Data[0].MatchID
			order["match_id"] = mchID
			order["game_id"] = handicapInfo.Matches[mchID].GameID
			order["tournament_id"] = handicapInfo.Matches[mchID].TournamentID
			order["match_type"] = handicapInfo.Matches[mchID].Category
			order["match_start_time"] = handicapInfo.Matches[mchID].StartTime
			order["team_id"] = handicapInfo.Matches[mchID].TeamID
			order["team_names"] = handicapInfo.Matches[mchID].MatchTeam
			order["team_cn_names"] = handicapInfo.Matches[mchID].MatchCnTeam
			order["team_en_names"] = handicapInfo.Matches[mchID].MatchEnTeam
			order["round"] = handicapInfo.Markets[v.Data[0].MarketID].Round
			order["is_live"] = handicapInfo.Matches[mchID].IsLive
			order["odd_discount"] = utils.TrimDecimal(oddDiscount)
			// 局内串关赔率超过限制，则按最高限制赔率
			if odd.GreaterThan(risks["round_complex_max_odd"]) {
				odd = risks["round_complex_max_odd"]
			}
		}
		odd = odd.Round(6) // 串关注单赔率保留6位小数(四舍五入)
		order["odd"] = odd.String()
		order["org_odd"] = odd.String()
		comps[k].Odd = odd
		comps[k].OrderId = orderID
		if v.ParleyNum > 1 {
			order["parent_id"] = parentId
			order["parley_num"] = v.ParleyNum
		}
		order["theory_prize"] = utils.TrimDecimal(v.Amount.Mul(odd))
		theoryPrize = v.Amount.Mul(odd)
		if member.Tester == model.UserTypeCredit {
			err = (&model.CreditLimit{}).CheckCreditComplexLimit(ctx.ID(), agent.ID, member.UID, v.ParleyType, v.Amount, odd, exchangeRate, creditComplexSum, lan)
			if err != nil {
				helper.Print(ctx, "false", err.Error())
				return
			}

			if memberRiskStatus || agent.LimitMode != 0 {
				// 投注风控
				limitVal, err = riskChange(member, matchIds, marketIds, simpleRiskFlag, complexRiskFlag, roundComplexRiskFlag, risks, comps, simples, handicapInfo, exchangeRate, lan)
				if err != nil {
					helper.Print(ctx, "false", err.Error())
					return
				}
			}

			order["agent_id"] = member.AgentID
			order["agent_account"] = member.AgentAccount
		}
		if riskTagId != "" {
			order["risk_tag_id"] = riskTagId
		}

		// 组装账变参数
		param := map[string]interface{}{
			"order_no":                fmt.Sprintf("%d", orderID),
			"member_id":               member.UID,
			"member_account":          member.Account,
			"merchant_id":             member.MerchantID,
			"merchant_account":        member.MerchantAccount,
			"parent_merchant_id":      member.ParentMerchantID,
			"parent_merchant_account": member.ParentMerchantAccount,
			"top_merchant_id":         member.TopMerchantId,
			"top_merchant_account":    member.TopMerchantAccount,
			"sort_level":              member.SortLevel,
			"deph":                    member.Deph,
			"tester":                  member.Tester,
			"agent_id":                member.AgentID,
			"agent_account":           member.AgentAccount,
			"currency_code":           member.CurrencyCode,
			"exchange_rate":           ratef,
		}
		transferParam := model.BetTransfer{
			BetAmount: v.Amount,
			Param:     param,
		}

		transfers[orderID] = transferParam
		complexMp[orderID] = order
		if v.Flags == model.OrderTypeComplex {
			// 今日会员串关限额赔付校验
			overrunSetting, err := model.GetOverrunSetting(v.ParleyType)
			if err != nil {
				helper.Print(ctx, "false", lang.Text(lan, "msgGetOverrunError")+err.Error())
				return
			}

			theoryAmount := (v.Amount.Mul(odd)).Sub(v.Amount).Div(exchangeRate).Round(3)
			amount := v.Amount.Div(exchangeRate).Round(3)
			if dailyTotal[model.MemberComplexPrizeTotal].LessThan(theoryAmount) &&
				odd.GreaterThanOrEqual(overrunSetting[fmt.Sprintf(model.LimitOddStrF, v.ParleyType)]) &&
				!amount.LessThanOrEqual(overrunSetting[fmt.Sprintf(model.LimitBetStrF, v.ParleyType)]) {
				helper.Print(ctx, "false", lang.Text(lan, "msgComplexPrizeOverrun"))
				return
			}

			prizeTotal[model.MemberComplexPrizeTotal] = prizeTotal[model.MemberComplexPrizeTotal].Add(theoryAmount)
		}
		// 全局赛事使用限额
		for _, od := range comps[k].Data {
			if v.Flags == model.OrderTypeRoundComplex {
				usedLimit := (od.Odd.Div(comps[k].OddSum).Mul(theoryPrize.Sub(v.Amount))).Div(exchangeRate).Round(3)
				detail[od.OdId]["used_limit"] = usedLimit
				if match.Category != model.MatchCategoryChampion {
					//局内串关赔付
					mchRandGlobalTotal[od.MatchID] = mchRandGlobalTotal[od.MatchID].Add(usedLimit)
					//赛事赔付
					mchGlobalTotal[od.MatchID] = mchGlobalTotal[od.MatchID].Add(usedLimit)
				}
			} else {
				if _, ok = mktGlobalTotal[od.MatchID]; !ok {
					mktGlobalTotal[od.MatchID] = map[string]decimal.Decimal{}
				}
				usedLimit := (od.Odd.Div(comps[k].OddSum).Mul(theoryPrize.Sub(v.Amount))).Div(exchangeRate).Round(3)
				detail[od.OdId]["used_limit"] = usedLimit
				if match.Category != model.MatchCategoryChampion {
					//盘口赔付
					mktGlobalTotal[od.MatchID][od.MarketID] = mktGlobalTotal[od.MatchID][od.MarketID].Add(usedLimit)
					//串关赔付
					mchCompGlobalTotal[od.MatchID] = mchCompGlobalTotal[od.MatchID].Add(usedLimit)
					//赛事赔付
					mchGlobalTotal[od.MatchID] = mchGlobalTotal[od.MatchID].Add(usedLimit)
				}
			}
		}
		compDetailMp[orderID] = detail
	}

	if len(simpleMp) == 0 && len(complexMp) == 0 {
		helper.Print(ctx, "false", lang.Text(lan, "msgBetInvalid"))
		return
	}

	if len(comps) > 0 {
		err = model.CompUsedLimitCheck(comps, member, handicapInfo, limitVal, compDetailMp, exchangeRate, lan)
		if err != nil {
			helper.Print(ctx, "false", err.Error())
			return
		}
	}

	begin := ctx.Time()
	model.AddLog(model.LogInfo, "betCost", 0, "[%s] BetDo start!", model.FmtTime(begin))
	// 投注
	betInfo := model.BetInfo{
		Lan:             lan,
		CID:             ctx.ID(),
		ExchangeRate:    exchangeRate.String(),
		Delay:           delay,
		Member:          member,
		RiskTagID:       riskTagId,
		RiskTagMatchID:  riskTagMatchId,
		IsSportsGame:    bSportsGame,
		Simples:         simpleMp,
		Complexes:       complexMp,
		Transfers:       transfers,
		OrderDetails:    compDetailMp,
		DefaultMarket:   defaultMarket,
		OrderOptionType: orderOptionType,
		Additional:      additionalMap,
	}
	err = model.BetDo(betInfo)
	end := time.Now()
	model.AddLog(model.LogInfo, "betCost", 0, "[%s] BetDo end, cost:%s", model.FmtTime(end), end.Sub(begin))
	if err != nil {
		if err.Error() == "token invalid" {
			session.Destroy(ctx)
			helper.Print(ctx, "false", lang.Text(lan, "msgTokenInvalid"))
			return
		}

		helper.Print(ctx, "false", lang.Text(lan, "msgBetFail")+err.Error())
		return
	}

	go func(c fasthttp.RequestCtx) {
		// 更新已串注使用额度
		if member.Tester != model.UserTypeTester {
			model.UpdateCompUsedLimit(&c, comps, member)
		}
		if member.Tester != model.UserTypeTester {
			// 更新赛事全局额度
			err = model.GlobalTotalUpdate(mktGlobalTotal, mchCompGlobalTotal, mchMixGlobalTotal, mchRandGlobalTotal, mchGlobalTotal, handicapInfo)
			if err != nil {
				fmt.Println(err.Error())
			}
		}
		for k, v := range prizeTotal {
			types := model.SingleRiskPrizeTotalType
			if k == model.MemberComplexPrizeTotal {
				types = model.ComplexRiskPrizeTotalType
			}
			amount, _ := v.Float64()
			err = model.DeductionMemberDailyTotal(member.MerchantID, member.UID, types, amount)
			if err != nil {
				fmt.Println(err.Error())
			}
		}
		ua := string(ctx.Request.Header.UserAgent())
		if len(ua) > 255 {
			ua = ua[0:254]
		}
		//记录用户登陆IP
		ipDate := &model.Ips{
			ID:                    helper.GenId(),
			TopMerchantId:         member.TopMerchantId,
			TopMerchantAccount:    member.TopMerchantAccount,
			ParentMerchantID:      member.ParentMerchantID,
			ParentMerchantAccount: member.ParentMerchantAccount,
			MerchantID:            member.MerchantID,
			MerchantAccount:       member.MerchantAccount,
			Uid:                   member.UID,
			Account:               member.Account,
			Ip:                    ip,
			Ua:                    ua,
			Time:                  time.Now().Unix(),
		}
		err = model.IpsAdd(ipDate)
		if err != nil {
			zlog.Error(nil, "trade_ip_list", "", fmt.Sprintf("记录会员投注ip失败, uid:%d, ip:%d, ua:%s, err:%s", member.UID, ip, ua, err.Error()), "", 0)
		}
	}(*ctx)

	helper.Print(ctx, "true", lang.Text(lan, "msgBetSuccess"))
}

/**
 * @Description: 单注注单风控校验
 * @Author: awen
 * @Date: 2020/7/22
 * @LastEditTime: 2020/7/22
 * @LastEditors: awen
 **/
func RiskCheckSimple(mktMinLimitVal model.MarketRiskLimit, simples []*model.SimpleBetContent, rate decimal.Decimal, lan string) error {

	// 投注赔付金额
	var (
		prizeStaticProfit int             //单注限红
		limit             decimal.Decimal //单注最高赔付、盘口最高赔
		mchLimit          decimal.Decimal //赛事最高赔付
		pspDeci           decimal.Decimal //单注限红浮动值
		betAmountLimit    decimal.Decimal //风控最大投注金额值
		ok                bool
	)
	// 单注最高赔付、盘口最高赔付、赛事最高赔付 取最低值后除以(投注项赔率-1)，得到最大投注金额，最后与单注限红值比较取其中的低值
	for _, v := range simples {
		// 单注最大投注金额
		if prizeStaticProfit, ok = mktMinLimitVal.MktPrizeStaticProfit[v.Data.MarketID]; !ok {
			return errors.New(lang.Text(lan, "msgRiskCheckFail"))
		}
		pspDeci = decimal.NewFromInt32(int32(prizeStaticProfit)).Mul(rate).Floor()

		if limit, ok = mktMinLimitVal.MktLimitVal[v.Data.MarketID]; ok {

			mchLimit = mktMinLimitVal.MchLimitVal[v.Data.MatchID]
			limit = decimal.Min(limit, mchLimit)
			if v.Flags == model.OrderTypeMix {
				limit = decimal.Min(mchLimit, mktMinLimitVal.MixPrizeLimit)
			}
			limit = limit.Mul(rate).Floor()
			// 单注赔付金额=最低赔付值/(投注项赔率-1)
			payOdd := v.Data.Odd.Sub(model.DeciOne)
			betAmountLimit = limit.Div(payOdd)

			// 最大投注金额= 单注限红和单注赔付金额 之间的最小值
			if pspDeci.LessThan(betAmountLimit) {
				betAmountLimit = pspDeci
			}
			// 判断投注金额是否超限
			if v.Amount.GreaterThan(betAmountLimit) {
				return errors.New(lang.Text(lan, "msgBetExceedLimit"))
			}

			// 赛事剩余赔付额度减去当前注单赔付额（注单金额*(赔率-1)）
			mchLimit = mchLimit.Sub(v.Amount.Mul(payOdd))
			mktMinLimitVal.MchLimitVal[v.Data.MatchID] = mchLimit
			continue
		} else {
			return errors.New(lang.Text(lan, "msgBetFail") + "328")
		}
	}
	return nil
}

/**
 * @Description: 串关注单风控校验
 * @Author: awen
 * @Date: 2020/7/24
 * @LastEditTime: 2020/7/24
 * @LastEditors: awen
 **/
func RiskCheckComplex(comps []*model.ComplexBetContent, mktRiskLimit model.MarketRiskLimit, handicaps utils.HandicapData, rndCompMaxOdd decimal.Decimal, rate decimal.Decimal, lan string) error {

	var (
		mktPsp   int // 盘口单注限红
		mktID    string
		mchLimit decimal.Decimal //赛事最高赔付
	)

	rndCompOddDscnt := decimal.NewFromFloat(handicaps.Matches[comps[0].Data[0].MatchID].RndCompOddDscnt).Div(model.DeciHundred)
	parleyType := 0
	if len(comps) > 1 {
		for _, v := range comps {
			if v.ParleyType > parleyType {
				parleyType = v.ParleyType
			}
		}
	}
	for _, v := range comps {
		pt := v.ParleyType
		if v.ParleyNum != 1 {
			pt = parleyType
		}
		odd := decimal.NewFromInt(1)       // 串关注单赔率
		var simpleLimits []decimal.Decimal // 串关注单中每个单注最小投注限额
		for _, content := range v.Data {
			mktID = content.MarketID
			// 串注注单中单注注单盘口限红值
			if mktLimit, ok := mktRiskLimit.MktLimitVal[mktID]; ok {
				mchLimit = mktRiskLimit.MchLimitVal[content.MatchID]
				mktLimit = decimal.Min(mktLimit, mchLimit)
				// 普通串注判断盘口串注最大限额
				if v.Flags == model.OrderTypeComplex {
					compPrizeLimit := decimal.NewFromInt32(int32(handicaps.Markets[mktID].MchCompPrizeLimit))
					mktLimit = decimal.Min(mktLimit, compPrizeLimit)
				}
				// 子单单注最大投注金额 = 单注最高赔付/(投注项赔率-1)
				simpleLimit := mktLimit.Div(content.Odd.Sub(model.DeciOne))
				if mktPsp, ok = mktRiskLimit.MktPrizeStaticProfit[mktID]; ok {
					pspDeci := decimal.NewFromInt32(int32(mktPsp)) // 单注限红
					if pspDeci.LessThan(simpleLimit) {
						simpleLimit = pspDeci
					}
				}
				simpleLimits = append(simpleLimits, simpleLimit)
			}
			if v.Flags == model.OrderTypeRoundComplex {
				// 局内串关单个投注项实际赔率：(投注项赔率-1)*局内串关返还率+1
				odd = odd.Mul(content.Odd.Sub(model.DeciOne).Mul(rndCompOddDscnt).Add(model.DeciOne))
			} else {
				odd = odd.Mul(content.Odd) // 串关注单赔率计算
			}

		}

		if simpleLimits == nil {
			zlog.Error(nil, "betRisk", "", fmt.Sprintf("串关风控子单单注赔付获取失败: complex:%+v,mktMinLimitVal:%+v", v, mktRiskLimit.MktLimitVal), "", 0)
			return errors.New(lang.Text(lan, "msgBetFail") + "309")
		}
		minSimpleLimit := decimal.Min(simpleLimits[0], simpleLimits...)

		// 如果是局内串关投注，最大投注金额为: 局内串关剩余最高赔付/(局内串关赔率*局内串关折扣)
		if v.Flags == model.OrderTypeRoundComplex {
			mktRiskLimit.ComplexMaxPrize = decimal.Min(mktRiskLimit.RndCompMaxPrize, mktRiskLimit.RndCompMchMaxPrize)
			// 局内串关赔率超过系统设置的最高赔率
			if odd.GreaterThan(rndCompMaxOdd) {
				odd = rndCompMaxOdd
			}

			// 当前局内串关注单赔付金额
			payPrize := odd.Mul(v.Amount).Sub(v.Amount)
			// 赛事剩余局内串关赔付额 = 赛事局内串关总赔付-当前局内串关注单的赔付金额
			mktRiskLimit.RndCompMchMaxPrize = mktRiskLimit.RndCompMchMaxPrize.Sub(payPrize)
		}
		// 串关注单赔率最多保留6位小数
		odd = odd.Round(6)
		complexMaxAmount := mktRiskLimit.ComplexMaxPrize.Div(odd.Sub(model.DeciOne))

		// 如果子单最小投注额小于串关
		if minSimpleLimit.LessThan(complexMaxAmount) {
			complexMaxAmount = minSimpleLimit
		}
		// 串注超限判断
		overrunSetting, err := model.GetOverrunSetting(pt)
		if err != nil {
			return errors.New(lang.Text(lan, "msgGetOverrunError") + err.Error())
		}

		amount := v.Amount.Div(rate).Round(3)
		if odd.GreaterThanOrEqual(overrunSetting[fmt.Sprintf(model.LimitOddStrF, pt)]) && v.Flags == model.OrderTypeComplex {
			if amount.LessThanOrEqual(overrunSetting[fmt.Sprintf(model.LimitBetStrF, pt)]) {
				return nil
			}

			return errors.New(lang.Text(lan, "msgSeriesSingleBetLimit"))
		}

		if amount.GreaterThan(complexMaxAmount) {
			return errors.New(lang.Text(lan, "msgSeriesSingleBetLimit"))
		}
	}
	return nil
}

/*
* @Description: 投注风控校验
* @Author: noah
* @Date: 2021/5/29 15:07
* @LastEditTime: 2021/5/29 15:07
* @LastEditors: noah
 */
func riskChange(member fund.Member, matchIds, marketIds *strset.Set,
	simpleRiskFlag, complexRiskFlag, roundComplexRiskFlag bool,
	risks map[string]decimal.Decimal, comps []*model.ComplexBetContent,
	simples []*model.SimpleBetContent, handicapInfo utils.HandicapData, rate decimal.Decimal, lan string) (model.MarketRiskLimit, error) {
	// 投注风控
	riskParam := BetRiskParam{
		Member:               member,           // 会员信息
		MatchIds:             matchIds.List(),  // 投注的赛事ID
		MarketIds:            marketIds.List(), // 会员投注盘口ID
		SimpleRiskFlag:       simpleRiskFlag,   // 是否需要单注注单风控
		ComplexRiskFlag:      complexRiskFlag,  // 是否需要串关注单风控
		RoundComplexRiskFlag: roundComplexRiskFlag,
		RiskSetting:          risks,
		Complexes:            comps, // 串关投注数据
		Simples:              simples,
	}

	return betRisk(riskParam, handicapInfo, rate, lan)
}

package controller

import (
	"fmt"
	"game/contrib/zlog"
	"game/lang"
	"game/utils"
	"github.com/go-redis/redis/v7"
	"github.com/scylladb/go-set/strset"
	"github.com/shopspring/decimal"
	"strconv"
	"strings"
	"time"

	g "github.com/doug-martin/goqu/v9"

	"game/contrib/jingo"
	"game/contrib/validator"
	"game/helper"
	"game/model"

	"github.com/valyala/fasthttp"
)

type MemberController struct{}

//投注列表参数
type BetOrderListParam struct {
	MarketId  uint64 `rule:"digit" default:"0" min:"1" msg:"market_id格式不正确" name:"market_id"`                //盘口ID
	Status    uint8  `rule:"digit" default:"0" min:"1" max:"2" msg:"status格式不正确" name:"status"`              // 1 未结算 2 已经结算
	OrderType uint8  `rule:"digit" default:"0" min:"1" max:"4" msg:"type格式不正确" name:"type"`                  //投注类型 1-普通注单 2-普通串关注单 3-局内串关注单, 4-复合玩法注单
	MatchType uint8  `rule:"digit" default:"0" min:"1" max:"11" msg:"match_type格式不正确" name:"match_type"`     //赛事类型 正常-1 冠军-2 大逃杀-3 篮球-4 主播盘-5 足球-6 虚拟足球-7,虚拟篮球-8,虚拟赛马-9,虚拟赛狗-10,虚拟摩托车-11
	Live      uint8  `rule:"digit" default:"0" min:"1" max:"2" msg:"live格式不正确" name:"live"`                  //赛事阶段 1-初盘 2-滚盘
	BeginTime string `rule:"dateTime" default:"2020-01-01 00:00:00" msg:"begin_time格式不正确" name:"begin_time"` //开始时间
	EndTime   string `rule:"dateTime" default:"2020-01-01 00:00:00" msg:"end_time格式不正确" name:"end_time"`     //结束时间
	Page      uint   `rule:"digit" default:"1" min:"1" msg:"page错误" name:"page"`                             //页码
	PageSize  uint   `rule:"digit" default:"10" min:"1" max:"50" msg:"page_size错误" name:"page_size"`         //页码大小
}

//资金列表参数
type FundListParam struct {
	Type      uint8  `rule:"digit" default:"0" min:"1" max:"6" msg:"type格式不正确" name:"type"`          //类型
	BeginTime string `rule:"date" default:"2020-01-01" msg:"begin_time格式不正确" name:"begin_time"`      //开始时间
	EndTime   string `rule:"date" default:"2020-01-01" msg:"end_time格式不正确" name:"end_time"`          //结束时间
	Page      uint   `rule:"digit" default:"1" min:"1" msg:"page错误" name:"page"`                     //页码
	PageSize  uint   `rule:"digit" default:"10" min:"1" max:"50" msg:"page_size错误" name:"page_size"` //页数限制
}

//前端功能统计参数
type FrontStatisticsParam struct {
	Page        uint8  `json:"page"`         //1-首页,2-赛事页面,3-赛果页面,4-个人中心页面,5-购物车点击页面,6-购物车注单页面,7-游戏点击页面
	ClickTab    int    `json:"click_tab"`    //点击标签
	ClickNumber uint8  `json:"click_number"` //点击次数
	GameId      string `json:"game_id" `     //游戏id
}

var (
	transDataEncStruct = jingo.NewStructEncoder(model.FundListData{})
)

/**
 * @Description:获取会员余额
 * @Author: wesley
 * @Date: 2020/5/21
 * @LastEditTime:2020/6/14 14:35
 * @LastEditors: Noah
 */
func (that *MemberController) Balance(ctx *fasthttp.RequestCtx) {

	member, err := model.GetTokenData(ctx)
	if err != nil {
		model.AddLog(model.LogError, model.LogFlag, ctx.ID(), "GetTokenData fail: %s", err.Error())
		helper.Print(ctx, "false", fmt.Sprintf("error, trace:%d", ctx.ID()))
		return
	}

	//获取用户资金余额
	balance, err := model.BalanceGet(member)
	if err != nil {
		model.AddLog(model.LogError, model.LogFlag, ctx.ID(), "BalanceGet fail: %s", err.Error())
		helper.Print(ctx, "false", fmt.Sprintf("error, trace:%d", ctx.ID()))
		return
	}

	creditStatus := 0
	if member.Tester == model.UserTypeCredit {
		agent, err := model.GetAgent(member.AgentID)
		if err != nil {
			helper.Print(ctx, "false", err.Error())
			return
		}

		limitStatus, err := model.GetMemberLimitStatus(member.UID)
		if err != nil {
			helper.Print(ctx, "false", err.Error())
			return
		}

		if limitStatus {
			creditStatus = model.CreditMemberLimit
		} else if agent.LimitMode != 0 {
			creditStatus = model.CreditAgentChange
		}
	}
	rate := decimal.NewFromInt(1)
	if member.CurrencyCode != model.DefaultCurrencyCode && member.CurrencyCode != 0 {
		r, err := model.GetRate(member.CurrencyCode)
		if err != nil {
			helper.Print(ctx, "false", "获取汇率失败, "+err.Error())
			return
		}

		rate = decimal.NewFromFloat(r)
	}

	maintainCmd, err := model.NoticeGetMaintain() // 获取系统维护时间
	if err != nil && err != redis.Nil {
		fmt.Printf("NoticeGetMaintain get zk redis error:%s\n", err.Error())
	}
	data := model.MemberBalance{
		Uid:                     fmt.Sprintf("%d", member.UID),
		Account:                 member.Account,
		Balance:                 balance,
		OddUpdateType:           member.OddUpdateType,
		Tester:                  member.Tester,
		CreditLimitOddThreshold: model.CreditLimitOddThreshold,
		CreditStatus:            creditStatus,
		MerchantID:              member.MerchantID,
		TopMerchantAccount:      member.TopMerchantAccount,
		CurrencyEn:              model.CurrencyNameMap[member.CurrencyCode],
		CurrencyCode:            member.CurrencyCode,
		ExchangeRate:            rate,
		MaintainTime:            maintainCmd,
	}
	if member.CurrencyCode != 0 {
		err = data.QuickData.GetQuickData(member.CurrencyCode)
		if err != nil {
			fmt.Println("get quick currency set error : " + err.Error())
		}
	}
	if data.QuickData.QuickOne == "" {
		data.QuickData.QuickOne = "10"
	}
	if data.QuickData.QuickTwo == "" {
		data.QuickData.QuickTwo = "20"
	}
	if data.QuickData.QuickThree == "" {
		data.QuickData.QuickThree = "50"
	}

	helper.Print(ctx, "true", data)
}

/**
 * @Description:资金列表
 * @Author: wesley
 * @Date: 2020/5/26
 * @LastEditTime:
 * @LastEditors: Noah
 */
func (that *MemberController) FundList(ctx *fasthttp.RequestCtx) {

	lan := string(ctx.Request.Header.Peek("lang"))
	user, err := model.GetTokenData(ctx)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	var (
		param     FundListParam
		beginTime time.Time
		endTime   time.Time
		succeed   bool
		data      model.FundListData
	)
	err = validator.Bind(ctx, &param)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	if param.BeginTime == "2020-01-01" && param.EndTime == "2020-01-01" {
		helper.Print(ctx, "false", lang.Text(lan, "msgTimeCantNull"))
		return
	} else {
		succeed, beginTime, endTime = getDiffTime(ctx, param.BeginTime, param.EndTime, 30*3)
		if !succeed {
			helper.PrintJson(ctx, "true", "")
			return
		}
	}

	mt := model.MTGet()

	if mt.StartWay == model.DbQuery {

		ex := g.Ex{
			"member_id":    user.UID,
			"created_time": g.Op{"between": g.Range(beginTime.UnixNano()/1e6, endTime.UnixNano()/1e6)},
		}
		if param.Type != 0 {
			ex["trade_type"] = param.Type
		}

		data, err = model.FundList(param.Page, param.PageSize, ex)
	} else {

		query := model.EsFundQueryParam{
			UID:       user.UID,
			Type:      param.Type,
			BeginTime: beginTime,
			EndTime:   endTime,
			Page:      int(param.Page),
			PageSize:  int(param.PageSize),
		}
		data, err = model.EsFundListGet(query, ctx.Time())
	}

	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	buf := jingo.NewBufferFromPool()
	transDataEncStruct.Marshal(&data, buf)
	helper.PrintJson(ctx, "true", buf.String())
	buf.ReturnToPool()
}

/**
* @Description:  注单记录
* @Author: wesley
* @Date: 2020/7/4 8:24 下午
* @LastEditTime: 2020/7/4 8:24 下午
* @LastEditors: brandon
 */
func (that *BetOrderController) List(ctx *fasthttp.RequestCtx) {

	lan := string(ctx.Request.Header.Peek("lang"))
	user, err := model.GetTokenData(ctx)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	var (
		param     BetOrderListParam
		data      model.BetOrderListData
		beginTime time.Time
		endTime   time.Time
		settled   int
		succeed   bool
	)
	err = validator.Bind(ctx, &param)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	if param.Status > 0 {
		if param.Status == model.StatusSettle {
			settled = 1 // 已结算注单
		} else {
			settled = 0 // 待结算注单
		}
	}

	mt := model.MTGet()

	if param.BeginTime == "2020-01-01 00:00:00" && param.EndTime == "2020-01-01 00:00:00" {
		helper.Print(ctx, "false", lang.Text(lan, "msgTimeCantNull"))
		return
	} else {
		succeed, beginTime, endTime = getDiffTime(ctx, param.BeginTime, param.EndTime, 30*3)
		if !succeed {
			helper.Print(ctx, "true", "")
			return
		}
	}

	if mt.StartWay == model.DbQuery {

		ex := g.Ex{
			"member_id": user.UID,
		}
		if param.Status > 0 { //是否已结算 0-否 1-是
			ex["settled"] = settled
		}
		if param.MarketId != 0 {
			ex["market_id"] = param.MarketId
		}
		if param.MatchType != 0 {
			ex["match_type"] = param.MatchType
		}
		if param.OrderType != 0 {
			ex["order_type"] = param.OrderType
		}
		if param.Live != 0 {
			ex["is_live"] = param.Live
		}
		ex["bet_time"] = g.Op{"between": g.Range(beginTime.UnixNano()/1e6, endTime.UnixNano()/1e6)}
		data, err = model.BetOrderList(param.Page, param.PageSize, ex)
	} else {

		//es query
		query := model.EsOrderQueryParam{
			UID:       user.UID,
			Status:    param.Status,
			Settled:   settled,
			MarketId:  param.MarketId,
			OrderType: param.OrderType,
			MatchType: param.MatchType,
			Live:      param.Live,
			BeginTime: beginTime,
			EndTime:   endTime,
			Page:      int(param.Page),
			PageSize:  int(param.PageSize),
		}

		data, err = model.EsOrderListGet(query)
	}

	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	//已结算返还金额加上已拒绝，已取消，已撤销注单金额
	if param.Status == model.StatusSettle {
		ex1 := g.Ex{
			"member_id":  user.UID,
			"bet_status": []interface{}{model.BetStatusRefused, model.BetStatusCancelled, model.BetStatusUndo},
			"bet_time":   g.Op{"between": g.Range(beginTime.UnixNano()/1e6, endTime.UnixNano()/1e6)},
		}
		if param.MarketId != 0 {
			ex1["market_id"] = param.MarketId
		}
		if param.MatchType != 0 {
			ex1["match_type"] = param.MatchType
		}
		if param.OrderType != 0 {
			ex1["order_type"] = param.OrderType
		}
		if param.Live != 0 {
			ex1["is_live"] = param.Live
		}
		amount, err := model.SumReturnBetAmount(ex1)
		if err != nil {
			helper.Print(ctx, "false", err.Error())
			return
		}

		data.BetTotal.WinAmountTotal += amount
	}

	//注单盘口名多语言格式化
	oddTypeSet := strset.New()
	tourID := strset.New()
	oddTypeSetVirtual := strset.New() //虚拟体育
	tourIdSetVirtual := strset.New()
	for _, simple := range data.Bet {
		if simple.OrderType != model.OrderTypeSimple && simple.OrderType != model.OrderTypeMix {
			continue
		}
		if utils.CheckSportsGameID(simple.GameID) {
			oddTypeSetVirtual.Add(simple.OrgOddID)
			tourIdSetVirtual.Add(simple.TournamentID)
		} else {
			oddTypeSet.Add(simple.OrgOddID)
			tourID.Add(simple.TournamentID)
		}
	}
	for _, comps := range data.Detail {
		for _, od := range comps {
			if utils.CheckSportsGameID(od.GameID) {
				oddTypeSetVirtual.Add(od.OrgOddID)
				tourIdSetVirtual.Add(od.TournamentID)
			} else {
				oddTypeSet.Add(od.OrgOddID)
				tourID.Add(od.TournamentID)
			}
		}
	}

	//根据玩法ID和客户端语音获取对应语言的玩法名
	var (
		mpOddTypeName        map[string]string
		tourName             map[string]string
		mpOddTypeNameVirtual map[string]string
		mpTourNameVirtual    map[string]string
	)

	mpOddTypeName = model.MultiLanguageName(model.RamDataOddType, oddTypeSet.List(), lan)
	tourName = model.MultiLanguageName(model.RamDataTournament, tourID.List(), lan)
	mpOddTypeNameVirtual = model.MultiLanguageName(model.RamDataVirtual, oddTypeSetVirtual.List(), lan)
	mpTourNameVirtual = model.MultiLanguageName(model.RamDataVirtual, tourIdSetVirtual.List(), lan)
	//格式化并组装注单盘口名数据
	for i, v := range data.Bet {
		if !utils.CheckSportsGameID(v.GameID) {
			data.Bet[i].MarketName = mpOddTypeName[v.OrgOddID]
			data.Bet[i].TourName = tourName[v.TournamentID]
		} else {
			data.Bet[i].MarketName = mpOddTypeNameVirtual[v.OrgOddID]
			data.Bet[i].TourName = mpTourNameVirtual[v.TournamentID]
			if len(v.RoundNo) > 0 {
				if tourCupData, ok := mt.SportsGameDataMap[v.TournamentID]; ok {
					data.Bet[i].RoundNo = model.SportsRoundNoFormat(v.RoundNo, lan, tourCupData.IsCup)
				}
			}
		}
		//投注项名称客户端语言为简体中文或繁体中文时 ，显示简体中文；其他语种时显示为英文
		if lan == lang.CN || lan == lang.ZH {
			continue
		}
		data.Bet[i].OddName = v.OddEnName
	}

	for k, v := range data.Detail {
		for i, odv := range v {
			if !utils.CheckSportsGameID(odv.GameID) {
				v[i].MarketName = mpOddTypeName[odv.OrgOddID]
				v[i].TourName = tourName[odv.TournamentID]
			} else {
				v[i].MarketName = mpOddTypeNameVirtual[odv.OrgOddID]
				v[i].TourName = mpTourNameVirtual[odv.OrgOddID]
			}
			//投注项名称客户端语言为简体中文或繁体中文时 ，显示简体中文；其他语种时显示为英文
			if lan == lang.CN || lan == lang.ZH {
				continue
			}
			v[i].OddName = odv.OddEnName
		}
		data.Detail[k] = v
	}

	helper.Print(ctx, "true", data)
}

/**
 * @Description: 设置用户赔率变动方式
 * @Author: noah
 * @Date: 2020/8/3
 * @LastEditTime: 2020/8/3
 * @LastEditors: noah
 **/
func (that *MemberController) OddUpdateTypeSet(ctx *fasthttp.RequestCtx) {

	lan := string(ctx.Request.Header.Peek("lang"))
	v := string(ctx.QueryArgs().Peek("odd_update_type"))
	oddUpdateType, err := strconv.Atoi(v)
	if err != nil || oddUpdateType < 1 || oddUpdateType > 3 {
		helper.Print(ctx, "false", lang.Text(lan, "errParameter"))
		return
	}

	//获取用户信息
	member, err := model.GetTokenData(ctx)
	if err != nil {
		model.AddLog(model.LogError, model.LogFlag, ctx.ID(), "GetTokenData fail: %s", err.Error())
		helper.Print(ctx, "false", fmt.Sprintf("error, trace:%d", ctx.ID()))
		return
	}

	err = model.MemberOddUpdateTypeSet(member, oddUpdateType)
	if err != nil {
		model.AddLog(model.LogError, model.LogFlag, ctx.ID(), "MemberOddUpdateTypeSet fail: %s", err.Error())
		helper.Print(ctx, "false", fmt.Sprintf("error, trace:%d", ctx.ID()))
		return
	}

	helper.Print(ctx, "true", lang.Text(lan, "setSuccess"))
}

//根据目标差距天数判断开始和结束时间符合预期
func getDiffTime(ctx *fasthttp.RequestCtx, begin, end string, targetDiff int) (bool, time.Time, time.Time) {

	beginTime := helper.StrToTime(begin)
	endTime := helper.StrToTime(end)
	diff := int(endTime.Sub(beginTime).Seconds())
	today := helper.DailyEndTime(ctx, 0)
	maxDiff := targetDiff * 24 * 3600
	if diff < 0 {
		return false, beginTime, endTime
	}

	if endTime.Unix() > today.Unix() {
		endTime = today
	}

	if diff > maxDiff {
		beginTime = endTime.AddDate(0, 0, -targetDiff)
	}

	return true, beginTime, endTime
}

/*
* @Description:前端功能统计
* @Author: abraham
* @Date: 2021/6/1 19:18
* @LastEditTime: 2021/6/1 19:18
* @LastEditors: abraham
 */
func (that *MemberController) FrontStatistics(ctx *fasthttp.RequestCtx) {

	member, err := model.GetTokenData(ctx)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	var infos []model.StatisticsInfoEs
	device := getDeviceType(string(ctx.Request.Header.UserAgent()))
	startTime := helper.StrToTime(time.Now().Format("2006-01-02")).Unix()
	endTime := helper.StrToTime(time.Now().Format("2006-01-02")).AddDate(0, 0, 1).Unix()
	times := string(ctx.PostArgs().Peek("online_interval"))
	interval, err := strconv.ParseInt(times, 10, 64)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	if interval != 0 {
		var info model.StatisticsInfoEs
		info.ID = fmt.Sprintf("%d", helper.Cputicks())
		info.UID = member.UID
		info.TopMerchantId = member.TopMerchantId
		info.MerchantID = member.MerchantID
		info.SortLevel = member.SortLevel
		info.Device = device
		info.OnlineInterval = interval
		info.CreatedAt = ctx.Time().Unix()
		if int64(member.RegisterTime) > startTime && int64(member.RegisterTime) < endTime {
			info.Types = model.NewUser
		} else {
			info.Types = model.OldUser
		}

		infos = append(infos, info)
	}

	frontData := string(ctx.FormValue("front_data"))
	if frontData != "" {
		var param []FrontStatisticsParam
		err = helper.JsonUnmarshal([]byte(frontData), &param)
		if err != nil {
			helper.Print(ctx, "false", err.Error())
			return
		}

		for _, p := range param {

			if tab, ok := model.GameMap[p.GameId]; ok {
				p.ClickTab = tab
			}
			var info model.StatisticsInfoEs
			info.ID = fmt.Sprintf("%d", helper.Cputicks())
			info.UID = member.UID
			info.TopMerchantId = member.TopMerchantId
			info.MerchantID = member.MerchantID
			info.SortLevel = member.SortLevel
			info.Device = device
			info.ClickNumber = p.ClickNumber
			info.ClickTab = p.ClickTab
			info.Page = p.Page
			info.CreatedAt = ctx.Time().Unix()
			if int64(member.RegisterTime) > startTime && int64(member.RegisterTime) < endTime {
				info.Types = model.NewUser
			} else {
				info.Types = model.OldUser
			}

			infos = append(infos, info)
		}
	}

	if len(infos) > 0 {
		err = model.StatisticsInfoEsInsert(infos)
		if err != nil {
			zlog.Error(ctx, "statisticsInfo", "", fmt.Sprintf("statistics info fail, uid:%d, device:%v, err:%s", member.UID, device, err.Error()), member.UID, member.MerchantID)
		}
	}

	helper.Print(ctx, "true", "succeed")
}

/*
* @Description:根据ua获取终端
* @Author: abraham
* @Date: 2021/5/24 14:07
* @LastEditTime: 2021/5/24 14:07
* @LastEditors: abraham
 */
func getDeviceType(uaStr string) uint8 {

	if strings.Contains(uaStr, "iPhone") {
		return model.IosDevice
	}

	if strings.Contains(uaStr, "Android") {
		return model.AndroidDevice
	}

	if strings.Contains(uaStr, "Windows") {
		return model.PcDevice
	}

	return model.OtherDevice
}

/*
* @Description:获取会员今日最高中奖(派彩)金额
* @Author: awen
* @Date: 2022-01-17 15:36
* @LastEditTime: 2022-01-17 15:36
* @LastEditors: awen
 */
func (that *MemberController) TodayMaxPrize(ctx *fasthttp.RequestCtx) {

	member, err := model.GetTokenData(ctx)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	maxPrize, err := model.MemberTodayMaxPrize(member.UID)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	helper.Print(ctx, "true", maxPrize)
}

/*
* @Description: 会员设置默认语言
* @Author: jinxi
* @Date: 2022/2/9 13:28
* @LastEditTime: 2022/2/9 13:28
* @LastEditors: jinxi
 */
func (that *MemberController) LangSet(ctx *fasthttp.RequestCtx) {

	lan := string(ctx.QueryArgs().Peek("lang"))

	//获取用户信息
	member, err := model.GetTokenData(ctx)
	if err != nil {
		model.AddLog(model.LogError, model.LogFlag, ctx.ID(), "GetTokenData fail: %s", err.Error())
		helper.Print(ctx, "false", fmt.Sprintf("error, trace:%d", ctx.ID()))
		return
	}

	member.Lang = lan
	err = model.MemberLangSet(member)
	if err != nil {
		model.AddLog(model.LogError, model.LogFlag, ctx.ID(), "MemberLangSet fail: %s", err.Error())
		helper.Print(ctx, "false", fmt.Sprintf("error, trace:%d", ctx.ID()))
		return
	}

	helper.Print(ctx, "true", "succeed")
}

/*
* @Description: 获取节庆图片
* @Author: jinxi
* @Date: 2022/3/15 14:56
* @LastEditTime: 2022/3/15 14:56
* @LastEditors: jinxi
 */
func (that *MemberController) GetFestival(ctx *fasthttp.RequestCtx) {

	lan := string(ctx.Request.Header.Peek("lang"))

	data, err := model.GetFestivalUI(lan)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	helper.Print(ctx, "true", data)
}

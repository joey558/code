package controller

import (
	"errors"
	"fmt"
	"game/contrib/validator"
	"game/helper"
	"game/lang"
	"game/model"
	"game/utils"
	fund "game/wallet"
	"strings"

	"github.com/shopspring/decimal"
	"github.com/valyala/fasthttp"
)

type LimitBetController struct{}

// 获取剩余投注配置参数
type BetSurplusQuotaParam struct {
	MatchID  string `rule:"digit" min:"1" msg:"match_id格式不正确" name:"match_id"`   //比赛编号
	MarketID string `rule:"digit" min:"1" msg:"market_id格式不正确" name:"market_id"` //盘口编号
	OddId    string `rule:"digit" min:"1" msg:"odd_id格式不正确" name:"odd_id"`       //投注项编号
}

// 投注风控参数
type BetRiskParam struct {
	Member               fund.Member                `json:"member"`                  // 会员信息
	MatchIds             []string                   `json:"match_ids"`               // 赛事ID
	MarketIds            []string                   `json:"market_ids"`              // 赛事ID
	MktTotalAmount       map[string]decimal.Decimal `json:"mkt_total_amount"`        // 盘口总投注金额
	SimpleRiskFlag       bool                       `json:"simple_risk_flag"`        // 是否需要单注风控
	ComplexRiskFlag      bool                       `json:"complex_risk_flag"`       // 是否需要串注风控
	RoundComplexRiskFlag bool                       `json:"round_complex_risk_flag"` // 是否需要局内串关风控
	RiskSetting          map[string]decimal.Decimal `json:"risk_setting"`            // 全局风控设置
	Simples              []*model.SimpleBetContent  `json:"simples"`                 // 单住投注内容
	Complexes            []*model.ComplexBetContent `json:"complexes"`               // 串注内容
}

/**
 * @Description: 获取会员投注项最高投注限额
 * @Author: awen
 * @Date: 2020/7/16
 * @LastEditTime: 2020/7/17
 * @LastEditors: awen
 **/
func (that *LimitBetController) SurplusQuota(ctx *fasthttp.RequestCtx) {

	lan := string(ctx.Request.Header.Peek("lang"))
	var param BetSurplusQuotaParam
	err := validator.Bind(ctx, &param)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	//获取用户信息
	member, err := model.GetTokenData(ctx)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	mpMatchMarketID := map[string]string{
		param.MarketID: param.MatchID,
	}

	// 获取盘口信息
	handicapInfo, err := model.HandicapInfo(mpMatchMarketID)
	if err != nil {
		helper.Print(ctx, "false", lang.Text(lan, "errLoadHandicap"))
		return
	}

	//2.获取会员赛事和盘口预期盈利统计
	orderTheoryStat, err := model.OrderTheoryPrizeStatDB(member.UID, []string{param.MatchID}, []string{param.MarketID})
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	//读取风控基本参数
	risks, err := model.GetRiskSetting(0, model.RedisBasicSettingsForRisk, lan, model.RiskSettingFields)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	//3.计算用户投注限额
	v, err := model.RiskMarketPrizeLimitCalc(member, []string{param.MarketID}, handicapInfo, orderTheoryStat, lan) //最小赔付
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	rate := decimal.NewFromInt(1)
	if member.CurrencyCode != model.DefaultCurrencyCode && member.CurrencyCode != 0 {
		r, err := model.GetRate(member.CurrencyCode)
		if err != nil {
			helper.Print(ctx, "false", "获取汇率失败, "+err.Error())
			return
		}

		rate = decimal.NewFromFloat(r)
	}
	dailyTotal, err := model.GetMemberDailyTotal(member.MerchantID, member.UID)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	data := model.MemberSurplusQuota{
		SimpleMin:           risks["simple_min_bet"],
		SimpleMax:           decimal.Min(v.MktLimitVal[param.MarketID], v.MchLimitVal[param.MatchID]),
		PrizeStaticProfit:   decimal.NewFromInt(int64(v.MktPrizeStaticProfit[param.MarketID])).Mul(rate).Floor().String(),
		ComplexMin:          risks["complex_min_bet"].Mul(rate).Ceil(),
		ComplexMaxPrize:     v.ComplexMaxPrize.Mul(rate).Floor(),
		RndCompMaxPrize:     decimal.Min(v.RndCompMaxPrize, v.RndCompMchMaxPrize).Mul(rate).Floor(),
		RndCompMaxOdd:       risks["round_complex_max_odd"],
		MixPrizeLimit:       decimal.Min(v.MixPrizeLimit, v.MchLimitVal[param.MatchID]).Mul(rate).Floor(),
		WinBalance:          dailyTotal[model.MemberWinTotal].Mul(rate).Floor(),
		SimplePrizeBalance:  decimal.Max(dailyTotal[model.MemberSinglePrizeTotal].Mul(rate).Floor(), decimal.Zero),
		ComplexPrizeBalance: decimal.Max(dailyTotal[model.MemberComplexPrizeTotal].Mul(rate).Floor(), decimal.Zero),
	}
	switch member.Tester {
	case model.UserTypeCredit:
		data.CreditLimit = &model.CreditLimit{}
		err = data.CreditLimit.GetCreditLimit(ctx.ID(), member.AgentID, //代理(商户)ID
			member.UID,     //会员UID
			param.MatchID,  //赛事ID
			param.MarketID, //盘口ID
			handicapInfo,   //赛事信息
			rate,           //汇率
		)
		if err != nil {
			helper.Print(ctx, "false", err.Error())
			return
		}

	default:
		data.MemberLimit = &model.MemberLimit{}
		_, err = data.MemberLimit.GetMemberComplexLimit(
			member,         //会员
			param.MatchID,  //赛事ID
			param.MarketID, //盘口ID
			lan,            //语言
			handicapInfo,   //赛事信息
			data.SimpleMax, //单注最大
			v.MchCompLimit, //串注限额
			rate,           //汇率
		)
		if err != nil {
			helper.Print(ctx, "false", err.Error())
			return
		}
	}

	match := handicapInfo.Matches[param.MatchID]
	if match.SID != "0" {
		oddTypeID := handicapInfo.Markets[param.MarketID].OddTypeID

		bSportsGame := utils.CheckSportsGameID(match.GameID)
		// 获取体育的限红数据
		tyMinBet := decimal.Zero      // 最小可投注金额【无需处理，直接使用】
		tyOrderMaxPay := decimal.Zero // 最大可投注金额【无需处理，直接使用】
		limitResp, err := model.TYGetLimitResp(member.UID, member.Account, match.SID, param.MarketID, param.OddId, oddTypeID, bSportsGame, match.IsLive, 1)
		if err != nil {
			fmt.Println(err)
		} else if len(limitResp.Data) > 0 {
			tyMinBet = limitResp.Data[0].MinBet
			tyOrderMaxPay = limitResp.Data[0].OrderMaxPay
		}

		tyOrderMaxPay = model.TYCalcMaxLimit(tyMinBet, tyOrderMaxPay)

		odds := handicapInfo.Odds[param.OddId]
		oddV, _ := decimal.NewFromString(odds.Odd)
		tyOrderMaxPay = tyOrderMaxPay.Mul(oddV.Sub(model.DecimalOne))

		data.SimpleMin = decimal.Max(data.SimpleMin, tyMinBet)
		if bSportsGame {
			data.SimpleMax = tyOrderMaxPay
			data.PrizeStaticProfit = fmt.Sprintf("%v", data.SimpleMax)
		} else {
			data.SimpleMax = decimal.Min(data.SimpleMax, tyOrderMaxPay)
		}
	}

	data.SimpleMin = decimal.Max(data.SimpleMin, decimal.Zero).Mul(rate).Ceil()
	data.SimpleMax = decimal.Max(data.SimpleMax, decimal.Zero).Mul(rate).Floor()

	helper.Print(ctx, "true", data)
}

/**
 * @Description: 用户投注风控
 * @Author: awen
 * @Date: 2020/7/24
 * @LastEditTime: 2020/7/24
 * @LastEditors: awen
 **/
func betRisk(riskParam BetRiskParam, handicaps utils.HandicapData, rate decimal.Decimal, lan string) (model.MarketRiskLimit, error) {

	mktRiskLimit := model.MarketRiskLimit{}
	// 投注风控-1.统计会员赛事和盘口有效注单预期派彩金额
	orderTheoryStat, err := model.OrderTheoryPrizeStatDB(riskParam.Member.UID, riskParam.MatchIds, riskParam.MarketIds)
	if err != nil {
		return mktRiskLimit, errors.New(lang.Text(lan, "msgBetFail") + err.Error())
	}

	// 投注风控-2.计算出每个投注盘口的最高赔付值
	mktRiskLimit, err = model.RiskMarketPrizeLimitCalc(riskParam.Member, riskParam.MarketIds, handicaps, orderTheoryStat, lan) //最小赔付
	if err != nil {
		return mktRiskLimit, errors.New(lang.Text(lan, "msgBetFail") + err.Error())
	}

	// 单注注单风控
	if riskParam.SimpleRiskFlag {
		err = RiskCheckSimple(mktRiskLimit, riskParam.Simples, rate, lan)
		if err != nil {
			return mktRiskLimit, err
		}
	}

	// 串注注单风控
	if riskParam.ComplexRiskFlag {
		err = RiskCheckComplex(riskParam.Complexes, mktRiskLimit, handicaps, riskParam.RiskSetting["round_complex_max_odd"], rate, lan)
		if err != nil {
			return mktRiskLimit, err
		}
	}

	return mktRiskLimit, nil
}

// GetOverrunSetting
/**
* @Description: 串注超限设置数据
* @Author: noah
* @Date: 2022/2/6 17:16
* @LastEditTime:2022/2/6 17:16
* @LastEditors: noah
 */
func (that *LimitBetController) GetOverrunSetting(ctx *fasthttp.RequestCtx) {

	data := map[string]float64{}
	lan := string(ctx.Request.Header.Peek("lang"))
	//获取用户信息
	member, err := model.GetTokenData(ctx)
	if err != nil {
		helper.Print(ctx, "false", lang.Text(lan, "msgBetFail")+err.Error())
		return
	}

	rate := decimal.NewFromInt(1)
	if member.CurrencyCode != model.DefaultCurrencyCode && member.CurrencyCode != 0 {
		r, err := model.GetRate(member.CurrencyCode)
		if err != nil {
			helper.Print(ctx, "false", lang.Text(lan, "msgBetFail")+err.Error())
			return
		}

		rate = decimal.NewFromFloat(r)
	}

	limits, err := model.GetOverrunSetting(0)
	if err != nil {
		helper.Print(ctx, "false", lang.Text(lan, "msgGetOverrunError")+err.Error())
		return
	}

	for k, v := range limits {
		f, _ := v.Float64()
		if strings.Contains(k, "bet") {
			v = v.Mul(rate).Floor()
			f, _ = v.Float64()
		}
		data[k] = f
	}

	helper.Print(ctx, "true", data)
}

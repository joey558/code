package controller

import (
	"game/contrib/validator"
	"game/helper"
	"game/model"
	"github.com/valyala/fasthttp"
)

type VirtualController struct{}

type videoRplListParam struct {
	GameID  string `default:"0" rule:"sDigit" min:"0" msg:"game_id error"  name:"game_id"`    // 游戏ID, 多个以逗号分开
	TourID  string `default:"0" rule:"sDigit" min:"0" msg:"tour_id error"  name:"tour_id"`    // 联赛ID
	BatchNo string `default:"0"  rule:"sDigit"  min:"0" msg:"batch_no error" name:"batch_no"` // 批次号
}

/**
 * @Description: 虚拟体育视频
 * @Author:Sven
 * @Date:2022/4/6 15:25
 * @LastEditTime: 2022/4/6 15:25
 * @LastEditors: Sven
 */
func (v *VirtualController) VideoRpl(ctx *fasthttp.RequestCtx) {

	var param videoRplListParam
	err := validator.Bind(ctx, &param)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}
	rplJSON, err := model.VirtualVideoRpl(param.GameID, param.TourID, param.BatchNo)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	helper.PrintJson(ctx, "true", rplJSON)
}

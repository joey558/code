package controller

import (
	"fmt"
	"game/contrib/validator"
	"game/helper"
	"game/lang"
	"game/model"
	"game/utils"
	"github.com/valyala/fasthttp"
	"strconv"
	"strings"
)

var (
//gameNavEncoder = jingo.NewSliceEncoder([]model.GameNav{})
)

type GameController struct{}

type UserVerParam struct {
	DeviceType int    `rule:"digit" min:"1" msg:"device_type错误" name:"device_type"` // 设备类型;1=pc,2=h5
	Version    string `rule:"none" msg:"version error" name:"version"`              // 版本号
}

/**
* @Description: 游戏菜单
* @Author: wesley
* @Date: 2020/6/27 10:47 上午
* @LastEditTime: 2020/6/27 10:47 上午
* @LastEditors: wesley
 */
func (that *GameController) Nav(ctx *fasthttp.RequestCtx) {

	var data []model.GameNav

	user, err := model.GetTokenData(ctx)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	data, err = model.GameNavGet(user.MerchantID)
	if err != nil {
		model.AddLog(model.LogError, model.LogFlag, ctx.ID(), "GameNavGet fail: %s", err.Error())
		helper.Print(ctx, "false", fmt.Sprintf("error, trace:%d", ctx.ID()))
		return
	}

	lan := string(ctx.Request.Header.Peek("lang"))
	for i, v := range data {
		if lan == "" {
			data[i].Name = v.NameMap[lang.CN]
			continue
		}
		data[i].Name = v.NameMap[lan]
	}

	helper.Print(ctx, "true", data)
}

/**
 * @Description: 通过游戏id获取联赛列表
 * @Author: maxic
 * @Date: 2021/1/30
 * @LastEditTime: 2021/1/30
 * @LastEditors: maxic
 **/
func (that *GameController) Tour(ctx *fasthttp.RequestCtx) {

	lan := string(ctx.Request.Header.Peek("lang"))
	gameId := string(ctx.QueryArgs().Peek("game_id"))
	if !validator.CheckStringDigit(gameId) {
		helper.Print(ctx, "false", lang.Text(lan, "errParameter"))
		return
	}

	user, err := model.GetTokenData(ctx)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	res, err := model.GameTourGet(gameId, user.MerchantID)
	if err != nil {
		model.AddLog(model.LogError, model.LogFlag, ctx.ID(), "GameTourGet fail: %s", err.Error())
		helper.Print(ctx, "false", fmt.Sprintf("error, trace:%d", ctx.ID()))
		return
	}

	helper.Print(ctx, "true", res)
}

/*
 * @Description: 联赛-虚拟体育
 * @Author: robin
 * @Date: 2022/4/3 15:52
 * @LastEditTime: 2022/4/3 15:52
 * @LastEditors: robin
 */
func (that *GameController) SportsTour(ctx *fasthttp.RequestCtx) {

	lan := string(ctx.Request.Header.Peek("lang"))
	gameId := string(ctx.QueryArgs().Peek("game_id"))
	if !validator.CheckStringDigit(gameId) {
		helper.Print(ctx, "false", lang.Text(lan, "errParameter"))
		return
	}

	if !utils.CheckSportsGameID(gameId) {
		helper.Print(ctx, "false", "the virtual sports gameId is error.")
		return
	}

	user, err := model.GetTokenData(ctx)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	data, err := model.SportsGameTourGet(gameId, lan, user.MerchantID)
	if err != nil {
		model.AddLog(model.LogError, model.LogFlag, ctx.ID(), "GameTourGet fail: %s", err.Error())
		helper.Print(ctx, "false", fmt.Sprintf("error, trace:%d", ctx.ID()))
		return
	}

	helper.Print(ctx, "true", data)
}

/**
* @Description: 通过游戏id获取游戏名
* @Author: brandon
* @Date: 2020/6/30 10:19 下午
* @LastEditTime: 2020/6/30 10:19 下午
* @LastEditors: brandon
 */
func (that *GameController) GetName(ctx *fasthttp.RequestCtx) {

	lan := string(ctx.Request.Header.Peek("lang"))
	ids := string(ctx.PostArgs().Peek("ids"))
	if !validator.CheckStringCommaDigit(ids) {
		helper.Print(ctx, "false", lang.Text(lan, "errParameter"))
		return
	}
	arr := strings.Split(ids, ",")

	value, err := model.GameGetName(arr)
	if err != nil {
		model.AddLog(model.LogError, model.LogFlag, ctx.ID(), "GameGetName fail: %s", err.Error())
		helper.Print(ctx, "false", fmt.Sprintf("error, trace:%d", ctx.ID()))
		return
	}

	helper.Print(ctx, "true", value)
}

/**
* @Description: 通过联赛ids获取联赛名列表
* @Author: maxic
* @Date: 2020/7/4
* @LastEditTime: 2021/10/2 14:36
* @LastEditors: robin
 */
func (that *GameController) GetTourName(ctx *fasthttp.RequestCtx) {

	lan := string(ctx.Request.Header.Peek("lang"))
	ids := string(ctx.PostArgs().Peek("ids"))
	if !validator.CheckStringCommaDigit(ids) {
		helper.Print(ctx, "false", lang.Text(lan, "errParameter"))
		return
	}

	arrId := strings.Split(ids, ",")
	data := model.MultiLanguageName(model.RamDataTournament, arrId, lan)

	helper.Print(ctx, "true", data)
}

/**
* @Description: 用户首次登录新上版本时 弹出引导页
* @Author: cupid
* @Date: 2021/09/07
* @LastEditTime: 2021/09/07
* @LastEditors: cupid
 */
func (that *GameController) UserVer(ctx *fasthttp.RequestCtx) {

	param := UserVerParam{}
	lan := string(ctx.Request.Header.Peek("lang"))
	err := validator.Bind(ctx, &param)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	if param.Version == "" {
		helper.Print(ctx, "false", lang.Text(lan, "msgVersionCantNull"))
		return
	}

	//获取用户信息
	member, err := model.GetTokenData(ctx)
	if err != nil {
		model.AddLog(model.LogError, model.LogFlag, ctx.ID(), "GetTokenData fail: %s", err.Error())
		helper.Print(ctx, "false", fmt.Sprintf("error, trace:%d", ctx.ID()))
		return
	}

	oldVerStr, err := model.UserVer(member, param.DeviceType, param.Version)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
	}

	helper.PrintJson(ctx, "true", oldVerStr)
}

func (that *GameController) CheckCacheData(ctx *fasthttp.RequestCtx) {

	u, err := model.GetTokenData(ctx)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	fmt.Printf("RamDataCheck merchant[%s] account[%s]\n", u.MerchantAccount, u.Account)
	key := string(ctx.QueryArgs().Peek("key"))
	helper.Print(ctx, "true", model.GetCacheDataMap(key))
}

func (that *GameController) HotMatchDataSizeSet(ctx *fasthttp.RequestCtx) {

	lan := string(ctx.Request.Header.Peek("lang"))
	nStr := string(ctx.PostArgs().Peek("n"))
	if !validator.CheckStringDigit(nStr) {
		helper.Print(ctx, "false", lang.Text(lan, "errParameter"))
		return
	}

	u, err := model.GetTokenData(ctx)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	fmt.Printf("HotMatchDataSizeSet merchant[%s] account[%s] match size[%s]\n", u.MerchantAccount, u.Account, nStr)

	n, err := strconv.Atoi(nStr)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	if n < 0 || n > 10 {
		helper.Print(ctx, "false", lang.Text(lan, "msgRange"))
		return
	}

	model.UpdateHotMatchSize(n)
	helper.Print(ctx, "true", lang.Text(lan, "msgModify"))
}

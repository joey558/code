package controller

import (
	"game/contrib/jingo"
	"game/contrib/validator"
	"game/helper"
	"game/lang"
	"game/model"
	"game/utils"
	"strings"

	_ "github.com/doug-martin/goqu/v9/dialect/mysql"
	"github.com/valyala/fasthttp"
)

type MatchController struct{}

type MatchListParam struct {
	GameID   string `default:"0" rule:"sDigit" min:"0" msg:"game_id error"  name:"game_id"`     // 游戏ID, 多个以逗号分开
	Flag     int    `default:"0" rule:"digit" min:"0" max:"8" msg:"flag error"  name:"flag"`    // 标识 (0:全部,1:今日,2:赛前,3:滚盘,4:串关,5:赛果,6:筛选,7:主播盘,8:冠军盘)
	Day      int    `default:"0" rule:"digit" msg:"day error"  name:"day"`                      // 天
	PageSize int64  `default:"20" rule:"digit" min:"20" msg:"page_size error" name:"page_size"` //页码
}

type SportsMatchListParam struct {
	GameID string `default:"0" rule:"sDigit" min:"0" msg:"game_id error"  name:"game_id"` // 游戏ID, 多个以逗号分开
	TourID string `default:"0" rule:"sDigit" min:"0" msg:"tour_id error"  name:"tour_id"` // 联赛ID
}

type SportsMatchResultListParam struct {
	GameID string `default:"0" rule:"sDigit" min:"0" msg:"game_id error"  name:"game_id"`   // 游戏ID, 多个以逗号分开
	TourID string `default:"0" rule:"sDigit" min:"0" msg:"tour_id error"  name:"tour_id"`   // 联赛ID
	Day    int    `default:"0" rule:"digit"  min:"0" max:"6" msg:"day error"  name:"day"`   // 天
	Page   int64  `default:"0" rule:"digit" min:"0" msg:"page_size error" name:"page_size"` //页码
}

type SportsMatchBatchNoResultListParam struct {
	GameID  string `default:"0" rule:"sDigit" min:"0" msg:"game_id error"  name:"game_id"`    // 游戏ID, 多个以逗号分开
	TourID  string `default:"0" rule:"sDigit" min:"0" msg:"tour_id error"  name:"tour_id"`    // 联赛ID
	BatchNo string `default:"0" rule:"sDigit"  min:"0" msg:"batch_no error"  name:"batch_no"` // 批次
}

type MatchIdsParam struct {
	Ids string `name:"ids" rule:"sDigit" msg:"ids错误"` // IDs, 多个以逗号分开
}

var matchStatDataEnc = jingo.NewStructEncoder(utils.MatchCountStat{})

func (that *MatchController) Index(ctx *fasthttp.RequestCtx) {

	lan := string(ctx.Request.Header.Peek("lang"))
	var param MatchListParam
	err := validator.Bind(ctx, &param)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	user, err := model.GetTokenData(ctx)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	data, err := model.GameIndexGet(param.GameID, param.Flag, param.Day, param.PageSize, ctx.Time(), user.MerchantID, lan)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	helper.Print(ctx, "true", data)
}

func (that *MatchController) SportsIndex(ctx *fasthttp.RequestCtx) {

	lan := string(ctx.Request.Header.Peek("lang"))
	var param SportsMatchListParam
	err := validator.Bind(ctx, &param)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	if !utils.CheckSportsGameID(param.GameID) {
		helper.Print(ctx, "false", "the virtual sports gameId is error.")
		return
	}

	user, err := model.GetTokenData(ctx)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	data, err := model.SportsGameIndexGet(param.GameID, param.TourID, "", user.MerchantID, lan, 0, 0, model.SportsMatchEarly)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	helper.Print(ctx, "true", data)
}

func (that *MatchController) SportsIndexResult(ctx *fasthttp.RequestCtx) {

	lan := string(ctx.Request.Header.Peek("lang"))
	var param SportsMatchResultListParam
	err := validator.Bind(ctx, &param)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	if !utils.CheckSportsGameID(param.GameID) {
		helper.Print(ctx, "false", "the virtual sports gameId is error.")
		return
	}

	user, err := model.GetTokenData(ctx)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	data, err := model.SportsGameIndexGet(param.GameID, param.TourID, "", user.MerchantID, lan, param.Day, param.Page, model.SportsMatchResult)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	helper.Print(ctx, "true", data)
}

func (that *MatchController) SportsBatchNoResult(ctx *fasthttp.RequestCtx) {

	lan := string(ctx.Request.Header.Peek("lang"))
	var param SportsMatchBatchNoResultListParam
	err := validator.Bind(ctx, &param)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	if !utils.CheckSportsGameID(param.GameID) {
		helper.Print(ctx, "false", "the virtual sports gameId is error.")
		return
	}

	user, err := model.GetTokenData(ctx)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	data, err := model.SportsGameIndexGet(param.GameID, param.TourID, param.BatchNo, user.MerchantID, lan, 0, 0, model.SportsMatchBatchNoResult)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	helper.Print(ctx, "true", data)
}

func (that *MatchController) Recommend(ctx *fasthttp.RequestCtx) {

	user, err := model.GetTokenData(ctx)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	lan := string(ctx.Request.Header.Peek("lang"))
	data, err := model.RecommendMatchGet(user.MerchantID, lan)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	helper.Print(ctx, "true", data)

}

func (that *MatchController) GetTimer(ctx *fasthttp.RequestCtx) {

	data := model.MatchTimerRamGet()
	helper.Print(ctx, "true", data)
}

func (that *MatchController) MatchStat(ctx *fasthttp.RequestCtx) {

	gameID := string(ctx.QueryArgs().Peek("game_id"))
	var ids []string
	if gameID != "" {
		ids = strings.Split(gameID, ",")
	} else {

	}

	user, err := model.GetTokenData(ctx)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	data, err := model.MatchStatistics(user.MerchantID, ids, ctx.Time())
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	buf := jingo.NewBufferFromPool()
	matchStatDataEnc.Marshal(&data, buf)
	helper.PrintJson(ctx, "true", buf.String())
	buf.ReturnToPool()
}

//用户 前台盘口详情展示
func (that *MatchController) View(ctx *fasthttp.RequestCtx) {

	lan := string(ctx.Request.Header.Peek("lang"))
	matchID := string(ctx.QueryArgs().Peek("match_id")) // 盘口
	if !validator.CheckStringCommaDigit(matchID) {
		helper.Print(ctx, "false", lang.Text(lan, "errParameter"))
		return
	}

	user, err := model.GetTokenData(ctx)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	data, err := model.GameViewGet(matchID, user.MerchantID, lan)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	helper.Print(ctx, "true", data)
}

//用户 前台盘口详情展示-虚拟体育
func (that *MatchController) SportsView(ctx *fasthttp.RequestCtx) {

	lan := string(ctx.Request.Header.Peek("lang"))
	matchID := string(ctx.QueryArgs().Peek("match_id")) // 盘口
	if !validator.CheckStringCommaDigit(matchID) {
		helper.Print(ctx, "false", lang.Text(lan, "errParameter"))
		return
	}

	user, err := model.GetTokenData(ctx)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	data, err := model.SportsGameViewGet(matchID, user.MerchantID, lan)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	helper.Print(ctx, "true", data)
}

//通过IDS查询赛事列表
func (that *MatchController) MatchList(ctx *fasthttp.RequestCtx) {

	var param MatchIdsParam
	lan := string(ctx.Request.Header.Peek("lang"))
	err := validator.Bind(ctx, &param)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	mchIDs := strings.Split(param.Ids, ",")
	if len(mchIDs) == 0 {
		helper.Print(ctx, "false", lang.Text(lan, "msgIDCantNull"))
		return
	}

	user, err := model.GetTokenData(ctx)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	data, err := model.MatchIdsGet(mchIDs, user.MerchantID, lan)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	//处理冠军盘赛事
	for i, match := range data {
		if match.Category != 2 { // 冠军盘
			continue
		}

		champMarkets, err := model.ChampMarketList(lan, match.ID, match.MktIDs)
		if err != nil {
			helper.Print(ctx, "false", err.Error())
			return
		}

		data[i].ChampMarkets = champMarkets
	}

	helper.Print(ctx, "true", data)

}

// 获取主播盘小局开始时间和游戏截图
func (that *MatchController) AnchorInfo(ctx *fasthttp.RequestCtx) {

	var param MatchIdsParam
	lan := string(ctx.Request.Header.Peek("lang"))
	err := validator.Bind(ctx, &param)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	mchIDs := strings.Split(param.Ids, ",")
	if len(mchIDs) == 0 {
		helper.Print(ctx, "false", lang.Text(lan, "msgIDCantNull"))
		return
	}

	data, err := model.MatchAnchorInfoGet(mchIDs, lan)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	helper.Print(ctx, "true", data)
}

// 获取冠军盘战队
func (that *MatchController) GetTeam(ctx *fasthttp.RequestCtx) {

	var param MatchIdsParam
	lan := string(ctx.Request.Header.Peek("lang"))
	err := validator.Bind(ctx, &param)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	mchIDs := strings.Split(param.Ids, ",")
	if len(mchIDs) == 0 {
		helper.Print(ctx, "false", lang.Text(lan, "msgIDCantNull"))
		return
	}

	data, err := model.MatchChampTeamGet(mchIDs)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	helper.Print(ctx, "true", data)
}

// 获取有视频源的赛事列表
func (that *MatchController) GetVideoList(ctx *fasthttp.RequestCtx) {

	var result []model.GetVideoData

	// 从缓存中获取正在滚球的赛事
	data, err := model.VideoGameIndexGet("0", 3, 0, 0, ctx.Time())
	if err != nil {
		helper.Print(ctx, "false", result)
		return
	}

	arr, ok := data.([]interface{})
	if !ok {
		helper.Print(ctx, "false", result)
		return
	}

	for _, item := range arr {
		strJson, ok := item.(string)
		if !ok {
			continue
		}

		// 解析赛事信息
		var mchInfo utils.GameIndex
		err = helper.JsonUnmarshal([]byte(strJson), &mchInfo)
		if err != nil {
			continue
		}

		// 判断是否 开盘 滚球 并且有视频URL https://
		// ios取值UserVideoURL,  PC，安卓取值AdminVideoURL
		if mchInfo.Status != 5 || mchInfo.IsLive != 2 || (len(mchInfo.UserVideoURL) < 8 && len(mchInfo.AdminVideoURL) < 8) {
			continue
		}

		videoData := model.GetVideoData{
			MatchID:             mchInfo.ID,
			GameID:              mchInfo.GameID,
			VideoType:           mchInfo.VideoType,
			MatchCnTeam:         mchInfo.MatchCnTeam,
			MatchEnTeam:         mchInfo.MatchEnTeam,
			TournamentShortName: mchInfo.TournamentShortName,
			TournamentCnName:    mchInfo.TournamentCnName,
			MatchLevel:          mchInfo.MatchLevel,
		}

		videoData.Videos = []string{}
		if len(mchInfo.UserVideoURL) > 8 {
			videoData.Videos = append(videoData.Videos, mchInfo.UserVideoURL)
		}
		if len(mchInfo.AdminVideoURL) > 8 {
			videoData.Videos = append(videoData.Videos, mchInfo.AdminVideoURL)
		}

		result = append(result, videoData)
	}

	helper.Print(ctx, "true", result)
}

//ob旗舰-热门推荐
func (that *MatchController) ObRecommend(ctx *fasthttp.RequestCtx) {

	data, err := model.ObRecommendMatchGet(ctx.Time())
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	helper.Print(ctx, "true", data)

}

/*
* @Description: 一般联赛积分榜
* @Author: jinxi
* @Date: 2022/3/25 12:49
* @LastEditTime: 2022/3/25 12:49
* @LastEditors: jinxi
 */
func (that *MatchController) CommonScore(ctx *fasthttp.RequestCtx) {

	lan := string(ctx.Request.Header.Peek("lang"))
	tourId := string(ctx.QueryArgs().Peek("tour_id"))

	data, err := model.GetCommonScore(tourId, lan)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	helper.Print(ctx, "true", data)
}

/*
* @Description: 小组赛积分榜
* @Author: jinxi
* @Date: 2022/3/25 13:47
* @LastEditTime: 2022/3/25 13:47
* @LastEditors: jinxi
 */
func (that *MatchController) GroupScore(ctx *fasthttp.RequestCtx) {

	lan := string(ctx.Request.Header.Peek("lang"))
	tourId := string(ctx.QueryArgs().Peek("tour_id"))

	data, err := model.GetGroupScore(tourId, lan)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	helper.Print(ctx, "true", data)
}

/*
* @Description: 淘汰赛积分榜
* @Author: jinxi
* @Date: 2022/3/25 13:55
* @LastEditTime: 2022/3/25 13:55
* @LastEditors: jinxi
 */
func (that *MatchController) DisuseScore(ctx *fasthttp.RequestCtx) {

	lan := string(ctx.Request.Header.Peek("lang"))
	tourId := string(ctx.QueryArgs().Peek("tour_id"))

	data, err := model.GetDisuseScore(tourId, lan)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	helper.Print(ctx, "true", data)
}

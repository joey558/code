package controller

import (
	"fmt"
	"github.com/valyala/fasthttp"
	"github.com/wI2L/jettison"
	"time"

	"game/contrib/validator"
	"game/helper"
	"game/model"
)

type NoticeController struct{}

type noticeListParam struct {
	Page     int64 `rule:"digit" default:"1" min:"1" msg:"page错误" name:"page"`            // 页码
	PageSize int64 `rule:"digit" default:"10" min:"1" msg:"page_size错误" name:"page_size"` // 页大小
}

/**
 * @Description:公告列表
 * @Author: curt
 * @Date: 2020/6/14 上午11:26
 * @LastEditTime: 2020/6/14 上午11:26
 * @LastEditors: curt
 */
func (that *NoticeController) List(ctx *fasthttp.RequestCtx) {

	param := noticeListParam{}
	err := validator.Bind(ctx, &param)
	if err != nil {
		helper.Print(ctx, "false", err.Error())
		return
	}

	lan := string(ctx.Request.Header.Peek("lang"))
	y, m, d := ctx.Time().Date()
	today := time.Date(y, m, d, 0, 0, 0, 0, ctx.Time().Location())
	data, err := model.NoticeList(lan, today, param.Page, param.PageSize)
	if err != nil {
		model.AddLog(model.LogError, model.LogFlag, ctx.ID(), "NoticeList fail: %s", err.Error())
		helper.Print(ctx, "false", fmt.Sprintf("error, trace:%d", ctx.ID()))
		return
	}

	//i18nData := model.NoticeI18nRespFormat(data, lan)

	res, err := jettison.MarshalOpts(data, jettison.NoHTMLEscaping())
	if err != nil {
		model.AddLog(model.LogError, model.LogFlag, ctx.ID(), "MarshalOpts fail: %s", err.Error())
		helper.Print(ctx, "false", fmt.Sprintf("error, trace:%d", ctx.ID()))
		return
	}

	helper.PrintJson(ctx, "true", string(res))
}

package mRejson

import (
	"fmt"
	"github.com/go-redis/redis/v7"
	jsoniter "github.com/json-iterator/go"
)

var cjson = jsoniter.ConfigCompatibleWithStandardLibrary

func Build(cli *redis.Client, cache MCache) error {

	key := fmt.Sprintf("merch:%d", cache.ID)
	buf, err := cjson.Marshal(cache)
	if err != nil {
		return err
	}

	err = cli.Do("JSON.SET", key, ".", buf).Err()
	if err != nil {
		return err
	}

	if cache.ParentID > 0 {
		key = fmt.Sprintf("merch:%d", cache.ParentID)
		err = cli.Do("JSON.SET", key, fmt.Sprintf(".sub_merchant.$%d", cache.ID), buf).Err()
		if err != nil {
			return err
		}
	}

	return nil
}

func Get(cli *redis.Client, merchantID uint64) (MCache, error) {

	merchant := MCache{}
	key := fmt.Sprintf("merch:%d", merchantID)
	data, err := cli.Do("JSON.GET", key).Text()
	if err != nil {
		return merchant, err
	}

	err = cjson.UnmarshalFromString(data, &merchant)

	return merchant, err
}

func GetSub(cli *redis.Client, merchantID uint64) (map[string]MCache, error) {

	merchant := map[string]MCache{}
	key := fmt.Sprintf("merch:%d", merchantID)
	data, err := cli.Do("JSON.GET", key, "NOESCAPE", ".sub_merchant").Text()
	if err != nil {
		return merchant, err
	}

	err = cjson.UnmarshalFromString(data, &merchant)

	return merchant, err
}

package mRejson

import (
	"fmt"
	"github.com/go-redis/redis/v7"
)

func BuildAgent(cli *redis.Client, cache AgentCache) error {

	key := fmt.Sprintf("agent:%d", cache.ID)
	buf, err := cjson.Marshal(cache)
	if err != nil {
		return err
	}

	err = cli.Do("JSON.SET", key, ".", buf).Err()
	if err != nil {
		return err
	}

	if cache.ParentID > 0 {
		key = fmt.Sprintf("agent:%d", cache.ParentID)
		err = cli.Do("JSON.SET", key, fmt.Sprintf(".sub_agent.$%d", cache.ID), buf).Err()
		if err != nil {
			return err
		}
	}

	return nil
}

func SetAgent(pipe redis.Pipeliner, id, parentID uint64, node, val interface{}) {

	var value interface{}
	switch val.(type) {
	case float32:
		value = fmt.Sprintf("%0.3f", val.(float32))
	case float64:
		value = fmt.Sprintf("%0.3f", val.(float64))
	case string:
		value = `"` + val.(string) + `"`
	case []byte:
		value = val
	default:
		value = val
	}
	key := fmt.Sprintf("agent:%d", id)
	pipe.Do("JSON.SET", key, fmt.Sprintf(".%s", node), value)

	if parentID > 0 {
		key = fmt.Sprintf("agent:%d", parentID)
		pipe.Do("JSON.SET", key, fmt.Sprintf(".sub_agent.$%d.%s", id, node), value)
		fmt.Println(pipe.Do("JSON.SET", key, fmt.Sprintf(".sub_agent.$%d.%s", id, node), value))
	}
}

func DelSubAgent(pipe redis.Pipeliner, id, subID uint64) {

	key := fmt.Sprintf("agent:%d", id)
	pipe.Do("JSON.DEL", key, fmt.Sprintf(".sub_agent.$%d", subID))
}

func GetAgent(cli *redis.Client, id uint64) (AgentCache, error) {

	agent := AgentCache{}
	key := fmt.Sprintf("agent:%d", id)
	data, err := cli.Do("JSON.GET", key).Text()
	if err != nil {
		return agent, err
	}

	err = cjson.UnmarshalFromString(data, &agent)

	return agent, err
}

func GetSubAgent(cli *redis.Client, id uint64) (map[string]AgentCache, error) {

	agent := map[string]AgentCache{}
	key := fmt.Sprintf("agent:%d", id)
	data, err := cli.Do("JSON.GET", key, "NOESCAPE", ".sub_agent").Text()
	if err != nil {
		return agent, err
	}

	err = cjson.UnmarshalFromString(data, &agent)

	return agent, err
}

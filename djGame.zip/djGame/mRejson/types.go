package mRejson

type MCache struct {
	ID            uint64            `json:"id"`
	Account       string            `json:"account"`
	ParentID      uint64            `json:"parent_id"`
	ParentAccount string            `json:"parent_account"`
	TopID         uint64            `json:"top_id"`
	TopAccount    string            `json:"top_account"`
	SortLevel     string            `json:"sort_level"`
	Deph          uint64            `json:"deph"`
	Status        uint8             `json:"status"`
	SecretKey     string            `json:"secret_key"`
	MType         int               `json:"m_type"`
	SubMerchant   map[string]MCache `json:"sub_merchant"`
}

type AgentCache struct {
	ID              uint64                `json:"id"`
	Account         string                `json:"account"`
	ParentID        uint64                `json:"parent_id"`
	ParentAccount   string                `json:"parent_account"`
	TopID           uint64                `json:"top_id"`
	TopAccount      string                `json:"top_account"`
	SortLevel       string                `json:"sort_level"`
	Deph            uint64                `json:"deph"`
	CID             string                `json:"cid"`
	MerchantID      uint64                `json:"merchant_id"`
	MerchantAccount string                `json:"merchant_account"`
	InitialQuota    float64               `json:"initial_quota"`
	UsedQuota       float64               `json:"used_quota"`
	LimitMode       int                   `json:"limit_mode"`
	Status          uint8                 `json:"status"`
	SubAgent        map[string]AgentCache `json:"sub_agent"`
}

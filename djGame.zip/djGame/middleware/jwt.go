package middleware

import (
	"errors"
	"game/contrib/session"
	"github.com/valyala/fasthttp"
)

var (
	allows = map[string]bool{
		"/game/version":            true,
		"/game/pprof/":             true,
		"/game/pprof/block":        true,
		"/game/pprof/allocs":       true,
		"/game/pprof/cmdline":      true,
		"/game/pprof/goroutine":    true,
		"/game/pprof/heap":         true,
		"/game/pprof/profile":      true,
		"/game/pprof/trace":        true,
		"/game/pprof/threadcreate": true,
		"/game/systemTime":         true,
	}
)

func CheckTokenMiddleware(ctx *fasthttp.RequestCtx) error {

	path := string(ctx.Path())
	if _, ok := allows[path]; ok {
		return nil
	}

	data, err := session.Get(ctx)
	if err != nil {
		return errors.New(`{"status":"false","data":"token"}`)
	}

	ctx.SetUserValue("sess", data)

	return nil
}

package model

import (
	"fmt"
	"github.com/go-redis/redis/v7"
)

// Redis KEY 统一宝义在这里,并对每个KEY做完整的注释
const (
	//联赛缓存
	redisHKeyTournament = "tmtInfo:%s"
	// 会员缓存
	RedisKeyMember = "u:%d:%s"
	// 公告
	redisNoticeList = "notice:%s"
	// 公告维护时间
	redisNoticeMaintain = "noticeMaintain"
	// 风控基本参数Key
	RedisBasicSettingsForRisk = "setting"
	// 会员风控参数
	RedisUserRisk = "ur:%d"
	// 自动变赔redis stream
	RedisStreamAutoOdd = "autoOdd"
	// 查询商户信息
	RedisMerchantGetInfo = "merch:id:%d"
	// 赛事计时器rejson
	RedisMchTimerRejson = "mchTimer"
	RedisLangGame       = "Lang:g_%s" //国际化语言-游戏
	RedisLangOddType    = "Lang:o_%s" //国际化语言-玩法
	RedisLangSports     = "Lang:v_%s" //国际化语言-(游戏|玩法)-虚拟体育

	//投注开启开关
	RedisBetLock = "betlock"
	//风险参数
	RedisRiskMember                      = "riskMember"
	RedisMatchRoundTime                  = "mchRoundTime:%s"                   // 主播盘-小局开始时间缓存
	RedisMatchRoundImg                   = "mchRoundImg:%s:%d"                 // 主播盘-小局游戏截图缓存
	RedisMatchChampTeam                  = "mchChampTeam:%s"                   // 冠军赛 战队缓存
	RedisKeyCreditLimit                  = "cm_limit:%d:%d:%d"                 // 信用网代理单注限额配置
	RedisKeyCreditCompLimit              = "cm_comp_limit:%d"                  // 信用网代理串注限额配置
	RedisKeyCreditMemberCompLimit        = "cm_m_comp_limit:%d"                // 信用网会员串注限额配置
	RedisKeyCreditMemberLimit            = "cm_u_limit:%d:%d:%d"               // 信用网会员单注限额配置
	RedisKeyCreditDefaultAgentLimit      = "credit_default_agent_limit:%d:%d"  // 信用网代理默认赔付限额配置(赛事等级,游戏ID)
	RedisKeyCreditDefaultAgentCompLimit  = "credit_default_agent_comp_limit"   // 信用网代理默认串注赔付限额配置
	RedisKeyCreditDefaultMemberLimit     = "credit_default_member_limit:%d:%d" // 信用网会员默认赔付限额配置(赛事等级,游戏ID)
	RedisKeyCreditDefaultMemberCompLimit = "credit_default_member_comp_limit"  // 信用网会员默认串注赔付限额配置
	RedisKeySToken                       = "stoken:%d"                         // c端中心钱包token与OB电竞会员ID关联映射
	RedisKeyMemberCompUsedLimit          = "memberCompUsedLimit:%d:%d:%s"      // 会员每日串注限额(商户ID,会员ID,今日时间字符串)
	RedisKeyMatchCompUsedLimit           = "matchCompUsedLimit:%s"             // 赛事总串注已使用限额(赛事ID)
	RedisKeyMatchLevelCompLimit          = "matchLevelCompLimit"               // 赛事等级串注限额
	RedisKeyLevelUsedLimit               = "levelUsedLimit:%d"                 // 会员赛事等级已使用串注限额
	RedisKeyCurrencyRate                 = "currencyRate:%d"                   // 多币种RedisKey
	RedisKeyLang                         = "Lang:%s"                           // 多语言(code)
	RedisKeyMemberDailyTotal             = "memberDailyTotal:%d:%d:%s"         // 会员每日数据统计(商户ID:会员ID:日期字符串)
	RedisKeyMatchLevelGlobalLimit        = "matchLevelGlobalLimit:%d"          //  赛事等级全局设置
	RedisKeyMonitorChannel               = "monitorChannel"                    //赛事预警监控推送/订阅主题
	RedisKeyFestival                     = "festival:%s"                       // 节庆图片(语言类型)
	RedisCommonScore                     = "m_commonScore:%s"                  //虚拟足球-一般联赛积分榜
	RedisGroupScore                      = "m_groupScore:%s"                   //虚拟足球-小组赛积分榜
	RedisDisuseScore                     = "m_disuseScore:%s"                  //虚拟足球-一般联赛积分榜
)

// 公用哈希获取
func redisHMGet(pipe *redis.Client, keyName string, ids []string) (map[string]string, error) {

	total := len(ids)
	data := map[string]string{}
	value, err := pipe.HMGet(keyName, ids...).Result()
	if err != nil {
		return data, err
	}

	for i := 0; i < total; i++ {
		// 取出interface{}类型数据，转换时类型断言
		if v, ok := value[i].(string); ok {
			data[ids[i]] = v
		} else {
			data[ids[i]] = ""
		}
	}

	return data, nil
}

func zkRedisHMGet(pipe *redis.ClusterClient, keyName string, ids []string) (map[string]string, error) {

	total := len(ids)
	data := map[string]string{}
	value, err := pipe.HMGet(keyName, ids...).Result()
	if err != nil {
		return data, err
	}

	for i := 0; i < total; i++ {
		// 取出interface{}类型数据，转换时类型断言
		if v, ok := value[i].(string); ok {
			data[ids[i]] = v
		} else {
			data[ids[i]] = ""
		}
	}

	return data, nil
}

func redisGetSTokens(uid uint64) string {

	sToken, err := mt.MerchantRedis.Get(fmt.Sprintf(RedisKeySToken, uid)).Result()
	if err != nil {
		return ""
	}

	return sToken
}

/*
 * @Description: 批量获取多个key对应字段的缓存
 * @Author: robin
 * @Date: 2021/10/2 14:10
 * @LastEditTime: 2021/10/2 14:10
 * @LastEditors: robin
 */
func RedisPipelineHMGet(ids []string, field string, key string) (map[string]string, error) {

	data := map[string]string{}
	results := map[string]*redis.SliceCmd{}

	pipe := mt.ZKRedisCluster.Pipeline()
	defer pipe.Close()
	for _, id := range ids {
		key := fmt.Sprintf(key, id)
		value := pipe.HMGet(key, field)
		results[id] = value
	}
	_, err := pipe.Exec()
	if err != nil {
		return data, err
	}

	for id, result := range results {
		value, err := result.Result()
		if err != nil {
			return data, err
		}

		if v, ok := value[0].(string); ok {
			data[id] = v
		} else {
			data[id] = ""
		}
	}

	return data, err
}

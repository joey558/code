package model

import (
	"fmt"
	"game/helper"
	"github.com/go-redis/redis/v7"
	"time"
)

// 公告显示结构体
type Notice struct {
	GameID  string `json:"game_id"` //游戏ID
	Top     uint8  `json:"top"`     //是否置顶:0=否,1=是
	Title   string `json:"title"`   //标题
	Content string `json:"content"` //内容
	Time    uint32 `json:"time"`    //时间
}

//客户端只返回对应语言的功能内容
type NoticeI18n struct {
	GameID  string `json:"game_id"` //游戏ID
	Top     uint8  `json:"top"`     //是否置顶:0=否,1=是
	Title   string `json:"title"`   //标题
	Content string `json:"content"` //内容
	Time    uint32 `json:"time"`    //时间
}

type NoticeData struct {
	D []Notice `json:"d"`
	T int64    `json:"t"`
}

type NoticeResp struct {
	D []NoticeI18n `json:"d"`
	T int64        `json:"t"`
}

/**
 * @Description:
 * @Author: 顺序显示公告信息
 * @Date: 2020/6/14 上午11:25
 * @LastEditTime: 2020/6/14 上午11:25
 * @LastEditors:
 */
func NoticeList(lan string, today time.Time, page, pageSize int64) (NoticeData, error) {

	cacheKey := fmt.Sprintf("notice-%s", lan)
	if page == 1 && pageSize == 10 {
		if v, ok := mt.ramCacheData.Notice.Load(cacheKey); ok {
			return v.(NoticeData), nil
		}
		fmt.Printf("[%s]Redis Query NoticeList! lang:%s|page:%d|pageSize:%d \n", mt.Config.MerchantName, lan, page, pageSize)
	}

	if page < 2 {
		page = 1
	}
	offset := (page - 1) * pageSize
	data := NoticeData{}
	opt := redis.ZRangeBy{ // 只显示1个月内公告
		Min:    fmt.Sprintf("%d", today.AddDate(0, -1, 0).Unix()),
		Max:    "+inf",
		Offset: offset,
		Count:  pageSize,
	}

	key := fmt.Sprintf(redisNoticeList, lan)
	pipe := mt.ZKRedisCluster.Pipeline()
	defer pipe.Close()

	listCmd := pipe.ZRevRangeByScore(key, &opt)
	countCmd := pipe.ZCount(key, opt.Min, opt.Max)
	_, err := pipe.Exec()
	if err != nil {
		return data, err
	}

	list, err := listCmd.Result()
	if err != nil {
		return data, err
	}

	for _, sv := range list {
		noticeValue := Notice{}
		err = helper.JsonUnmarshalFromString(sv, &noticeValue)
		if err != nil {
			fmt.Println("NoticeList JsonUnmarshalFromString error:", err.Error())
			continue
		}

		data.D = append(data.D, noticeValue)

	}
	data.T = countCmd.Val()

	if page == 1 && pageSize == 10 {
		if _, ok := keyLock.Load(cacheKey); !ok {
			keyLock.Store(cacheKey, 1)
			mt.ramCacheData.Notice.Store(cacheKey, data)
			idxCache := IdxCache{
				Key:         cacheKey,
				RefreshTime: 1 * time.Minute,
			}

			_ = mt.idxCachePool.Invoke(idxCache)
		}
	}

	return data, nil
}

/**
 * @Description:
 * @Author: 获取公告维护提示时间
 * @Date: 2022/3/15 上午11:25
 * @LastEditTime: 2022/3/15 上午11:25
 * @LastEditors:
 */
func NoticeGetMaintain() (string, error) {

	return mt.ZKRedisCluster.Get(redisNoticeMaintain).Result() // 获取系统维护时间
}

//func NoticeI18nRespFormat(d NoticeData, lan string) NoticeResp {
//	data := NoticeResp{
//		T: d.T,
//	}
//
//	var notices []NoticeI18n
//	for _, v := range d.D {
//		notice := NoticeI18n{
//			GameID: v.GameID,
//			Top:    v.Top,
//			Time:   v.Time,
//		}
//
//		switch lan {
//		case lang.CN:
//			notice.Title = v.Title
//			notice.Content = v.Content
//		case lang.ZH:
//			notice.Title = v.TitleZh
//			notice.Content = v.ContentZh
//		case lang.EN:
//			notice.Title = v.TitleEn
//			notice.Content = v.ContentEn
//		case lang.VI:
//			notice.Title = v.TitleVi
//			notice.Content = v.ContentVi
//		default:
//			notice.Title = v.Title
//			notice.Content = v.Content
//		}
//
//		notices = append(notices, notice)
//	}
//	data.D = notices
//
//	return data
//}

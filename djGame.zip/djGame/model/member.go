package model

import (
	"fmt"
	"game/contrib/session"
	"game/helper"
	"game/utils"
	fund "game/wallet"
	g "github.com/doug-martin/goqu/v9"
	"github.com/doug-martin/goqu/v9/exp"
	"github.com/go-redis/redis/v7"
	"github.com/shopspring/decimal"
	"github.com/valyala/fasthttp"
)

const (
	TblMemberTransaction = "tbl_member_transaction" //账变表
	TblMember            = "tbl_member"             //会员信息表
)

// 会员风控等级
type MemberRiskLevel struct {
	ID                 uint64  `db:"id" json:"id" rule:"none" msg:"id不能为0" name:"id"`                                                        // id
	BetWinLimit        int64   `db:"bet_win_limit" json:"bet_win_limit" name:"bet_win_limit" rule:"digit" msg:"请指定单注限红且为整数"`                 // 单注红利限额
	BetLimit           int64   `db:"bet_limit" json:"bet_limit" name:"bet_limit" rule:"digit" msg:"请指定单注限额且为整数"`                             // 单注限额
	MktWinLimit        int64   `db:"mkt_win_limit" json:"mkt_win_limit" name:"mkt_win_limit" rule:"digit" msg:"请指定盘口红利且为整数"`                 // 盘口红利限额
	MchWinLimit        int64   `db:"mch_win_limit" json:"mch_win_limit" name:"mch_win_limit" rule:"digit" msg:"请指定赛事红利且为整数"`                 // 赛事红利限额
	ParleyWinLimit     int64   `db:"parley_win_limit" json:"parley_win_limit" name:"parley_win_limit" rule:"digit" msg:"请指定串注赔付限额且为整数"`      // 串注赔付限额
	BetWinLimitRate    float64 `db:"bet_win_limit_rate" json:"bet_win_limit_rate" name:"bet_win_limit_rate" msg:"请指定单注红利限额百分比且为数字"`          // 单注红利限额百分比
	BetLimitRate       float64 `db:"bet_limit_rate" json:"bet_limit_rate" name:"bet_limit_rate" msg:"请指定单注限额百分比且为数字"`                        // 单注限额百分比
	MktWinLimitRate    float64 `db:"mkt_win_limit_rate" json:"mkt_win_limit_rate" name:"mkt_win_limit_rate" msg:"请指定盘口红利限额百分比且为数字"`          // 盘口红利限额百分比
	MchWinLimitRate    float64 `db:"mch_win_limit_rate" json:"mch_win_limit_rate" name:"mch_win_limit_rate" msg:"请指定赛事红利限额百分比且为数字"`          // 赛事红利限额百分比
	ParleyWinLimitRate float64 `db:"parley_win_limit_rate" json:"parley_win_limit_rate" name:"parley_win_limit_rate" msg:"请指定串注赔付限额百分比且为数字"` // 串注赔付限额百分比
	RiskLevel          int     `db:"risk_level" json:"risk_level" name:"risk_level"`                                                         // 会员等级 0:VIP等级 1:风控等级
}

type Message struct {
	Data []MemberRiskLevel
}

//会员资金结算
type MemberBalance struct {
	Uid                     string          `json:"uid"`                          //用户ID
	Account                 string          `json:"account"`                      //账户
	Balance                 string          `json:"balance"`                      //结算
	OddUpdateType           uint8           `json:"odd_update_type"`              //1 自动接受最新赔率 2自动接受更高赔率 3永不接受最新赔率
	Tester                  uint8           `json:"tester"`                       //是否测试账号(0:正常账号,1:测试账号)
	CreditLimitOddThreshold string          `json:"credit_limit_odd_threshold"`   //信用网限额赔率阈值，小于等于这个值取信用网限额，大于则取总控限额
	CreditStatus            int             `json:"credit_status"`                //信用状态:0-正常,1-信用代理转已为标准代理,2-信用会员已被风控
	MerchantID              uint64          `db:"merchant_id" json:"merchant_id"` //用户所属的商户id
	TopMerchantAccount      string          `json:"top_merchant_account"`         //顶层商户账户名
	CurrencyCode            int             `json:"currency_code"`                // 币种Code
	CurrencyEn              string          `json:"currency_en"`                  // 币种英文名称
	ExchangeRate            decimal.Decimal `json:"exchange_rate"`                // 汇率
	MaintainTime            string          `json:"maintain_time"`                // 公告维护时间
	QuickData
}

//资金列表参数
type FundListData struct {
	T int64          `json:"t"` //统计
	D []FundResponse `json:"d"` //资金返回参数
}

//资金返回
type FundResponse struct {
	ID            uint64  `db:"id" json:"id"`                         //ID
	BetOrderID    uint64  `db:"bet_order_id" json:"bet_order_id"`     //投注单编号
	TradeType     uint8   `db:"trade_type" json:"trade_type"`         //交易类型
	Amount        float64 `db:"amount" json:"amount"`                 //交易额
	BalanceBefore float64 `db:"balance_before" json:"balance_before"` //结算前
	BalanceAfter  float64 `db:"balance_after" json:"balance_after"`   //结算后
	CreatedTime   uint64  `db:"created_time" json:"created_time"`     //创建时间
}

//节庆UI
type FestivalUi struct {
	ID         int64  `rule:"digit" msg:"id error" name:"id"`                 // ID
	Language   string `rule:"none" msg:"language error"  name:"language"`     // 语言类型 zh：中文简体  tw：中文繁体  en：英文  vi：越南语
	Img1       string `rule:"none" msg:"img1 error"  name:"img1"`             // DJ：PC节日资源图  CP：PC节日资源图  TY：PC节日资源图（日间版）
	Img2       string `rule:"none" msg:"img2 error"  name:"img2"`             // DJ：PC推荐位  CP：PC节日资源图  TY：PC节日资源图（日间版）
	Img3       string `rule:"none" msg:"img3 error"  name:"img3"`             // DJ：PC弹窗资源图  CP：H5节日资源图  TY：PC节日资源图（夜间版）
	Img4       string `rule:"none" msg:"img4 error"  name:"img4"`             // DJ：H5节日资源图  CP：H5节日资源图  TY：PC节日资源图（夜间版）
	Img5       string `rule:"none" msg:"img5 error"  name:"img5"`             // DJ：H5推荐位  CP：H5节日资源图  TY：H5节日资源图（日间版）
	Img6       string `rule:"none" msg:"img6 error"  name:"img6"`             // DJ：H5弹窗资源图  CP：H5节日资源图  TY：H5节日资源图（夜间版）
	State      int    `rule:"digit" msg:"state error" name:"state"`           // 0：失效  1：生效
	StartTime  int64  `rule:"digit" msg:"startTime error" name:"startTime"`   // 开始时间
	EndTime    int64  `rule:"digit" msg:"endTime error" name:"endTime"`       // 结束时间
	CreateTime int64  `rule:"digit" msg:"createTime error" name:"createTime"` // 创建时间
}

/**
 * @Description:通过Token获取用户信息
 * @Author: wesley
 * @Date: 2020/5/7
 * @LastEditTime: 2020/6/14 14:53
 * @LastEditors: Noah
 */
func GetTokenData(ctx *fasthttp.RequestCtx) (fund.Member, error) {

	member := fund.Member{}
	sess := ctx.UserValue("sess").([]byte)
	err := helper.JsonUnmarshal(sess, &member)
	if err != nil {
		return member, err
	}

	return member, nil
}

/**
 * @Description:获取用户余额
 * @Author: wesley
 * @Date: 2020/5/21
 * @LastEditTime: 2020/6/14 14:54
 * @LastEditors: Noah
 */
func BalanceGet(member fund.Member) (string, error) {
	// 信用网会员从中心钱包获取代理剩余额度
	if member.Tester == UserTypeCredit {
		return fund.GetCreditBalance(member.Account)
	} else {
		return fund.GetBalanceRedis(mt.MerchantRedis, member.UID)
	}
}

/**
 * @Description:账变记录
 * @Author: wesley
 * @Date: 2020/5/26
 * @LastEditTime: 2020/6/14 14:55
 * @LastEditors: Noah
 */
func FundList(page, pageSize uint, ex g.Ex) (FundListData, error) {

	data := FundListData{}
	count, err := utils.Count(mt.MerchantSlaveDB, TblMemberTransaction, ex)
	if err != nil {
		return data, err
	}
	if count == 0 {
		return data, err
	}
	data.T = int64(count)

	if page < 2 {
		page = 1
	}
	err = utils.SelectAll(&data.D, utils.QueryArg{
		Db:     mt.MerchantSlaveDB,
		Table:  TblMemberTransaction,
		Fields: clFundResponse,
		Ex:     []g.Expression{ex},
		Order:  []exp.OrderedExpression{g.C("created_time").Desc()},
		Offset: (page - 1) * pageSize,
		Limit:  pageSize,
	})

	return data, err
}

func MemberOddUpdateTypeSet(member fund.Member, oddUpdateType int) error {

	dbConn, err := mt.MerchantDB.Begin()
	if err != nil {
		return err
	}

	member.OddUpdateType = uint8(oddUpdateType)
	record := g.Record{"odd_update_type": oddUpdateType}
	ex := g.Ex{"uid": member.UID}
	_, err = utils.Update(utils.Conn{Tx: dbConn}, TblMember, record, ex)
	if err != nil {
		_ = dbConn.Rollback()
		return err
	}
	//更新会员缓存
	mkey := fmt.Sprintf(RedisKeyMember, member.MerchantID, member.Account)
	buf, err := helper.JsonMarshal(member)
	if err != nil {
		_ = dbConn.Rollback()
		return err
	}
	_, err = mt.MerchantRedis.Set(mkey, buf, -1).Result()
	if err != nil {
		_ = dbConn.Rollback()
		return err
	}

	//更新session
	session.Update(buf, member.UID)
	return dbConn.Commit()
}

/*
* @Description: 获取用户限红状态
* @Author: noah
* @Date: 2021/5/31 15:16
* @LastEditTime: 2021/5/31 15:16
* @LastEditors: noah
 */
func GetMemberLimitStatus(memberId uint64) (bool, error) {

	_, err := mt.ZKRedisCluster.HGet(RedisRiskMember, fmt.Sprintf("%d", memberId)).Result()
	if err == redis.Nil {
		return false, nil
	} else if err != nil {
		return false, err
	}

	return true, nil
}

func MemberLangSet(member fund.Member) error {

	//更新会员缓存
	mkey := fmt.Sprintf(RedisKeyMember, member.MerchantID, member.Account)
	buf, err := helper.JsonMarshal(member)
	if err != nil {
		return err
	}

	_, err = mt.MerchantRedis.Set(mkey, buf, -1).Result()
	if err != nil {
		return err
	}

	//更新session
	session.Update(buf, member.UID)
	return nil
}

/*
* @Description: 从缓存中获取节庆图片
* @Author: jinxi
* @Date: 2022/3/15 14:59
* @LastEditTime: 2022/3/15 14:59
* @LastEditors: jinxi
 */
func GetFestivalUI(lan string) (map[string]string, error) {

	key := fmt.Sprintf(RedisKeyFestival, lan)
	return zkRedisHMGet(mt.ZKRedisCluster, key, FestivalKeys)
}

/*
* @Description: 从redis读取会员的藏单率
* @Author: xp
* @Date: 2022/4/10 14:59
* @LastEditTime: 2022/4/10 14:59
* @LastEditors: xp
 */
func GetHideAmountRate(member fund.Member) float64 {

	hideAmountRateKey := fmt.Sprintf("%s:%d:%d", utils.RedisHideAmountRate, member.MerchantID, member.UID)
	hideAmountRate, err := mt.ZKRedisCluster.Get(hideAmountRateKey).Float64()
	if err != nil {
		hideAmountRate = 0
	}

	return hideAmountRate
}

package model

import (
	"github.com/scylladb/go-set/strset"
	"time"

	g "github.com/doug-martin/goqu/v9"
	"github.com/shopspring/decimal"
)

const (
	BetStatusWaitConfirm = 1  // 待确认
	BetStatusRefused     = 2  // 已拒绝
	BetStatusWaitSettle  = 3  // 等待结算
	BetStatusCancelled   = 4  // 已取消
	BetStatusWin         = 5  // 已中奖
	BetStatusLose        = 6  // 未中奖
	BetStatusUndo        = 7  // 已撤销
	BetStatusWinHalf     = 8  // 赢半
	BetStatusLoseHalf    = 9  // 输半
	BetStatusDraw        = 10 // 走水

	ParleyTypeMaxValue = 10 //串注最大支持10串1
)

//游戏显示隐藏
const (
	GameOpenMatchStatusClose = "0" //关闭游戏的赛事
	GameOpenMatchStatusOpen  = "1" //开启游戏的赛事
)

// 串注、复合玩法注单状态 1-待确认 2-已取消 3-已中奖 4-未中奖
const (
	CompTypeWaitConfirm = 1
	CompTypeCancel      = 2
	CompTypeWin         = 3
	CompTypeLoss        = 4
	CompTypeUndo        = 5
	CompTypeWinHalf     = 6
	CompTypeLoseHalf    = 7
	CompTypeDraw        = 8
)
const (
	topicMarketOrderBet = "/market/order/bet/%s"  // 盘口注单统计更新通知
	topicOrderRefresh   = "/order/status/refresh" // 总控实时注单页面推送注单刷新通知
)

const (
	OrderTypeSimple       = 1 // 单注
	OrderTypeComplex      = 2 // 普通串关
	OrderTypeRoundComplex = 3 // 局内串关
	OrderTypeMix          = 4 // 复合
)
const (
	MatchLimit   = "match_limit" //代理赛事限额
	MemberBetMax = "bet_%s_max"  //代理赛事限额
)
const (
	LimitStatus = "limit_status"
)

const (
	CreditAgentChange = 1 //信用代理转为标准
	CreditMemberLimit = 2 //信用会员已被风控
)

const (
	MatchSimple       = 0 // 比赛不支持串关
	MatchComplex      = 1 // 比赛支持串关
	MatchRoundComplex = 2 // 比赛支持串关和局内串关
)

// 赛事类型
const (
	MatchCategoryNormal           = 1  // 正常
	MatchCategoryChampion         = 2  // 冠军
	MatchCategoryBattleRoyale     = 3  // 大逃杀
	MatchCategoryBasketball       = 4  // 篮球
	MatchCategoryAnchor           = 5  // 主播盘
	MatchCategoryFootball         = 6  // 足球
	SportsMatchCategoryFootball   = 7  // 虚拟足球
	SportsMatchCategoryBasketBall = 8  // 虚拟篮球
	SportsMatchCategoryHorse      = 9  // 虚拟赛马
	SportsMatchCategoryDog        = 10 // 虚拟赛狗
	SportsMatchCategoryMotorBike  = 11 // 虚拟摩托车
)

const (
	//盘口单注注单投注成功后推送更新盘口注单统计数据通知
	mqttMarketOrderBet = `{"match_id":"%s","market_id":"%s"}`
	//实时注单推送刷新通知(order_type=1单注, order_type=2串注)
	mqttOrderRefresh = `{"order_type": %d}`
)

const (
	BeanStalkBetOrderConfirm   = "bet_confirm_%s"    //注单确认
	BeanstalkMarketMonitorTube = "market_monitor"    //盘口监控
	BeanstalkAutoOddTube       = "auto_odd"          //自动变赔
	BeanstalkCreditTimeoutTube = "credit_timeout_%s" //信用盘注单超时
	BeanstalkCancelTube        = "cancel_%s"         // 撤单任务队列
	BeanstalkTradeTube         = "trade_%s"          // 操盘任务队列,用于体育投注失败拒单
)

//es key
const (
	EsSimpleIndexKeyWord          = "bet_order"          //单注索引
	EsComplexIndexKeyWord         = "order_detail"       //串注索引
	EsFundIndexKeyWord            = "member_transaction" //账变记录索引
	EsFrontStatisticsIndexKeyWord = "front_statistics"   //前端统计索引
	EsIndexKeyWordUserVer         = "user_ver"           //用户版本号
)

//会员账号类型
const (
	UserTypeNormal = 0 //正常用户
	UserTypeTester = 1 //测试用户
	UserTypeCredit = 2 //信用用户
)

const (
	Champion = "champion" //10-猜冠军（单项结算）,11-猜冠军（多项结算）
	//早盘
	AllWinLossEarly      = "all_win_loss_early"      //全局输赢
	SingleWinLossEarly   = "single_win_loss_early"   //单局输赢
	AllHandicapEarly     = "all_handicap_early"      //全局让分
	SingleHandicapEarly  = "single_handicap_early"   //单局让分
	AllOverUnderEarly    = "all_over_under_early"    //全局大小
	SingleOverUnderEarly = "single_over_under_early" //单局大小
	CorrectMapScoreEarly = "correct_map_score_early" //全局地图让分
	OtherEarly           = "other_early"             //包含 全局是否、全局单双、全局趣味、单局单双、单局是否、单局趣味

	//滚盘
	AllWinLossLive      = "all_win_loss_live"      //全局输赢
	SingleWinLossLive   = "single_win_loss_live"   //单局输赢
	AllHandicapLive     = "all_handicap_live"      //全局让分
	SingleHandicapLive  = "single_handicap_live"   //单局让分
	AllOverUnderLive    = "all_over_under_live"    //全局大小
	SingleOverUnderLive = "single_over_under_live" //单局大小
	CorrectMapScoreLive = "correct_map_score_live" //全局地图让分
	OtherLive           = "other_live"             // 包含 全局是否、全局单双、全局趣味、单局单双、单局是否、单局趣味
)

const (
	OptionTypeWinLose         = 1  // 输赢
	OptionTypeHandicap        = 2  // 让分
	OptionTypeOverUnder       = 3  // 大小
	OptionTypePloy            = 4  // 趣味
	OptionTypeCorrectScore    = 5  // 波胆
	OptionType1X2             = 6  // 胜平负
	OptionTypeOddEven         = 7  // 单双
	OptionTypeYesNo           = 8  // 是否
	OptionTypeChampWin        = 10 // 猜冠军 单选
	OptionTypeChampWinMore    = 11 // 猜冠军 多选
	OptionTypeMix             = 12 // 复合玩法
	OptionTypePlayerWinLose   = 13 // 队员输赢
	OptionTypePlayerHandicap  = 14 // 队员让分
	OptionTypePlayerOverUnder = 15 // 队员大小
	OptionTypePlayerOddEven   = 16 // 队员单双
	OptionTypePlayerYesNo     = 17 // 队员是否
	OptionTypeHeroWinLose     = 18 // 英雄输赢
	OptionTypeHeroHandicap    = 19 // 英雄让分
	OptionTypeHeroOverUnder   = 20 // 英雄大小
	OptionTypeHeroOddEven     = 21 // 英雄单双
	OptionTypeHeroYesNo       = 22 // 英雄是否
)

const (
	MatchEarly = 1 //早盘
	MatchLive  = 2 //滚盘
)

const (
	SportsMatchEarly         = 1 //早盘赛事-虚拟体育
	SportsMatchResult        = 2 //已结算赛事-虚拟体育
	SportsMatchBatchNoResult = 3 //(指定批次)已结束赛事-虚拟体育
)

//信用盘赔率限额
var (
	CreditOddLimit = decimal.Decimal{}
	NewFilterGames = strset.New()
)

const (
	MemberUsedLimitDefaultExpiredTime = 24 * time.Hour //1天
)

// 投注注单
type BetOrder struct {
	ID                 string  `db:"id" json:"id"`
	MemberID           uint64  `db:"member_id" json:"member_id"`                                // 会员ID
	MemberAccount      string  `db:"member_account" json:"member_account"`                      // 会员名
	MerchantID         uint64  `db:"merchant_id" json:"merchant_id"`                            // 商户ID
	BetAmount          string  `db:"bet_amount" json:"bet_amount"`                              //注单金额
	BetIP              uint32  `db:"bet_ip" json:"bet_ip"`                                      //投注IP
	BetStatus          int     `db:"bet_status" json:"bet_status"`                              //注单状态 1-待确认 2-已拒绝 3-待结算 4-已取消 5-已中奖 6-未中奖 7-已撤销
	BetTime            string  `db:"bet_time" json:"bet_time"`                                  //投注时间
	ConfirmType        int     `db:"confirm_type" json:"confirm_type"`                          //确认方式
	Device             uint32  `db:"device" json:"device"`                                      //设备类型
	GameID             string  `db:"game_id" json:"game_id"`                                    //游戏ID
	IsLive             int     `db:"is_live" json:"is_live"`                                    //赛事阶段 1-初盘 2-滚盘
	MarketEnName       string  `db:"market_en_name" json:"market_en_name"`                      //盘口英文名称
	MarketCnName       string  `db:"market_cn_name" json:"market_cn_name"`                      //盘口中文名称
	MarketID           string  `db:"market_id" json:"market_id"`                                //盘口ID
	MatchID            string  `db:"match_id" json:"match_id"`                                  //赛事ID
	MatchStartTime     int     `db:"match_start_time" json:"match_start_time"`                  //赛事开始时间
	MatchType          int     `db:"match_type" json:"match_type"`                              //赛事类型
	Odd                string  `db:"odd" json:"odd"`                                            //赔率
	OddID              string  `db:"odd_id" json:"odd_id"`                                      //投注项ID
	OddName            string  `db:"odd_name" json:"odd_name"`                                  //投注项名称
	OddEnName          string  `db:"odd_en_name" json:"odd_en_name"`                            //投注项英文名称
	OrderType          int     `db:"order_type" json:"order_type"`                              //注单类型
	ParleyType         int     `db:"parley_type" json:"parley_type"`                            //串关类型
	Round              int     `db:"round" json:"round"`                                        //第几局
	SettleTime         int     `db:"settle_time" json:"settle_time"`                            //结算时间
	TeamNames          string  `db:"team_names" json:"team_names"`                              //队伍名称
	TeamCnNames        string  `db:"team_cn_names" json:"team_cn_names"`                        //队伍中文名称
	TeamEnNames        string  `db:"team_en_names" json:"team_en_names"`                        //队伍英文名称
	TeamID             string  `db:"team_id" json:"team_id"`                                    //战队id
	Tester             uint8   `db:"tester" json:"tester"`                                      //是否测试账号(0:正常账号,1:测试账号;2:信用账户)
	TheoryPrize        string  `db:"theory_prize" json:"theory_prize"`                          //理论奖金
	TournamentID       string  `db:"tournament_id" json:"tournament_id"`                        //联赛ID
	WinAmount          string  `db:"win_amount" json:"win_amount"`                              //派彩金额
	TopMerchantId      uint64  `db:"top_merchant_id" json:"top_merchant_id"`                    //顶层商户ID
	TopMerchantAccount string  `db:"top_merchant_account" json:"top_merchant_account"`          // 顶层商户账户名
	SortLevel          string  `db:"sort_level" json:"sort_level" rule:"chn" name:"sort_level"` //商户排序层级
	Deph               uint64  `db:"deph" json:"deph" rule:"chn" name:"deph"`                   //商户层深
	Reason             int     `db:"reason" json:"reason"`                                      // x-赛事取消理由, 1xx-盘口取消理由, 201-赔率错误，202-比赛提前开始
	OddDiscount        string  `db:"odd_discount" json:"odd_discount"`                          // 赔率折扣
	RiskTagID          string  `db:"risk_tag_id" json:"-"`                                      // 风险标签ID
	TYMatchSID         string  `db:"ty_match_sid" json:"-"`                                     // 体育赛事的SID
	TYOrderID          string  `db:"ty_order_id" json:"-"`                                      // 体育的注单ID
	OrgOddID           string  `db:"org_odd_id" json:"org_odd_id"`                              // 玩法id
	ScoreBenchmark     string  `db:"score_benchmark" json:"score_benchmark"`                    // 基准分
	BatchNo            string  `db:"batch_no" json:"batch_no"`                                  // 批次-虚拟体育
	RoundNo            string  `db:"round_no" json:"round_no"`                                  // 轮次-虚拟体育
	AcceptOdds         int     `db:"-" json:"-"`                                                // 程序使用，赔率变更选择
	PlaceNum           int     `db:"-" json:"-"`                                                // 程序使用，坑位（盘口位置，1：表示主盘，2：表示第一副盘）如有则必传
	TYToken            string  `db:"-" json:"-"`                                                // 程序使用，体育的用户Token
	ExchangeRate       string  `db:"-" json:"-"`                                                // 赔率
	HideAmountRate     float64 `db:"hide_amount_rate" json:"-"`                                 // 藏单率
	OddTypeID          string  `db:"-" json:"odd_type_id"`                                      // 玩法id
	MarketName         string  `db:"-" json:"market_name"`                                      // 多语言适配盘口名
	TYNewOdd           string  `db:"-" json:"-"`                                                // DJ投注TY成功后返回的新赔率
	TourName           string  `db:"-" json:"tour_name"`                                        // 联赛名称
}

// 串注注单数据
type OrderDetailData struct {
	BetTime        string `db:"bet_time" json:"bet_time"` //投注时间
	GameID         string `db:"game_id" json:"game_id"`   //游戏ID
	ID             string `db:"id" json:"id"`
	IsLive         int    `db:"is_live" json:"is_live"`                   //赛事阶段 1-初盘 2-滚盘
	MarketEnName   string `db:"market_en_name" json:"market_en_name"`     //盘口英文名称
	MarketCnName   string `db:"market_cn_name" json:"market_cn_name"`     //盘口中文名称
	MarketID       string `db:"market_id" json:"market_id"`               //盘口ID
	MatchID        string `db:"match_id" json:"match_id"`                 //赛事ID
	MatchStartTime int    `db:"match_start_time" json:"match_start_time"` //赛事开始时间
	MatchType      int    `db:"match_type" json:"match_type"`             //赛事类型
	Odd            string `db:"odd" json:"odd"`                           //赔率
	OddID          string `db:"odd_id" json:"odd_id"`                     //投注项ID
	OddName        string `db:"odd_name" json:"odd_name"`                 //投注项名称
	OddEnName      string `db:"odd_en_name" json:"odd_en_name"`           //投注项英文名称
	OrderID        string `db:"order_id" json:"order_id"`                 //订单id
	Round          int    `db:"round" json:"round"`                       //第几局
	Status         int    `db:"status" json:"status"`                     //1-待结算 2-已取消 3-已中奖 4-未中奖
	TeamNames      string `db:"team_names" json:"team_names"`             //战队名称
	TeamCnNames    string `db:"team_cn_names" json:"team_cn_names"`       //队伍中文名称
	TeamEnNames    string `db:"team_en_names" json:"team_en_names"`       //队伍英文名称
	TournamentID   string `db:"tournament_id" json:"tournament_id"`       //联赛ID
	TeamID         string `db:"team_id" json:"team_id"`                   //战队id
	SettleTime     int    `db:"settle_time" json:"settle_time"`           //结算时间
	Reason         int    `db:"reason" json:"reason"`                     //x-赛事取消理由, 1xx-盘口取消理由, 201-赔率错误，202-比赛提前开始
	OrgOddID       string `db:"org_odd_id" json:"org_odd_id"`             //玩法id
	MarketName     string `db:"-" json:"market_name"`                     //多语言适配盘口名
	TourName       string `db:"-" json:"tour_name"`                       //联赛名称
}

//串注限额keys
var limitKeys = []string{
	"limit2",
	"limit3",
	"limit4",
	"limit5",
	"limit6",
	"limit7",
	"limit8",
	"limit9",
	"limit10",
}

//节庆图片keys
var FestivalKeys = []string{
	"id",
	"language",
	"img1",
	"img2",
	"img3",
	"img4",
	"img5",
	"img6",
	"state",
	"start_time",
	"end_time",
	"create_time",
}

var CompsNumMap = map[int]int{
	4:  3,
	11: 4,
	26: 5,
	//22:6,
	//29:7,
	//37:8,
	//46:9,
	//56:10,
}

var LangSportsTourBatchNo = map[string]string{
	"cn": "第X轮",
	"zh": "第X輪",
	"en": "Round",
	"vi": "Vòng",
}

var SportsMatchGameIDMap = map[int]int{
	SportsMatchCategoryFootball:   1001, //虚拟足球
	SportsMatchCategoryBasketBall: 1004, //虚拟篮球
	SportsMatchCategoryHorse:      1011, //虚拟赛马
	SportsMatchCategoryDog:        1002, //虚拟赛狗
	SportsMatchCategoryMotorBike:  1010, //虚拟摩托车
}

//信用盘限额游戏ID
var creditGameIds = map[uint64]bool{
	257154660915053: true,
	257289795134339: true,
	257578064923863: true,
	257561197207055: true,
}

const (
	OtherDevice   = 0 //其他终端
	PcDevice      = 1 //pc端
	H5Device      = 2 //h5端
	AndroidDevice = 3 //android端
	IosDevice     = 4 //IOS端
)

//es索引Mapping
const FrontStatisticsBody = `{
    "mappings" : {
      "properties" : {
        "click_number" : {
          "type" : "long"
        },
        "click_tab" : {
          "type" : "long"
        },
        "created_at" : {
          "type" : "long"
        },
        "device" : {
          "type" : "long"
        },
        "id" : {
          "type" : "text",
          "fields" : {
            "keyword" : {
              "type" : "keyword",
              "ignore_above" : 256
            }
          }
        },
        "merchant_id" : {
          "type" : "long"
        },
        "online_interval" : {
          "type" : "long"
        },
        "page" : {
          "type" : "long"
        },
        "sort_level" : {
          "type" : "text",
          "fields" : {
            "keyword" : {
              "type" : "keyword",
              "ignore_above" : 256
            }
          }
        },
        "top_merchant_id" : {
          "type" : "long"
        },
        "types" : {
          "type" : "long"
        },
        "uid" : {
          "type" : "long"
        }
      }
    }
  }`

// es-会员当前版本索引Mapping
const APPUpdateESBody = `{
	"mappings": {
		"properties": {
			"id": {
				"type": "text",
				"fields": {
					"keyword": {
						"type": "keyword",
						"ignore_above": 256
					}
				}
			},
			"merchant_id": {
				"type": "long"
			},
			"uid": {
				"type": "long"
			},
			"pc": {
				"type": "text",
				"fields": {
					"keyword": {
						"type": "keyword",
						"ignore_above": 256
					}
				}
			},
			"h5": {
				"type": "text",
				"fields": {
					"keyword": {
						"type": "keyword",
						"ignore_above": 256
					}
				}
			}
		}
	}
}`

const (
	OldUser = 1 //老用户
	NewUser = 2 //新用户
)

//游戏id与ClickTab点击标签的映射
var GameMap = map[string]int{
	"257289795134339":   49, //DOTA2
	"257578064923863":   50, //CS:GO
	"257154660915053":   51, //LOL
	"257561197207055":   52, //王者荣耀
	"257697372071315":   53, //蓝球
	"257672679460102":   54, //雷神之锤
	"257719680296134":   55, //足球
	"21363218739142692": 56, //激斗峡谷
	"271192272576750":   57, //无畏契约
	"257366452854033":   58, //明星大乱斗
	"257393813865855":   59, //彩虹6号
	"257421187099429":   60, //使命召唤
	"257445934728386":   61, //堡垒之夜
	"257474469784520":   62, //绝地求生
	"257532676759026":   63, //守望先锋
	"257594184113856":   64, //星际争霸
	"257620516983156":   65, //街头霸王
	"257647180647306":   66, //万智牌
	"257733146228414":   67, //NBA2K
	"258003077224510":   68, //魔兽争霸III
	"258006510157846":   69, //星际争霸II
	"258143683216896":   70, //神之浩劫
	"258172821136137":   71, //火箭联盟
	"258336811299100":   72, //魔兽世界
	"258337013509741":   73, //FIFA
	"614598069861073":   74, //炉石传说
	"1376613872342718":  75, //传说对决
	"1377323217127607":  76, //皇室战争
	"1377370776735090":  77, //穿越火线
	"31476623018398892": 78, //和平精英
}
var (
	// BetTotalFields 注单统计MySQL查询字段
	BetTotalFields = []interface{}{
		g.Func("IFNULL", g.COUNT("id"), 0).As("bet_count"),
		g.Func("IFNULL", g.SUM("bet_amount"), 0).As("bet_amount_total"),
		g.Func("IFNULL", g.SUM("win_amount"), 0).As("win_amount_total"),
		g.Func("IFNULL", g.SUM("theory_prize"), 0).As("theory_prize_total"),
	}
	// EsSimpleSearchFields ES 单注查询字段
	EsSimpleSearchFields = []string{
		"id", "tester", "order_type", "parley_type", "game_id", "tournament_id", "org_odd_id",
		"match_id", "match_type", "market_id", "market_cn_name", "team_names", "team_cn_names", "team_en_names",
		"odd_id", "odd_name", "odd_en_name", "round", "odd", "bet_ip", "device", "bet_amount",
		"win_amount", "is_live", "bet_status", "confirm_type", "bet_time",
		"settle_time", "match_start_time", "theory_prize", "team_id", "reason", "odd_discount", "market_en_name", "batch_no", "round_no",
	}
	// EsComplexSearchFields ES 串注查询字段
	EsComplexSearchFields = []string{
		"id", "game_id", "tournament_id", "match_id", "match_type", "org_odd_id",
		"market_id", "market_en_name", "market_cn_name", "team_names", "team_cn_names", "team_en_names",
		"round", "is_live", "odd_id", "odd_name", "odd_en_name", "odd", "status", "bet_time", "order_id",
		"match_start_time", "settle_time", "team_id", "reason",
	}
	// EsFundSearchFields ES fundSearch查询字段
	EsFundSearchFields = []string{
		"id", "bet_order_id", "order_type", "trade_type", "amount",
		"balance_before", "balance_after", "created_time",
	}
)

// 获取有视频源的赛事列表
type GetVideoData struct {
	MatchID             string   `json:"match_id"`              //赛事ID
	GameID              string   `json:"game_id"`               //游戏ID
	MatchCnTeam         string   `json:"match_cn_team"`         //赛事中文名
	MatchEnTeam         string   `json:"match_en_team"`         //赛事英文名
	TournamentShortName string   `json:"tournament_short_name"` //联赛检查
	TournamentCnName    string   `json:"tournament_cn_name"`    //联赛中文名
	MatchLevel          int      `json:"match_level"`           //赛事等级
	VideoType           int      `json:"video_type"`            //视频来源
	Videos              []string `json:"videos"`                //视频播放URL
}

const (
	StatusUnSettle = 1 //未结算
	StatusSettle   = 2 //已结算
)
const (
	MemberComplexPrizeTotal = "complex_prize_total" // 会员串关每日赔付限额
	MemberSinglePrizeTotal  = "single_prize_total"  // 会员单关每日赔付限额
	MemberWinTotal          = "win_total"           // 会员派彩限额
)

const (
	DefaultCurrencyCode = 1 // 默认人民币币种数字
)

var (
	CurrencyNameMap = map[int]string{
		1:  "CNY",     // 人民币
		2:  "USD",     // 美元
		3:  "HKD",     // 港元
		4:  "VND1000", // 越南盾1000
		5:  "SGD",     // 新家坡
		6:  "GBP",     // 英镑
		7:  "EUR",     // 欧元
		9:  "TWD",     // 台币
		10: "JPY",     // 日元
		11: "PHP",     // 菲币
		12: "KRW",     // 韩元
		13: "AUD",     // 澳元
		14: "CAD",     // 加元
		15: "AED",     // 阿联酋迪拉姆
		16: "MOP",     // 澳门元
		17: "DZD",     // 阿尔及利亚第纳尔
		18: "OMR",     // 阿曼里亚尔
		19: "EGP",     // 埃及镑
		20: "RUB",     // 俄罗斯卢布
		21: "IDR1000", // 印尼盾1000
		22: "MYR",     // 马来西亚林吉特
		23: "VND",     // 越南盾
		24: "INR",     // 印度卢比
		25: "IDR",     // 印尼盾
		26: "THB",     // 泰铢
		27: "BND",     // 文莱林吉特
		28: "CEO",     // 测试币
	}

	quickFields = []string{"quick_one", "quick_two", "quick_three"}
)

var (
	MemberDailyTotalFields = []string{MemberComplexPrizeTotal, MemberSinglePrizeTotal, MemberWinTotal}
)

const (
	ComplexRiskOddTypeStr = "_odd_max"
	ComplexRiskBetTypeStr = "_bet_max"
)
const (
	SingleRiskPrizeTotalType  = 1 // 会员单日单注限额统计类型
	ComplexRiskPrizeTotalType = 2 // 会员单日串注限额统计类型
)

var OneDay = 24 * time.Hour

// OverrunLimitKeys 超限串注限额keys
var OverrunLimitKeys = []string{
	"limit2_odd_max",
	"limit3_odd_max",
	"limit4_odd_max",
	"limit5_odd_max",
	"limit6_odd_max",
	"limit7_odd_max",
	"limit8_odd_max",
	"limit9_odd_max",
	"limit10_odd_max",
	"limit2_bet_max",
	"limit3_bet_max",
	"limit4_bet_max",
	"limit5_bet_max",
	"limit6_bet_max",
	"limit7_bet_max",
	"limit8_bet_max",
	"limit9_bet_max",
	"limit10_bet_max",
}

const (
	LimitOddStrF = "limit%d_odd_max"
	LimitBetStrF = "limit%d_bet_max"
)
const (
	MchCompPrizeLimit    = "mch_comp_prize_limit"
	MchMixPrizeLimit     = "mch_mix_prize_limit"
	MchRndPrizeLimit     = "mch_rnd_prize_limit"
	MchMktPrizeLimit     = "mch_mkt_prize_limit"
	MchPrizeLimit        = "mch_prize_limit"
	defaultMaxPrizeLimit = 99999999 // 默认最大赔付额度
)

const (
	MonitorTypeComp   = iota + 1 // 1-普通串关赛事总赔付
	MonitorTypeMix               // 2-复合玩法总赔付
	MonitorTypeRound             // 3-局内串关总赔付
	MonitorTypeMatch             // 4-赛事总赔付
	MonitorTypeMarket            // 5-盘口总赔付
)

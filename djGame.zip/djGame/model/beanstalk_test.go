package model

import (
	"testing"
)

func TestProduce(t *testing.T) {
	//
	//initBeanstalk("34.92.193.98:11300")
	//produce("mytube", []byte("myjob"), 10*time.Second)
}

func TestConsume(t *testing.T) {

	//initBeanstalk("34.92.193.98:11300")
	//subscribe()
}

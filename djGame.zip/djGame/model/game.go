package model

import (
	"fmt"
	"game/utils"
	"github.com/go-redis/redis/v7"
	errs "github.com/pkg/errors"
	"github.com/scylladb/go-set"
	"github.com/scylladb/go-set/strset"
	"sort"
	"time"
)

type Game struct {
	ID           string `db:"id" rule:"none" json:"id"`             //游戏ID
	CreateByID   uint64 `db:"create_by_id" json:"create_by_id" `    //创建人ID
	UpdateByID   uint64 `db:"update_by_id" json:"update_by_id"`     //修改人ID
	CreateTime   int64  `db:"create_time" json:"create_time"`       //创建时间
	UpdateTime   int64  `db:"update_time" json:"update_time"`       //修改时间
	CreateByName string `db:"create_by_name" json:"create_by_name"` //创建人名称
	ShortName    string `db:"short_name" json:"short_name"`         //简称
	CnName       string `db:"cn_name" json:"cn_name"`               //中文名称
	EnName       string `db:"en_name" json:"en_name"`               //英文名称
	UpdateByName string `db:"update_by_name" json:"update_by_name"` //修改人名称
	SortCode     int    `db:"sort_code" json:"sort_code"`           //排序码
	Status       int    `db:"status" json:"status"`                 //状态 开启-1关闭-0
	MatchesCount int64  `json:"matches_count"`
}

// GameNav 前台游戏菜单
type GameNav struct {
	ID       string            `db:"id" json:"id"`         //游戏ID
	Status   string            `db:"status" json:"status"` //状态 开启-1关闭-0
	Count    string            `json:"count"`              //数量
	SortCode string            `json:"sort_code"`          //排序码
	Name     string            `json:"name" db:"-"`        //游戏名(支持多语言)
	NameMap  map[string]string `json:"-"`                  //游戏名多语言数据
}

//联赛数据-虚拟体育
type SportsGameTourData struct {
	ID    string `json:"id"`     //联赛ID
	Name  string `json:"name"`   //联赛名称
	IsCup string `json:"is_cup"` //是否杯赛
}

//联赛数据-虚拟体育
type SportsTourCupData struct {
	ID       string `json:"id"`        //联赛ID
	SID      string `json:"sid"`       //联赛SID
	SortCode int    `json:"sort_code"` //联赛排序Code
	IsCup    int    `json:"is_cup"`    //是否杯赛
}

// 玩法分类栏-虚拟体育
type PlayTypeData struct {
	ID     string `json:"id" db:"id"`           //分类栏ID
	Name   string `json:"name" db:"name"`       //分类栏名称
	SortID int    `json:"sort_id" db:"sort_id"` //排序ID
	PlayID string `json:"play_id" db:"play_id"` //玩法ID集合
}

/**
 * @Description: 获取游戏菜单
 * @Author: wesley
 * @Date: 2020/6/28 16:57
 * @LastEditTime: 2020/6/28 16:57
 * @LastEditors: wesley
 */
func GameNavGet(merchantID uint64) ([]GameNav, error) {

	var (
		nav  []GameNav
		data []*redis.SliceCmd
	)

	filterGames, err := GetMerchantFilterGames(merchantID)
	if err != nil {
		return nav, err
	}

	cacheKey := "nav"

	if v, ok := mt.ramCacheData.Nav.Load(cacheKey); ok {
		nav = v.([]GameNav)
		if filterGames.IsEmpty() {
			return nav, nil
		}

		for i, _ := range nav {
			if filterGames.Has(nav[i].ID) {
				nav[i].Count = "0"
			}
		}

		return nav, nil
	}

	if filterGames.IsEmpty() {
		merchantID = 0
	}

	fmt.Printf("[%s]Redis Query GameNavGet! merchantID:%d \n", mt.Config.MerchantName, merchantID)
	pipe := mt.ZKRedisCluster.Pipeline()
	defer pipe.Close()

	mpNameI18nCmds := map[string]*redis.SliceCmd{}
	for _, id := range mt.Config.GameIDs {
		if utils.CheckSportsGameID(id) {
			continue
		}
		key := fmt.Sprintf("gnav:%s", id)
		val := pipe.HMGet(key, "id", "status", "count", "sort_code")
		data = append(data, val)

		mpNameI18nCmds[id] = pipe.HMGet(fmt.Sprintf(RedisLangGame, id), Languages...)
	}

	_, err = pipe.Exec()
	if err != nil && err != redis.Nil {
		return nav, err
	}

	for _, value := range data {

		res, err := value.Result()
		if err != nil {
			return nav, nil
		}

		if res[0] == nil { // 对应游戏id的记录不存在
			continue
		}

		id := getHashValue(res[0])
		nameMap := map[string]string{}
		if nameCmd, ok := mpNameI18nCmds[id]; ok {
			nameVals, err := nameCmd.Result()
			if err != nil {
				continue
			}

			for i, nv := range nameVals {
				nameMap[Languages[i]] = getHashValue(nv)
			}
		}

		count := "0"
		// 判断游戏是否被过滤
		if !filterGames.Has(id) {
			count = getHashValue(res[2])
			if len(count) == 0 {
				count = "0"
			}
		}
		n := GameNav{
			ID:       id,
			Status:   getHashValue(res[1]),
			Count:    count,
			SortCode: getHashValue(res[3]),
			NameMap:  nameMap,
		}
		nav = append(nav, n)
	}

	if merchantID == 0 {
		if _, ok := keyLock.Load(cacheKey); !ok {
			keyLock.Store(cacheKey, 1)
			mt.ramCacheData.Nav.Store(cacheKey, nav)
			idxCache := IdxCache{
				Key:         cacheKey,
				RefreshTime: 5 * time.Second,
			}

			_ = mt.idxCachePool.Invoke(idxCache)
		}
	}

	return nav, nil
}

/**
 * @Description: 通过游戏id获取联赛列表
 * @Author: maxic
 * @Date: 2021/1/30
 * @LastEditTime: 2021/1/30
 * @LastEditors: maxic
 **/
func GameTourGet(gameId string, merchantID uint64) (interface{}, error) {

	filterGames, err := GetMerchantFilterGames(merchantID)
	if err != nil {
		return nil, err
	}

	return utils.GameTourCacheGet(mt.ZKRedisCluster, gameId, "", filterGames)
}

/*
 * @Description: 通过游戏id获取联赛列表-虚拟体育
 * @Author: robin
 * @Date: 2022/4/3 15:57
 * @LastEditTime: 2022/4/3 15:57
 * @LastEditors: robin
 */
func SportsGameTourGet(gameId, lan string, merchantID uint64) (interface{}, error) {

	filterGames, err := GetMerchantFilterGames(merchantID)
	if err != nil {
		return nil, err
	}

	return SportsGameTourCacheGet(mt.ZKRedisCluster, gameId, lan, filterGames)
}

/*
 * @Description: 检测游戏 显示隐藏赛事状态
 * @Author: robin
 * @Date: 2022/4/23 20:57
 * @LastEditTime: 2022/4/23 20:57
 * @LastEditors: robin
 */
func CheckOpenMatch(gameId string) bool {
	isOpenMatch, err := mt.ZKRedisCluster.HGet(fmt.Sprintf(utils.RedisGameNav, gameId), "is_open_match").Result()
	if err != nil {
		fmt.Printf("CheckOpenMatch-HGet, 联赛SID[%s] Error:%s.\n", gameId, err.Error())
		return false
	}

	if isOpenMatch != GameOpenMatchStatusOpen {
		return false
	}

	return true
}

/*
 * @Description: 获取联赛缓存数据
 * @Author: robin
 * @Date: 2022/4/3 15:38
 * @LastEditTime: 2022/4/3 15:38
 * @LastEditors: robin
 */
func SportsGameTourCacheGet(pool *redis.ClusterClient, gameId, lan string, filterGames *strset.Set) (interface{}, error) {

	// 游戏被过滤，直接返回空数组
	if filterGames.Has(gameId) {
		return map[string][]string{}, nil
	}

	var (
		tourIds           []string
		gameTourDataSlice []SportsGameTourData
		tourCupDataSlice  []SportsTourCupData
		err               error
	)

	if !CheckOpenMatch(gameId) {
		return map[string][]string{}, nil
	}

	keyGameID := fmt.Sprintf(utils.RedisGameSportsTour, gameId)
	tourIds, err = pool.SMembers(keyGameID).Result()
	if err != nil {
		fmt.Printf("SportsGameTourCacheGet 获取游戏ID[%s]的联赛数据, Error:%s\n", gameId, err.Error())
		return nil, err
	}

	for _, id := range tourIds {
		_, ok := mt.SportsGameDataMap[id]
		if !ok {
			continue
		}
		tourCupDataSlice = append(tourCupDataSlice, mt.SportsGameDataMap[id])
	}

	sort.Slice(tourCupDataSlice, func(i, j int) bool {
		return tourCupDataSlice[j].SortCode > tourCupDataSlice[i].SortCode
	})

	tournamentNameMap := MultiLanguageName(RamDataVirtual, tourIds, lan)
	for _, data := range tourCupDataSlice {
		strCup, err := pool.HGet(utils.RedisTourIsCup, data.SID).Result()
		if err != nil {
			if errs.Cause(err) == redis.Nil {
				fmt.Printf("SportsGameTourCacheGet-HGet, 联赛SID[%s] Redis is Nil.\n", data.SID)
			} else {
				fmt.Printf("SportsGameTourCacheGet-HGet, 联赛SID[%s] Error:%s.\n", data.SID, err.Error())
			}
			continue
		}

		_, ok := tournamentNameMap[data.ID]
		if ok {
			tourData := SportsGameTourData{
				ID:    data.ID,
				Name:  tournamentNameMap[data.ID],
				IsCup: strCup,
			}
			gameTourDataSlice = append(gameTourDataSlice, tourData)
		}
	}

	return gameTourDataSlice, nil

}

/**
* @Description: 通过游戏ids获取游戏名列表
* @Author: brandon
* @Date: 2020/6/30 10:22 下午
* @LastEditTime: 2021/10/2 14:33
* @LastEditors: robin
 */
func GameGetName(ids []string) (map[string]string, error) {

	return RedisPipelineHMGet(ids, "short_name", utils.RedisGameNav)
}

func getHashValue(value interface{}) string {

	var r string
	if v, ok := value.(string); ok {
		r = v
	}

	return r
}

/**
* @Description: 获取商户过滤的游戏列表
* @Author: xp
* @Date: 2021/7/22
* @LastEditTime: 2021/7/22
* @LastEditors: xp
 */
func GetMerchantFilterGames(merchantId uint64) (*strset.Set, error) {

	result := set.NewStringSet()
	if merchantId <= 0 {
		return result, nil
	}

	if v, ok := MerchantFilterGame[merchantId]; ok {
		result = v
	}

	return result, nil
}

func SetMerchantFilterGames(merchantId uint64) (bool, error) {

	result := set.NewStringSet()
	if merchantId > 0 {
		key := fmt.Sprintf(utils.RedisMerchantFilterGame, merchantId)
		list, err := mt.ZKRedisCluster.SMembers(key).Result()
		if err == redis.Nil {
			return false, nil
		}

		if err != nil {
			return false, err
		}

		result.Add(list...)
	}

	mt.ramCacheData.FilterGame.Store(merchantId, result)
	return true, nil
}

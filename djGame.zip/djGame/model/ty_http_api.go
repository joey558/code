package model

import (
	"encoding/json"
	"errors"
	"fmt"
	"game/helper"
	"strconv"
	"time"

	"github.com/shopspring/decimal"

	"github.com/valyala/fasthttp"
)

// 体育的用户信息
type tyMemberInfo struct {
	DJUserName   string `json:"dj_user_name"` // 电竞的用户名
	TYUserID     string `json:"ty_user_id"`   // 体育的用户ID
	TYToken      string `json:"ty_token"`     // 体育的token
	LastReadTime int64  // 上次读取时间
}

// 体育登录返回信息
type tyLoginResponse struct {
	Status     bool   `json:"status"`
	Msg        string `json:"msg"`
	Code       string `json:"code"`
	ServerTime int64  `json:"serverTime"`
	Data       struct {
		UserId    string `json:"userId"`
		Domain    string `json:"domain"`
		Token     string `json:"token"`
		ImgDomain string `json:"imgDomain"`
		Url       string `json:"url"`
		LoginUrl  string `json:"loginUrl"`
	} `json:"data"`
}

// 投注请求结构
type tyBetRequest struct {
	DeviceType   uint32          `json:"deviceType"` // 设备类型 1:H5，2：PC,3:Android,4:IOS,5:其他
	DeviceImei   string          `json:"deviceImei"` // 设备号，当设备类型=1/3/4时，需要传值
	AcceptOdds   int             `json:"acceptOdds"` // 1：自动接收更好的赔率 2：自动接受任何赔率变动 3：不自动接受赔率变动
	SeriesOrders []tySeriesOrder `json:"seriesOrders"`
}

// 投注请求结构
type tySeriesOrder struct {
	SeriesType      int             `json:"seriesType"`      // 串关类型
	SeriesSum       int             `json:"seriesSum"`       // 串关数量
	FullBet         int             `json:"fullBet"`         // 是否满额投注，1：是，0：否
	OrderDetailList []tyOrderDetail `json:"orderDetailList"` // 注单集合对象
}

// 投注请求结构
type tyOrderDetail struct {
	PlayId            string  `json:"playId"`            // 玩法id
	OddFinally        string  `json:"oddFinally"`        // 最终赔率
	Odds              float64 `json:"odds"`              // 欧洲赔率 OddFinally * 100000
	BetAmount         string  `json:"betAmount"`         // 投注金额【无需处理，用户数据为准】
	PlayOptionsId     string  `json:"playOptionsId"`     // 投注项id
	MatchId           string  `json:"matchId"`           // 赛事id
	MarketTypeFinally string  `json:"marketTypeFinally"` // 最终盘口类型
	MarketId          string  `json:"marketId"`          // 盘口Id
	MatchType         int     `json:"matchType"`         // 赛事类型标识 1:早盘赛事 ，2:滚球盘赛事，3:冠军，4:虚拟赛事，5:电竞赛事【根据页面tab来区分】
	ScoreBenchmark    string  `json:"scoreBenchmark"`    // 基准分
	PlaceNum          int     `json:"placeNum"`          // 坑位（盘口位置，1：表示主盘，2：表示第一副盘）如有则必传
}

// 注单确认查询返回信息
type tyQueryOrderStatusResponse struct {
	Msg  string `json:"msg"`
	Code string `json:"code"`
	Data []struct {
		OrderNo        string `json:"orderNo"`
		Status         int    `json:"status"` // 订单状态 0:已确认,1:已处理,2:拒绝,3:待确认,4:失败
		OddsChangeList []struct {
			BetNo         string `json:"betNo"`
			UsedOdds      string `json:"usedOdds"`
			PlayOptionsId string `json:"playOptionsId"`
		} `json:"oddsChangeList"`
	} `json:"data"`
}

// 投注返回结构
type tyBetResponse struct {
	Code string `json:"code"`
	Msg  string `json:"msg"`
	Time int64  `json:"ts"`
	Data struct {
		Lock          int `json:"lock"` // 0:不锁，1:锁住
		TYOrderDetail []struct {
			Addition     string `json:"addition"`     // 附加金额
			BetMoney     string `json:"betMoney"`     // 投注金额【/100为用户真实投注金额】
			MarketType   string `json:"marketType"`   // 盘口类型
			MarketValues string `json:"marketValues"` // 盘口值

			MatchInfo   string `json:"matchInfo"`   // 对阵信息
			MatchStatus int    `json:"matchStatus"` // 赛事状态：0未开赛，1 进行中 4 结束
			MaxWinMoney string `json:"maxWinMoney"` // 对打可盈金额

			OddsValues      string `json:"oddsValues"`      // 欧赔
			OrderNo         string `json:"orderNo"`         // 订单号
			OrderStatusCode int    `json:"orderStatusCode"` // 订单状态码(0:待处理, 1:已处理, 2:取消交易, 3:待确认, 4:已拒绝, 5:撤单)
			PlayName        string `json:"playName"`        // 玩法名称

			PlayOptionName string `json:"playOptionName"` // 投注项名称
			PlayOptionsId  string `json:"playOptionsId"`  // 投注项id
			TeamName       string `json:"teamName"`       // 团队名称
		} `json:"orderDetailRespList"`
	} `json:"data"`
}

//体育限额接口-请求信息
type tyLimitRequest struct {
	MatchID      string `json:"matchId"`
	MarketID     string `json:"marketId"`
	PlayID       string `json:"playId"`
	PlayOptionID string `json:"playOptionId"`
	MatchType    int    `json:"matchType"`
	DeviceType   int    `json:"deviceType"`
}

//体育限额接口-响应信息
type TYLimitResponse struct {
	Msg        string `json:"msg"`
	Code       string `json:"code"`
	ServerTime int64  `json:"ts"`
	Data       []struct {
		Code        int             `json:"code"`
		GlobalId    string          `json:"globalId"`
		MinBet      decimal.Decimal `json:"minBet"`
		OrderMaxPay decimal.Decimal `json:"orderMaxPay"`
		PlayId      string          `json:"playId"`
		Type        string          `json:"type"`
		SeriesOdds  string          `json:"seriesOdds"`
	} `json:"data"`
}

// 获取盘口信息-请示信息
type TYQueryLatestMarketInfoRequest struct {
	MarketID    string `json:"marketId"`
	MatchInfoID string `json:"matchInfoId"`
	OddsID      string `json:"oddsId"`
	OddsType    string `json:"oddsType"`
	PlayID      string `json:"playId"`
	MatchType   int    `json:"matchType"`
	SportID     int    `json:"sportId"`
	PlaceNum    int    `json:"placeNum"`
}

//体育限额接口-响应信息
type TYQueryLatestMarketInfoResponse struct {
	Msg        string `json:"msg"`
	Code       string `json:"code"`
	ServerTime int64  `json:"ts"`
	Data       []struct {
		ID          string `json:"id"`
		Score       string `json:"score"`
		MarketValue string `json:"marketValue"`
	} `json:"data"`
}

/*
* @Description: 获取体育登录接口信息
* @Author: xp
* @Date: 2021/12/7 20:03
* @LastEditTime: 2021/12/7 20:03
* @LastEditors: xp
 */
func tyHttpUserLogin(userID uint64, userName string) (tyMemberInfo, error) {

	tyMember := tyMemberInfo{}

	// 需要重新登录
	// todo:电竞不同的商户，可能用户名相同，但传给体育时必须保证唯一，在用户名里拼接用户id或者商户id
	tyUserName := fmt.Sprintf("%s_%d", userName, userID)
	terminal := "pc"
	timestamp := fmt.Sprintf("%d", time.Now().UnixNano()/1e6)

	data := new(fasthttp.Args)
	data.Add("userName", tyUserName)
	data.Add("merchantCode", mt.Config.TYApiConf.MerchantCode)
	data.Add("terminal", terminal)
	data.Add("timestamp", timestamp)

	str := helper.GetMD5Hash(mt.Config.TYApiConf.MerchantCode + "&" + tyUserName + "&" + terminal + "&" + timestamp)
	signature := helper.GetMD5Hash(str + "&" + mt.Config.TYApiConf.SecretKey)
	data.Add("signature", signature)

	headers := map[string]string{
		fasthttp.HeaderContentType: "application/x-www-form-urlencoded",
	}

	respBytes, statusCode, err := helper.HttpDoTimeout(data.QueryString(), fasthttp.MethodPost, mt.Config.TYApiConf.LoginUrl, headers, 7*time.Second)
	if err != nil {
		return tyMember, err
	}

	if statusCode != fasthttp.StatusOK {
		return tyMember, fmt.Errorf("tyHttpUserLogin service error: %d", statusCode)
	}

	var tyUserLoginResp tyLoginResponse
	err = helper.JsonUnmarshal(respBytes, &tyUserLoginResp)
	if err != nil {
		fmt.Printf("tyHttpUserLogin 接口请求失败: %s\n", err.Error())
		return tyMember, err
	}

	if tyUserLoginResp.Code != tyApiSuccess {
		txt := fmt.Sprintf("tyHttpUserLogin 接口请求失败[%v]. ErrCode:[%v] \n", tyUserLoginResp.Msg, tyUserLoginResp.Code)
		fmt.Printf(txt)
		return tyMember, errors.New(txt)
	}

	//保存体育用户信息
	tyMember.DJUserName = userName
	tyMember.TYToken = tyUserLoginResp.Data.Token
	tyMember.TYUserID = tyUserLoginResp.Data.UserId
	tyMember.LastReadTime = time.Now().Unix()
	values := map[string]interface{}{
		"dj_user_name": tyMember.DJUserName,
		"ty_user_id":   tyMember.TYUserID,
		"ty_token":     tyMember.TYToken,
	}
	tyMemberMap.Store(userID, tyMember)

	pipe := mt.MerchantRedis.Pipeline()
	defer pipe.Close()

	redisKey := fmt.Sprintf(redisTYMember, userID)
	pipe.HMSet(redisKey, values)
	pipe.Expire(redisKey, 24*time.Hour) // 缓存24小时
	_, err = pipe.Exec()

	return tyMember, err
}

/*
* @Description: 注单确认查询
* @Author: xp
* @Date: 2021/12/7 20:03
* @LastEditTime: 2021/12/7 20:03
* @LastEditors: xp
 */
func tyHttpQueryOrderStatus(order BetOrder) (tyQueryOrderStatusResponse, error) {

	var resp tyQueryOrderStatusResponse

	headers := map[string]string{
		fasthttp.HeaderContentType: "application/x-www-form-urlencoded",
		"requestId":                order.TYToken,
	}

	url := fmt.Sprintf("%s?orderNos=%s", mt.Config.TYApiConf.QueryOrderStatusUrl, order.TYOrderID)
	respBytes, statusCode, err := helper.HttpDoTimeout(nil, fasthttp.MethodGet, url, headers, 7*time.Second)
	if err != nil {
		return resp, fmt.Errorf("tyHttpQueryOrderStatus HttpPost Err. [%v]\n", err)
	}

	if statusCode != fasthttp.StatusOK {
		return resp, fmt.Errorf("tyHttpQueryOrderStatus service error: %d", statusCode)
	}

	err = json.Unmarshal(respBytes, &resp)
	if err != nil {
		fmt.Printf("tyHttpQueryOrderStatus json  ReqBuf:%s\nRespBuf:%s\nerr:%v\n", url, string(respBytes), err)
	}

	return resp, err
}

/*
* @Description: 体育投注接口
* @Author: xp
* @Date: 2021/12/7 20:03
* @LastEditTime: 2021/12/7 20:03
* @LastEditors: xp
 */
func tyHttpBet(order BetOrder) (tyBetResponse, error) {

	tyBetResp := tyBetResponse{}

	odds, err := strconv.ParseFloat(order.Odd, 64)
	if err != nil {
		// 赔率有错误,直接撤单并删除任务
		return tyBetResp, err
	}
	odds = odds * 100000
	newOrder := tyOrderDetail{
		PlayId:            order.OrgOddID,       // 玩法id
		OddFinally:        order.Odd,            // 最终赔率
		Odds:              odds,                 // 欧洲赔率 OddFinally * 100000
		BetAmount:         order.BetAmount,      // 投注金额【无需处理，用户数据为准】
		PlayOptionsId:     order.OddID,          // 投注项id
		MatchId:           order.TYMatchSID,     // 体育赛事id
		MarketTypeFinally: "EU",                 // 最终盘口类型
		MarketId:          order.MarketID,       // 盘口Id
		MatchType:         order.MatchType,      // 赛事类型标识 1:早盘赛事，2:滚球盘赛事，3:冠军，4:虚拟赛事，5:电竞赛事
		ScoreBenchmark:    order.ScoreBenchmark, // 基准分
		PlaceNum:          order.PlaceNum,
	}
	tySeriesOrders := tySeriesOrder{
		SeriesType: 1,
		SeriesSum:  1,
		FullBet:    0,
	}
	tySeriesOrders.OrderDetailList = append(tySeriesOrders.OrderDetailList, newOrder)

	tyBetReq := tyBetRequest{
		DeviceType: order.Device,
		DeviceImei: "",
		AcceptOdds: order.AcceptOdds,
	}
	tyBetReq.SeriesOrders = append(tyBetReq.SeriesOrders, tySeriesOrders)

	reqBytes, err := helper.JsonMarshal(tyBetReq)
	if err != nil {
		// json有错误
		return tyBetResp, err
	}

	headers := map[string]string{
		fasthttp.HeaderContentType: "application/json",
		"requestId":                order.TYToken,
	}

	respBytes, statusCode, err := helper.HttpDoTimeout(reqBytes, fasthttp.MethodPost, mt.Config.TYApiConf.BetUrl, headers, 15*time.Second)
	if err != nil {
		return tyBetResp, fmt.Errorf("tyHttpBet HttpPost Err. [%v]\n", err)
	}

	if statusCode != fasthttp.StatusOK {
		// http请求失败,直接撤单并删除任务
		return tyBetResp, fmt.Errorf("tyHttpBet service error: %d", statusCode)
	}

	err = json.Unmarshal(respBytes, &tyBetResp)

	fmt.Printf("tyHttpBet \n ReqBuf:%s\nRespBuf:%s\n", string(reqBytes), string(respBytes))

	return tyBetResp, err
}

/*
* @Description: 体育限红接口
* @Author: xp
* @Date: 2021/12/7 20:03
* @LastEditTime: 2021/12/7 20:03
* @LastEditors: xp
 */
func tyHttpLimit(tyToken, sID, marketID, optionID, playID string, matchType, device int) (TYLimitResponse, error) {

	var tyLimitResp TYLimitResponse

	headers := map[string]string{
		fasthttp.HeaderContentType: "application/json",
		"requestId":                tyToken,
	}

	tyLimitReq := tyLimitRequest{
		MatchID:      sID,
		MatchType:    matchType,
		MarketID:     marketID,
		PlayID:       playID,
		PlayOptionID: optionID,
		DeviceType:   device,
	}
	reqMap := map[string][]tyLimitRequest{
		"orderMaxBetMoney": {tyLimitReq},
	}
	reqBytes, err := helper.JsonMarshal(reqMap)
	if err != nil {
		return tyLimitResp, err
	}

	respBytes, statusCode, err := helper.HttpDoTimeout(reqBytes, fasthttp.MethodPost, mt.Config.TYApiConf.LimitUrl, headers, 7*time.Second)
	if err != nil {
		return tyLimitResp, err
	}

	if statusCode != fasthttp.StatusOK {
		return tyLimitResp, fmt.Errorf("tyHttpLimit service error: %d", statusCode)
	}

	err = helper.JsonUnmarshal(respBytes, &tyLimitResp)

	return tyLimitResp, err
}

/*
* @Description: 获取盘口信息
* @Author: xp
* @Date: 2021/12/7 20:03
* @LastEditTime: 2021/12/7 20:03
* @LastEditors: xp
 */
func tyHttpQueryLatestMarketInfo(tyMemberToken, matchID, marketID, playID, optionID string, matchType, sportID, placeNum int) (TYQueryLatestMarketInfoResponse, error) {

	var resp TYQueryLatestMarketInfoResponse

	headers := map[string]string{
		fasthttp.HeaderContentType: "application/json",
		"requestId":                tyMemberToken,
	}

	req := [1]TYQueryLatestMarketInfoRequest{}
	req[0].MatchInfoID = matchID
	req[0].MarketID = marketID
	req[0].OddsID = optionID
	req[0].PlayID = playID
	req[0].MatchType = matchType
	req[0].SportID = sportID
	req[0].PlaceNum = placeNum

	reqMap := map[string][1]TYQueryLatestMarketInfoRequest{}
	reqMap["idList"] = req

	reqBytes, err := json.Marshal(reqMap)
	if err != nil {
		return resp, err
	}

	respBytes, statusCode, err := helper.HttpDoTimeout(reqBytes, fasthttp.MethodPost, mt.Config.TYApiConf.QueryLatestMarketInfoUrl, headers, 7*time.Second)
	if err != nil {
		return resp, fmt.Errorf("tyHttpQueryLatestMarketInfo HttpPost Err. [%v]\n", err)
	}

	if statusCode != fasthttp.StatusOK {
		return resp, fmt.Errorf("tyHttpQueryLatestMarketInfo service error: %d", statusCode)
	}

	err = json.Unmarshal(respBytes, &resp)

	return resp, err
}

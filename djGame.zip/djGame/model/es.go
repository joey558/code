package model

import (
	"context"
	"errors"
	"fmt"
	"game/helper"
	fund "game/wallet"
	"github.com/olivere/elastic/v7"
	"time"
)

type EsSimple struct {
	BetAmount      float64 `json:"bet_amount"`       //注单金额
	BetIP          uint32  `json:"bet_ip"`           //投注IP
	BetStatus      int     `json:"bet_status"`       //注单状态 1-待确认 2-已拒绝 3-待结算 4-已取消 5-已中奖 6-未中奖 7-已撤销
	BetTime        int64   `json:"bet_time"`         //投注时间
	ConfirmType    int     `json:"confirm_type"`     //确认方式 1-自动确认 2-手动待确认 3-手动确认 4-手动拒绝
	Device         uint32  `json:"device"`           //设备 [1-PC  2-H5  3-Android  4-IOS]
	GameID         uint64  `json:"game_id"`          //游戏ID
	ID             uint64  `json:"id"`               //主键id
	IsLive         int     `json:"is_live"`          //赛事阶段 1-初盘 2-滚盘
	MarketEnName   string  `json:"market_en_name"`   //盘口英文名
	MarketCnName   string  `json:"market_cn_name"`   //盘口中文名
	MarketID       uint64  `json:"market_id"`        //盘口id
	MatchID        uint64  `json:"match_id"`         //赛事id
	MatchStartTime int     `json:"match_start_time"` //赛事开始时间
	MatchType      int     `json:"match_type"`       //赛事类型 正常-1 冠军-2 大逃杀-3 篮球-4 主播盘-5 足球-6
	Odd            string  `json:"odd"`              //赔率
	OddID          uint64  `json:"odd_id"`           //投注项id
	OddName        string  `json:"odd_name"`         //投注项名称
	OddEnName      string  `json:"odd_en_name"`      //投注项英文名
	OrderType      int     `json:"order_type"`       //注单类型 1-普通注单 2-普通串关注单 3-局内串关注单, 4-复合玩法注单
	OrgOddID       uint64  `json:"org_odd_id"`       //玩法id
	ParleyType     int     `json:"parley_type"`      //串关类型 1普通注单 2:2串1  3:3串1 4:4串1 5:5串1 6:6串1 7:7串1 8:8串1
	Round          int     `json:"round"`            //第几局
	SettleTime     int     `json:"settle_time"`      //结算时间
	TeamNames      string  `json:"team_names"`       //队伍名称
	TeamCnNames    string  `json:"team_cn_names"`    //队伍中文名称
	TeamEnNames    string  `json:"team_en_names"`    //队伍英文名称
	TeamID         string  `json:"team_id"`          //战队id
	Tester         uint8   `json:"tester"`           //是否测试账号(0:正常账号,1:测试账号,2:信用账户)
	TheoryPrize    float64 `json:"theory_prize"`     //理论奖金
	TournamentID   uint64  `json:"tournament_id"`    //联赛ID
	WinAmount      float64 `json:"win_amount"`       //派彩金额
	Reason         int     `json:"reason"`           //x-赛事取消理由, 1xx-盘口取消理由, 201-赔率错误，202-比赛提前开始
	OddDiscount    float64 `json:"odd_discount"`     //赔率折扣
	ScoreBenchmark string  `json:"score_benchmark"`  //投注时的比分
	BatchNo        string  `json:"batch_no"`         //批次-虚拟体育
	RoundNo        string  `json:"round_no"`         //轮次-虚拟体育
}

type EsComplex struct {
	BetTime        int64  `json:"bet_time"`         //投注时间
	GameID         uint64 `json:"game_id"`          //游戏ID
	ID             uint64 `json:"id"`               //主键id
	IsLive         int    `json:"is_live"`          //赛事阶段 1-初盘 2-滚盘
	MarketEnName   string `json:"market_en_name"`   //盘口英文名
	MarketCnName   string `json:"market_cn_name"`   //盘口中文名
	MarketID       uint64 `json:"market_id"`        //盘口id
	MatchID        uint64 `json:"match_id"`         //赛事id
	OrgOddID       uint64 `json:"org_odd_id"`       //玩法id
	MatchStartTime int    `json:"match_start_time"` //赛事开始时间
	MatchType      int    `json:"match_type"`       //赛事类型 正常-1 冠军-2 大逃杀-3 篮球-4 主播盘-5 足球-6
	Odd            string `json:"odd"`              //赔率
	OddID          uint64 `json:"odd_id"`           //投注项id
	OddName        string `json:"odd_name"`         //投注项名称
	OddEnName      string `json:"odd_en_name"`      //投注项英文名
	OrderID        uint64 `json:"order_id"`         //注单id
	Round          int    `json:"round"`            //第几局
	Status         int    `json:"status"`           //1-待结算 2-已取消 3-已中奖 4-未中奖
	TeamNames      string `json:"team_names"`       //队伍名称
	TeamCnNames    string `json:"team_cn_names"`    //队伍中文名称
	TeamEnNames    string `json:"team_en_names"`    //队伍英文名称
	TournamentID   uint64 `json:"tournament_id"`    //联赛ID
	TeamID         string `json:"team_id"`          //战队id
	SettleTime     int    `json:"settle_time"`      //结算时间
	Reason         int    `json:"reason"`           //x-赛事取消理由, 1xx-盘口取消理由, 201-赔率错误，202-比赛提前开始
}

type EsOrderQueryParam struct {
	UID       uint64    //会员id
	MarketId  uint64    //盘口id
	OrderType uint8     //注单类型 1-普通注单 2-普通串关注单 3-局内串关注单, 4-复合玩法注单
	MatchType uint8     //赛事类型 正常-1 冠军-2 大逃杀-3 篮球-4 主播盘-5 足球-6
	Live      uint8     //赛事阶段 1-初盘 2-滚盘
	Status    uint8     // 1 未结算 2 已经结算
	Settled   int       //是否已结算 0-否 1-是
	BeginTime time.Time //开始时间
	EndTime   time.Time //结束时间
	Page      int       //第几页
	PageSize  int       //每页条数
}

type EsFundQueryParam struct {
	UID       uint64    //用户id
	Type      uint8     //1-资金转入 2-资金转出 3-投注 4-派奖 5-取消注单 6-拒绝注单 7-撤单 8-撤销派奖
	BeginTime time.Time //开始时间
	EndTime   time.Time //结束时间
	Page      int       //第几页
	PageSize  int       //每页条数
}

type StatisticsInfoEs struct {
	ID             string `json:"id"`              //ID
	UID            uint64 `json:"uid"`             //用户ID
	TopMerchantId  uint64 `json:"top_merchant_id"` //顶层商户ID
	MerchantID     uint64 `json:"merchant_id" `    //商户ID
	SortLevel      string `json:"sort_level" `     //商户排序层级
	Device         uint8  `json:"device"`          //终端 0-其他 1-PC  2-H5  3-Android  4-IOS
	OnlineInterval int64  `json:"online_interval"` //在线时长
	ClickTab       int    `json:"click_tab"`       //点击标签
	ClickNumber    uint8  `json:"click_number"`    //点击次数
	Types          uint8  `json:"types"`           //1-老用户,2-新增用户
	Page           uint8  `json:"page"`            //1-首页,2-赛事页面,3-赛果页面,4-个人中心页面,5-购物车点击页面,6-购物车注单页面,7-游戏点击页面
	CreatedAt      int64  `json:"created_at"`      //创建时间
}

type EsUserVer struct {
	UID        uint64 `json:"uid"`          //用户ID
	MerchantID uint64 `json:"merchant_id" ` //商户ID
	Pc         string `json:"pc"`           //pc版本
	H5         string `json:"h5"`           //h5版本
}

/**
 * @Description:
 * @Author: wesley
 * @Date: 2020/8/31 17:28
 * @LastEditTime: 2020/8/31 17:28
 * @LastEditors: wesley
 */
func EsFundListGet(param EsFundQueryParam, now time.Time) (FundListData, error) {

	var data FundListData
	//索引
	index := mt.Config.Elasticsearch.IndexPrefix + EsFundIndexKeyWord

	res, err := fundSearch(param).Index(index).Do(context.Background())
	if err != nil {
		return data, err
	}

	// 单注数据
	if res.Status == 0 && res.Hits.TotalHits.Value > 0 {

		data.T = res.Hits.TotalHits.Value

		for _, v := range res.Hits.Hits {

			d := FundResponse{}
			err := helper.JsonUnmarshal(v.Source, &d)
			if err != nil {
				return data, err
			}
			data.D = append(data.D, d)
		}
	}

	return data, nil
}

/**
 * @Description: es 注单列表
 * @Author: wesley
 * @Date: 2020/8/31 17:28
 * @LastEditTime: 2020/8/31 17:28
 * @LastEditors: wesley
 */
func EsOrderListGet(param EsOrderQueryParam) (BetOrderListData, error) {

	var (
		data    BetOrderListData
		compIDs []interface{}
	)

	//单注索引
	index := mt.Config.Elasticsearch.IndexPrefix + EsSimpleIndexKeyWord
	resOrder, err := simpleSearch(param).Index(index).Do(context.Background())
	if err != nil {
		return data, err
	}

	// 单注数据
	if resOrder.Status == 0 && resOrder.Hits.TotalHits.Value > 0 {

		data.T = resOrder.Hits.TotalHits.Value

		for _, v := range resOrder.Hits.Hits {

			simple := EsSimple{}
			err := helper.JsonUnmarshal(v.Source, &simple)
			if err != nil {
				return data, err
			}

			data.Bet = append(data.Bet, compileSimple(simple))
			if simple.OrderType == OrderTypeComplex || simple.OrderType == OrderTypeRoundComplex || simple.OrderType == OrderTypeMix {
				compIDs = append(compIDs, simple.ID)
			}
		}
		resOrderSum, err := simpleSearchSum(param).Index(index).Do(context.Background())
		if err != nil {
			return data, err
		}

		// 注单数量
		betCount, _ := resOrderSum.Aggregations.ValueCount("bet_count")
		data.BetTotal.BetCount = int(*betCount.Value)
		// 注单金额
		betAmountTotal, _ := resOrderSum.Aggregations.Sum("bet_amount_total")
		data.BetTotal.BetAmountTotal = *betAmountTotal.Value
		// 派彩金额
		winAmountTotal, _ := resOrderSum.Aggregations.Sum("win_amount_total")
		data.BetTotal.WinAmountTotal = *winAmountTotal.Value
		// 理论奖金
		theoryPrizeTotal, _ := resOrderSum.Aggregations.Sum("theory_prize_total")
		data.BetTotal.TheoryPrizeTotal = *theoryPrizeTotal.Value
	}
	// 串注详情查询
	if len(compIDs) > 0 {

		//串注索引
		detailIndex := mt.Config.Elasticsearch.IndexPrefix + EsComplexIndexKeyWord
		resDetail, err := complexSearch(compIDs).Index(detailIndex).Do(context.Background())
		if err != nil {
			return data, err
		}
		if resDetail.Status == 0 && resDetail.Hits.TotalHits.Value > 0 {

			m := map[string][]OrderDetailData{}

			for _, vv := range resDetail.Hits.Hits {

				esComplex := EsComplex{}
				err := helper.JsonUnmarshal(vv.Source, &esComplex)
				if err != nil {
					return data, err
				}
				od := compileComplex(esComplex)
				m[od.OrderID] = append(m[od.OrderID], od)
			}
			data.Detail = m
		}
	}

	return data, nil
}

/**
 * @Description:
 * @Author: wesley
 * @Date: 2020/8/31 17:28
 * @LastEditTime: 2020/8/31 17:28
 * @LastEditors: wesley
 */
func simpleSearch(param EsOrderQueryParam) *elastic.SearchService {

	boolQuery := elastic.NewBoolQuery()
	terms := []elastic.Query{
		elastic.NewTermQuery("member_id", param.UID),
	}
	if param.MarketId > 0 {
		terms = append(terms, elastic.NewTermQuery("market_id", param.MarketId))
	}
	if param.OrderType != 0 {
		terms = append(terms, elastic.NewTermQuery("order_type", param.OrderType))
	}
	if param.MatchType != 0 {
		terms = append(terms, elastic.NewTermQuery("match_type", param.MatchType))
	}
	if param.Live != 0 {
		terms = append(terms, elastic.NewTermQuery("is_live", param.Live))
	}
	if param.Status > 0 { // 注单状态搜索
		terms = append(terms, elastic.NewTermQuery("settled", param.Settled))
	}

	offset := param.PageSize * (param.Page - 1)

	boolQuery.Must(terms...)
	boolQuery.Filter(elastic.NewRangeQuery("bet_time").Gte(param.BeginTime.UnixNano() / 1e6).Lte(param.EndTime.UnixNano() / 1e6))
	fsc := elastic.NewFetchSourceContext(true).Include(EsSimpleSearchFields...)

	//打印es查询json
	//src, _ := boolQuery.Source()
	//queryJson, _ := helper.MarshalToString(src)
	//fmt.Println(queryJson)

	return mt.Es.Search().FetchSourceContext(fsc).Query(boolQuery).From(offset).Size(param.PageSize).TrackTotalHits(true).Sort("bet_time", false)
}

func simpleSearchSum(param EsOrderQueryParam) *elastic.SearchService {

	boolQuery := elastic.NewBoolQuery()
	terms := []elastic.Query{
		elastic.NewTermQuery("member_id", param.UID),
	}
	if param.MarketId > 0 {
		terms = append(terms, elastic.NewTermQuery("market_id", param.MarketId))
	}
	if param.OrderType != 0 {
		terms = append(terms, elastic.NewTermQuery("order_type", param.OrderType))
	}
	if param.MatchType != 0 {
		terms = append(terms, elastic.NewTermQuery("match_type", param.MatchType))
	}
	if param.Live != 0 {
		terms = append(terms, elastic.NewTermQuery("is_live", param.Live))
	}
	if param.Status > 0 {
		terms = append(terms, elastic.NewTermQuery("settled", param.Settled))
	}

	boolQuery.Must(terms...)
	boolQuery.Filter(elastic.NewRangeQuery("bet_time").Gte(param.BeginTime.UnixNano() / 1e6).Lte(param.EndTime.UnixNano() / 1e6))
	fsc := elastic.NewFetchSourceContext(true).Include(EsSimpleSearchFields...)
	betCount := elastic.NewValueCountAggregation().Field("id")            // 注单数量
	betAmountTotal := elastic.NewSumAggregation().Field("bet_amount")     // 注单金额
	winAmountTotal := elastic.NewSumAggregation().Field("win_amount")     // 派彩金额
	theoryPrizeTotal := elastic.NewSumAggregation().Field("theory_prize") // 理论奖金
	//打印es查询json
	//src, _ := boolQuery.Source()
	//queryJson, _ := helper.MarshalToString(src)
	//fmt.Println(queryJson)
	return mt.Es.Search().FetchSourceContext(fsc).Query(boolQuery).
		Aggregation("bet_count", betCount).
		Aggregation("bet_amount_total", betAmountTotal).
		Aggregation("win_amount_total", winAmountTotal).
		Aggregation("theory_prize_total", theoryPrizeTotal)
}

/**
 * @Description:
 * @Author: wesley
 * @Date: 2020/8/31 17:28
 * @LastEditTime: 2020/8/31 17:28
 * @LastEditors: wesley
 */
func complexSearch(compIDs []interface{}) *elastic.SearchService {

	boolQuery := elastic.NewBoolQuery()
	boolQuery.Must(elastic.NewTermsQuery("order_id", compIDs...))
	fsc := elastic.NewFetchSourceContext(true).Include(EsComplexSearchFields...)

	//打印es查询json
	//src, _ := boolQuery.Source()
	//queryJson, _ := helper.MarshalToString(src)
	//fmt.Println(queryJson)

	return mt.Es.Search().Query(boolQuery).FetchSourceContext(fsc).From(0).Size(10000).TrackTotalHits(true)
}

/**
 * @Description:
 * @Author: wesley
 * @Date: 2020/9/1 17:35
 * @LastEditTime: 2020/9/1 17:35
 * @LastEditors: wesley
 */
func fundSearch(param EsFundQueryParam) *elastic.SearchService {

	boolQuery := elastic.NewBoolQuery()
	terms := []elastic.Query{
		elastic.NewTermsQuery("member_id", param.UID),
	}

	if param.Type != 0 {
		terms = append(terms, elastic.NewTermsQuery("trade_type", param.Type))
	}

	offset := param.PageSize * (param.Page - 1)

	boolQuery.Must(terms...)
	boolQuery.Filter(elastic.NewRangeQuery("created_time").Gte(param.BeginTime.UnixNano() / 1e6).Lte(param.EndTime.UnixNano() / 1e6))
	fsc := elastic.NewFetchSourceContext(true).Include(EsFundSearchFields...)

	//打印es查询json
	//src, _ := boolQuery.Source()
	//queryJson, _ := helper.MarshalToString(src)
	//fmt.Println(queryJson)

	return mt.Es.Search().FetchSourceContext(fsc).Query(boolQuery).From(offset).Size(param.PageSize).TrackTotalHits(true).Sort("created_time", false)
}

func compileSimple(data EsSimple) BetOrder {

	return BetOrder{
		BetAmount:      fmt.Sprintf("%.0f", data.BetAmount),
		BetIP:          data.BetIP,
		BetStatus:      data.BetStatus,
		BetTime:        fmt.Sprintf("%d", data.BetTime),
		ConfirmType:    data.ConfirmType,
		Device:         data.Device,
		GameID:         fmt.Sprintf("%d", data.GameID),
		ID:             fmt.Sprintf("%d", data.ID),
		IsLive:         data.IsLive,
		MarketEnName:   data.MarketEnName,
		MarketCnName:   data.MarketCnName,
		MarketID:       fmt.Sprintf("%d", data.MarketID),
		MatchID:        fmt.Sprintf("%d", data.MatchID),
		MatchStartTime: data.MatchStartTime,
		MatchType:      data.MatchType,
		Odd:            data.Odd,
		OddID:          fmt.Sprintf("%d", data.OddID),
		OddName:        data.OddName,
		OddEnName:      data.OddEnName,
		OrderType:      data.OrderType,
		ParleyType:     data.ParleyType,
		Round:          data.Round,
		SettleTime:     data.SettleTime,
		TeamNames:      data.TeamNames,
		TeamCnNames:    data.TeamCnNames,
		TeamEnNames:    data.TeamEnNames,
		TeamID:         data.TeamID,
		Tester:         data.Tester,
		TheoryPrize:    fmt.Sprintf("%.3f", data.TheoryPrize),
		TournamentID:   fmt.Sprintf("%d", data.TournamentID),
		WinAmount:      fmt.Sprintf("%.3f", data.WinAmount),
		Reason:         data.Reason,
		OddDiscount:    fmt.Sprintf("%0.2f", data.OddDiscount),
		ScoreBenchmark: data.ScoreBenchmark,
		OrgOddID:       fmt.Sprintf("%d", data.OrgOddID),
		BatchNo:        data.BatchNo,
		RoundNo:        data.RoundNo,
	}
}

func compileComplex(data EsComplex) OrderDetailData {

	return OrderDetailData{
		BetTime:        fmt.Sprintf("%d", data.BetTime),
		GameID:         fmt.Sprintf("%d", data.GameID),
		ID:             fmt.Sprintf("%d", data.ID),
		IsLive:         data.IsLive,
		MarketEnName:   data.MarketEnName,
		MarketCnName:   data.MarketCnName,
		MarketID:       fmt.Sprintf("%d", data.MarketID),
		MatchID:        fmt.Sprintf("%d", data.MatchID),
		MatchStartTime: data.MatchStartTime,
		MatchType:      data.MatchType,
		Odd:            data.Odd,
		OddID:          fmt.Sprintf("%d", data.OddID),
		OddName:        data.OddName,
		OddEnName:      data.OddEnName,
		OrderID:        fmt.Sprintf("%d", data.OrderID),
		Round:          data.Round,
		Status:         data.Status,
		TeamNames:      data.TeamNames,
		TeamCnNames:    data.TeamCnNames,
		TeamEnNames:    data.TeamEnNames,
		TournamentID:   fmt.Sprintf("%d", data.TournamentID),
		TeamID:         data.TeamID,
		SettleTime:     data.SettleTime,
		Reason:         data.Reason,
		OrgOddID:       fmt.Sprintf("%d", data.OrgOddID),
	}
}

/*
* @Description:创建es索引
* @Author: abraham
* @Date: 2021/5/11 13:41
* @LastEditTime: 2021/5/11 13:41
* @LastEditors: abraham
 */
func CreateIndex(cli *elastic.Client, index, body string) error {

	ctx := context.Background()
	//判断索引是否存在
	exists, err := cli.IndexExists(index).Do(ctx)
	if err != nil {
		return err
	}

	//索引不存在 新增索引
	if !exists {
		_, err := cli.CreateIndex(index).BodyString(body).Do(ctx)
		if err != nil {
			return err
		}
	}

	return nil
}

/*
* @Description:添加StatisticsInfo信息
* @Author: abraham
* @Date: 2021/6/3 11:45
* @LastEditTime: 2021/6/3 11:45
* @LastEditors: abraham
 */
func StatisticsInfoEsInsert(infos []StatisticsInfoEs) error {

	index := mt.Config.ZkElasticsearch.IndexPrefix + EsFrontStatisticsIndexKeyWord
	err := CreateIndex(mt.ZkEs, index, FrontStatisticsBody)
	if err != nil {
		return err
	}

	req := mt.ZkEs.Bulk().Index(index)
	for _, info := range infos {
		doc := elastic.NewBulkIndexRequest().Id(info.ID).Doc(info)
		req.Add(doc)
	}
	if req.NumberOfActions() <= 0 {
		return nil
	}

	_, err = req.Do(context.Background())

	return err
}

func GetIndex(prefix, indexStr string) string {
	index := prefix + indexStr
	return index
}

/**
 * @Description: 删除数据
 * @Author: Daxie
 * @Date: 2020/9/21 19:36
 * @LastEditTime: 2020/9/21 19:36
 * @LastEditors: Daxie
 */
func DeleteData(index, id string) error {

	ctx := context.Background()
	res, err := mt.Es.Delete().
		Index(index).
		Id(id).
		Refresh("wait_for").
		Do(ctx)

	if err != nil {
		return err
	}

	if res.Result == "deleted" {
		return errors.New("Document 1: deleted")
	}

	return nil
}

/**
 * @Description: 写入数据
 * @Author: Daxie
 * @Date: 2020/9/21 19:37
 * @LastEditTime: 2020/9/21 19:37
 * @LastEditors: Daxie
 */
func EsCreateData(cli *elastic.Client, index string, id string, data interface{}) error {

	ctx := context.Background()
	// 写入
	_, err := cli.Index().
		Index(index).
		Id(id).
		BodyJson(data).
		Refresh("wait_for"). //sync方式的写入
		Do(ctx)

	if err != nil {
		return err
	}

	return nil
}

/**
 * @Description: 更新数据
 * @Author: Daxie
 * @Date: 2020/9/21 21:02
 * @LastEditTime: 2020/9/21 21:02
 * @LastEditors: Daxie
 */
func EsUpdateData(cli *elastic.Client, index, id string, data interface{}) error {

	ctx := context.Background()
	// id存在 则修改 否则 新增
	_, err := cli.Update().
		Index(index).
		Id(id).
		Refresh("wait_for"). //sync方式的写入
		Doc(data).
		DocAsUpsert(true).
		Do(ctx)

	if err != nil {
		return err
	}

	return nil
}

/**
 * @Description: 索引id,查询数据
 * @Author: Daxie
 * @Date: 2020/9/21 19:27
 * @LastEditTime: 2020/9/21 19:27
 * @LastEditors: Daxie
 */
func EsGetSource(cli *elastic.Client, index, id string) (string, error) {
	ctx := context.Background()
	get1, err := cli.Get().
		Index(index).
		Id(id).
		Do(ctx)

	if err != nil {
		return "", err
	}

	return string(get1.Source), nil
}

/**
 * @Description: 删除索引
 * @Author: Daxie
 * @Date: 2020/9/21 19:27
 * @LastEditTime: 2020/9/21 19:27
 * @LastEditors: Daxie
 */
func EsDelIndex(index string) (bool, error) {

	ctx := context.Background()
	deleteIndex, err := mt.Es.DeleteIndex(index).Do(ctx)
	return deleteIndex.Acknowledged, err
}

/**
 * @Description: 写入数据
 * @Author: Daxie
 * @Date: 2020/9/21 19:37
 * @LastEditTime: 2020/9/21 19:37
 * @LastEditors: Daxie
 */
func UserVer(member fund.Member, deviceType int, version string) (string, error) {

	oldVerStr := `{"pc":"","h5":""}`
	esCli := mt.ZkEs

	// 创建索引
	index := GetIndex(mt.Config.ZkElasticsearch.IndexPrefix, EsIndexKeyWordUserVer)
	err := CreateIndex(esCli, index, APPUpdateESBody)
	if err != nil {
		return oldVerStr, err
	}

	var info EsUserVer
	info.UID = member.UID
	info.MerchantID = member.MerchantID

	esid := fmt.Sprintf("%d%d", member.MerchantID, member.UID)
	esSource, err := EsGetSource(esCli, index, esid)
	if err != nil || esSource == "" { //插入

		if deviceType == 1 { // 1=pc,2=h5
			info.Pc = version
			info.H5 = ""
		} else {
			info.Pc = ""
			info.H5 = version
		}

		err = EsCreateData(esCli, index, esid, info)

	} else { // 更新

		esUserVerData := EsUserVer{}
		err = helper.JsonUnmarshal([]byte(esSource), &esUserVerData)
		if err != nil {
			return oldVerStr, err
		}

		oldVerStr = fmt.Sprintf(`{"pc":"%s","h5":"%s"}`, esUserVerData.Pc, esUserVerData.H5)
		if deviceType == 1 { // 1=pc,2=h5
			info.Pc = version
			info.H5 = esUserVerData.H5
		} else {
			info.Pc = esUserVerData.Pc
			info.H5 = version
		}

		err = EsUpdateData(esCli, index, esid, info)
	}

	if err != nil {
		return oldVerStr, err
	}

	return oldVerStr, nil
}

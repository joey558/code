package model

import (
	"errors"
	"fmt"
	"game/helper"
	"game/lang"
	"game/utils"
	errs "github.com/pkg/errors"
	"github.com/scylladb/go-set"
	"github.com/scylladb/go-set/strset"
	"sort"
	"strconv"
	"strings"
	"time"

	"github.com/go-redis/redis/v7"
)

const (
	MatchStatusEntered    = 1 // 已录入
	MatchStatusPending    = 2 // 待审核
	MatchStatusReject     = 3 // 驳回
	MatchStatusWaitOpen   = 4 // 待开盘
	MatchStatusOpened     = 5 // 开盘
	MatchStatusClosed     = 6 // 关盘
	MatchStatusSettle     = 7 // 结算
	MatchStatusWaitCancel = 8 // 待取消
	MatchStatusCancel     = 9 // 取消
)

const (
	MatchFlagAll    = iota // 全部
	MatchFlagDaily         // 今日
	MatchFlagEarly         // 早盘
	MatchFlagLive          // 滚盘
	MatchPassOf            // 串关
	MatchFlagSettle        // 历史
	MatchFlagFilter        // 所有已开盘（筛选使用）
)

// 赛事计时器缓存, 在请求时全部返回，不能做读取操作。
var (
	timers = map[string]MatchTimer{}
)

// 赛事显示状态
const (
	MatchHide = 0 // 隐藏
	MatchShow = 1 // 显示
)

type MatchTimer struct {
	MatchID    string `name:"match_id" json:"match_id" rule:"digit" min:"1" msg:"match_id错误"`                      // 赛事ID
	TimeTicket int64  `name:"time_ticket" json:"time_ticket" rule:"digit" min:"0" max:"60000" msg:"time_ticket错误"` // 计时器秒数（最大值计时时间为999分钟59秒）
	StartTime  int64  `name:"start_time" json:"start_time" rule:"none"`                                            // 计时器开始时间（程序使用）
	Status     int    `name:"status" json:"status" rule:"digit" min:"0" max:"1"  msg:"status错误"`                   // 计时器状态（0=暂停, 1-计时）
	Round      string `name:"round" json:"round" rule:"none"`                                                      // 当前局数
}

type MatchAnchorList struct {
	MatchID   string             `json:"match_id"`   //赛事ID
	Round     int                `json:"round"`      //第几局
	StartTime int                `json:"start_time"` //开始时间
	Images    []MatchRoundImages `json:"images"`     //图标
}

type MatchRoundImages struct {
	ID       string `json:"id"`                 //主键id
	MatchID  string `json:"match_id"`           //赛事ID
	Round    int    `json:"round"`              //第几局
	Images   string `json:"images"`             //图片链接
	Remark   string `json:"remark"`             //图片描述
	SortCode int    `json:"sort_code"`          //图片排序码
	LCode    string `db:"l_code" json:"l_code"` //多语言code
}

type MatchRoundTime struct {
	ID        string `json:"id"`         //主键id
	MatchID   string `json:"match_id"`   //赛事ID
	Round     int    `json:"round"`      //第几局
	StartTime int    `json:"start_time"` //开始时间
}

type MatchTeams struct {
	TeamID     string `json:"team_id"`      //主键id
	TeamEnName string `json:"team_en_name"` //英文名称
	TeamCnName string `json:"team_cn_name"` //中文名称
	SortID     int    `json:"sort_id"`      //排序id
}

type SportsGameData struct {
	BatchNo  int               `json:"batch_no"`
	RoundNo  string            `json:"round_no"`
	GameData []utils.GameIndex `json:"game_data"`
}

type SportsGameMatchResultData struct {
	BatchNo   int                 `json:"batch_no"`
	RoundNo   string              `json:"round_no"`
	StartTime int64               `json:"start_time"`
	GameData  []SportsMatchSettle `json:"game_data"`
}

type SportsMatchSettle struct {
	ID        string `json:"id"`
	BatchNo   int    `json:"batch_no"`
	RoundNo   string `json:"round_no"`
	StartTime int64  `json:"start_time"`
	Score     string `json:"score"`
	TeamName  string `json:"team_name"`
	TeamId    string `json:"team_id"`
}

type SportsMatchResultData struct {
	ID         string `json:"id"`           //赛事id
	BatchNo    string `json:"batch_no"`     //批次号
	RoundNo    string `json:"round_no"`     //轮次
	Score      string `json:"score"`        //赛事比分
	TeamCnName string `json:"team_cn_name"` //战队-中文
	TeamEnName string `json:"team_en_name"` //战队-英文
	TeamID     string `json:"team_id"`      //战队ID
	StartTime  int64  `json:"start_time"`   //开始时间
}

type SportsMatchBatchNoData struct {
	BatchNo   string            `json:"batch_no"`
	RoundNo   string            `json:"round_no"`
	StartTime int64             `json:"start_time"`
	GameData  []utils.GameIndex `json:"game_data"`
}

// 盘口列表数据-虚拟体育
type VirtualMarketData struct {
	ID          string               `json:"id"`           // 盘口id
	MatchID     string               `json:"match_id"`     // 赛事id
	OddTypeID   string               `json:"odd_type_id"`  // 玩法类型ID
	Name        string               `json:"name"`         // 盘口名称(根据客户端语言匹配)
	Round       int                  `json:"round"`        // 第几局 0-全局 100-半场
	OptionType  int                  `json:"option_type"`  // 玩法类型 1-输赢 2-让分 3-大小 4趣味 5-波胆 6-胜负平 7-单双 8-是否 12-复合
	Suspended   int                  `json:"suspended"`    // 是否暂停  1-暂停 0-取消暂停
	Visible     int                  `json:"visible"`      // 是否显示  1-显示 0-隐藏
	Status      int                  `json:"status"`       // 已开盘-6 已关盘-7 待结算-8 已结算-9 已取消-12
	SortCode    int                  `json:"sort_code"`    // 排序码
	SettleTime  int64                `json:"settle_time"`  // 结算时间
	SettleCount int                  `json:"settle_count"` // 结算次数
	IsDefault   int                  `json:"is_default" `  // 是否首页展示默认盘口
	OptionTotal int                  `json:"option_total"` // 选项数量
	Odds        map[string]utils.Odd `json:"odds"`         // 投注项
	Reason      int                  `json:"reason"`       // 101-无赛果，102-赛果无法定义，103-赛制错误，104-盘口信息错误，105-平局退款，300-返还率缩减未生效
	Remark      string               `json:"remark"`       // 备注
}

//赛事历史比分-盘口详情信息
type MatchScorePlayTypeMarketData struct {
	HistoryScore            []string             `json:"history_score"`
	HomeWin                 int                  `json:"home_win"`
	AwayWin                 int                  `json:"away_win"`
	HomeStatus              []int                `json:"home_status"`
	AwayStatus              []int                `json:"away_status"`
	MatchPlayTypeMarketData []PlayTypeMarketData `json:"match_detail"`
	MatchData               utils.GameIndex      `json:"match_data"`
}

//玩法分类栏-盘口数据-虚拟体育
type PlayTypeMarketData struct {
	ID         string              `json:"id"`          // id
	Name       string              `json:"name"`        // name
	SortID     int                 `json:"sort_id"`     // sort_id
	MarketData []VirtualMarketData `json:"market_data"` // 盘口数据
}

//虚拟体育一般联赛积分总榜结构体
type MatchCommonScore struct {
	Draw                   int    `json:"draw"`                   //平的场次
	History                string `json:"history"`                //近期的赛果
	Lost                   int    `json:"lost"`                   //输的场次
	Points                 int    `json:"points"`                 //积分
	Ranking                int    `json:"ranking"`                //排名
	Tid                    string `json:"tid"`                    //联赛ID
	TotalCount             int    `json:"totalCount"`             //比赛场次
	VirtualTeamId          string `json:"virtualTeamId"`          //球队id
	VirtualTeamName        string `json:"virtualTeamName"`        //球队名称
	Win                    int    `json:"win"`                    //赢的场次
	WinDrawLostDescription string `json:"winDrawLostDescription"` //描述
}

//虚拟体育小组赛积分总榜结构体
type MatchGroupScore struct {
	GroupId      string `json:"groupId"` //小组标志
	DetailPOList []struct {
		Draw                   int    `json:"draw"`                   //平的场次
		GoalsConceded          int    `json:"goalsConceded"`          //失球数
		GoalsScored            int    `json:"goalsScored"`            //进球数
		GoalsWinning           int    `json:"goalsWinning"`           //净胜球数
		Lost                   int    `json:"lost"`                   //输的场次
		Points                 int    `json:"points"`                 //积分
		Ranking                int    `json:"ranking"`                //排名
		Tid                    string `json:"tid"`                    //联赛ID
		TotalCount             int    `json:"totalCount"`             //比赛场次
		VirtualTeamId          string `json:"virtualTeamId"`          //球队id
		VirtualTeamName        string `json:"virtualTeamName"`        //球队名称
		Win                    int    `json:"win"`                    //赢的场次
		WinDrawLostDescription string `json:"winDrawLostDescription"` //310描述
	} `json:"sVirtualSportXZTeamRankingDetailPOList"`
}

type MatchGroupDisuseScoreResp struct {
	Data     []MatchGroupScore `json:"group_data"`
	IsDisuse int               `json:"is_disuse"`
}

//虚拟体育淘汰赛积分总榜结构体
type MatchDisuseScore struct {
	AwayName     string `json:"awayName"`     //客队名称
	AwayNameCode string `json:"awayNameCode"` //客队名字编码
	AwayScore    string `json:"awayScore"`    //客队比分
	HomeName     string `json:"homeName"`     //主队名称
	HomeNameCode string `json:"homeNameCode"` //主队名字编码
	HomeScore    string `json:"homeScore"`    //主队比分
	IsSecond     string `json:"isSecond"`     //是否有第二回合：N 否 Y 是
	Phase        string `json:"phase"`        //阶段： GROUPS-小组赛 Q32 64强 Q16 32强 Q8 16强 Q4 8强 SEMIFINAL 半决赛 FINAL 决赛
	TournamentId string `json:"tournamentId"` //比赛场次
}

// 盘口类型
const (
	MarketStatusWaitInput      = 1  // 待录入
	MarketStatusInputFinished  = 2  // 已录入
	MarketStatusInputReject    = 3  // 录入驳回
	MarketStatusPending        = 4  // 待审核
	MarketStatusWaitOpen       = 5  // 待开盘
	MarketStatusOpen           = 6  // 已开盘
	MarketStatusClose          = 7  // 已关盘
	MarketStatusWaitSettle     = 8  // 待结算
	MarketStatusSettled        = 9  // 已结算
	MarketStatusResultRejected = 10 // 赛果驳回
	MarketStatusWaitCancel     = 11 // 待取消
	MarketStatusCancelled      = 12 // 已取消
)

func VideoGameIndexGet(gameIds string, flag, day int, pageSize int64, now time.Time) (interface{}, error) {

	data, err := utils.GameIndexGet(mt.ZKRedisCluster, gameIds, flag, day, pageSize, now, mt.Config.MerchantName)
	if err != nil {
		return nil, err
	}

	return data, nil
}

//内存赛事数据多语言国际化
func ramMatchI18n(idxMatches []utils.GameIndex, lan string) []utils.GameIndex {

	tournamentIds := strset.New()
	oddTypeIds := strset.New()
	for _, mch := range idxMatches {
		tournamentIds.Add(mch.TournamentID)
		if mch.DefaultMarket != nil {
			oddTypeIds.Add(mch.DefaultMarket.OddTypeID)
		}
	}

	mpTournamentName := MultiLanguageName(RamDataTournament, tournamentIds.List(), lan)
	mpOddTypeName := MultiLanguageName(RamDataOddType, oddTypeIds.List(), lan)
	for i, v := range idxMatches {
		//if lan == lang.CN || lan == "" {
		//	idxMatches[i].TournamentName = v.TournamentCnName
		//} else {
		//	idxMatches[i].TournamentName = mpTournamentName[v.TournamentID]
		//}
		idxMatches[i].TournamentName = mpTournamentName[v.TournamentID]

		if v.DefaultMarket == nil {
			continue
		}

		idxMatches[i].DefaultMarket.Name = mpOddTypeName[v.DefaultMarket.OddTypeID]
	}

	return idxMatches
}

/**
 * @Description: 获取用户前端index主页数据
 * @Author: maxic
 * @Date: 2020/8/15
 * @LastEditTime: 2020/8/15
 * @LastEditors: maxic
 **/
func GameIndexGet(gameIds string, flag, day int, pageSize int64, now time.Time, merchantID uint64, lan string) ([]utils.GameIndex, error) {

	var (
		idxMatches []utils.GameIndex
		err        error
	)

	filterGames := strset.New()
	if gameIds == "0" {
		filterGames, err = GetMerchantFilterGames(merchantID)
		if err != nil {
			return nil, nil
		}

		if filterGames.Size() == 0 {
			merchantID = 0
		}
		//gmIds, err = MerchantGameIDBuild(merchantID)
		//if err != nil {
		//	return nil, err
		//}
		//
		//if gmIds == "0" {
		//	merchantID = 0
		//} else {
		//	gameIds = gmIds
		//}
	} else {
		if len(strings.Split(gameIds, ",")) == 1 {
			filterGames, err = GetMerchantFilterGames(merchantID)
			if err != nil {
				return nil, err
			}

			if filterGames.Has(gameIds) {
				return nil, nil
			}
		}
		merchantID = 0
	}

	//首页全部游戏和热门游戏的滚球和早盘赛事从内存中获取
	//内存数据标识： 0-非内存数据 1-内存数据
	ramFlag := 0
	if flag == utils.NavFlagLive && day == 0 && pageSize == 20 {
		if _, ok := HotGames[gameIds]; ok || gameIds == "0" {
			ramFlag = 1
		}
	}

	//内存key
	cacheKey := fmt.Sprintf("live-%s", gameIds)
	if ramFlag == 1 {
		//热门游戏滚球赛事和全部游戏的所有类型赛事
		if flag == utils.NavFlagEarly { //早盘赛事
			if v, ok := mt.ramCacheData.EarlyMatch.Load(cacheKey); ok {
				return ramMatchI18n(v.([]utils.GameIndex), lan), nil
			}
		} else { //滚球赛事
			if v, ok := mt.ramCacheData.LiveMatch.Load(cacheKey); ok {
				return ramMatchI18n(v.([]utils.GameIndex), lan), nil
			}
		}

		fmt.Printf("[%s]Redis Query GameIndexGet! merch:%d|gameIds:%s|flag:%d|day:%d|pageSize:%d \n", mt.Config.MerchantName, merchantID, gameIds, flag, day, pageSize)
	}

	idxMatches, err = idxMatchDataLoad(filterGames, gameIds, flag, day, pageSize, now, lan)
	if err != nil {
		return nil, err
	}

	//滚球和早盘赛事加载到内存中
	if ramFlag == 1 && gameIds == "0" && filterGames.IsEmpty() {
		if _, ok := keyLock.Load(cacheKey); !ok {
			idxMatchRamLoad(flag, gameIds, idxMatches)

			idxCache := IdxCache{
				Key:         cacheKey,
				RefreshTime: 1 * time.Second,
			}

			_ = mt.idxCachePool.Invoke(idxCache)
		}
	}

	return idxMatches, nil
}

/*
 * @Description: 联赛-轮次格式化-虚拟体育
 * @Author: robin
 * @Date: 2022/4/14 13:03
 * @LastEditTime: 2022/4/14 13:03
 * @LastEditors: robin
 */
func SportsRoundNoFormat(strRoundNo, lan string, isCup int) string {

	var strReturnRoundNo string
	if strRoundNo == "FINAL" || strings.Contains(strRoundNo, "SEMIFINAL") || strings.Contains(strRoundNo, "Q") {
		strReturnRoundNo = strRoundNo
		return strReturnRoundNo
	}

	_, ok := LangSportsTourBatchNo[lan]
	if !ok {
		lan = lang.EN
	}

	if lan == lang.EN || lan == lang.VI {
		strReturnRoundNo = LangSportsTourBatchNo[lan] + strRoundNo
		return strReturnRoundNo
	}

	if isCup == 0 { //普通联赛
		strReturnRoundNo = LangSportsTourBatchNo[lan]
		strReturnRoundNo = strings.Replace(strReturnRoundNo, "X", strRoundNo, 1)
	} else { //杯赛
		if len(strRoundNo) == 3 {
			strReturnRoundNo = LangSportsTourBatchNo[lan]
			tempSlice := strings.Split(strRoundNo, "-")
			if len(tempSlice) == 2 {
				strRoundNo = strings.Replace(strReturnRoundNo, "X", tempSlice[0], 1)
				strReturnRoundNo = fmt.Sprintf("%s-%s", strRoundNo, tempSlice[1])
			}
		}
	}
	return strReturnRoundNo
}

/*
 * @Description: 获取虚拟体育-赛事列表
 * @Author: robin
 * @Date: 2022/4/2 14:09
 * @LastEditTime: 2022/4/2 14:09
 * @LastEditors: robin
 */
func SportsGameIndexGet(gameId, tourId, batchNo string, merchantID uint64, lan string, day int, page int64, matchType int) (interface{}, error) {

	var (
		idxMatches  []utils.GameIndex
		matchResult []SportsMatchResultData
		err         error
	)

	filterGames := strset.New()
	filterGames, err = GetMerchantFilterGames(merchantID)
	if err != nil {
		return nil, err
	}

	if filterGames.Has(gameId) {
		return nil, nil
	}

	tourCupData := mt.SportsGameDataMap[tourId]
	if matchType == SportsMatchEarly {
		if !CheckOpenMatch(gameId) {
			return nil, nil
		}
	}

	if matchType == SportsMatchResult {
		matchResult, err = SportsMatchResultDataLoad(gameId, tourId, lan, day, page)
		if err != nil {
			return nil, err
		}

		if len(matchResult) == 0 {
			return nil, nil
		}

		var gameAllSlice []SportsGameMatchResultData
		var gameSlice []SportsGameMatchResultData
		dataMap := map[int][]SportsMatchSettle{}
		for _, d := range matchResult {
			if len(d.BatchNo) == 0 {
				continue
			}

			intKey, err := strconv.Atoi(d.BatchNo)
			if err != nil {
				continue
			}

			var strMatchTeam string
			if lan == lang.CN || lan == lang.ZH {
				strMatchTeam = d.TeamCnName
			} else {
				strMatchTeam = d.TeamEnName
			}

			dataMap[intKey] = append(dataMap[intKey],
				SportsMatchSettle{ID: d.ID, BatchNo: intKey, RoundNo: d.RoundNo, StartTime: d.StartTime, Score: d.Score, TeamName: strMatchTeam, TeamId: d.TeamID})
		}

		for batchNo, data := range dataMap {
			gameData := SportsGameMatchResultData{
				BatchNo:   batchNo,
				RoundNo:   data[0].RoundNo,
				StartTime: data[0].StartTime,
				GameData:  data,
			}
			gameData.RoundNo = SportsRoundNoFormat(data[0].RoundNo, lan, tourCupData.IsCup)
			gameAllSlice = append(gameAllSlice, gameData)
		}

		sort.Slice(gameAllSlice, func(i, j int) bool {
			return gameAllSlice[j].BatchNo < gameAllSlice[i].BatchNo
		})

		for i, g := range gameAllSlice {
			if i > 20 {
				break
			}
			gameSlice = append(gameSlice, g)
		}

		return gameSlice, nil

	} else {
		idxMatches, err = SportsMatchDataLoad(filterGames, gameId, tourId, lan, day, page, matchType)
		if err != nil {
			return nil, err
		}

		if len(idxMatches) == 0 {
			return nil, nil
		}
	}

	if matchType == SportsMatchEarly {
		var gameAllSlice []SportsGameData
		var gameEarlySlice []SportsGameData
		dataMap := map[int][]utils.GameIndex{}
		for _, d := range idxMatches {
			if len(d.BatchNo) == 0 || d.IsOpenMatch == 0 {
				continue
			}

			intKey, err := strconv.Atoi(d.BatchNo)
			if err != nil {
				continue
			}
			d.RoundNo = SportsRoundNoFormat(d.RoundNo, lan, tourCupData.IsCup)
			dataMap[intKey] = append(dataMap[intKey], d)
		}

		for batchNo, data := range dataMap {
			gameData := SportsGameData{
				BatchNo:  batchNo,
				RoundNo:  data[0].RoundNo,
				GameData: data,
			}
			gameAllSlice = append(gameAllSlice, gameData)
		}

		sort.Slice(gameAllSlice, func(i, j int) bool {
			return gameAllSlice[j].BatchNo < gameAllSlice[i].BatchNo
		})

		for i, g := range gameAllSlice {
			if i > 4 {
				break
			}
			gameEarlySlice = append(gameEarlySlice, g)
		}

		sort.Slice(gameEarlySlice, func(i, j int) bool {
			return gameEarlySlice[j].BatchNo > gameEarlySlice[i].BatchNo
		})

		return gameEarlySlice, nil
	} else {
		var gameBatchNoData SportsMatchBatchNoData
		for _, d := range idxMatches {
			if len(d.BatchNo) == 0 || d.BatchNo != batchNo {
				continue
			}
			gameBatchNoData.BatchNo = batchNo
			gameBatchNoData.RoundNo = d.RoundNo
			gameBatchNoData.StartTime = d.StartTime
			gameBatchNoData.RoundNo = SportsRoundNoFormat(d.RoundNo, lan, tourCupData.IsCup)
			gameBatchNoData.GameData = append(gameBatchNoData.GameData, d)
		}
		return gameBatchNoData, nil
	}
}

/**
 * @Description: 加载首页赛事列表数据
 * @Author: awen
 * @Date: 2022-02-16 15:07
 * @LastEditTime: 2022-02-16 15:07
 * @LastEditors: awen
 **/
func idxMatchDataLoad(filterGames *strset.Set, gmIds string, flag int, day int, pageSize int64, now time.Time, lan string) ([]utils.GameIndex, error) {

	data, err := utils.GameIndexGet(mt.ZKRedisCluster, gmIds, flag, day, pageSize, now, mt.Config.MerchantName)
	if err != nil {
		return nil, err
	}

	return idxMatchFormat(filterGames, data, lan)
}

/*
 * @Description: 加载首页赛事列表数据
 * @Author: robin
 * @Date: 2022/4/3 17:27
 * @LastEditTime: 2022/4/3 17:27
 * @LastEditors: robin
 */
func SportsMatchDataLoad(filterGames *strset.Set, gameId, tourId string, lan string, day int, page int64, matchType int) ([]utils.GameIndex, error) {

	data, err := SportsGameIdxGet(mt.ZKRedisCluster, gameId, tourId, day, page, matchType)
	if err != nil {
		return nil, err
	}

	return SportsIdxMatchFormat(filterGames, data, lan) //虚拟体育赛事
}

/*
 * @Description: 赛果列表-虚拟体育
 * @Author: robin
 * @Date: 2022/4/18 13:09
 * @LastEditTime: 2022/4/18 13:09
 * @LastEditors: robin
 */
func SportsMatchResultDataLoad(gameId, tourId string, lan string, day int, page int64) ([]SportsMatchResultData, error) {

	begin := time.Now()
	matchKey := ""
	y, m, d := begin.Date()
	today := time.Date(y, m, d, 0, 0, 0, 0, begin.Location())
	tomorrow := today.AddDate(0, 0, 1)
	matchKey = fmt.Sprintf(utils.RedisGameSportsResultTourMatch, gameId, tourId)
	date := tomorrow.AddDate(0, 0, -day)
	if page < 2 {
		page = 1
	}

	zRangeBy := &redis.ZRangeBy{
		Min:    fmt.Sprintf("%d", date.AddDate(0, 0, -1).Unix()),
		Max:    fmt.Sprintf("%d", date.Unix()-1),
		Offset: (page - 1) * 200,
		Count:  200,
	}

	matchSlice, err := mt.ZKRedisCluster.ZRevRangeByScore(matchKey, zRangeBy).Result()
	if err != nil && errs.Cause(err) != redis.Nil {
		fmt.Printf("【赛果列表-虚拟体育】 SportsMatchResultDataLoad  游戏ID[%s] 联赛ID[%s]的赛事缓存 Redis Error:%s\n", gameId, tourId, err.Error())
		return nil, err
	}

	pipe := mt.ZKRedisCluster.Pipeline()
	defer pipe.Close()

	var (
		dataSlice []SportsMatchResultData
	)
	resultsMap := map[string]*redis.StringCmd{}
	for _, matchId := range matchSlice {
		resultsMap[matchId] = pipe.Get(fmt.Sprintf(utils.RedisSportsMatchResult, gameId, matchId))
	}

	_, err = pipe.Exec()
	if err != nil {
		if errs.Cause(err) != redis.Nil {
			fmt.Printf("【赛果列表-虚拟体育】SportsMatchResultDataLoad-Get, 获取缓存 pipe Exec Error[%s].\n", err.Error())
		}
		return nil, err
	}

	for matchId, item := range resultsMap {
		data, err := item.Result()
		if err != nil {
			if errs.Cause(err) != redis.Nil {
				fmt.Printf("【赛果列表-虚拟体育】SportsMatchResultDataLoad-Result, 获取赛事[%s]缓存 Error[%s].\n", matchId, err.Error())
			}
			continue
		}
		tmpData := SportsMatchResultData{}
		err = helper.JsonUnmarshal([]byte(data), &tmpData)
		if err != nil {
			fmt.Printf("【赛果列表-虚拟体育】SportsMatchResultDataLoad-JsonUnmarshal, 获取缓存 Result Error[%s].\n", err.Error())
			continue
		}

		dataSlice = append(dataSlice, tmpData)
	}

	return dataSlice, nil

}

/*
 * @Description: 获取缓存赛事
 * @Author: robin
 * @Date: 2022/4/3 17:31
 * @LastEditTime: 2022/4/3 17:31
 * @LastEditors: robin
 */
func SportsGameIdxGet(pool *redis.ClusterClient, gameId, tourId string, day int, page int64, matchType int) ([]interface{}, error) {

	begin := time.Now()
	defer func() {
		cost := time.Since(begin)
		if cost.Seconds() > 3 {
			fmt.Printf("GameId[%s][SportsGameIdxGet] slow query. cost time:%v\n", gameId, cost)
		}
	}()

	var matchKey string
	min, max := "-inf", "+inf"
	if matchType == SportsMatchEarly { // 早盘赛事
		matchKey = fmt.Sprintf(utils.RedisGameSportsEarlyTourMatch, gameId, tourId)
		min = fmt.Sprintf("%d", time.Now().Unix()-int64(60*2))
	} else if matchType == SportsMatchBatchNoResult { //已结束赛事 指定批次
		matchKey = fmt.Sprintf(utils.RedisGameSportsCloseTourMatch, gameId, tourId)
		min = fmt.Sprintf("%d", time.Now().Unix()-int64(60*10))
	}

	if page < 2 {
		page = 1
	}
	zRangeBy := &redis.ZRangeBy{ //设置赛事指定时间范围
		Min: min,
		Max: max,
	}

	matchSlice, err := pool.ZRangeByScore(matchKey, zRangeBy).Result()
	if err != nil && errs.Cause(err) != redis.Nil {
		fmt.Printf("GameId[%s][SportsGameIdxGet] 联赛ID缓存 Redis Error:%s\n", gameId, err.Error())
		return nil, err
	}

	pipe := pool.Pipeline()
	defer pipe.Close()

	var (
		redisCmd []*redis.Cmd
		data     []interface{}
	)
	for _, matchId := range matchSlice {
		key := fmt.Sprintf(utils.RedisGameIndex, matchId)
		redisCmd = append(redisCmd, pipe.Do("JSON.GET", key, "NOESCAPE", "."))
	}

	_, err = pipe.Exec()
	if err != nil && errs.Cause(err) != redis.Nil {
		fmt.Println("GameTourGet pipe.Exec err:", err)
		return nil, err
	}

	for _, cmd := range redisCmd {
		val, err := cmd.Result()
		if err != nil {
			fmt.Printf("GameId[%s][SportsGameIdxGet] 赛事缓存 Redis Error:%s, CMD:%s\n", gameId, err.Error(), cmd.Args())
			continue
		}

		if val != nil {
			data = append(data, val.(string))
		}
	}

	return data, nil
}

/**
 * @Description: 格式化赛事数据，并组装默认盘口
 * @Author: awen
 * @Date: 2022-02-16 19:21
 * @LastEditTime: 2022-02-16 19:21
 * @LastEditors: awen
 **/

func idxMatchFormat(filterGames *strset.Set, data []interface{}, lan string) ([]utils.GameIndex, error) {

	var (
		idxMatches []utils.GameIndex
		err        error
	)

	if len(data) == 0 {
		return nil, nil
	}

	tournamentIds := strset.New()
	oddTypeSet := strset.New()
	for _, iv := range data {
		idxMch := utils.GameIndex{}
		err = helper.JsonUnmarshalFromString(iv.(string), &idxMch)
		if err != nil {
			continue
		}

		if filterGames.Has(idxMch.GameID) {
			continue
		}

		//冠军盘赛事需求获取该赛事所有盘口
		if idxMch.Category == 2 {
			idxMch.ChampMarkets, err = ChampMarketList(lan, idxMch.ID, idxMch.MktIDs)
			if err != nil {
				return nil, err
			}
		}

		//国际化联赛名联赛ID
		tournamentIds.Add(idxMch.TournamentID)
		idxMatches = append(idxMatches, idxMch)

		if idxMch.DefaultMarket == nil {
			continue
		}

		if lan == lang.CN || lan == "" {
			idxMch.DefaultMarket.Name = idxMch.DefaultMarket.CnName
		}

		//玩法id集合
		if idxMch.DefaultMarket.OddTypeID != "" {
			oddTypeSet.Add(idxMch.DefaultMarket.OddTypeID)
		}
	}

	if tournamentIds.Size() == 0 && oddTypeSet.Size() == 0 {
		return idxMatches, nil
	}

	mpTournamentName := MultiLanguageName(RamDataTournament, tournamentIds.List(), lan)
	mpOddTypeName := MultiLanguageName(RamDataOddType, oddTypeSet.List(), lan)
	for i, v := range idxMatches {
		idxMatches[i].TournamentName = mpTournamentName[v.TournamentID]
		if v.DefaultMarket == nil {
			continue
		}

		mktName := mpOddTypeName[v.DefaultMarket.OddTypeID]
		if v.DefaultMarket.ScoreBenchmark != "" {
			mktName += fmt.Sprintf("(%s)", v.DefaultMarket.ScoreBenchmark)
		}
		idxMatches[i].DefaultMarket.Name = mktName

	}

	return idxMatches, nil
}

/*
 * @Description: 初始化赛事的联赛 玩法 盘口等多语言
 * @Author: robin
 * @Date: 2022/4/2 14:50
 * @LastEditTime: 2022/4/2 14:50
 * @LastEditors: robin
 */
func SportsIdxMatchFormat(filterGames *strset.Set, data []interface{}, lan string) ([]utils.GameIndex, error) {

	var (
		idxMatches []utils.GameIndex
		err        error
	)

	if len(data) == 0 {
		return nil, nil
	}

	tournamentIds := strset.New()
	oddTypeSet := strset.New()
	for _, iv := range data {
		idxMch := utils.GameIndex{}
		err = helper.JsonUnmarshalFromString(iv.(string), &idxMch)
		if err != nil {
			continue
		}

		if filterGames.Has(idxMch.GameID) {
			continue
		}

		if lan == lang.CN || lan == lang.ZH {
			idxMch.MatchTeam = idxMch.MatchCnTeam
		} else {
			idxMch.MatchTeam = idxMch.MatchEnTeam
		}

		//国际化联赛名联赛ID
		tournamentIds.Add(idxMch.TournamentID)
		idxMatches = append(idxMatches, idxMch)

		if idxMch.DefaultMarket == nil {
			continue
		}

		if lan == lang.CN {
			idxMch.DefaultMarket.Name = idxMch.DefaultMarket.CnName
		} else {
			idxMch.DefaultMarket.Name = idxMch.DefaultMarket.EnName
		}

		//玩法id集合
		if idxMch.DefaultMarket.OddTypeID != "" {
			oddTypeSet.Add(idxMch.DefaultMarket.OddTypeID)
		}
	}

	if tournamentIds.Size() == 0 && oddTypeSet.Size() == 0 {
		return idxMatches, nil
	}

	mpTournamentName := MultiLanguageName(RamDataVirtual, tournamentIds.List(), lan)
	mpOddTypeName := MultiLanguageName(RamDataVirtual, oddTypeSet.List(), lan)
	for i, v := range idxMatches {
		if len(mpTournamentName[v.TournamentID]) == 0 {
			continue
		}

		idxMatches[i].TournamentName = mpTournamentName[v.TournamentID]
		if v.DefaultMarket == nil || len(idxMatches[i].TournamentName) == 0 {
			continue
		}

		if len(mpOddTypeName[v.DefaultMarket.OddTypeID]) == 0 {
			continue
		}

		idxMatches[i].DefaultMarket.Name = mpOddTypeName[v.DefaultMarket.OddTypeID]
	}

	return idxMatches, nil
}

/**
 * @Description: 格式化赛事盘口详情盘口数据
 * @Author: awen
 * @Date: 2022-02-27 13:36
 * @LastEditTime: 2022-02-27 13:36
 * @LastEditors: awen
 **/
func viewMarketFormat(data []interface{}, lan string) ([]utils.Market, error) {

	//st := time.Now()
	var (
		viewMarkets []utils.Market
		err         error
	)

	oddTypeSet := strset.New()
	for _, iv := range data {
		mkt := utils.Market{}
		err = helper.JsonUnmarshalFromString(iv.(string), &mkt)
		if err != nil {
			continue
		}

		if lan == lang.CN || lan == "" {
			mkt.Name = mkt.CnName
		}

		viewMarkets = append(viewMarkets, mkt)

		//玩法id集合
		oddTypeSet.Add(mkt.OddTypeID)
	}

	if lan == lang.CN || oddTypeSet.Size() == 0 {
		return viewMarkets, nil
	}

	//获取玩法国际化名称
	mpOddTypeName := MultiLanguageName(RamDataOddType, oddTypeSet.List(), lan)
	//mixSubMarketId := map[int][]string{} //复合盘子盘口id（key为复合玩法在盘口中的下标，value为子盘口切片）
	//mixSubIds := strset.New()            //子盘口id集合
	for i, v := range viewMarkets {
		//复合玩法
		//if v.OptionType == OptionTypeMix {
		//	mixSubMarketId[i] = strings.Split(v.SubMktID, ",")
		//	mixSubIds.Add(mixSubMarketId[i]...)
		//	continue
		//}

		mktName := mpOddTypeName[v.OddTypeID]
		if v.ScoreBenchmark != "" {
			mktName += fmt.Sprintf("(%s)", v.ScoreBenchmark)
		}
		viewMarkets[i].Name = mktName
	}

	//处理复合玩法盘口名(所有子盘口名用+拼接)
	//if len(mixSubMarketId) > 0 && len(viewMarkets) > 0 {
	//	mpMixSubMarketName := map[string]string{}
	//	for _, m := range viewMarkets {
	//		if mixSubIds.Has(m.ID) {
	//			mpMixSubMarketName[m.ID] = m.Name
	//		}
	//	}
	//
	//	for i, subIds := range mixSubMarketId {
	//		subMarketName := ""
	//		for _, subId := range subIds {
	//			if len(mpMixSubMarketName[subId]) == 0 {
	//				continue
	//			}
	//
	//			if subMarketName != "" {
	//				subMarketName += "+"
	//			}
	//			subMarketName += mpMixSubMarketName[subId]
	//		}
	//		viewMarkets[i].Name = subMarketName
	//	}
	//
	//}

	//fmt.Println("viewMatchFormat cost:", time.Now().Sub(st).String())
	return viewMarkets, nil
}

/*
 * @Description:  格式化赛事盘口详情盘口数据-虚拟体育
 * @Author: robin
 * @Date: 2022/4/9 13:24
 * @LastEditTime: 2022/4/9 13:24
 * @LastEditors: robin
 */
func viewSportsMarketFormat(data []interface{}, lan string) ([]PlayTypeMarketData, error) {

	var (
		viewMarkets         []VirtualMarketData
		playTypeMarketSlice []PlayTypeMarketData
		SportsPlayTypeIds   []string
		err                 error
	)

	oddTypeSet := strset.New()
	for _, iv := range data {
		mkt := utils.Market{}
		err = helper.JsonUnmarshalFromString(iv.(string), &mkt)
		if err != nil {
			continue
		}

		tempMarket := VirtualMarketData{
			ID:          mkt.ID,
			MatchID:     mkt.MatchID,
			OddTypeID:   mkt.OddTypeID,
			Round:       mkt.Round,
			OptionType:  mkt.OptionType,
			Suspended:   mkt.Suspended,
			Visible:     mkt.Visible,
			Status:      mkt.Status,
			SortCode:    mkt.SortCode,
			SettleCount: mkt.SettleCount,
			IsDefault:   mkt.IsDefault,
			Odds:        mkt.Odds,
			Remark:      mkt.Remark,
		}

		if lan == lang.CN || lan == lang.ZH {
			tempMarket.Name = mkt.CnName
		} else {
			tempMarket.Name = mkt.EnName
			for key := range mkt.Odds {
				tempMarket.Odds[key] = utils.Odd{
					ID:        mkt.Odds[key].ID,
					MatchID:   mkt.Odds[key].MatchID,
					MarketID:  mkt.Odds[key].MarketID,
					Name:      mkt.Odds[key].EnName,
					EnName:    mkt.Odds[key].EnName,
					Odd:       mkt.Odds[key].Odd,
					IsWinner:  mkt.Odds[key].IsWinner,
					SortID:    mkt.Odds[key].SortID,
					Visible:   mkt.Odds[key].Visible,
					Suspended: mkt.Odds[key].Suspended,
					TeamID:    mkt.Odds[key].TeamID,
				}
			}
		}

		viewMarkets = append(viewMarkets, tempMarket)
		oddTypeSet.Add(mkt.OddTypeID)
	}

	if oddTypeSet.Size() == 0 {
		return playTypeMarketSlice, nil
	}

	//获取玩法国际化名称
	mpOddTypeName := MultiLanguageName(RamDataVirtual, oddTypeSet.List(), lan)
	for i, v := range viewMarkets {
		mktName := mpOddTypeName[v.OddTypeID]
		if len(mktName) == 0 {
			continue
		}
		viewMarkets[i].Name = mktName
	}

	for _, playType := range mt.SportsPlayTypeDataMap {
		SportsPlayTypeIds = append(SportsPlayTypeIds, playType.ID)
	}

	mpPlayTypeName := MultiLanguageName(RamDataVirtual, SportsPlayTypeIds, lan)
	playTypeMarketMap := map[string]PlayTypeMarketData{}
	for _, playTypeIds := range mt.SportsPlayTypeDataMap {
		for _, mkt := range viewMarkets {
			oddTypeSID := TYGetOddTypeSID(mkt.OddTypeID)
			if strings.Contains(playTypeIds.PlayID, oddTypeSID) {
				_, ok := playTypeMarketMap[playTypeIds.ID]
				if !ok {
					playTypeMarketMap[playTypeIds.ID] = PlayTypeMarketData{
						ID:         playTypeIds.ID,
						Name:       mpPlayTypeName[playTypeIds.ID],
						SortID:     playTypeIds.SortID,
						MarketData: []VirtualMarketData{mkt},
					}
				} else {
					playTypeMarketMap[playTypeIds.ID] = PlayTypeMarketData{
						ID:         playTypeIds.ID,
						Name:       mpPlayTypeName[playTypeIds.ID],
						SortID:     playTypeIds.SortID,
						MarketData: append(playTypeMarketMap[playTypeIds.ID].MarketData, mkt),
					}
				}
			}
		}
	}

	for _, playTypeMarket := range playTypeMarketMap {
		playTypeMarketSlice = append(playTypeMarketSlice, playTypeMarket)
	}

	sort.Slice(playTypeMarketSlice, func(i, j int) bool {
		return playTypeMarketSlice[j].SortID > playTypeMarketSlice[i].SortID
	})

	return playTypeMarketSlice, nil
}

// 根据商户id获取游戏id列表，所有游戏=0
func MerchantGameIDBuild(merchantID uint64) (string, error) {
	gameIds := "0"
	if merchantID > 0 {
		filterGames, err := GetMerchantFilterGames(merchantID)
		if err != nil {
			return "", err
		}

		if !filterGames.IsEmpty() {
			var ids []string
			for _, id := range mt.Config.GameIDs {
				if !filterGames.Has(id) {
					ids = append(ids, id)
				}
			}
			if len(ids) == 0 {
				return "", errors.New("")
			}
			gameIds = strings.Join(ids, ",")
		}
	}
	return gameIds, nil
}

/**
 * @Description: 获取用户前端view赛事详情数据
 * @Author: maxic
 * @Date: 2020/8/15
 * @LastEditTime: 2020/8/15
 * @LastEditors: maxic
 **/
func GameViewGet(matchId string, merchantID uint64, lan string) ([]utils.Market, error) {

	filterGames, err := GetMerchantFilterGames(merchantID)
	if err != nil {
		return nil, err
	}

	//if v, ok := mt.ramCacheData.HotMchMarket[matchId]; ok {
	//	return v, nil
	//}

	var (
		valStr     string
		mpMarketId map[string][]string
		mktIds     []string
	)

	if v, ok := mt.ramCacheData.LiveMarketIds.Load(matchId); ok {
		mpMarketId = v.(map[string][]string)
	} else {
		valStr, err = utils.MatchMarketIDGet(mt.ZKRedisCluster, matchId)
		if err != nil {
			return nil, err
		}

		err = helper.JsonUnmarshalFromString(valStr, &mpMarketId)
		if err != nil {
			return nil, err
		}
	}

	for _, mki := range mpMarketId {
		mktIds = append(mktIds, mki...)
	}

	data, err := utils.GameViewGet(mt.ZKRedisCluster, matchId, mktIds, filterGames)
	if err != nil {
		return nil, err
	}

	return viewMarketFormat(data, lan)
}

/**
 * @Description: 获取用户前端view赛事详情数据
 * @Author: maxic
 * @Date: 2020/8/15
 * @LastEditTime: 2020/8/15
 * @LastEditors: maxic
 **/
func SportsGameViewGet(matchId string, merchantID uint64, lan string) (MatchScorePlayTypeMarketData, error) {

	var (
		matchScorePlayTypeMarket MatchScorePlayTypeMarketData
		playTypeMarketData       []PlayTypeMarketData
	)

	filterGames, err := GetMerchantFilterGames(merchantID)
	if err != nil {
		return matchScorePlayTypeMarket, err
	}

	var (
		valStr     string
		mpMarketId map[string][]string
		mktIds     []string
	)

	matchData, err := SportsMatchIdsGet([]string{matchId}, merchantID, lan)
	if err != nil {
		return matchScorePlayTypeMarket, err
	}

	valStr, err = utils.MatchMarketIDGet(mt.ZKRedisCluster, matchId)
	if err != nil {
		return matchScorePlayTypeMarket, err
	}

	err = helper.JsonUnmarshalFromString(valStr, &mpMarketId)
	if err != nil {
		return matchScorePlayTypeMarket, err
	}

	for _, mki := range mpMarketId {
		mktIds = append(mktIds, mki...)
	}

	marketData, err := utils.GameViewGet(mt.ZKRedisCluster, matchId, mktIds, filterGames)
	if err != nil {
		return matchScorePlayTypeMarket, err
	}

	if len(marketData) == 0 {
		return matchScorePlayTypeMarket, err
	}

	playTypeMarketData, err = viewSportsMarketFormat(marketData, lan)
	if err != nil {
		return matchScorePlayTypeMarket, err
	}

	if len(playTypeMarketData) == 0 {
		return matchScorePlayTypeMarket, err
	}

	var (
		scoreArray []string
		homeWin    int
		awayWin    int
		homeStatus []int
		awayStatus []int
	)
	homeStatus = []int{0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
	awayStatus = []int{0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
	scoreArray = strings.Split(matchData[0].Score, ",")
	for i, score := range scoreArray {
		tempScore := strings.Split(score, ":")
		if len(tempScore) != 2 {
			continue
		}
		if tempScore[0] > tempScore[1] {
			homeStatus[i] = 1
			awayStatus[i] = -1
			homeWin = homeWin + 1
		} else if tempScore[0] == tempScore[1] {
			homeStatus[i] = 0
			awayStatus[i] = 0
		} else {
			homeStatus[i] = -1
			awayStatus[i] = 1
			awayWin = awayWin + 1
		}
	}
	homeWin = homeWin * 20
	awayWin = awayWin * 20

	tourCupData := mt.SportsGameDataMap[matchData[0].TournamentID]
	matchData[0].RoundNo = SportsRoundNoFormat(matchData[0].RoundNo, lan, tourCupData.IsCup)
	matchScorePlayTypeMarket = MatchScorePlayTypeMarketData{
		HistoryScore:            scoreArray,
		HomeWin:                 homeWin,
		AwayWin:                 awayWin,
		HomeStatus:              homeStatus,
		AwayStatus:              awayStatus,
		MatchPlayTypeMarketData: playTypeMarketData,
		MatchData:               matchData[0],
	}

	return matchScorePlayTypeMarket, nil
}

/**
 * @Description: 获取推荐赛事
 * @Author: awen
 * @Date: 2020/8/17
 * @LastEditTime: 2020/8/17
 * @LastEditors: awen
 **/
func RecommendMatchGet(merchantID uint64, lan string) ([]utils.GameIndex, error) {

	filterGames, err := GetMerchantFilterGames(merchantID)
	if err != nil {
		return nil, err
	}

	if filterGames.IsEmpty() {
		merchantID = 0
	}

	cacheKey := "recommend"
	if filterGames.IsEmpty() {
		if v, ok := mt.ramCacheData.Recommend.Load(cacheKey); ok {
			return ramMatchI18n(v.([]utils.GameIndex), lan), nil
		}
	}

	fmt.Printf("[%s]Redis Query RecommendMatchGet! merchantID:%d \n", mt.Config.MerchantName, merchantID)
	key := "mchRecommend"
	opt := redis.ZRangeBy{
		Min:    "1",
		Max:    "+inf",
		Offset: 0,
		Count:  20, // 默认最多取20个推荐赛事
	}

	mchIDs, err := mt.ZKRedisCluster.ZRangeByScore(key, &opt).Result()
	if err != nil {
		return nil, err
	}

	if len(mchIDs) == 0 {
		return nil, nil
	}

	data, err := utils.MatchIndexGet(mt.ZKRedisCluster, mchIDs, filterGames)
	if err != nil {
		return nil, err
	}

	recommendMatch, err := idxMatchFormat(filterGames, data, lan)
	if err != nil {
		return nil, err
	}

	//只有未禁用游戏商户的推荐赛事会放入内存中维护
	//if filterGames.IsEmpty() {
	//	if _, ok := keyLock.Load(cacheKey); !ok {
	//		keyLock.Store(cacheKey, 1)
	//		mt.ramCacheData.Recommend.Store(cacheKey, recommendMatch)
	//		idxCache := IdxCache{
	//			Key:         cacheKey,
	//			RefreshTime: 2 * time.Second,
	//		}
	//
	//		_ = mt.idxCachePool.Invoke(idxCache)
	//	}
	//}

	return recommendMatch, nil
}

func HandicapInfo(mpMarketID map[string]string) (utils.HandicapData, error) {

	return utils.HandicapInfo(mt.ZKRedisCluster, mpMarketID)
}

func MatchStatistics(merchantID uint64, gameIds []string, now time.Time) (utils.MatchCountStat, error) {

	data := utils.MatchCountStat{}
	filterGames, err := GetMerchantFilterGames(merchantID)
	if err != nil {
		return data, err
	}

	if filterGames.IsEmpty() {
		merchantID = 0
	}

	cacheKey := "stat"
	if len(gameIds) == 0 && merchantID == 0 {
		if v, ok := mt.ramCacheData.Stat.Load(cacheKey); ok {
			return v.(utils.MatchCountStat), nil
		}
		fmt.Printf("[%s]Redis Query MatchStatistics! merchantID:%d,gameIds:%v \n", mt.Config.MerchantName, merchantID, gameIds)
	}

	data, err = utils.GameNavMatchCountGet(mt.ZKRedisCluster, gameIds, filterGames, now)
	if err != nil {
		return data, err
	}

	if len(gameIds) == 0 && merchantID == 0 {
		if _, ok := keyLock.Load(cacheKey); !ok {
			keyLock.Store(cacheKey, 1)
			mt.ramCacheData.Stat.Store(cacheKey, data)
			idxCache := IdxCache{
				Key:         cacheKey,
				RefreshTime: 1 * time.Second,
			}
			_ = mt.idxCachePool.Invoke(idxCache)
		}
	}

	return data, nil
}

func MatchTimerGet(ts int64, matchIds []string) (map[string]MatchTimer, error) {

	data := map[string]MatchTimer{}
	fields := []string{"time_ticket", "status", "start_time", "round"}
	res := make(map[string]*redis.SliceCmd)
	pipe := mt.ZKRedisCluster.Pipeline()
	for _, matchId := range matchIds {
		key := fmt.Sprintf("mthTimer:%s", matchId)
		res[matchId] = pipe.HMGet(key, fields...)
	}
	_, err := pipe.Exec()
	_ = pipe.Close()
	if err != nil {
		return data, err
	}
	for k, timer := range res {
		var (
			startTime, timeTicket int64
			status                int
			round                 string
		)
		t, err := timer.Result()
		if err != nil {
			return data, err
		}
		if ticket, ok := t[0].(string); ok {
			timeTicket, _ = strconv.ParseInt(ticket, 10, 64)
		}
		if s, ok := t[1].(string); ok {
			status, _ = strconv.Atoi(s)
		}
		if st, ok := t[2].(string); ok {
			startTime, _ = strconv.ParseInt(st, 10, 64)
		}
		if r, ok := t[3].(string); ok {
			round = r
		}
		if status == 1 {
			// 计时中每次获取时重新计算TimeTicket时间
			timeTicket += ts - startTime
		}
		data[k] = MatchTimer{
			MatchID:    k,
			StartTime:  startTime,
			TimeTicket: timeTicket,
			Status:     status,
			Round:      round,
		}
	}
	return data, nil
}

/**
 * @Description:从内存中获取赛事计时器
 * @Author:Sven
 * @Date:2021/11/22 12:15
 * @LastEditTime: 2021/11/22 12:15
 * @LastEditors: Sven
 */
func MatchTimerRamGet() map[string]MatchTimer {

	return timers
}

/**
 * @Description: 赛事计时器 协程初始化
 * @Author:Sven
 * @Date:2021/11/22 13:11
 * @LastEditTime: 2021/11/22 13:11
 * @LastEditors: Sven
 */
func TimersInit() {
	err := LoadTimers()
	if err != nil {
		fmt.Println(" init timers err:", err.Error())
	}
	idxCache := IdxCache{
		Key:         "timer",
		RefreshTime: 3 * time.Second,
	}

	err = mt.idxCachePool.Invoke(idxCache)
	if err != nil {
		fmt.Println(" init timers err:", err.Error())
	}
}

/**
 * @Description: 从redis 加载赛事计时器, redis 加载 100个key 约30ms
 * @Author:Sven
 * @Date:2021/11/22 13:56
 * @LastEditTime: 2021/11/22 13:56
 * @LastEditors: Sven
 */
func LoadTimers() error {

	jt, err := mt.ZKRedisCluster.Do("JSON.GET", RedisMchTimerRejson).Text()
	if err != nil {
		return err
	}

	if jt == "" {
		fmt.Println("match timers no data")
		return nil
	}

	redisTimers := map[string]MatchTimer{}
	err = helper.JsonUnmarshalFromString(jt, &redisTimers)
	if err != nil {
		return err
	}

	//更新内存map指针
	timers = redisTimers
	return nil
}

func MatchIdsGet(mchIds []string, merchantID uint64, lan string) ([]utils.GameIndex, error) {

	filterGames, err := GetMerchantFilterGames(merchantID)
	if err != nil {
		return nil, err
	}

	data, err := utils.MatchIndexGet(mt.ZKRedisCluster, mchIds, filterGames)
	if err != nil {
		return nil, err
	}

	return idxMatchFormat(filterGames, data, lan)
}

func SportsMatchIdsGet(mchIds []string, merchantID uint64, lan string) ([]utils.GameIndex, error) {

	filterGames, err := GetMerchantFilterGames(merchantID)
	if err != nil {
		return nil, err
	}

	data, err := utils.MatchIndexGet(mt.ZKRedisCluster, mchIds, filterGames)
	if err != nil {
		return nil, err
	}

	return SportsIdxMatchFormat(filterGames, data, lan)
}

// 获取冠军赛事的盘口列表
func ChampMarketList(lan, matchId string, champMatchMarketIds map[string][]string) ([]utils.Market, error) {

	var (
		mktIds    []string
		marketVal []interface{}
		data      []utils.Market
		err       error
	)

	for _, v := range champMatchMarketIds {
		mktIds = append(mktIds, v...)
	}

	marketVal, err = utils.GameViewGet(mt.ZKRedisCluster, matchId, mktIds, strset.New())
	if err != nil {
		return nil, err
	}

	//格式化冠军盘赛事盘口
	data, err = viewMarketFormat(marketVal, lan)
	if err != nil {
		return nil, err
	}

	return data, err
}

// 获取赛事风险标签ID
func MatchRiskTagIdGet(matchId string) (string, error) {

	return utils.MatchRiskTagIdGet(mt.ZKRedisCluster, matchId)
}

// 获取主播盘小局开始时间和游戏截图
func MatchAnchorInfoGet(mchIds []string, lang string) (map[string][]MatchAnchorList, error) {

	data := map[string][]MatchAnchorList{}
	res := make(map[string][]*redis.SliceCmd)
	pipe := mt.ZKRedisCluster.Pipeline()
	lCodeSet := set.NewStringSet()
	for _, mchID := range mchIds {
		list := []*redis.SliceCmd{}

		list = append(list, pipe.MGet(fmt.Sprintf(RedisMatchRoundTime, mchID)))
		for i := 1; i <= 11; i++ { // 小局截图
			list = append(list, pipe.MGet(fmt.Sprintf(RedisMatchRoundImg, mchID, i)))
		}

		res[mchID] = list
	}
	_, err := pipe.Exec()
	_ = pipe.Close()
	if err != nil && err != redis.Nil {
		return data, err
	}

	for mchID, item := range res {
		var (
			list       []MatchAnchorList
			roundTimer []MatchRoundTime
		)

		for i, t := range item {
			result, err := t.Result()
			if err != nil {
				continue
			}

			if i == 0 { // 效验小局开始时间是否存在，
				if res, ok := result[0].(string); ok {
					err = helper.JsonUnmarshal([]byte(res), &roundTimer)
					if err != nil {
						return data, err
					}
				}
			} else {
				// 小局图片
				info := MatchAnchorList{
					MatchID: mchID,
					Round:   i,
				}

				for _, item := range roundTimer {
					if item.Round == i {
						info.StartTime = item.StartTime
						break
					}
				}

				info.Images = []MatchRoundImages{}
				if res, ok := result[0].(string); ok {
					err = helper.JsonUnmarshal([]byte(res), &info.Images)
					if err != nil {
						return data, err
					}
				}

				for _, image := range info.Images {
					lCodeSet.Add(image.LCode)
				}

				list = append(list, info)
			}
		}

		data[mchID] = list
	}

	value, err := RedisPipelineHMGet(lCodeSet.List(), lang, RedisKeyLang)
	if err != nil {
		return data, err
	}

	for id, da := range data {
		for i, d := range da {
			for l, image := range d.Images {
				if _, ok := value[fmt.Sprintf("%s", image.LCode)]; ok {
					data[id][i].Images[l].Remark = value[image.LCode]
				}
			}
		}
	}

	return data, nil
}

// 获取冠军盘战队
func MatchChampTeamGet(mchIds []string) (map[string][]MatchTeams, error) {

	data := map[string][]MatchTeams{}
	res := make(map[string]*redis.StringSliceCmd)
	pipe := mt.ZKRedisCluster.Pipeline()
	for _, mchID := range mchIds {
		key := fmt.Sprintf(RedisMatchChampTeam, mchID)
		res[mchID] = pipe.SMembers(key)
	}
	_, err := pipe.Exec()
	_ = pipe.Close()
	if err != nil && err != redis.Nil {
		return data, err
	}

	for matchID, item := range res {

		var list []MatchTeams
		result, err := item.Result()
		if err != nil {
			return data, err
		}

		for _, t := range result {
			team := MatchTeams{}
			err = helper.JsonUnmarshal([]byte(t), &team)
			if err != nil {
				return data, err
			}
			list = append(list, team)
		}

		// 排序
		sort.Slice(list, func(i, j int) bool {
			return list[j].SortID > list[i].SortID
		})

		data[matchID] = list
	}

	return data, nil
}

/*
* @Description: ob旗舰-热门推荐
* @Author: jinxi
* @Date: 2021/8/13 17:07
* @LastEditTime: 2021/8/13 17:07
* @LastEditors: jinxi
 */
func ObRecommendMatchGet(ctxTime time.Time) ([]utils.GameIndex, error) {

	recommendMatches, err := RecommendMatchGet(0, lang.CN)
	if err != nil {
		return nil, err
	}

	//先从推荐赛事中获取6条赛事
	if len(recommendMatches) > 6 {
		return recommendMatches[0:6], nil
	}

	//推荐赛事不足6条时，再从滚球赛事中取20条进行追加补充
	liveMatches, err := GameIndexGet("0", 3, 0, 20, ctxTime, 0, lang.CN)
	if err != nil {
		return nil, err
	}

	if len(liveMatches) == 0 {
		return recommendMatches, nil
	}

	mpExistMch := map[string]int{}
	for _, recMch := range recommendMatches {
		mpExistMch[recMch.ID] = 1
	}

	for _, liveMch := range liveMatches {
		if mpExistMch[liveMch.ID] == 1 {
			continue
		}

		recommendMatches = append(recommendMatches, liveMch)

		if len(recommendMatches) == 6 {
			break
		}
	}

	return recommendMatches, nil
}

/*
* @Description: 获取有效赛事
* @Author: jinxi
* @Date: 2021/8/14 20:21
* @LastEditTime: 2021/8/14 20:21
* @LastEditors: jinxi
 */
func AvailableMatchGet(key string, opt *redis.ZRangeBy, rec bool) ([]interface{}, []string, map[string]string, error) {

	var avlMatch []interface{}
	var cmds []*redis.Cmd
	mpMatch := map[string]string{}
	pipe := mt.ZKRedisCluster.Pipeline()
	defer pipe.Close()

	//赛事id
	mchIDs, err := mt.ZKRedisCluster.ZRangeByScore(key, opt).Result()
	if err != nil {
		return avlMatch, mchIDs, mpMatch, err
	}

	for _, v := range mchIDs {
		key := fmt.Sprintf(utils.RedisGameIndex, v)
		cmds = append(cmds, pipe.Do("JSON.GET", key, "NOESCAPE", "."))
	}

	_, err = pipe.Exec()
	if err != nil && err != redis.Nil {
		return avlMatch, mchIDs, mpMatch, err
	}

	for _, cmd := range cmds {

		val, err := cmd.Result()
		if err != nil {
			continue
		}

		if val != nil {
			match := utils.GameIndex{}
			err = helper.JsonUnmarshal([]byte(val.(string)), &match)
			if err != nil {
				return avlMatch, mchIDs, mpMatch, err
			}

			//赛事为显示状态并且开盘状态
			if match.Visible == MatchShow && match.Status == MatchStatusOpened {
				if rec { //如果为推荐赛事
					avlMatch = append(avlMatch, val)
				} else if !rec && match.Rec == 0 { //如果为滚球赛事
					avlMatch = append(avlMatch, val)
					mpMatch[match.ID] = val.(string)
				}
			}
		}
	}

	return avlMatch, mchIDs, mpMatch, err
}

/*
 * @Description: 查找风险会员的标签ID
 * @Author: robin
 * @Date: 2021/11/5 18:47
 * @LastEditTime: 2021/11/5 18:47
 * @LastEditors: robin
 */
func GetRiskMemberTagId(memberId uint64) (string, error) {

	riskTagIds, err := mt.ZKRedisCluster.HGet("riskMember", fmt.Sprintf("%d", memberId)).Result()
	if err != nil && err != redis.Nil {
		return "", errors.New("Redis HGet risk member tag id error ")
	}
	return riskTagIds, nil
}

/*
* @Description: 一般联赛积分榜
* @Author: jinxi
* @Date: 2022/3/25 12:53
* @LastEditTime: 2022/3/25 12:53
* @LastEditors: jinxi
 */
func GetCommonScore(sid, lan string) ([]MatchCommonScore, error) {

	var data []MatchCommonScore
	key := fmt.Sprintf(RedisCommonScore, sid)
	bytes, err := mt.ZKRedisCluster.Get(key).Bytes()
	if err != nil {
		if err != redis.Nil {
			return data, err
		}
	}

	if lan == lang.CN || lan == lang.ZH {
		lan = lang.CN
	} else {
		lan = lang.EN
	}

	if bytes != nil {
		err = helper.JsonUnmarshal(bytes, &data)
		if err != nil {
			return data, err
		}

		var ids []string
		for _, match := range data {
			ids = append(ids, match.VirtualTeamName)
		}
		teamNames := MultiLanguageName(RamDataVirtual, ids, lan)

		for i, match := range data {
			data[i].VirtualTeamName = teamNames[match.VirtualTeamName]
		}
	}

	return data, err
}

/*
* @Description: 小组赛积分榜
* @Author: jinxi
* @Date: 2022/3/25 13:48
* @LastEditTime: 2022/3/25 13:48
* @LastEditors: jinxi
 */
func GetGroupScore(sid, lan string) (MatchGroupDisuseScoreResp, error) {

	var data MatchGroupDisuseScoreResp
	key := fmt.Sprintf(RedisGroupScore, sid)
	bytes, err := mt.ZKRedisCluster.Get(key).Bytes()
	if err != nil {
		if err != redis.Nil {
			return data, err
		}
	}

	if lan == lang.CN || lan == lang.ZH {
		lan = lang.CN
	} else {
		lan = lang.EN
	}

	if bytes != nil {
		err = helper.JsonUnmarshal(bytes, &data)
		if err != nil {
			return data, err
		}

		var ids []string
		for _, match := range data.Data {
			for _, v := range match.DetailPOList {
				ids = append(ids, v.VirtualTeamName)
			}
		}
		teamNames := MultiLanguageName(RamDataVirtual, ids, lan)

		for i, match := range data.Data {
			for k, v := range match.DetailPOList {
				data.Data[i].DetailPOList[k].VirtualTeamName = teamNames[v.VirtualTeamName]
			}
		}
	}

	return data, err
}

/*
* @Description: 淘汰赛积分榜
* @Author: jinxi
* @Date: 2022/3/25 13:56
* @LastEditTime: 2022/3/25 13:56
* @LastEditors: jinxi
 */
func GetDisuseScore(sid, lan string) (map[string][]MatchDisuseScore, error) {

	var data map[string][]MatchDisuseScore
	key := fmt.Sprintf(RedisDisuseScore, sid)
	bytes, err := mt.ZKRedisCluster.Get(key).Bytes()
	if err != nil {
		if err != redis.Nil {
			return data, err
		}
	}

	if lan == lang.CN || lan == lang.ZH {
		lan = lang.CN
	} else {
		lan = lang.EN
	}

	if bytes != nil {
		err = helper.JsonUnmarshal(bytes, &data)
		if err != nil {
			return data, err
		}

		var ids []string
		for _, match := range data {
			for _, v := range match {
				ids = append(ids, v.AwayNameCode, v.HomeNameCode)
			}
		}
		teamNames := MultiLanguageName(RamDataVirtual, ids, lan)

		for i, match := range data {
			for k, v := range match {
				data[i][k].HomeName = teamNames[v.HomeNameCode]
				data[i][k].AwayName = teamNames[v.AwayNameCode]
			}
		}
	}

	return data, err
}

package model

import (
	"errors"
	"fmt"
	"game/helper"
	"game/lang"
	"log"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/shopspring/decimal"

	"github.com/panjf2000/ants/v2"
)

var (
	tyMemberMap        sync.Map           // 体育用户缓存
	oddTypeIDMap       map[string]string  // 电竞 体育玩法ID对应表
	tyBetPool          *ants.PoolWithFunc // 体育投注协程池
	tyGetBetDetailPool *ants.PoolWithFunc // 体育获取单条注单信息协程池

	CheckScoreBenchmarkMap = map[string]bool{ // 需要检查基准分的玩法IDMap
		"14650626566501040":  true, // 全场让球
		"47957485339937812":  true, // 半场让球
		"123445693265569240": true, // 剩余时间获胜
		"53758685711873936":  true, // 上半场剩余时间获胜
	}
)

const (
	tySuccess         = "0000000" // 请示成功
	tyApiSuccess      = "0000"    // 请示成功
	tyNeedUserLogin   = "0401002" // 请先登录
	tyUserLoginExpire = "0401013" // 账户信息已过期，请重新登录

	redisTYMember   = "tyMember:%d"     // 体育用户 tyMember:电竞用户id
	RedisMTSBetLock = "tyMTSBetLock:%d" // MTS注单锁，直到确认注成，最多锁16秒，%d为电竞的UID

	tradeStreamFlagRiskOrderReject = "4" // 4盘口风险注单拒绝
)

const (
	// 投注接口(bet)返回的状态
	tyBetStatusFailed      = 0 // 投注失败
	tyBetStatusSuccess     = 1 // 投注成功
	tyBetStatusWaitConfirm = 2 // 等确认

	/////////////////////////////////////////////////////////////////

	// 注单确认查询接口(queryOrderStatus)返回的状态
	tyQueryOrderStatusConfirmed   = 0 // 已确认
	tyQueryOrderStatusSolved      = 1 // 已处理
	tyQueryOrderStatusRefuse      = 2 // 拒绝
	tyQueryOrderStatusWaitConfirm = 3 // 待确认
	tyQueryOrderStatusFailed      = 4 // 失败

	/////////////////////////////////////////////////////////////////

	// 拉单接口(queryBetList)返回的状态
	tyQueryBetListStatusPending     = 0 // 待处理
	tyQueryBetListStatusSettled     = 1 // 已结算
	tyQueryBetListStatusCancelled   = 2 // 取消(人工)
	tyQueryBetListStatusWaitConfirm = 3 // 待确认
	tyQueryBetListStatusRefuse      = 4 // 风控拒单
	tyQueryBetListStatusUndo        = 5 // 撤单(赛事取消)

)

const (
	// 自定义的状态
	tyBetSuccess         = 1 // 投注成功
	tyBetFailed          = 2 // 投注失败，不能重试
	tyBetFailedCanRe     = 3 // 投注失败，可以重试
	tyBetFailedNeedLogin = 4 // 投注失败，需要重新登录
)

// 体育API配置项
type tyAPIConf struct {
	MerchantCode             string `json:"merchant_code"`                // 商户代号
	SecretKey                string `json:"secret_key"`                   // 加密key
	LoginUrl                 string `json:"login_url"`                    // 登录地址
	BetUrl                   string `json:"bet_url"`                      // 投注地址
	LimitUrl                 string `json:"limit_url"`                    // 限红地址
	QueryOrderStatusUrl      string `json:"query_order_status_url"`       // 注单确认查询地址
	QueryLatestMarketInfoUrl string `json:"query_latest_market_info_url"` // 获取盘口信息地址
}

/*
* @Description: 启动体育协程池
* @Author: xp
* @Date: 2021/12/19 10:00
* @LastEditTime:  2021/12/19 10:00
* @LastEditors: xp
 */
func startTYPool() {

	// 初始化玩法对应表
	tyInitOddTypeSIDMap()

	// 启动投注协程池
	tyBetPool, _ = ants.NewPoolWithFunc(500, func(payload interface{}) {
		if m, ok := payload.(BetOrder); ok {
			// 投注
			err := tyBetProcess(m)
			if err != nil {
				fmt.Printf("doTYBetProcess,err = %s\n", err)
			}
		}
	})

	// 启动获取单条注单信息协程池
	tyGetBetDetailPool, _ = ants.NewPoolWithFunc(500, func(payload interface{}) {
		if m, ok := payload.(BetOrder); ok {
			//  获取单条注单信息，确认
			err := tyQueryOrderStatusProcess(m)
			if err != nil {
				fmt.Printf("tyQueryOrderStatusProcess,err = %s\n", err)
			}
		}
	})
}

/*
* @Description: 投送注单确认任务
* @Author: xp
* @Date: 2021/12/19 10:00
* @LastEditTime:  2021/12/19 10:00
* @LastEditors: xp
 */
func orderConfirm(order BetOrder) error {

	od := OrderDelay{
		MatchID:        order.MatchID,
		MarketID:       order.MarketID,
		OddId:          order.OddID,
		BetAmount:      order.BetAmount,
		TheoryPrize:    order.TheoryPrize,
		Odd:            order.Odd,
		ExchangeRate:   order.ExchangeRate,
		HideAmountRate: order.HideAmountRate,
		TYOrderID:      order.TYOrderID,
		TYNewOdd:       order.TYNewOdd,
	}

	orderID, err := strconv.ParseUint(order.ID, 10, 64)
	if err != nil {
		return err
	}

	return PutDelayQueue(0, order.MemberID, orderID, od, order.Tester, order.RiskTagID)
}

/*
* @Description: 投送拒绝注单任务
* @Author: xp
* @Date: 2022/01/26 15:42
* @LastEditTime:  2022/01/26 15:42
* @LastEditors: xp
 */
func orderRefuse(order BetOrder) error {

	if order.ID == "" || order.TYMatchSID == "" {
		return nil
	}

	return BeansTaskOrderRefuse(order.MatchID, order.MarketID, "", tradeStreamFlagRiskOrderReject, order.ID, order.TYMatchSID)
}

/*
* @Description: 初始化体育玩法对应表
* @Author: xp
* @Date: 2021/12/19 10:00
* @LastEditTime:  2021/12/19 10:00
* @LastEditors: xp
 */
func tyInitOddTypeSIDMap() {

	strJson, err := mt.ZKRedisCluster.Do("JSON.GET", "oddTypeSIDMap").Text()
	if err != nil {
		log.Fatalln(err)
	}

	err = helper.JsonUnmarshal([]byte(strJson), &oddTypeIDMap)
	if err != nil {
		log.Fatalln(err)
	}
}

/*
* @Description: 获取体育用户token, 如果获取不到，会调用登录接口
* @Author: xp
* @Date: 2021/12/19 10:00
* @LastEditTime:  2021/12/19 10:00
* @LastEditors: xp
 */
func tyGetToken(userID uint64, userName string) (tyMemberInfo, error) {

	tyMember := tyMemberInfo{}

	// 先从内存里读取
	if v, ok := tyMemberMap.Load(userID); ok {
		tyMember = v.(tyMemberInfo)
		// 如果内存缓存超过5分钟，或者内存的token为空，则删除内存缓存，再从redis读取
		if time.Now().Unix()-tyMember.LastReadTime > 300 || len(tyMember.TYToken) == 0 {
			tyMemberMap.Delete(userID)
		}

		return tyMember, nil
	}

	redisKey := fmt.Sprintf(redisTYMember, userID)

	// 如果redis里有体育的token,则不需要登录，否则登录后获取token
	vals, err := mt.MerchantRedis.HMGet(redisKey, "dj_user_name", "ty_user_id", "ty_token").Result()
	if err == nil && len(vals) >= 3 && vals[0] != nil && vals[1] != nil && vals[2] != nil {
		tyMember.DJUserName = vals[0].(string)
		tyMember.TYUserID = vals[1].(string)
		tyMember.TYToken = vals[2].(string)
		tyMember.LastReadTime = time.Now().Unix()

		return tyMember, nil
	}

	return tyHttpUserLogin(userID, userName)
}

/*
* @Description: 删除体育的用户token
* @Author: xp
* @Date: 2021/12/19 10:00
* @LastEditTime:  2021/12/19 10:00
* @LastEditors: xp
 */
func tyRemoveToken(userID uint64) {

	redisKey := fmt.Sprintf(redisTYMember, userID)
	mt.MerchantRedis.Unlink(redisKey)
}

/*
* @Description: 处理投注结果
* @Author: xp
* @Date: 2021/12/19 10:00
* @LastEditTime:  2021/12/19 10:00
* @LastEditors: xp
 */
func tyDoBetResult(status int, order BetOrder) error {

	switch status {
	case tyBetSuccess: // 投注成功，已确认注单，并删除任务
		return orderConfirm(order)

	case tyBetFailed: // 投注失败，撤消注单，并删除任务
		return orderRefuse(order)

	case tyBetFailedCanRe, tyBetFailedNeedLogin: // 投注失败，其他原因，但可以重试，超过3次就删除任务
		if status == tyBetFailedNeedLogin {
			tyRemoveToken(order.MemberID)
		}
	}

	return nil
}

/*
* @Description: 处理投注
* @Author: xp
* @Date: 2021/12/19 10:00
* @LastEditTime:  2021/12/19 10:00
* @LastEditors: xp
 */
func tyBetProcess(order BetOrder) error {

	// 获取体育token,如果不存在，会先登录
	tyMember, err := tyGetToken(order.MemberID, order.MemberAccount)
	if err != nil {
		fmt.Println(err)
		// 用户登录失败，保留任务，下次执行
		return tyDoBetResult(tyBetFailedNeedLogin, order)
	}

	order.TYToken = tyMember.TYToken
	tyBetResp, err := tyHttpBet(order)
	if err != nil {
		fmt.Println(err)
		// http请求失败,直接撤单并删除任务
		return tyDoBetResult(tyBetFailed, order)
	}

	// 判断是否返回token失效的错误码，如果是，则删除tyToken的缓存
	// 401002:请先登录  401013:账户信息已过期，请重新登录
	if tyBetResp.Code == tyNeedUserLogin || tyBetResp.Code == tyUserLoginExpire {
		// 投注失败,直接撤单并删除任务
		return tyDoBetResult(tyBetFailedNeedLogin, order)
	}

	if tyBetResp.Code != tySuccess {
		fmt.Printf("bet 接口请求失败[%v]. ErrCode:[%v]\n", tyBetResp.Msg, tyBetResp.Code)
		// 投注失败,直接撤单并删除任务
		return tyDoBetResult(tyBetFailed, order)
	}

	// 处理注单状态
	if len(tyBetResp.Data.TYOrderDetail) == 0 {
		fmt.Println("bet 接口请求失败. tyBetResp.Data.TYOrderDetail == 0")
		// 返回的数据有误,直接撤单并删除任务
		return tyDoBetResult(tyBetFailed, order)
	}

	orderStatus := tyBetResp.Data.TYOrderDetail[0].OrderStatusCode

	// 锁住投注，直到确认成功，最多16秒会自动解锁
	if tyBetResp.Data.Lock == 1 && orderStatus == tyBetStatusWaitConfirm {
		redisKey := fmt.Sprintf(RedisMTSBetLock, order.MemberID)
		_ = mt.MerchantRedis.Set(redisKey, 1, 16*time.Second)
		fmt.Println("写入redis：", redisKey)
	}

	// 处理注单状态
	// 0:待处理, 相当于投注成功, 电竞发送确认注单消息
	// 1:已处理, 结算之后才会更新到这个值,bet接口不需要处理
	// 2:取消交易, 4:已拒绝, 5:撤单   投注体育失败，电竞也撤单
	// 3:待确认,需要调用yewu13/v1/betOrder/queryOrderStatus 接口，异步确认
	switch orderStatus {
	case tyBetStatusFailed: // 4:已拒绝 5:撤单
		// 投注体育失败，电竞也撤单
		return tyDoBetResult(tyBetFailed, order)

	case tyBetStatusSuccess: // 1:投注成功
		// 投注成功,保存体育注单id,确认注单并删除任务
		order.TYOrderID = tyBetResp.Data.TYOrderDetail[0].OrderNo
		order.TYNewOdd = tyBetResp.Data.TYOrderDetail[0].OddsValues
		return tyDoBetResult(tyBetSuccess, order)

	case tyBetStatusWaitConfirm: // 2:待确认,需要调用/v1/betOrder/queryOrderStatus 接口，异步确认
		order.TYOrderID = tyBetResp.Data.TYOrderDetail[0].OrderNo
		tyGetBetDetailPool.Invoke(order)
	}

	return nil
}

/*
* @Description: 处理注单确认
* @Author: xp
* @Date: 2021/12/19 10:00
* @LastEditTime:  2021/12/19 10:00
* @LastEditors: xp
 */
func tyQueryOrderStatusProcess(order BetOrder) error {

	iOrderStatus := -1 // -1:原值 0:确认 1:取消
	if len(order.TYOrderID) > 0 {
		for i := 0; i < 8; i++ {
			// 每隔2秒调用一次接口，调用8次，共16秒
			time.Sleep(2 * time.Second)

			resp, err := tyHttpQueryOrderStatus(order)
			if err != nil {
				fmt.Println(err)
				continue
			}

			if resp.Code != tySuccess {
				continue
			}

			if len(resp.Data) == 0 {
				continue
			}

			// 检查注单
			for _, v := range resp.Data {
				if v.OrderNo != order.TYOrderID {
					continue
				}

				if v.Status == tyQueryOrderStatusRefuse || v.Status == tyQueryOrderStatusFailed {
					// 拒绝 失败
					iOrderStatus = 1
					break
				}

				if v.Status == tyQueryOrderStatusConfirmed || v.Status == tyQueryOrderStatusSolved {
					// 已确认 已处理
					iOrderStatus = 0

					// 查找投注项
					for _, vv := range v.OddsChangeList {
						if vv.PlayOptionsId == order.OddID {
							order.TYNewOdd = vv.UsedOdds
							break
						}
					}
				}

				break
			}
		}
	}

	// 解锁
	if iOrderStatus != -1 {
		redisKey := fmt.Sprintf(RedisMTSBetLock, order.MemberID)
		mt.MerchantRedis.Unlink(redisKey)

		fmt.Println("删除redis：", redisKey)
	}

	if iOrderStatus == 0 {
		// 确认
		_ = orderConfirm(order)
		return nil
	}

	// 取消
	_ = orderRefuse(order)

	return nil
}

/*
* @Description:获取体育的基准分和盘口值
* @Author: xp
* @Date: 2021/12/4 8:01
* @LastEditTime: 2021/12/4 8:01
* @LastEditors: xp
 */
func tyGetScoreBenchmark(userID uint64, userName, tyMatchSID, marketID, playID, optionID string, matchType, sportID, placeNum int) (string, string, error) {

	// 如果redis里有体育的token,则不需要登录，否则登录后获取token
	tyMember, err := tyGetToken(userID, userName)
	if err != nil {
		return "", "", err
	}

	marketInfoResp, err := tyHttpQueryLatestMarketInfo(tyMember.TYToken, tyMatchSID, marketID, playID, optionID, matchType, sportID, placeNum)
	if err != nil {
		return "", "", err
	}

	if marketInfoResp.Code != tySuccess {
		return "", "", fmt.Errorf("tyGetScoreBenchmark service error: %s", marketInfoResp.Msg)
	}
	if len(marketInfoResp.Data) == 0 {
		return "", "", nil
	}

	marketValue := marketInfoResp.Data[0].MarketValue
	scoreBenchmark := marketInfoResp.Data[0].Score
	if len(scoreBenchmark) > 0 {
		arr := strings.Split(scoreBenchmark, "|")
		if len(arr) > 1 {
			return arr[1], marketValue, nil
		}
	}

	return "", marketValue, nil
}

/*
* @Description: 计算体育最大限额
* @Author: xp
* @Date: 2021/12/19 10:00
* @LastEditTime:  2021/12/19 10:00
* @LastEditors: xp
 */
func TYCalcMaxLimit(minBet, orderMaxPay decimal.Decimal) decimal.Decimal {

	strMin := minBet.Truncate(0).String()
	strMax := orderMaxPay.Truncate(0).String()

	minLen := len(strMin)
	maxLen := len(strMax)
	if minLen >= maxLen {
		return orderMaxPay
	}

	maxBytes := []byte(strMax)
	for i := 0; i < minLen; i++ {
		maxBytes[maxLen-i-1] = '0'
	}

	maxBet, err := decimal.NewFromString(string(maxBytes))
	if err != nil {
		maxBet = orderMaxPay
	}

	return maxBet
}

/*
* @Description:获取体育的赛事类型
* @Author: xp
* @Date: 2021/12/4 8:01
* @LastEditTime: 2021/12/4 8:01
* @LastEditors: xp
 */
func TYGetMatchType(isLive int) int {

	tyMatchType := 1
	if isLive == 2 {
		tyMatchType = 2
	}

	return tyMatchType
}

/*
* @Description:通过电竞的玩法获取对应的体育玩法
* @Author: xp
* @Date: 2021/12/4 8:01
* @LastEditTime: 2021/12/4 8:01
* @LastEditors: xp
 */
func TYGetOddTypeSID(oddTypeID string) string {

	oddTypeSID, ok := oddTypeIDMap[oddTypeID]
	if !ok {
		return ""
	}

	return oddTypeSID
}

/*
* @Description:获取会员投注限额
* @Author: xp
* @Date: 2021/12/4 8:01
* @LastEditTime: 2021/12/4 8:01
* @LastEditors: xp
 */
func TYGetLimitResp(userID uint64, userName, sID, marketID, oddID, oddTypeID string, bSportsGame bool, isLive, device int) (TYLimitResponse, error) {

	var tyLimitResp TYLimitResponse

	// 如果redis里有体育的token,则不需要登录，否则登录后获取token
	tyMember, err := tyGetToken(userID, userName)
	if err != nil {
		return tyLimitResp, err
	}

	oddTypeSID := TYGetOddTypeSID(oddTypeID)
	tyMatchType := TYGetMatchType(isLive)
	if bSportsGame {
		tyMatchType = 4
	}
	tyLimitResp, err = tyHttpLimit(tyMember.TYToken, sID, marketID, oddID, oddTypeSID, tyMatchType, device)
	if err != nil {
		return tyLimitResp, err
	}

	// 判断是否返回token失效的错误码，如果是，则删除tyToken的缓存
	// 401002:请先登录  401013:账户信息已过期，请重新登录
	if tyLimitResp.Code == tyNeedUserLogin || tyLimitResp.Code == tyUserLoginExpire {
		redisKey := fmt.Sprintf(redisTYMember, userID)
		mt.MerchantRedis.Unlink(redisKey)
		return tyLimitResp, fmt.Errorf("GetTYLimitResp service error: %s", tyLimitResp.Msg)
	}

	if tyLimitResp.Code != tySuccess {
		return tyLimitResp, fmt.Errorf("GetTYLimitResp service error: %s", tyLimitResp.Msg)
	}

	return tyLimitResp, nil
}

/*
* @Description:检测体育投注限额
* @Author: xp
* @Date: 2021/12/4 8:01
* @LastEditTime: 2021/12/4 8:01
* @LastEditors: xp
 */
func TYCheckLimit(userID uint64, userName, matchSID, marketID, oddID, oddTypeID string, bSportsGame bool, isLive int, betAmount, rate decimal.Decimal, lan string) error {

	if len(matchSID) == 0 || matchSID == "0" {
		return nil
	}

	limitResp, err := TYGetLimitResp(userID, userName, matchSID, marketID, oddID, oddTypeID, bSportsGame, isLive, 1)
	if err != nil {
		return err
	}

	// 判断限红
	if len(limitResp.Data) == 0 {
		return nil
	}

	minBet := limitResp.Data[0].MinBet.Mul(rate).Ceil()
	if betAmount.LessThan(minBet) {
		return fmt.Errorf(lang.Text(lan, "msgMinBet"), minBet.String())
	}

	orderMaxPay := TYCalcMaxLimit(limitResp.Data[0].MinBet, limitResp.Data[0].OrderMaxPay)
	if betAmount.GreaterThan(orderMaxPay) {
		return errors.New(lang.Text(lan, "msgBetExceedLimit"))
	}

	return nil
}

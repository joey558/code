package model

import (
	"fmt"
	"time"

	"github.com/beanstalkd/go-beanstalk"
	"github.com/panjf2000/ants/v2"
	"github.com/silenceper/pool"
)

//滚盘注单
type OrderDelay struct {
	MatchID        string  //赛事id
	MarketID       string  //盘口id
	OddId          string  //投注项id
	BetAmount      string  //注单金额
	TheoryPrize    string  //预期派彩金额
	BetDelayTime   int     //注单确认时间
	Odd            string  // 注单赔率
	ExchangeRate   string  // 汇率
	HideAmountRate float64 // 藏单率
	TYOrderID      string  // 体育注单
	TYNewOdd       string  // 投注成功后体育返回的新赔率
}

type BeansProducerAttr struct {
	CID     interface{}   //context id, 方便追踪
	Pool    pool.Pool     //beanstalk连接池
	Tube    string        //tube 名称
	Message string        //job body
	Delay   time.Duration //延迟ready的秒数
	TTR     time.Duration //允许worker执行的最大秒数
	PRI     uint32        //优先级
}

func BeansAddTask(task BeansProducerAttr) error {

	v, err := task.Pool.Get()
	if err != nil {
		AddLog(LogError, LogFlag, task.CID, "get beans pool err: %s", err.Error())
		return err
	}

	if conn, ok := v.(*beanstalk.Conn); ok {

		tube := &beanstalk.Tube{Conn: conn, Name: task.Tube}
		_, err = tube.Put([]byte(task.Message), task.PRI, task.Delay, task.TTR)
		if err != nil {
			AddLog(LogError, LogFlag, task.CID, "put beans tube err: %s", err.Error())
			return err
		}
	}

	//将连接放回连接池中
	return task.Pool.Put(v)
}

func BeansInvoke(routinePool *ants.PoolWithFunc, task BeansProducerAttr) error {

	if err := routinePool.Invoke(task); err != nil {
		AddLog(LogError, LogFlag, task.CID, "BeansInvoke error: %s", err.Error())
	}

	return nil
}

func PutDelayQueue(cid, uid uint64, oid uint64, od OrderDelay, tester uint8, riskTagId string) error {

	msg := fmt.Sprintf("uid=%d&match_id=%s&market_id=%s&order_id=%d&odd_id=%s&bet_amount=%s&flag=1&theory_prize=%s&tester=%d&tag_id=%s&odd=%s&exchange_rate=%s&hide_amount_rate=%f&ty_order_id=%s&ty_new_odd=%s",
		uid, od.MatchID, od.MarketID, oid, od.OddId, od.BetAmount, od.TheoryPrize, tester, riskTagId, od.Odd, od.ExchangeRate, od.HideAmountRate, od.TYOrderID, od.TYNewOdd)

	return BeansInvoke(mt.BPool, BeansProducerAttr{
		CID:     cid,
		Pool:    mt.BeanPool,
		Tube:    fmt.Sprintf(BeanStalkBetOrderConfirm, mt.Config.MerchantName),
		Message: msg,
		Delay:   time.Duration(od.BetDelayTime) * time.Second,
		PRI:     1,
		TTR:     10 * time.Second,
	})
}

/**
 * @Description: 盘口预警监控任务
 * @Author: maxic
 * @Date: 2020/11/5
 * @LastEditTime: 2020/11/5
 * @LastEditors: maxic
 **/
func BeansTaskMarketMonitor(cid, matchId, marketId, oddId, orderId, category interface{}) error {

	return BeansInvoke(mt.BPool, BeansProducerAttr{
		CID:     cid,
		Pool:    mt.ZkBeanPool,
		Tube:    BeanstalkMarketMonitorTube,
		Message: fmt.Sprintf("match_id=%v&market_id=%v&odd_id=%v&order_id=%v&category=%v", matchId, marketId, oddId, orderId, category),
		Delay:   0,
		PRI:     1,
		TTR:     10 * time.Second,
	})
}

/**
 * @Description: 自动变赔任务
 * @Author: maxic
 * @Date: 2021/03/12
 * @LastEditTime: 2021/03/12
 * @LastEditors: maxic
 **/
func BeansTaskAutoOdd(id, matchId, marketId, oddId, betAmount, tester interface{}, isDefault, optionType int, exchangeRate string, hideAmountRate float64) error {

	return BeansInvoke(mt.BPool, BeansProducerAttr{
		CID:  id,
		Pool: mt.ZkBeanPool,
		Tube: BeanstalkAutoOddTube,
		Message: fmt.Sprintf("id=%v&match_id=%v&market_id=%v&odd_id=%v&bet_amount=%v&tester=%v&is_default=%d&option_type=%d&exchange_rate=%s&hide_amount_rate=%f",
			id, matchId, marketId, oddId, betAmount, tester, isDefault, optionType, exchangeRate, hideAmountRate),
		Delay: 0,
		PRI:   1,
		TTR:   10 * time.Second,
	})
}

/**
 * @Description: 中心钱包接口超时
 * @Author: awen
 * @Date: 2021/05/14
 * @LastEditTime: 2021/05/14
 * @LastEditors: awen
 **/
func BeansTaskCreditTimeout(orderID string, transType int, sToken, username, amount string) error {

	return BeansInvoke(mt.BPool, BeansProducerAttr{
		CID:     orderID,
		Pool:    mt.BeanPool,
		Tube:    fmt.Sprintf(BeanstalkCreditTimeoutTube, mt.Config.MerchantName),
		Message: fmt.Sprintf("id=%s&trans_type=%d&stoken=%s&username=%s&amount=%s", orderID, transType, sToken, username, amount),
		Delay:   5 * time.Second,
		PRI:     1,
		TTR:     10 * time.Second,
	})
}

/**
 * @Description: 追加拒单任务
 * @Author: xp
 * @Date: 2022/01/26 16:09
 * @LastEditTime: 2022/01/26 16:09
 * @LastEditors: xp
 */
func BeansTaskOrderRefuse(matchID, marketIds, extraInf, flag, orderID, tyMatchSID string) error {

	msg := fmt.Sprintf("match_id=%s&market_id=%s&flag=%s&order_id=%s&ty_match_sid=%s", matchID, marketIds, flag, orderID, tyMatchSID)
	if len(extraInf) > 0 {
		msg += extraInf
	}

	return BeansInvoke(mt.BPool, BeansProducerAttr{
		CID:     orderID,
		Pool:    mt.ZkBeanPool,
		Tube:    fmt.Sprintf(BeanstalkTradeTube, mt.Config.MerchantName),
		Message: msg,
		Delay:   2 * time.Second,
		PRI:     1,
		TTR:     60 * time.Second,
	})
}

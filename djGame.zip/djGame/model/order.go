package model

import (
	"database/sql"
	"game/helper"
	g "github.com/doug-martin/goqu/v9"
	"github.com/shopspring/decimal"
)

var (
	validOrderStatus = []int{
		BetStatusWaitConfirm,
		BetStatusWaitSettle,
		BetStatusWin,
		BetStatusLose,
		BetStatusWinHalf,
		BetStatusLoseHalf,
		BetStatusDraw,
	}

	validOrderDetailStatus = []int{
		CompTypeWaitConfirm,
		CompTypeWin,
		CompTypeLoss,
	}
)

type TheoryPrizeStat struct {
	MchTheoryPrize      map[string]decimal.Decimal `json:"mch_theory_prize"` // 会员赛事单注预期盈利统计
	MktTheoryPrize      map[string]decimal.Decimal `json:"mkt_theory_prize"` // 会员盘口单注预期盈利统计
	MchRoundTheoryPrize map[string]decimal.Decimal `json:"mch_round_prize"`  // 会员单局串关预期派彩金额
	MchMixTheoryPrize   map[string]decimal.Decimal `json:"mch_mix_prize"`    // 会员单局复合玩法预期派彩金额
}

type RoundCompTheoryPrize struct {
	TheoryPrize    decimal.Decimal `json:"theory_prize"`       //预期派彩金额
	MchTheoryPrize decimal.Decimal `json:"round_theory_prize"` //赛事预期派彩金额
}

type MemberTheoryPrize struct {
	MatchID      string  `db:"match_id" json:"match_id"`         // 赛事ID
	MarketID     string  `db:"market_id" json:"market_id"`       // 盘口ID
	BetAmount    string  `db:"bet_amount" json:"bet_amount"`     // 注单金额
	TheoryPrize  string  `db:"theory_prize" json:"theory_prize"` // 注单预期盈利金额
	OrderType    int     `db:"order_type" json:"order_type"`     // 注单类型
	ExchangeRate float64 `db:"exchange_rate"`                    // 赔率
}

type ComplexBetDetail struct {
	MatchID      string  `db:"match_id"`  // 赛事ID
	MarketID     string  `db:"market_id"` // 盘口ID
	OrderId      string  `db:"order_id"`
	Odd          string  `db:"odd"`
	BetAmount    float64 `db:"bet_amount"`
	ExchangeRate float64 `db:"exchange_rate"` // 赔率
}

type ComplexBetAmountSum struct {
	ParleyType  int     `db:"parley_type"`  //串关类型 1普通注单 2:2串1  3:3串1 4:4串1 5:5串1 6:6串1 7:7串1 8:8串1
	BetAmount   float64 `db:"bet_amount"`   //注单金额
	TheoryPrize float64 `db:"theory_prize"` //注单预期盈利金额
}

type SimpleBetAmountSum struct {
	BetAmount   float64 `db:"bet_amount"`   //注单金额
	TheoryPrize float64 `db:"theory_prize"` //注单预期盈利金额
}

var (
	dialect = g.Dialect("mysql")
)

func OrderTheoryPrizeStatDB(memberId uint64, matchIds, marketIds []string) (TheoryPrizeStat, error) {

	var (
		err               error
		ok                bool
		memberTheoryPrize []MemberTheoryPrize //会员赛事预期盈利
		betAmount         decimal.Decimal
		theoryPrize       decimal.Decimal //注单预期盈利金额
		rndCompTP         decimal.Decimal
		mixCompTP         decimal.Decimal
		complexBetDetails []ComplexBetDetail
	)
	data := TheoryPrizeStat{}
	mchStats := map[string]decimal.Decimal{}    //赛事预期盈利统计
	mktStats := map[string]decimal.Decimal{}    //盘口预期盈利统计
	mchRCStats := map[string]decimal.Decimal{}  //赛事局内串关预期盈利统计
	mchMixStats := map[string]decimal.Decimal{} //赛事复合玩法预期盈利统计
	ex := g.Ex{
		"member_id":  memberId,
		"order_type": []int{OrderTypeSimple, OrderTypeRoundComplex, OrderTypeMix},
		"match_id":   matchIds,
		"bet_status": validOrderStatus,
	}
	query, _, _ := dialect.Select(clMemberTheoryPrize...).From(TblBetOrder).Where(ex).ToSQL()
	err = mt.MerchantSlaveDB.Select(&memberTheoryPrize, query)
	if err != nil {
		return data, err
	}

	//计算会员赛事和盘口注单总预期派彩金额
	for _, tp := range memberTheoryPrize {
		betAmount, _ = decimal.NewFromString(tp.BetAmount)
		theoryPrize, err = decimal.NewFromString(tp.TheoryPrize)
		if err != nil {
			return data, err
		}
		theoryPrize = theoryPrize.Sub(betAmount)
		rate := decimal.NewFromFloat(tp.ExchangeRate)
		theoryPrize = theoryPrize.Div(rate).Round(3)
		switch tp.OrderType {
		case OrderTypeSimple:
			//累计会员赛事预期盈利金额
			if _, ok = mchStats[tp.MatchID]; ok {
				mchStats[tp.MatchID] = mchStats[tp.MatchID].Add(theoryPrize)
			} else {
				mchStats[tp.MatchID] = theoryPrize
			}

			//累计会员盘口预期盈利金额
			if _, ok = mktStats[tp.MarketID]; ok {
				mktStats[tp.MarketID] = mktStats[tp.MarketID].Add(theoryPrize)
			} else {
				mktStats[tp.MarketID] = theoryPrize
			}
		case OrderTypeRoundComplex:
			//累计会员赛事局内串关预期盈利金额
			if rndCompTP, ok = mchRCStats[tp.MatchID]; ok {
				mchRCStats[tp.MatchID] = rndCompTP.Add(theoryPrize) // 会员赛事总赔付值
			} else {
				mchRCStats[tp.MatchID] = theoryPrize
			}
		case OrderTypeMix: //复合玩法需同时累计局内串关与复合玩法赔付限额
			//累计会员赛事局内串关预期盈利金额
			if rndCompTP, ok = mchRCStats[tp.MatchID]; ok {
				mchRCStats[tp.MatchID] = rndCompTP.Add(theoryPrize) // 会员赛事总赔付值
			} else {
				mchRCStats[tp.MatchID] = theoryPrize
			}
			//累计会员赛事复合玩法预期盈利金额
			if mixCompTP, ok = mchMixStats[tp.MatchID]; ok {
				mchMixStats[tp.MatchID] = mixCompTP.Add(theoryPrize) // 会员赛事总赔付值
			} else {
				mchMixStats[tp.MatchID] = theoryPrize
			}
		default:
			continue
		}
	}

	ex = g.Ex{
		"member_id": memberId,
		"market_id": marketIds,
		"status":    validOrderDetailStatus,
	}
	query, _, _ = dialect.Select(clComplexBetDetail...).From(TblOrderDetail).Where(ex).ToSQL()
	err = mt.MerchantSlaveDB.Select(&complexBetDetails, query)
	if err != nil {
		return data, err
	}

	for _, i := range complexBetDetails {
		if i.BetAmount == 0 {
			continue
		}
		betAmount = decimal.NewFromFloat(i.BetAmount)
		odd, err := decimal.NewFromString(i.Odd)
		if err != nil {
			return data, err
		}

		theoryPrize = (betAmount.Mul(odd)).Sub(betAmount)
		rate := decimal.NewFromFloat(i.ExchangeRate)
		theoryPrize = theoryPrize.Div(rate).Round(3)
		//累计会员赛事预期盈利金额
		if _, ok := mchStats[i.MatchID]; ok {
			mchStats[i.MatchID] = mchStats[i.MatchID].Add(theoryPrize)
		} else {
			mchStats[i.MatchID] = theoryPrize
		}

		//累计会员盘口预期盈利金额
		if _, ok := mktStats[i.MarketID]; ok {
			mktStats[i.MarketID] = mktStats[i.MarketID].Add(theoryPrize)
		} else {
			mktStats[i.MarketID] = theoryPrize
		}
	}

	data.MchTheoryPrize = mchStats
	data.MktTheoryPrize = mktStats
	data.MchRoundTheoryPrize = mchRCStats
	data.MchMixTheoryPrize = mchMixStats

	return data, nil
}

/*
* @Description: 统计信用盘会员投注金额
* @Author: noah
* @Date: 2021/5/22 21:26
* @LastEditTime: 2021/5/22 21:26
* @LastEditors: noah
 */
func getCreditSTPSum(memberId, matchID, agentId string, marketers []string, isLive int) (float64, error) {

	data := SimpleBetAmountSum{}
	ex := g.Ex{
		"order_type": OrderTypeSimple,
		"match_id":   matchID,
		"bet_status": []int{BetStatusWaitConfirm, BetStatusWaitSettle, BetStatusWin, BetStatusLose},
	}
	if isLive != 0 {
		ex["is_live"] = isLive
	}
	if memberId != "" {
		ex["member_id"] = memberId
	}
	if len(marketers) != 0 {
		ex["market_id"] = marketers
	}
	if agentId != "" {
		ex["agent_id"] = agentId
	}
	query, _, _ := dialect.From(TblBetOrder).Select(
		g.Func("IFNULL", g.SUM("bet_amount"), 0).As("bet_amount"),      //注单金额
		g.Func("IFNULL", g.SUM("theory_prize"), 0).As("theory_prize")). //预派彩金额
		Where(ex).ToSQL()
	err := mt.MerchantSlaveDB.Get(&data, query)
	if err != nil && err != sql.ErrNoRows {
		return 0, err
	}

	return data.TheoryPrize - data.BetAmount, nil
}

/**
* @Description: 获取串注已用赔付额度
* @Author: noah
* @Date: 2021/7/24 19:01
* @LastEditTime:2021/7/24 19:01
* @LastEditors: noah
 */
func getCompSum(ex g.Ex) (map[int]float64, error) {

	var complexBetAmountSum []ComplexBetAmountSum
	complexBetAmountSumMap := map[int]float64{}
	query, _, _ := dialect.From(TblBetOrder).Select("parley_type",
		g.Func("IFNULL", g.SUM("bet_amount"), 0).As("bet_amount"),      //注单金额
		g.Func("IFNULL", g.SUM("theory_prize"), 0).As("theory_prize")). //预派彩金额
		Where(ex).GroupBy("parley_type").ToSQL()
	err := mt.MerchantSlaveDB.Select(&complexBetAmountSum, query)
	if err != nil && err != sql.ErrNoRows {
		return complexBetAmountSumMap, err
	}

	for i := range complexBetAmountSum {
		complexBetAmountSumMap[complexBetAmountSum[i].ParleyType] = complexBetAmountSum[i].TheoryPrize - complexBetAmountSum[i].BetAmount
	}

	return complexBetAmountSumMap, nil
}

//获取会员今日最高中奖金额
func MemberTodayMaxPrize(uid uint64) (string, error) {

	todayMaxPrize := "0"
	ex := g.Ex{
		"member_id":   uid,
		"bet_status":  []int{BetStatusWin, BetStatusWinHalf},
		"settle_time": g.Op{"between": g.Range(helper.GetStartOfDayUnix(), helper.GetEndOfDayUnix())},
	}
	query, _, _ := dialect.From(TblBetOrder).Select(
		g.Func("IFNULL", g.MAX("win_amount"), 0).As("win_amount")). //派彩金额
		Where(ex).ToSQL()

	err := mt.MerchantSlaveDB.Get(&todayMaxPrize, query)

	return todayMaxPrize, err
}

package model

import (
	"fmt"
	"github.com/go-redis/redis/v7"
	"log"
	"testing"
	"time"
)

func TestHandicapInfo(t *testing.T) {

	pool := initRedisSlave("34.92.193.98:6380", "ooXis3oIPxke8s7m")
	data, err := utils.HandicapInfo(pool, []string{"21250743921920007"})
	if err != nil {
		t.Error(err)
		return
	}

	t.Log(data)
}

func TestGameIndexGet(t *testing.T) {

	pool := initRedisSlave("34.92.193.98:6380", "ooXis3oIPxke8s7m")
	data, err := utils.GameIndexGet(pool, "257289795134339", 1, 0, 20, time.Now())
	if err != nil {
		t.Error(err)
		return
	}

	t.Log(data)
}

func initRedisSlave(dsn string, psd string) *redis.Client {

	reddb := redis.NewClient(&redis.Options{
		Addr:         dsn,
		Password:     psd, // no password set
		DB:           0,   // use default DB
		DialTimeout:  10 * time.Second,
		ReadTimeout:  30 * time.Second,
		WriteTimeout: 30 * time.Second,
		PoolSize:     10,
		PoolTimeout:  30 * time.Second,
		MaxRetries:   2,
		IdleTimeout:  5 * time.Minute,
	})
	pong, err := reddb.Ping().Result()
	fmt.Println(pong, err)
	if err != nil {
		log.Fatalf("initRedisSlave failed: %s", err.Error())
	}

	return reddb
}

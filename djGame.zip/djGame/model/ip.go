package model

import (
	"fmt"

	g "github.com/doug-martin/goqu/v9"
)

const TabMemberLoginRecord = "tbl_member_login_record"

type Ips struct {
	ID                    uint64 `db:"id"`                                                     //ID
	TopMerchantId         uint64 `db:"top_merchant_id" json:"top_merchant_id"`                 //顶层商户ID
	TopMerchantAccount    string `db:"top_merchant_account" json:"top_merchant_account"`       //顶层商户账号
	ParentMerchantID      uint64 `db:"parent_merchant_id" json:"parent_merchant_id"`           //父商户ID
	ParentMerchantAccount string `db:"parent_merchant_account" json:"parent_merchant_account"` //父商户名称
	MerchantID            uint64 `db:"merchant_id" json:"merchant_id"`                         //商户ID
	MerchantAccount       string `db:"merchant_account" json:"merchant_account"`               //商户名称
	Uid                   uint64 `db:"uid"`                                                    //用户ID
	Account               string `db:"account"`                                                //用户账号
	Ip                    uint32 `db:"ip"`                                                     //用户投注IP
	Ua                    string `db:"ua"`                                                     //user agent
	Time                  int64  `db:"time"`                                                   //创建时间
}

/*
* @Description: 添加用户登陆IP记录
* @Author: noah
* @Date: 2021/3/31 15:49
* @LastEditTime: 2021/3/31 15:49
* @LastEditors: noah
 */
func IpsAdd(data *Ips) error {

	var count uint64
	ex := g.Ex{
		"uid": data.Uid,
		"ip":  data.Ip,
	}

	query, _, _ := dialect.Select(g.COUNT("id")).From(TabMemberLoginRecord).Where(ex).ToSQL()
	//err := db.Get(&count, query)
	err := mt.MerchantSlaveDB.Get(&count, query)
	if err != nil {
		return err
	}

	if count == 0 {
		insertSql, _, _ := dialect.Insert(TabMemberLoginRecord).Rows(data).ToSQL()
		fmt.Println(insertSql)
		//_, err = db.Exec(insertSql)
		_, err = mt.MerchantDB.Exec(insertSql)

	} else {
		updateSql, _, _ := dialect.Update(TabMemberLoginRecord).Set(g.Record{"ua": data.Ua, "time": data.Time}).Where(ex).ToSQL()
		fmt.Println(updateSql)
		//_, err = db.Exec(updateSql)
		_, err = mt.MerchantDB.Exec(updateSql)
	}

	return err
}

package model

import (
	"errors"
	"game/helper"
	"github.com/valyala/fasthttp"
	"net/http"
	"time"
)

type RespModel struct {
	Status string      `json:"status"`
	Data   interface{} `json:"data"`
}

type BetConfirmRespModel struct {
	Status    string `json:"status"`
	Data      string `json:"data"`
	Time      string `json:"time"`
	Signature string `json:"signature"`
}

var (
	defaultTimeout = 30 * time.Second
)

func HttpGetHelper(url, param string) (RespModel, error) {
	resp := RespModel{}
	url = mt.Config.Credit.CentralWalletHost + url + "?" + param

	data, status, err := helper.HttpDoTimeout(nil, fasthttp.MethodGet, url, nil, defaultTimeout)
	if err != nil {
		return resp, err
	}

	if status != http.StatusOK {
		return resp, errors.New("未正确获取信息")
	}

	err = helper.JsonUnmarshal(data, &resp)
	if err != nil {
		return resp, err
	}

	return resp, nil
}

func HttpPostHelper(url string, req []byte) (RespModel, error) {

	resp := RespModel{}
	url = mt.Config.Credit.CentralWalletHost + url

	headers := map[string]string{
		"Content-Type": "application/x-www-form-urlencoded",
	}

	data, status, err := helper.HttpDoTimeout(req, fasthttp.MethodPost, url, headers, defaultTimeout)
	if err != nil {
		return resp, err
	}
	if status != http.StatusOK {
		return resp, errors.New("未正确获取信息")
	}

	err = helper.JsonUnmarshal(data, &resp)
	if err != nil {
		return resp, err
	}

	return resp, nil
}

func HttpBetConfirmHelper(url string, req []byte) (BetConfirmRespModel, error) {

	resp := BetConfirmRespModel{}
	url = mt.Config.Credit.CentralWalletHost + url

	headers := map[string]string{
		"Content-Type": "application/x-www-form-urlencoded",
	}

	data, status, err := helper.HttpDoTimeout(req, fasthttp.MethodPost, url, headers, defaultTimeout)
	if err != nil {
		return resp, err
	}
	if status != http.StatusOK {
		return resp, errors.New("未正确获取信息")
	}

	err = helper.JsonUnmarshal(data, &resp)
	if err != nil {
		return resp, err
	}

	return resp, nil
}

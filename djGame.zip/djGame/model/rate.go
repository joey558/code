package model

import (
	"fmt"
	"game/helper"
)

type QuickData struct {
	QuickOne   string `json:"quick_one"`
	QuickTwo   string `json:"quick_two"`
	QuickThree string `json:"quick_three"`
}

// GetRate
/**
 * @Description: 获取会员当前汇率
 * @Author: noah
 * @Date: 2022/2/1 14:15
 * @LastEditTime: 2022/2/1 14:15
 * @LastEditors: noah
 */
func GetRate(c int) (float64, error) {
	return mt.ZKRedisCluster.HGet(fmt.Sprintf(RedisKeyCurrencyRate, c), "rate").Float64()
}

// GetQuickData
/**
 * @Description: 获取会员当前汇率快捷金额设置
 * @Author: noah
 * @Date: 2022/2/1 14:15
 * @LastEditTime: 2022/2/1 14:15
 * @LastEditors: noah
 */
func (q *QuickData) GetQuickData(c int) error {

	r, err := mt.ZKRedisCluster.HMGet(fmt.Sprintf(RedisKeyCurrencyRate, c), quickFields...).Result()
	if err != nil {
		return err
	}

	d := map[string]string{}
	for i, j := range quickFields {
		if _, ok := r[i].(string); !ok {
			return nil
		}

		d[j] = fmt.Sprintf("%v", r[i])
	}
	encode, err := helper.JsonEncode(d)
	if err != nil {
		return err
	}

	return helper.JsonUnmarshal(encode, &q)
}

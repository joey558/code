package model

import (
	"errors"
	"fmt"
	"game/contrib/zlog"
	"game/helper"
	"game/lang"
	"game/utils"
	"game/wallet"
	fund "game/wallet"
	"regexp"
	"runtime"
	"time"

	g "github.com/doug-martin/goqu/v9"
	"github.com/doug-martin/goqu/v9/exp"
	"github.com/shopspring/decimal"
	"github.com/valyala/fasthttp"
)

const (
	TblBetOrder    = "tbl_bet_order"    //注单表
	TblOrderDetail = "tbl_order_detail" //串关注单明细表
)

type BetContent struct {
	OdId           uint64          `json:"od_id"`           //子单ID
	MatchID        string          `json:"matchId"`         //赛事id
	MarketID       string          `json:"marketId"`        //盘口id
	Oid            string          `json:"oid"`             //投注项ID
	Odd            decimal.Decimal `json:"odd"`             //服务器接受赔率
	OrgOdd         decimal.Decimal `json:"org_odd"`         //原始下单赔率
	CompUsedLimit  decimal.Decimal `json:"comp_used_limit"` //串注子单使用的赔付额度
	MatchLevel     string          `json:"match_level"`     //赛事等级
	ScoreBenchmark string          `json:"score_benchmark"` //基准分
}

func (b BetContent) String() string {
	return fmt.Sprintf("mch=%s&mkt=%s&oid=%s&odd=%s&org_odd=%s",
		b.MatchID,
		b.MarketID,
		b.Oid,
		utils.TrimDecimal(b.Odd),
		utils.TrimDecimal(b.OrgOdd))
}

//单注
type SimpleBetContent struct {
	Data   BetContent
	Flags  int             `json:"flags"`  //注单类型 1-普通注单 2-普通串关注单 3-局内串关注单, 4-复合玩法注单
	Amount decimal.Decimal `json:"amount"` //注单金额
}

func (s SimpleBetContent) String() string {
	return s.Data.String() + fmt.Sprintf("&bt=%d&a=%s", s.Flags, utils.TrimDecimal(s.Amount))
}

//串关
type ComplexBetContent struct {
	Data       []BetContent
	Flags      int             `json:"flags"`       //注单类型 1-普通注单 2-普通串关注单 3-局内串关注单, 4-复合玩法注单
	ParleyType int             `json:"parley_type"` //串关类型 1普通注单 2:2串1  3:3串1 4:4串1 5:5串1 6:6串1 7:7串1 8:8串1
	ParleyNum  int             `json:"parley_num"`  //串关注单数量
	Amount     decimal.Decimal `json:"amount"`      //注单金额
	OddSum     decimal.Decimal `json:"odd_sum"`     //赔率累加
	Odd        decimal.Decimal `json:"odd"`         //赔率累乘
	OrderId    uint64          `json:"order_id"`    //注单ID
}

func (c ComplexBetContent) String() string {
	str := ""
	for _, d := range c.Data {
		str += d.String() + "&"
	}
	return str + fmt.Sprintf("bt=%d&t=%d&a=%s", c.Flags, c.ParleyType, utils.TrimDecimal(c.Amount))
}

type BetOrderListData struct {
	Bet      []BetOrder                   `json:"bet"`
	Detail   map[string][]OrderDetailData `json:"detail"`
	T        int64                        `json:"t"`
	BetTotal BetOrderTotal                `json:"bet_total"`
}
type BetOrderTotal struct {
	BetCount         int     `db:"bet_count" json:"bet_count"`                   //注单数量
	BetAmountTotal   float64 `db:"bet_amount_total" json:"bet_amount_total"`     // 注单金额
	WinAmountTotal   float64 `db:"win_amount_total" json:"win_amount_total"`     // 派彩金额
	TheoryPrizeTotal float64 `db:"theory_prize_total" json:"theory_prize_total"` // 理论奖金
}

// 投注账变参数
type BetTransfer struct {
	BetAmount decimal.Decimal        `json:"bet_amount"`
	Param     map[string]interface{} `json:"param"`
}

// 投注接口附加参数
type BetAdditionalInfo struct {
	TYPlaceNum  int    // TY坑位
	MarketValue string // 盘口值
}

// 推送通知
type Notify struct {
	MktMchMp          map[string]string
	RefreshSimple     bool
	RefreshComplex    bool
	RefreshRndComplex bool
	RefreshMix        bool
}

// 投注信息
type BetInfo struct {
	CID             uint64
	Lan             string                         // 语言
	ExchangeRate    string                         // 汇率
	RiskTagID       string                         // 风控标签
	RiskTagMatchID  string                         // 风控赛事ID
	IsSportsGame    bool                           // 虚拟体育
	Member          fund.Member                    // 会员信息
	OrderOptionType map[uint64]int                 // 注单的玩法
	DefaultMarket   map[interface{}]int            // 默认盘口
	Simples         map[uint64]g.Record            // 单注
	Complexes       map[uint64]g.Record            // 串注
	Delay           map[uint64]OrderDelay          // 滚盘注单
	Transfers       map[uint64]BetTransfer         // 帐变参数
	OrderDetails    map[uint64]map[uint64]g.Record // 串注详情
	Additional      map[uint64]BetAdditionalInfo   // 投注附加参数,key为注单ID
}

// IsDuplex
/**
* @Description: 复式串注检查
* @Author: noah
* @Date: 2021/11/7 13:36
* @LastEditTime:2021/11/7 13:36
* @LastEditors: noah
 */
func IsDuplex(data *map[int]int, lan string) error {

	for k, v := range *data {
		i, ok := CompsNumMap[k]
		if !ok {
			return errors.New(lang.Text(lan, "errParlay"))
		}

		if i != v {
			return errors.New(lang.Text(lan, "errParlay"))
		}
	}

	return nil
}

// 余额校验
func BetBalanceCheck(member fund.Member, amount decimal.Decimal) (string, bool) {

	if member.Tester == UserTypeCredit {
		return "", true
	} else {
		balance, ok := wallet.BalanceIsEnoughX(mt.MerchantDB, member.UID, amount)
		return balance.String(), ok
	}
}

// 投注
func BetDo(betInfo BetInfo) error {

	autoOddMp := map[uint64]g.Record{}
	betMktMp := map[string]string{}
	simpleRefresh := false
	complexRefresh := false
	rndComplexRefresh := false
	mixRefresh := false
	bMemberCalc := false

	userLockKey := fmt.Sprintf("%s%d", defaultRedisKeyPrefix, betInfo.Member.UID)
	err := Lock(userLockKey, 60*time.Second)
	if err != nil {
		return err
	}

	defer func() {

		UnLock(userLockKey)

		n := Notify{
			MktMchMp:          betMktMp,
			RefreshSimple:     simpleRefresh,
			RefreshComplex:    complexRefresh,
			RefreshRndComplex: rndComplexRefresh,
			RefreshMix:        mixRefresh,
		}
		// 推送注量变更，单注/串注注单刷新通知
		if err := mt.MPool.Invoke(n); err != nil {
			AddLog(LogError, LogFlag, betInfo.CID, "invoke error, uid: %d, err: %s", betInfo.Member.UID, err.Error())
		}

		// 发送自动变赔beanstalk job
		for oID, order := range autoOddMp {
			isDefault := 0
			if value, ok := betInfo.DefaultMarket[order["market_id"]]; ok {
				isDefault = value
			}
			// 只对 （待确认-1 || 已确认-3） && 单注-1 进行自动变赔
			err := BeansTaskAutoOdd(
				order["id"],
				order["match_id"],
				order["market_id"],
				order["odd_id"],
				order["bet_amount"],
				order["tester"],
				isDefault,
				betInfo.OrderOptionType[oID],
				betInfo.ExchangeRate,
				order["hide_amount_rate"].(float64),
			)
			if err != nil {
				AddLog(LogError, LogFlag, betInfo.CID, "RedisStreamAutoOddSend error: %s", err.Error())
			}
		}
	}()

	sToken := "" //信用网中心钱包token
	if betInfo.Member.Tester == UserTypeCredit {
		sToken = redisGetSTokens(betInfo.Member.UID)
	}

	// 为了入库时间间隔1秒
	exist := UserBetHashExists(betInfo.CID, betInfo.Member)
	if exist {
		return errors.New(lang.Text(betInfo.Lan, "msgSubmitOften"))
	}

	// 单注注单入库
	if len(betInfo.Simples) > 0 {

		for k, v := range betInfo.Simples {
			marketID := v["market_id"].(string)
			oddID := v["odd_id"].(string)
			isLive := v["is_live"].(int)

			// 获取体育赛事SID
			tyMatchSID := "0"
			tyMatchType := 0
			tyOddSID := ""
			tyScoreBenchmark := ""
			tyPlaceNum := 1

			if sid, ok := v["ty_match_sid"]; ok && sid != nil && sid != "" && sid != "0" {
				tyMatchSID = sid.(string)
				tyMatchType = TYGetMatchType(isLive)
				if betInfo.IsSportsGame {
					tyMatchType = 4
				}

				oddTypeID := v["org_odd_id"].(string)
				tyOddSID = TYGetOddTypeSID(oddTypeID)

				// 调用体育获取基准分接口的条件：体育的足球 滚球 4个固定的玩法
				tySportID := 0
				if v["match_type"] == MatchCategoryBasketball {
					tySportID = 2
				} else if v["match_type"] == MatchCategoryFootball {
					tySportID = 1
				} else if v["match_type"].(int) >= SportsMatchCategoryFootball {
					categorySportGameId := v["match_type"].(int)
					tySportID = SportsMatchGameIDMap[categorySportGameId]
				}

				tyPlaceNum = betInfo.Additional[k].TYPlaceNum
				score, marketValue, err := tyGetScoreBenchmark(betInfo.Member.UID, betInfo.Member.Account, tyMatchSID, marketID, tyOddSID, oddID, tyMatchType, tySportID, tyPlaceNum)
				if err != nil {
					return err
				}

				// 需要检验基准分
				if _, ok = CheckScoreBenchmarkMap[oddTypeID]; ok && v["score_benchmark"] != score {
					return errors.New(lang.Text(betInfo.Lan, "msgScoreChanged"))
				}

				// 需要检验盘口值
				if betInfo.Additional[k].MarketValue != marketValue {
					return errors.New(lang.Text(betInfo.Lan, "msgMarketValueChanged"))
				}

				tyScoreBenchmark = score
			}

			dbConn, err := mt.MerchantDB.Begin()
			if err != nil {
				return err
			}

			_, err = utils.Insert(utils.Conn{Tx: dbConn}, TblBetOrder, v)
			if err != nil {
				_ = dbConn.Rollback()
				return err
			}

			vv := betInfo.Transfers[k]
			if betInfo.Member.Tester == UserTypeCredit {
				orderID := fmt.Sprintf("%d", k)
				balance, err := creditFn(fund.TransBet, sToken, betInfo.Member.Account, orderID, vv.BetAmount)
				if err != nil {
					if err.Error() != "timeout" {
						_ = dbConn.Rollback()
						return err
					} else {
						// 投注成功的滚盘注单
						if vvv, ok := betInfo.Delay[k]; ok {
							// 滚盘订单加入延时队列
							_ = PutDelayQueue(betInfo.CID, betInfo.Member.UID, k, vvv, betInfo.Member.Tester, "")
						}
						_ = dbConn.Commit()
						return errors.New(lang.Text(betInfo.Lan, "msgBetTimeOut"))
					}
				}

				err = fund.TxCreditTransfer(dbConn, mt.Notify, vv.Param, balance, vv.BetAmount, fund.TransBet)
				// 账变写入失败，调用中心钱包接口恢复会员额度
				if err != nil {
					_ = dbConn.Rollback()
					_, _ = creditFn(fund.TransBetFail, sToken, betInfo.Member.Account, orderID, vv.BetAmount)
					return err
				}
			} else {
				current, err := wallet.GetBalanceDBX(mt.MerchantDB, betInfo.Member.UID)
				if err != nil {
					fmt.Println("GetBalanceDBX error:", err.Error())
					_ = dbConn.Rollback()
					return err
				}

				balance, err := decimal.NewFromString(current)
				if err != nil {
					_ = dbConn.Rollback()
					return err
				}

				if vv.BetAmount.GreaterThan(balance) {
					_ = dbConn.Rollback()
					return errors.New(lang.Text(betInfo.Lan, "msgLackBalance"))
				}

				pipe := mt.MerchantRedis.TxPipeline()
				// 写入账变
				err = wallet.TxTransferX(dbConn, pipe, mt.Notify, vv.Param, balance, vv.BetAmount, wallet.TransBet)
				if err != nil {
					fmt.Printf("simple order[%d] TxTransferX error:%s\n", k, err.Error())
					_ = dbConn.Rollback()
					return err
				}
				_, err = pipe.Exec()
				if err != nil {
					_ = dbConn.Rollback()
					return err
				}
				_ = pipe.Close()
			}

			_ = dbConn.Commit()

			orderType := v["order_type"].(int)
			betStatus := v["bet_status"].(int)
			bRiskTagCalc := false
			if betInfo.Member.Tester == 0 {
				zkPipe := mt.ZKRedisCluster.TxPipeline()
				if tyMatchSID == "0" {
					// 体育注单都是待确认，所以不需要统计
					// 风险标签-统计: 注单类型(普通注单), 注单状态(待结算)
					if orderType == OrderTypeSimple && betStatus == BetStatusWaitSettle && betInfo.RiskTagID != "" && betInfo.RiskTagMatchID != "" {
						err := utils.RiskTagCalcUpdate(zkPipe, v, betInfo.RiskTagID)
						if err != nil {
							fmt.Println("风险标签-统计更新[投注金额,投注单数]失败", err)
						} else {
							bRiskTagCalc = true
							bMemberCalc = true
						}
					}

					optionType := betInfo.OrderOptionType[k]
					err = utils.FCOrderCalcUpdate(zkPipe, v, optionType)
					if err != nil {
						fmt.Println("FC注单统计更新失败", err)
					}
				} else {
					// 更新注单统计
					// 注意：因为体育的注单，全都都是待确认，所以这里把is_live设置为MatchLive
					// 在调用utils.OrderCalcUpdate时，就会统计为浮动数据
					if betInfo.IsSportsGame { //虚拟体育 - 默认早盘
						v["is_live"] = MatchEarly
					} else { // 电竞足球篮球
						v["is_live"] = MatchLive
					}
				}

				if !betInfo.IsSportsGame { //非虚拟体育
					err = utils.OrderCalcUpdate(zkPipe, v, bRiskTagCalc)
					if err != nil {
						fmt.Println("注单统计更新失败", err)
					}
				}

				_, _ = zkPipe.Exec()
				_ = zkPipe.Close()

				//添加盘口监控消息，包含待确认注单
				if orderType == OrderTypeSimple && tyMatchSID == "0" {
					_ = BeansTaskMarketMonitor(betInfo.CID, v["match_id"], v["market_id"], v["odd_id"], v["id"], v["match_type"])
				} else {
					// 把is_live在前面修改了，这里恢复原样
					v["is_live"] = isLive

					acceptOdds := 0
					switch betInfo.Member.OddUpdateType {
					case 1: // 1:自动接受最新赔率
						acceptOdds = 2 // 2:自动接受任何赔率变动
					case 2: // 2:自动接受更高赔率
						acceptOdds = 1 // 1:自动接收更好的赔率
					case 3: // 3:永不接受最新赔率
						acceptOdds = 3 //3:不自动接受赔率变动
					}

					tyBetInfo := BetOrder{
						ID:             fmt.Sprintf("%d", k),
						MemberID:       betInfo.Member.UID,
						MemberAccount:  betInfo.Member.Account,
						Tester:         betInfo.Member.Tester,
						MatchID:        v["match_id"].(string),
						TYMatchSID:     tyMatchSID,
						MarketID:       marketID,
						OrgOddID:       tyOddSID,
						Device:         v["device"].(uint32),
						Odd:            v["odd"].(string),
						OddID:          oddID,
						BetAmount:      v["bet_amount"].(string),
						TheoryPrize:    v["theory_prize"].(string),
						MatchType:      tyMatchType,
						TYOrderID:      "0",
						AcceptOdds:     acceptOdds,
						BetStatus:      BetStatusWaitConfirm,
						ScoreBenchmark: tyScoreBenchmark,
						PlaceNum:       tyPlaceNum,
						ExchangeRate:   betInfo.ExchangeRate,
						HideAmountRate: v["hide_amount_rate"].(float64),
					}
					if betInfo.RiskTagID != "" && betInfo.RiskTagMatchID != "" {
						tyBetInfo.RiskTagID = betInfo.RiskTagID
					}
					_ = tyBetPool.Invoke(tyBetInfo)
				}

				// 组装盘口注量更新推送参数
				betMktMp[v["market_id"].(string)] = v["match_id"].(string)
				autoOddMp[k] = v
			}

			// 投注成功的滚盘注单
			if vvv, ok := betInfo.Delay[k]; ok {
				// 滚盘订单加入延时队列
				var strRiskTagId string
				if betInfo.RiskTagMatchID != "" {
					strRiskTagId = betInfo.RiskTagID
				}

				_ = PutDelayQueue(betInfo.CID, betInfo.Member.UID, k, vvv, betInfo.Member.Tester, strRiskTagId)
			}

			if orderType == OrderTypeSimple {
				simpleRefresh = true
			}
		}
	}

	// 串关注单入库
	if len(betInfo.Complexes) > 0 {

		for k, v := range betInfo.Complexes {

			dbConn, err := mt.MerchantDB.Begin()
			if err != nil {
				return err
			}
			_, err = utils.Insert(utils.Conn{Tx: dbConn}, TblBetOrder, v)
			if err != nil {
				_ = dbConn.Rollback()
				return err
			}

			// 串注详情入库
			var details []g.Record
			for _, record := range betInfo.OrderDetails[k] {
				details = append(details, record)
			}

			_, err = utils.Insert(utils.Conn{Tx: dbConn}, TblOrderDetail, details)
			if err != nil {
				_ = dbConn.Rollback()
				return err
			}

			vv := betInfo.Transfers[k]
			if betInfo.Member.Tester == UserTypeCredit {
				orderID := fmt.Sprintf("%d", k)
				balance, err := creditFn(fund.TransBet, sToken, betInfo.Member.Account, orderID, vv.BetAmount)
				if err != nil {
					if err.Error() != "timeout" {
						_ = dbConn.Rollback()
						return err
					} else {
						_ = dbConn.Commit()
						return errors.New(lang.Text(betInfo.Lan, "msgBetTimeOut"))
					}
				}

				err = fund.TxCreditTransfer(dbConn, mt.Notify, vv.Param, balance, vv.BetAmount, fund.TransBet)
				// 账变写入失败，调用中心钱包接口恢复会员额度
				if err != nil {
					_ = dbConn.Rollback()
					_, _ = creditFn(fund.TransBetFail, sToken, betInfo.Member.Account, orderID, vv.BetAmount)
				}
			} else {
				pipe := mt.MerchantRedis.TxPipeline()
				current, err := wallet.GetBalanceDBX(mt.MerchantDB, betInfo.Member.UID)
				if err != nil {
					fmt.Println("GetBalanceDBX error:", err.Error())
					_ = dbConn.Rollback()
					return err
				}

				balance, err := decimal.NewFromString(current)
				if err != nil {
					_ = dbConn.Rollback()
					return err
				}

				if vv.BetAmount.GreaterThan(balance) {
					_ = dbConn.Rollback()
					return errors.New(lang.Text(betInfo.Lan, "msgLackBalance"))
				}
				// 写入账变
				err = wallet.TxTransferX(dbConn, pipe, mt.Notify, vv.Param, balance, vv.BetAmount, wallet.TransBet)
				if err != nil {
					fmt.Printf("complex order[%d] TxTransferX error:%s\n", k, err.Error())
					_ = dbConn.Rollback()
					return err
				}
				_, err = pipe.Exec()
				if err != nil {
					fmt.Println("更新余额失败")
					_ = dbConn.Rollback()
					return err
				}
				_ = pipe.Close()
			}

			_ = dbConn.Commit()
			orderType := v["order_type"].(int)
			betStatus := v["bet_status"].(int)
			bRiskTagCalc := false
			switch orderType {
			case OrderTypeComplex:
				complexRefresh = true
			case OrderTypeRoundComplex:
				rndComplexRefresh = true
			case OrderTypeMix:
				mixRefresh = true
				if betInfo.Member.Tester == 0 {
					zkPipe := mt.ZKRedisCluster.TxPipeline()
					v["is_live"] = 1
					// 风险标签-统计: 注单类型(复合玩法), 注单状态(待结算)
					if betStatus == BetStatusWaitSettle && betInfo.RiskTagID != "" && betInfo.RiskTagMatchID != "" {
						err := utils.RiskTagCalcUpdate(zkPipe, v, betInfo.RiskTagID)
						if err != nil {
							fmt.Println("风险标签-统计更新失败", err)
						} else {
							bRiskTagCalc = true
							bMemberCalc = true
						}
					}
					// 更新注单统计
					err = utils.OrderCalcUpdate(zkPipe, v, bRiskTagCalc)
					if err != nil {
						fmt.Println("注单统计更新失败", err)
					}
					_, err = zkPipe.Exec()
					_ = zkPipe.Close()
					if err != nil {
						fmt.Println("Mix Order ")
					}

					// 组装盘口注量更新推送参数
					betMktMp[v["market_id"].(string)] = v["match_id"].(string)
					// 添加盘口预警监控任务
					_ = BeansTaskMarketMonitor(betInfo.CID, v["match_id"], v["market_id"], v["odd_id"], v["id"], v["match_type"])
				}
			}
		}
	}

	if bMemberCalc == true && betInfo.RiskTagMatchID != "" {
		err = utils.RiskTagMemberCalcUpdate(mt.ZKRedisCluster, betInfo.RiskTagMatchID, betInfo.RiskTagID, betInfo.Member.UID)
		if err != nil {
			fmt.Println("风险标签[投注人数]统计更新失败", err)
		}
	}

	return nil
}

//投注推送
func BetNotify(n Notify) {

	// 推送盘口注量变更
	for mkt, mch := range n.MktMchMp {
		MqttPushMarketOrderBet(mch, mkt)
	}

	// 推送单注实时注单刷新通知
	if n.RefreshSimple {
		MqttPushOrderRefresh(OrderTypeSimple)
	}
	// 推送串注实时注单刷新通知
	if n.RefreshComplex {
		MqttPushOrderRefresh(OrderTypeComplex)
	}
	// 推送局内串关实时注单刷新通知
	if n.RefreshRndComplex {
		MqttPushOrderRefresh(OrderTypeRoundComplex)
	}
	// 推送复合玩法实时注单刷新通知
	if n.RefreshMix {
		MqttPushOrderRefresh(OrderTypeMix)
	}
}

// 投注记录列表
func BetOrderList(page, pageSize uint, ex g.Ex) (BetOrderListData, error) {

	var (
		data     BetOrderListData
		detail   []OrderDetailData
		orderIDs []string
	)

	// get count
	count, err := utils.Count(mt.MerchantSlaveDB, TblBetOrder, ex)
	if err != nil {
		return data, err
	}
	if count == 0 {
		return data, err
	}
	data.T = int64(count)
	tableName := TblBetOrder
	if _, ok := ex["member_id"]; ok {
		tableName = fmt.Sprintf("%s %s", tableName, "force index(`idx_tbo_member_id`)")
	}
	// get data
	err = utils.SelectAll(&data.Bet, utils.QueryArg{
		Db:     mt.MerchantSlaveDB,
		Table:  tableName,
		Fields: clBetOrder,
		Ex:     []g.Expression{ex},
		Order:  []exp.OrderedExpression{g.C("bet_time").Desc()},
		Offset: (page - 1) * pageSize,
		Limit:  pageSize,
	})
	if err != nil {
		return data, err
	}

	if len(data.Bet) == 0 {
		return data, nil
	}

	// get data total
	err = utils.SelectOne(&data.BetTotal, mt.MerchantSlaveDB, TblBetOrder, BetTotalFields, ex)
	if err != nil {
		return data, err
	}

	for _, v := range data.Bet {
		if v.OrderType > 1 {
			orderIDs = append(orderIDs, v.ID)
		}
	}

	if len(orderIDs) > 0 {

		m := map[string][]OrderDetailData{}
		err = utils.SelectAll(&detail, utils.QueryArg{
			Db:     mt.MerchantSlaveDB,
			Table:  TblOrderDetail,
			Fields: clOrderDetail,
			Ex:     []g.Expression{g.Ex{"order_id": orderIDs}},
			Order:  []exp.OrderedExpression{g.C("bet_time").Asc()},
		})
		if err != nil {
			return data, err
		}

		for _, vv := range detail {
			m[vv.OrderID] = append(m[vv.OrderID], vv)
		}
		data.Detail = m
	}

	return data, err
}

func BetHashExists(ctx *fasthttp.RequestCtx, member wallet.Member, simples []*SimpleBetContent, complexes []*ComplexBetContent) bool {

	orgArgs := fmt.Sprintf("%s,%s", simples, complexes)
	reg := regexp.MustCompile("org_odd=.*?&")
	args := reg.ReplaceAllString(orgArgs, "")
	key := helper.GetMD5Hash(fmt.Sprintf("%d%s", member.UID, args))
	success, err := mt.MerchantRedis.SetNX(key, "true", 5*time.Second).Result()
	if err != nil {
		AddLog(LogError, LogFlag, ctx.ID(), "BetHashExists err: ", err.Error())
		return true
	}
	exist := !success

	return exist
}

// 限制每个用户1秒只能请求1次投注接口
func UserBetHashExists(cid uint64, member wallet.Member) bool {

	key := fmt.Sprintf("UserBetHashExists_%d_%d", member.MerchantID, member.UID)
	success, err := mt.MerchantRedis.SetNX(key, "true", 1*time.Second).Result()
	if err != nil {
		AddLog(LogError, LogFlag, cid, "UserBetHashExists err: ", err.Error())
		return true
	}

	return !success
}

//中心钱包加款扣款接口调用函数
func creditFn(transType int, sToken, account, orderID string, amount decimal.Decimal) (decimal.Decimal, error) {

	balance, _, msg := fund.CreditBalanceAddDeduction(account, sToken, orderID, amount, transType)
	if msg != "" {
		// 中心扣款接口超时，将超时订单放入beanstalk,异步同步订单扣款状态
		if msg == fasthttp.ErrTimeout.Error() {
			err := BeansTaskCreditTimeout(orderID, transType, sToken, account, amount.String())
			if err != nil {
				_, file, line, _ := runtime.Caller(0)
				zlog.Error(nil, "creditTimeout", fmt.Sprintf("%s:%d", file, line), fmt.Sprintf("BetDo credit timeout, order[%s], transType[%d]", orderID, transType), 0, 0)
			}
			return balance, errors.New("timeout")
		} else {
			return balance, errors.New(msg)
		}
	}
	return balance, nil
}

func FmtTime(tm time.Time) string {
	return tm.Format("2006-01-02 15:04:05.000")
}

/**
 * @Description: 判断注单是否有被过滤的游戏
 * @Author: xp
 * @Date: 2021/7/24
 * @LastEditTime: 2021/7/24
 * @LastEditors: xp
 **/
func CheckBetFilterGame(merchantID uint64, handicapData utils.HandicapData, lan string) error {

	filterSet, err := GetMerchantFilterGames(merchantID)
	if err != nil {
		return err
	}

	for _, mch := range handicapData.Matches {
		if filterSet.Has(mch.GameID) {
			// 游戏被过滤，不能投注
			return errors.New(fmt.Sprintf(lang.Text(lan, "msgInvalidGame"), MultiLanguageName(RamDataGame, []string{mch.GameID}, lan)))
		}
	}

	return nil
}

/*
* @Description:计算已拒绝，已取消，已撤销注单金额总和
* @Author: abraham
* @Date: 2021/12/22 11:05
* @LastEditTime: 2021/12/22 11:05
* @LastEditors: abraham
 */
func SumReturnBetAmount(ex g.Ex) (float64, error) {

	var amount float64
	query, _, _ := dialect.From(TblBetOrder).Select(g.Func("IFNULL", g.SUM("bet_amount"), 0).As("total_amount")).Where(ex).Limit(1).ToSQL()
	err := mt.MerchantSlaveDB.Get(&amount, query)

	return amount, err
}

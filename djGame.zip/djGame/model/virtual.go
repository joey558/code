package model

import (
	"fmt"
	"game/helper"
	"game/utils"
	"github.com/go-redis/redis/v7"
	errs "github.com/pkg/errors"
	"time"
)

func GetVirtualMatchIDs(gameID, tourID, bachNo string) ([]utils.GameIndex, error) {

	min := fmt.Sprintf("%d", time.Now().Unix()-int64(60*2))
	zRangeBy := &redis.ZRangeBy{
		Min: min,
		Max: "+inf",
	}

	keyEarlyMatchID := fmt.Sprintf(utils.RedisGameSportsEarlyTourMatch, gameID, tourID)
	matchIDSli, err := mt.ZKRedisCluster.ZRangeByScore(keyEarlyMatchID, zRangeBy).Result()
	if err != nil && errs.Cause(err) != redis.Nil {
		fmt.Printf("GameId[%s][SportsGameIdxGet] 联赛ID缓存 Redis Error:%s\n", gameID, err.Error())
		return nil, err
	}
	pipe := mt.ZKRedisCluster.Pipeline()
	defer pipe.Close()

	cmds := make([]*redis.Cmd, len(matchIDSli))
	for i, id := range matchIDSli {
		key := fmt.Sprintf(utils.RedisGameIndex, id)
		cmds[i] = pipe.Do("JSON.GET", key, "NOESCAPE", ".")
	}

	_, err = pipe.Exec()
	if err != nil && errs.Cause(err) != redis.Nil {
		fmt.Println("GetVirtualMatchIDs pipe.Exec err:", err)
		return nil, err
	}

	data := make([]utils.GameIndex, 0)
	for _, cmd := range cmds {
		val, err := cmd.Result()
		if err != nil {
			fmt.Printf("GetVirtualMatchIDs Redis Error:%s, CMD:%s\n", err.Error(), cmd.Args())
			continue
		}

		mch := utils.GameIndex{}
		err = helper.JsonUnmarshalFromString(val.(string), &mch)
		if err != nil {
			continue
		}
		if mch.BatchNo == bachNo {
			data = append(data, mch)
		}
	}

	return data, nil
}

/**
 * @Description: 从redis 获取虚拟赛事视频链接 和比分进程
 * @Author:Sven
 * @Date:2022/4/13 15:44
 * @LastEditTime: 2022/4/13 15:44
 * @LastEditors: Sven
 */
func VirtualVideoRpl(gameID, tourID, batchNo string) (string, error) {

	key := fmt.Sprintf(utils.RedisGameSportsVideoBatch, gameID, tourID, batchNo)
	rplJSON, err := mt.ZKRedisCluster.Do("JSON.GET", key, ".").Text()
	if err != nil {

		fmt.Println("VirtualVideoRpl JSON.GET err :", err.Error())
	}
	return rplJSON, err
}

package model

import (
	"fmt"
	"game/lang"
	"time"
)

var Languages = []string{
	"cn", //简体中文
	"zh", //繁体中文
	"en", //英文
	"vi", //越南文
	"th", //泰文
	"ml", //马来文
}

//国际化名内存数据淘汰及重新加载队列
//var eliminateQueue = list.New()

type i18nDataType int

const (
	RamDataGame       i18nDataType = 1
	RamDataTournament i18nDataType = 2
	RamDataOddType    i18nDataType = 3
	RamDataVirtual    i18nDataType = 4
)

var RamDataName = map[i18nDataType]string{
	RamDataGame:       "Game",
	RamDataTournament: "Tournament",
	RamDataOddType:    "OddType",
	RamDataVirtual:    "Virtual",
}

const (
	defaultGameCacheTimeout       = -1 //游戏国际化名内存数据有效期
	defaultTournamentCacheTimeout = -1 //联赛国际化名内存数据有效期
	defaultOddTypeCacheTimeout    = -1 //玩法国际化名内存数据有效期
	defaultVirtualCacheTimeout    = -1 //虚拟体育国际化名内存数据有效期
)

type EliminateAttr struct {
	ID       string        //内存key
	DataType i18nDataType  //数据类型
	lan      string        //语种
	Ttl      time.Duration //过期时间
}

func MultiLanguageName(flag i18nDataType, ids []string, lan string) map[string]string {

	var (
		cacheLoadIds []string
		k            []byte //内存key
		v            []byte //内存值
		err          error
	)

	if len(ids) == 0 {
		return nil
	}

	st := time.Now()
	defer func() {
		cost := time.Since(st)
		if cost.Seconds() > 3 {
			fmt.Printf("MultiLanguageName slow cost, flag:%d, lan:%s, ids:%+v\n", flag, lan, ids)
		}
	}()

	//客户端语言繁体中文时，联赛名显示简体中文名，客户端语言非简体中文和英文时，全部显示英文名
	if flag == RamDataTournament {
		if lan != lang.CN && lan != lang.EN {
			if lan == lang.ZH {
				lan = lang.CN
			} else {
				lan = lang.EN
			}
		}

	}

	res := map[string]string{}
	for _, id := range ids {
		k = []byte(id + lan)
		switch flag {
		case RamDataGame:
			v, err = mt.ramCacheData.GameName.Get(k)
		case RamDataTournament:
			v, err = mt.ramCacheData.TournamentName.Get(k)
		case RamDataOddType:
			v, err = mt.ramCacheData.OddTypeName.Get(k)
		case RamDataVirtual:
			v, err = mt.ramCacheData.VirtualName.Get(k)
		default:
			return nil

		}

		if err != nil {
			cacheLoadIds = append(cacheLoadIds, id)
			continue
		}

		res[id] = string(v)
	}

	if len(cacheLoadIds) > 0 {
		rk := ""
		field := lan
		switch flag {
		case RamDataGame:
			rk = RedisLangGame
			break
		case RamDataTournament:
			rk = redisHKeyTournament
			field = fmt.Sprintf("%s_name", lan)
			break
		case RamDataOddType:
			rk = RedisLangOddType
			break
		case RamDataVirtual:
			rk = RedisLangSports
		default:
			return res
		}

		data, err := RedisPipelineHMGet(cacheLoadIds, field, rk)
		if err != nil {
			fmt.Printf("%s %s RedisPipelineHMGet error:%s\n", RamDataName[flag], lan, err.Error())
			return res
		}

		for key, value := range data {
			res[key] = value
			if value == "" {
				continue
			}

			k = []byte(key + lan)
			//对应语言有设置名称则加载到缓存中
			switch flag {
			case RamDataGame:
				err = mt.ramCacheData.GameName.Set(k, []byte(value), defaultGameCacheTimeout)
			case RamDataTournament:
				err = mt.ramCacheData.TournamentName.Set(k, []byte(value), defaultTournamentCacheTimeout)
			case RamDataOddType:
				err = mt.ramCacheData.OddTypeName.Set(k, []byte(value), defaultOddTypeCacheTimeout)
			case RamDataVirtual:
				err = mt.ramCacheData.VirtualName.Set(k, []byte(value), defaultVirtualCacheTimeout)
			default:
				return nil
			}

			if err != nil {
				fmt.Printf("%s %s RedisPipelineHMGet error:%s\n", RamDataName[flag], lan, err.Error())
				continue
			}
		}
	}

	return res
}

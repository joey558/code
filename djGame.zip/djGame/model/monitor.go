package model

import (
	"fmt"
	"game/helper"
	"game/utils"
	"github.com/go-redis/redis/v7"
	"github.com/shopspring/decimal"
	"strconv"
)

// Monitor 监控预警
type Monitor struct {
	ID                  string `db:"id" json:"id"`                                       //  盘口id(盘口类型数据 )/赛事id+类型(其他类型数据)
	MatchId             string `db:"match_id" json:"match_id"`                           //  赛事id
	Total               string `db:"total" json:"total"`                                 //  已用赔付统计
	PrizeMax            int    `db:"prize_max" json:"prize_max"`                         //  最大赔付限额
	Kind                int    `db:"kind" json:"kind"`                                   //  1-普通串关赛事总赔付 2-复合玩法总赔付 3-局内串关总赔付 4-赛事总赔付 5-盘口总赔付
	MatchLevel          int    `db:"match_level" json:"match_level"`                     //  赛事等级 1-m1 2-m2 3-m3 4-m4 ... 9999 m9999
	GameId              string `db:"game_id" json:"game_id"`                             //  游戏id
	IsLive              int    `db:"is_live" json:"is_live"`                             //  赛事阶段 1-初盘 2-滚盘
	Category            int    `db:"category" json:"category"`                           //  赛事类型 正常-1 冠军-2 大逃杀-3 篮球-4 主播盘-5 足球-6
	Bo                  int    `db:"bo" json:"bo"`                                       //  赛制
	StartTime           int64  `db:"start_time" json:"start_time"`                       //  开始时间
	TournamentId        string `db:"tournament_id" json:"tournament_id"`                 //  联赛id
	TournamentShortName string `db:"tournament_short_name" json:"tournament_short_name"` //  联赛名称
	CreditLevel         int    `db:"credit_level" json:"credit_level"`                   //  信用赛事等级
	MatchCnTeam         string `db:"match_cn_team" json:"match_cn_team"`                 //  队伍中文名称
	MatchEnTeam         string `db:"match_en_team" json:"match_en_team"`                 //  队伍英文名称
	MsgKind             int    `db:"-" json:"msg_kind"`                                  //  消息类型
	Round               int    `db:"round" json:"round"`                                 //  局数
	MarketCnName        string `db:"market_cn_name" json:"market_cn_name"`               //  盘口中文名称
	MarketEnName        string `db:"market_en_name" json:"market_en_name"`               //  盘口英文名称
	OptionType          int    `db:"option_type" json:"option_type"`                     //  玩法类型 1-输赢 2-让分 3-大小 4趣味 5-波胆 6-胜负平 7-单双 8-是否 9-复合
}

// GlobalTotalUpdate
/**
* @Description: 赛事全局已使用额度统计
* @Author: noah
* @Date: 2022/3/6 16:23
* @LastEditTime:2022/3/6 16:23
* @LastEditors: noah
 */
func GlobalTotalUpdate(mktTotal map[string]map[string]decimal.Decimal, compTotal, mixTotal, randTotal, mchTotal map[string]decimal.Decimal, handicap utils.HandicapData) error {

	pipe := mt.ZKRedisCluster.Pipeline()
	globalTotalUpdateFormMap(pipe, compTotal, MonitorTypeComp, handicap)     // 普通赛事串注全局赔付统计
	globalTotalUpdateFormMap(pipe, mixTotal, MonitorTypeMix, handicap)       // 复合玩法赛事全局赔付统计
	globalTotalUpdateFormMap(pipe, randTotal, MonitorTypeRound, handicap)    // 局内玩法赛事全局赔付统计
	globalTotalUpdateFormMap(pipe, mchTotal, MonitorTypeMatch, handicap)     // 赛事全局赔付统计
	globalTotalUpdateFormSubMap(pipe, mktTotal, MonitorTypeMarket, handicap) // 盘口全局赔付统计
	_, err := pipe.Exec()

	return err
}

/**
* @Description: 推送盘口级监控消息
* @Author: noah
* @Date: 2022/3/25 13:55
* @LastEditTime:2022/3/25 13:55
* @LastEditors: noah
 */
func globalTotalUpdateFormSubMap(pipe redis.Pipeliner, data map[string]map[string]decimal.Decimal, kind int, handicap utils.HandicapData) {

	for mchId, mktData := range data {
		for mkt, total := range mktData {
			toString, _ := helper.MarshalToString(Monitor{
				ID:                  mkt,
				MatchId:             mchId,
				Total:               total.Round(3).String(),
				PrizeMax:            getLevelLimit(handicap.Matches[mchId].MatchLevel, kind),
				Kind:                kind,
				MatchLevel:          handicap.Matches[mchId].MatchLevel,
				CreditLevel:         handicap.Matches[mchId].CreditLevel,
				GameId:              handicap.Matches[mchId].GameID,
				IsLive:              handicap.Matches[mchId].IsLive,
				Category:            handicap.Matches[mchId].Category,
				Bo:                  handicap.Matches[mchId].Bo,
				StartTime:           handicap.Matches[mchId].StartTime,
				TournamentId:        handicap.Matches[mchId].TournamentID,
				TournamentShortName: handicap.Matches[mchId].TournamentShortName,
				MatchCnTeam:         handicap.Matches[mchId].MatchCnTeam,
				MatchEnTeam:         handicap.Matches[mchId].MatchEnTeam,
				Round:               handicap.Markets[mkt].Round,
				MarketCnName:        handicap.Markets[mkt].CnName,
				MarketEnName:        handicap.Markets[mkt].EnName,
				OptionType:          handicap.Markets[mkt].OptionType,
			})
			pipe.LPush(RedisKeyMonitorChannel, toString)
		}
	}
}

/**
* @Description: 推送赛事级监控消息
* @Author: noah
* @Date: 2022/3/25 13:55
* @LastEditTime:2022/3/25 13:55
* @LastEditors: noah
 */
func globalTotalUpdateFormMap(pipe redis.Pipeliner, data map[string]decimal.Decimal, kind int, handicap utils.HandicapData) {

	for mchId, m := range data {
		prizeMax := int(handicap.Matches[mchId].MchsCompPrizeTotalLimit)
		if kind != MonitorTypeComp {
			prizeMax = getLevelLimit(handicap.Matches[mchId].MatchLevel, kind)
		}
		toString, _ := helper.MarshalToString(Monitor{
			ID:                  fmt.Sprintf("%s%d", mchId, kind),
			MatchId:             mchId,
			Total:               m.Round(3).String(),
			PrizeMax:            prizeMax,
			Kind:                kind,
			MatchLevel:          handicap.Matches[mchId].MatchLevel,
			CreditLevel:         handicap.Matches[mchId].CreditLevel,
			GameId:              handicap.Matches[mchId].GameID,
			IsLive:              handicap.Matches[mchId].IsLive,
			Category:            handicap.Matches[mchId].Category,
			Bo:                  handicap.Matches[mchId].Bo,
			StartTime:           handicap.Matches[mchId].StartTime,
			TournamentId:        handicap.Matches[mchId].TournamentID,
			TournamentShortName: handicap.Matches[mchId].TournamentShortName,
			MatchCnTeam:         handicap.Matches[mchId].MatchCnTeam,
			MatchEnTeam:         handicap.Matches[mchId].MatchEnTeam,
		})
		pipe.LPush(RedisKeyMonitorChannel, toString)
	}
}

/**
* @Description: 获取赛事等级监控预警限额
* @Author: noah
* @Date: 2022/3/25 13:55
* @LastEditTime:2022/3/25 13:55
* @LastEditors: noah
 */
func getLevelLimit(level, kind int) int {

	key := fmt.Sprintf(RedisKeyMatchLevelGlobalLimit, level)
	var filed string
	switch kind {
	case MonitorTypeMix:
		filed = MchMixPrizeLimit
	case MonitorTypeRound:
		filed = MchRndPrizeLimit
	case MonitorTypeMatch:
		filed = MchPrizeLimit
	case MonitorTypeMarket:
		filed = MchMktPrizeLimit
	default:
		return defaultMaxPrizeLimit
	}

	result, err := mt.ZKRedisCluster.HGet(key, filed).Result()
	if err != nil {
		fmt.Println(err.Error())
		return defaultMaxPrizeLimit
	}

	amount, err := strconv.Atoi(result)
	if err != nil {
		fmt.Println(err.Error())
		return defaultMaxPrizeLimit
	}

	return amount
}

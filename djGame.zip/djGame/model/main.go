package model

import (
	"fmt"
	"game/contrib/session"
	"game/contrib/zlog"
	"game/helper"
	"game/utils"
	"game/wallet"
	"github.com/coocood/freecache"
	errs "github.com/pkg/errors"
	"log"
	"os"
	"runtime"
	"strings"
	"sync"
	"time"

	"github.com/beanstalkd/go-beanstalk"
	"github.com/scylladb/go-set/strset"
	"github.com/shopspring/decimal"
	"github.com/valyala/fasthttp"

	mqtt "github.com/eclipse/paho.mqtt.golang"
	"github.com/go-redis/redis/v7"
	"github.com/jmoiron/sqlx"
	"github.com/olivere/elastic/v7"
	"github.com/panjf2000/ants/v2"
	cpool "github.com/silenceper/pool"
)

type MetaTable struct {
	Config                Conf // 全局配置信息
	MPool                 *ants.PoolWithFunc
	BPool                 *ants.PoolWithFunc
	MerchantRedis         *redis.Client
	ZKRedisCluster        *redis.ClusterClient
	MerchantDB            *sqlx.DB
	MerchantSlaveDB       *sqlx.DB
	BeanPool              cpool.Pool
	ZkBeanPool            cpool.Pool
	Notify                mqtt.Client
	Es                    *elastic.Client
	StartWay              int
	ZkEs                  *elastic.Client
	idxCachePool          *ants.PoolWithFunc //首页数据协程池
	ramCacheData          CacheData
	hotMchSize            int
	SportsGameDataMap     map[string]SportsTourCupData
	SportsPlayTypeDataMap map[string]PlayTypeData
}

type CreditCfg struct {
	Support           int               `json:"support"`             // 是否支持信用盘 0-不支持，1-支持
	SecretKey         string            `json:"secret_key"`          // 信用网商户秘钥
	CentralWalletHost string            `json:"central_wallet_host"` // 中心钱包接口地址
	Timeout           int               `json:"timeout"`             // 中心钱包接口超时时间
	RetryNum          int               `json:"retry_num"`           // 中心钱包接口重试次数
	XywMemberQuota    string            `json:"xyw_member_quota"`    // 信用网会员默认限额
	LimitOddThreshold string            `json:"limit_odd_threshold"` // 信用网风控限额赔率阈值
	Games             map[string]uint64 `json:"games"`               // 游戏map
	DisableGame       []string          `json:"disable_game"`        // 信用网关闭指定游戏投注
}

type Mqtt struct {
	Addr     []string `json:"addr"`
	Username string   `json:"username"`
	Password string   `json:"password"`
}

var (
	mt                      MetaTable
	CreditLimitOddThreshold = "2.000"
	MerchantFilterGame      map[uint64]*strset.Set

	clBetOrder          = utils.EnumFields(BetOrder{})
	clOrderDetail       = utils.EnumFields(OrderDetailData{})
	clFundResponse      = utils.EnumFields(FundResponse{})
	clMemberTheoryPrize = utils.EnumFields(MemberTheoryPrize{})
	clComplexBetDetail  = utils.EnumFields(ComplexBetDetail{})
	clMerchant          = utils.EnumFields(Merchant{})
)

var (
	DeciOne                 = decimal.NewFromInt32(1)
	DeciHundred             = decimal.NewFromInt32(100)
	DeciPrize               = decimal.NewFromInt32(5000)                                                                                                                               //中奖提示金额
	RiskSettingFields       = []string{"simple_min_bet", "complex_min_bet", "round_complex_max_odd"}                                                                                   //总控基本风控参数字段
	MemberRiskSettingFields = []string{"simple", "complex", "league", "handicap", "simple_limit", "limit_status", "mch_comp", "rnd_comp", "rnd_comp_mch", "mix_mch", "mch_comp_limit"} //会员风控参数字段
)

const (
	DbQuery = iota
	EsQuery
)

// Conf 配置结构体
type Conf struct {
	MerchantName string   `json:"merchant_name"`
	GameIDs      []string `json:"gameid"`
	Game         struct {
		Addr string `json:"addr"`
	} `json:"game"`
	Admin struct {
		Addr string `json:"addr"`
	} `json:"admin"`
	API struct {
		Addr string `json:"addr"`
	} `json:"api"`
	Db struct {
		Addr        string `json:"addr"`
		MaxIdleConn int    `json:"max_idle_conn"`
		MaxOpenConn int    `json:"max_open_conn"`
	} `json:"db"`
	SlaveDb struct {
		Addr        string `json:"addr"`
		MaxIdleConn int    `json:"max_idle_conn"`
		MaxOpenConn int    `json:"max_open_conn"`
	} `json:"slave_db"`
	ZKRedisCluster struct {
		Addr     []string `json:"addr"`
		Password string   `json:"password"`
	} `json:"zk_redis_cluster"`
	MerchantRedis struct {
		Addr     []string `json:"addr"`
		Password string   `json:"password"`
		Sentinel string   `json:"sentinel"`
		Db       int      `json:"db"`
	} `json:"merchant_redis"`
	Beanstalk   string `json:"beanstalk"`
	ZkBeanstalk string `json:"zk_beanstalk"`
	Mqtt        Mqtt   `json:"mqtt"`
	Zlog        struct {
		Brokers []string `json:"brokers"`
		URI     string   `json:"uri"`
	} `json:"zlog"`
	Elasticsearch struct {
		Host        []string `json:"host"`
		IndexPrefix string   `json:"index_prefix"`
	} `json:"elasticsearch"`
	Credit          CreditCfg `json:"credit"`
	ZkElasticsearch struct {
		Host        []string `json:"host"`
		IndexPrefix string   `json:"index_prefix"`
	} `json:"zk_elasticsearch"`
	ForeCastInfo utils.ForeCastConfig `json:"forecast_info"`
	TYApiConf    tyAPIConf            `json:"ty_api_conf"`
}

/**
 * @Description: 初始化
 * @Author: wesley
 * @Date: 2020/6/15 13:38
 * @LastEditTime: 2020/6/15 13:38
 * @LastEditors: wesley
 */
func Constructor(cfg Conf) {
	startWay := "mysql"
	if os.Args[3] == "es" {
		startWay = os.Args[3]
	}

	mt.Config = cfg
	mt.MerchantDB = initDB(cfg.Db.Addr, cfg.Db.MaxIdleConn, cfg.Db.MaxOpenConn)
	mt.MerchantSlaveDB = initSlaveDB(cfg.SlaveDb.Addr, cfg.SlaveDb.MaxIdleConn, cfg.SlaveDb.MaxOpenConn)
	mt.ZKRedisCluster = initRedisCluster(cfg.ZKRedisCluster.Addr, cfg.ZKRedisCluster.Password)
	mt.MerchantRedis = initRedisSentinel(cfg.MerchantRedis.Addr, cfg.MerchantRedis.Password, cfg.MerchantRedis.Sentinel, cfg.MerchantRedis.Db)
	mt.BeanPool = initBeanstalk(cfg.Beanstalk)
	mt.ZkBeanPool = initBeanstalk(cfg.ZkBeanstalk)
	mt.Notify = initMqttService(cfg.Mqtt)
	mt.hotMchSize = 5 //默认加载5条热门赛事盘口

	session.New(mt.MerchantRedis)
	zlog.New(cfg.Zlog.Brokers, cfg.Zlog.URI)

	InitMerchantFilterGame()

	initSportsTourCupData()

	initSportsPlayTypeData()

	mt.ramCacheData = CacheData{
		FilterGame:     sync.Map{},
		LiveMatch:      sync.Map{},
		LiveMarketIds:  sync.Map{},
		EarlyMatch:     sync.Map{},
		Recommend:      sync.Map{},
		Nav:            sync.Map{},
		Stat:           sync.Map{},
		Notice:         sync.Map{},
		GameName:       freecache.NewCache(10 * 1024 * 1024),
		TournamentName: freecache.NewCache(100 * 1024 * 1024),
		OddTypeName:    freecache.NewCache(500 * 1024 * 1024),
		VirtualName:    freecache.NewCache(500 * 1024 * 1024),
	}
	// 初始化首页赛事数据数据syncMap操作协程池
	mt.idxCachePool, _ = ants.NewPoolWithFunc(500, func(payload interface{}) {
		if m, ok := payload.(IdxCache); ok {
			for {
				time.Sleep(m.RefreshTime)
				res := RefreshRamData(m.Key)
				//内存数据更新失败时，清除内存中的旧数据
				if !res {
					switch m.Key {
					case "recommend": //推荐赛事
						mt.ramCacheData.Recommend.Delete(m.Key)
					case "stat": //赛事计数
						mt.ramCacheData.Stat.Delete(m.Key)
					case "nav": //游戏列表
						mt.ramCacheData.Nav.Delete(m.Key)
					case "notice": //公告
						mt.ramCacheData.Notice.Delete(m.Key)
					default:
						if strings.Contains(m.Key, "live") { //滚球赛事
							mt.ramCacheData.LiveMarketIds.Range(func(key, value interface{}) bool {
								mt.ramCacheData.LiveMarketIds.Delete(key)
								return true
							})
						} else if strings.Contains(m.Key, "early") { //早盘赛事
							mt.ramCacheData.EarlyMatch.Delete(m.Key)
						} else if strings.Contains(m.Key, "notice") {
							mt.ramCacheData.Notice.Delete(m.Key)
						}
					}
					keyLock.Delete(m.Key)
					break
				}
			}
		}
	})

	// 热门赛事盘口数据reload
	//go ReloadHotMchMarket()
	// 国际化内存数据淘汰及更新
	//go eliminateHandle()

	// 初始化mqtt推送协程池
	mt.MPool, _ = ants.NewPoolWithFunc(500, func(payload interface{}) {

		n, ok := payload.(Notify)
		if !ok {
			return
		}

		BetNotify(n)
	})
	// 初始化beanstalk推送协程池
	mt.BPool, _ = ants.NewPoolWithFunc(500, func(payload interface{}) {

		b, ok := payload.(BeansProducerAttr)
		if !ok {
			return
		}

		_ = BeansAddTask(b)
	})
	mt.ZkEs = InitES(cfg.ZkElasticsearch.Host)
	if startWay == "es" {
		mt.Es = InitES(cfg.Elasticsearch.Host)
		mt.StartWay = EsQuery
	}
	if mt.Config.Credit.LimitOddThreshold != "" {
		CreditLimitOddThreshold = mt.Config.Credit.LimitOddThreshold
	}
	CreditOddLimit, _ = decimal.NewFromString(CreditLimitOddThreshold)
	// 初始化ForeCast配置
	utils.InitForeCastConfig(cfg.ForeCastInfo)
	wallet.XywHost = mt.Config.Credit.CentralWalletHost
	wallet.XywHttpTimeout = time.Duration(mt.Config.Credit.Timeout) * time.Second
	wallet.XywSecretKey = mt.Config.Credit.SecretKey
	// 加载赛事计时器数据
	TimersInit()

	// 启动体育的协程池
	startTYPool()
}

func MTGet() MetaTable {
	return mt
}

type LogLevel string

const (
	LogInfo  LogLevel = "INFO"
	LogError LogLevel = "ERROR"

	LogFlag = "djGame"
)

func AddLog(level LogLevel, flag string, cid interface{}, format string, v ...interface{}) {

	_, file, line, _ := runtime.Caller(1)
	loc := fmt.Sprintf("%s:%d", file, line)
	msg := fmt.Sprintf(format, v...)

	fmt.Println(time.Now().Format("2006-01-02 15:04:05.000"), "|", level, "|", loc, "|", cid, "|", msg)

	if level == LogInfo {
		zlog.Info(nil, flag, loc, msg, cid, 0)
	} else {
		zlog.Error(nil, flag, loc, msg, cid, 0)
	}
}

/**
 * @Description: 初始化db
 * @Author: wesley
 * @Date: 2020/6/15 13:33
 * @LastEditTime: 2020/6/15 13:33
 * @LastEditors: wesley
 */
func initDB(dsn string, maxIdleConn, maxOpenConn int) *sqlx.DB {

	db, err := sqlx.Connect("mysql", dsn)
	if err != nil {
		log.Fatalln(err)
	}

	db.SetMaxOpenConns(maxOpenConn)
	db.SetMaxIdleConns(maxIdleConn)
	db.SetConnMaxLifetime(time.Second * 30)
	err = db.Ping()
	if err != nil {
		log.Fatalln(err)
	}

	return db
}

/**
 * @Description: 初始化商户slave db
 * @Author: awen
 * @Date: 2020/9/3 20:19
 * @LastEditTime: 2020/9/3 20:19
 * @LastEditors: awen
 */
func initSlaveDB(dsn string, maxIdleConn, maxOpenConn int) *sqlx.DB {

	db, err := sqlx.Connect("mysql", dsn)
	if err != nil {
		log.Fatalln(err)
	}

	db.SetMaxOpenConns(maxOpenConn)
	db.SetMaxIdleConns(maxIdleConn)
	db.SetConnMaxLifetime(time.Second * 30)
	err = db.Ping()
	if err != nil {
		log.Fatalf("init MerchantSlaveDB failed: %s", err.Error())
	}

	return db
}

/**
 * @Description: 初始化redis
 * @Author: wesley
 * @Date: 2020/6/15 13:33
 * @LastEditTime: 2020/6/15 13:33
 * @LastEditors: wesley
 */
func initRedisSentinel(dsn []string, psd, name string, db int) *redis.Client {

	reddb := redis.NewFailoverClient(&redis.FailoverOptions{
		MasterName:    name,
		SentinelAddrs: dsn,
		Password:      psd, // no password set
		DB:            db,  // use default DB
		DialTimeout:   10 * time.Second,
		ReadTimeout:   30 * time.Second,
		WriteTimeout:  30 * time.Second,
		PoolSize:      100,
		PoolTimeout:   30 * time.Second,
		MaxRetries:    2,
		IdleTimeout:   5 * time.Minute,
	})
	pong, err := reddb.Ping().Result()
	if err != nil {
		log.Fatalf("initRedisSentinel failed: %s", err.Error())
	}
	fmt.Println(pong, err)

	return reddb
}

/**
* @Description: 初始化redis
* @Author: noah
* @Date: 2021/9/28 19:14
* @LastEditTime:2021/9/28 19:14
* @LastEditors: noah
 */
func initRedisSlave(dsn string, psd string) *redis.Client {

	reddb := redis.NewClient(&redis.Options{
		Addr:         dsn,
		Password:     psd, // no password set
		DB:           0,   // use default DB
		DialTimeout:  10 * time.Second,
		ReadTimeout:  30 * time.Second,
		WriteTimeout: 30 * time.Second,
		PoolSize:     100,
		PoolTimeout:  30 * time.Second,
		MaxRetries:   2,
		IdleTimeout:  5 * time.Minute,
	})
	pong, err := reddb.Ping().Result()
	if err != nil {
		log.Fatalf("initRedisSlave failed: %s", err.Error())
	}
	fmt.Println(pong, err)

	return reddb
}

/**
* @Description: 初始化redis集群客户端
* @Author: awen
* @Date: 2022-02-08 15:37
* @LastEditTime: 2022-02-08 15:37
* @LastEditors: awen
 */
func initRedisCluster(dsn []string, pwd string) *redis.ClusterClient {

	clusterClient := redis.NewClusterClient(&redis.ClusterOptions{
		Addrs:          dsn,              // 集群节点地址，理论上只要填一个可用的节点客户端就可以自动获取到集群的所有节点信息。但是最好多填一些节点以增加容灾能力，因为只填一个节点的话，如果这个节点出现了异常情况，则Go应用程序在启动过程中无法获取到集群信息。
		Password:       pwd,              // 密码
		MaxRedirects:   8,                // 当遇到网络错误或者MOVED/ASK重定向命令时，最多重试几次，默认8
		ReadOnly:       false,            // 只含读操作的命令的"节点选择策略"。默认都是false，即只能在主节点上执行。 置为true则允许在从节点上执行只含读操作的命令
		RouteByLatency: false,            // 默认false。 置为true则ReadOnly自动置为true,表示在处理只读命令时，可以在一个slot对应的主节点和所有从节点中选取Ping()的响应时长最短的一个节点来读数据
		RouteRandomly:  false,            // 默认false。置为true则ReadOnly自动置为true,表示在处理只读命令时，可以在一个slot对应的主节点和所有从节点中随机挑选一个节点来读数据
		DialTimeout:    10 * time.Second, // 设置连接超时
		ReadTimeout:    30 * time.Second, // 设置读取超时
		WriteTimeout:   30 * time.Second, // 设置写入超时
		PoolSize:       100,              // 连接池最大socket连接数，默认为5倍CPU数， 5 * runtime.NumCPU
		MinIdleConns:   10,               // 在启动阶段创建指定数量的Idle连接，并长期维持idle状态的连接数不少于指定数量；。
		PoolTimeout:    30 * time.Second, // 当所有连接都处在繁忙状态时，客户端等待可用连接的最大等待时长，默认为读超时+1秒。
		MaxRetries:     2,                // 命令执行失败时，最多重试多少次，默认为0即不重试
		IdleTimeout:    5 * time.Minute,  // 闲置超时，默认5分钟，-1表示取消闲置超时检查
	})

	_, err := clusterClient.Ping().Result()
	if err != nil {
		log.Fatalln(err.Error())
	}

	return clusterClient
}

/**
 * @Description: 初始化beanstalk
 * @Author: wesley
 * @Date: 2020/6/15 13:32
 * @LastEditTime: 2020/6/15 13:32
 * @LastEditors: wesley
 */
func initBeanstalk(beanstalkConn string) cpool.Pool {

	factory := func() (interface{}, error) { return beanstalk.Dial("tcp", beanstalkConn) }
	closed := func(v interface{}) error { return v.(*beanstalk.Conn).Close() }
	poolConfig := &cpool.Config{
		InitialCap:  50,   // 资源池初始连接数
		MaxIdle:     50,   // 最大空闲连接数
		MaxCap:      1000, // 最大并发连接数
		Factory:     factory,
		Close:       closed,
		IdleTimeout: 15 * time.Second,
	}

	beanPool, err := cpool.NewChannelPool(poolConfig)
	if err != nil {
		log.Fatalln(err)
	}
	return beanPool
}

/**
 * @Description: 初始化mqtt
 * @Author: wesley
 * @Date: 2020/6/15 13:35
 * @LastEditTime: 2020/6/15 13:35
 * @LastEditors: wesley
 */
func initMqttService(mqttCfg Mqtt) mqtt.Client {

	clientOptions := mqtt.NewClientOptions().
		SetClientID(fmt.Sprintf("%d", helper.Cputicks())).
		SetCleanSession(false).
		SetAutoReconnect(true).
		SetKeepAlive(120 * time.Second).
		SetPingTimeout(10 * time.Second).
		SetWriteTimeout(10 * time.Second).
		SetMaxReconnectInterval(10 * time.Second).
		SetUsername(mqttCfg.Username).
		SetPassword(mqttCfg.Password)

	for _, v := range mqttCfg.Addr {
		clientOptions.AddBroker(v)
	}

	client := mqtt.NewClient(clientOptions)
	if conn := client.Connect(); conn.WaitTimeout(time.Duration(10)*time.Second) && conn.Wait() && conn.Error() != nil {
		log.Fatalf("token: %s", conn.Error())
	}
	return client
}

/**
* @Description: 初始化ES
* @Author: noah
* @Date: 2021/9/28 19:14
* @LastEditTime:2021/9/28 19:14
* @LastEditors: noah
 */
func InitES(url []string) *elastic.Client {

	client, err := elastic.NewClient(elastic.SetSniff(false), elastic.SetURL(url...))
	if err != nil {
		log.Fatal(err)
	}

	return client
}

// ServerStop
/**
* @Description: 服务停止
* @Author: noah
* @Date: 2021/9/28 17:47
* @LastEditTime:2021/9/28 17:47
* @LastEditors: noah
 */
func ServerStop(srv *fasthttp.Server) error {

	defer func() {
		mt.MPool.Release()
		mt.BPool.Release()
		_ = mt.ZKRedisCluster.Close()
		_ = mt.MerchantRedis.Close()
		_ = mt.MerchantDB.Close()
		_ = mt.MerchantSlaveDB.Close()
		if mt.StartWay == EsQuery {
			mt.ZkEs.Stop()
			mt.Es.Stop()
		}
		mt.Notify.Disconnect(250)
	}()

	return srv.Shutdown()
}

/*
 * @Description: 获取联赛数据-虚拟体育
 * @Author: robin
 * @Date: 2022/4/5 21:01
 * @LastEditTime: 2022/4/5 21:01
 * @LastEditors: robin
 */
func initSportsTourCupData() {

	result, err := mt.ZKRedisCluster.Get(utils.RedisTourCupData).Result()
	if err != nil {
		if errs.Cause(err) != redis.Nil {
			fmt.Printf("【联赛信息-虚拟体育】SportsTourCupDataGet-Get, 获取缓存 Result Error[%s].\n", err.Error())
		}
		return
	}

	var sportsDataSlice []SportsTourCupData
	err = helper.JsonUnmarshal([]byte(result), &sportsDataSlice)
	if err != nil {
		fmt.Printf("【联赛信息-虚拟体育】SportsTourCupDataGet-JsonUnmarshal, 获取缓存 Result Error[%s].\n", err.Error())
		return
	}

	mt.SportsGameDataMap = map[string]SportsTourCupData{}
	for _, data := range sportsDataSlice {
		mt.SportsGameDataMap[data.ID] = data
	}

}

/*
 * @Description: 获取玩法分类数据-虚拟体育
 * @Author: robin
 * @Date: 2022/4/10 20:15
 * @LastEditTime: 2022/4/10 20:15
 * @LastEditors: robin
 */
func initSportsPlayTypeData() {

	result, err := mt.ZKRedisCluster.Get(utils.RedisSportsPlayType).Result()
	if err != nil {
		if errs.Cause(err) != redis.Nil {
			fmt.Printf("【玩法分类信息-虚拟体育】SportsPlayTypeData-Get, 获取缓存 Result Error[%s].\n", err.Error())
		}
		return
	}

	var sportsPlayTypeSlice []PlayTypeData
	err = helper.JsonUnmarshal([]byte(result), &sportsPlayTypeSlice)
	if err != nil {
		fmt.Printf("【玩法分类信息-虚拟体育】SportsPlayTypeData-JsonUnmarshal, 获取缓存 Result Error[%s].\n", err.Error())
		return
	}

	mt.SportsPlayTypeDataMap = map[string]PlayTypeData{}
	for _, data := range sportsPlayTypeSlice {
		mt.SportsPlayTypeDataMap[data.ID] = data
	}
}

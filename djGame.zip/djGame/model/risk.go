package model

import (
	"errors"
	"fmt"
	"game/contrib/zlog"
	"game/helper"
	"game/lang"
	"game/utils"
	g "github.com/doug-martin/goqu/v9"
	"github.com/go-redis/redis/v7"
	"github.com/golang-module/carbon"
	"github.com/valyala/fasthttp"
	"strconv"
	"strings"

	fund "game/wallet"

	"github.com/shopspring/decimal"
)

// 单局串关风控参数
type RndCompRiskParam struct {
	RndCompPrizeLimit    decimal.Decimal // 单局串关单注最高赔付
	RndCompMchPrizeLimit decimal.Decimal // 单局串关赛事最高赔付
}

// MemberSurplusQuota 会员投注项限额
type MemberSurplusQuota struct {
	SimpleMin           decimal.Decimal `json:"simple_min"`            //单注最低限额
	SimpleMax           decimal.Decimal `json:"simple_max"`            //单注最高赔付
	PrizeStaticProfit   string          `json:"prize_static_profit"`   //单注限红值和单注最高赔付/(投注项赔率-1)之间取最低值
	ComplexMin          decimal.Decimal `json:"complex_min"`           //串关最低限额
	ComplexMaxPrize     decimal.Decimal `json:"complex_max_prize"`     //串关最高赔付
	RndCompMaxPrize     decimal.Decimal `json:"rnd_comp_max_prize"`    //局内串关最高赔付
	RndCompMaxOdd       decimal.Decimal `json:"rnd_comp_max_odd"`      //局内串关最多赔率
	MixPrizeLimit       decimal.Decimal `json:"mix_prize_limit"`       //复合玩法最多赔率
	WinBalance          decimal.Decimal `json:"win_balance"`           //会员单日剩余派彩金额
	SimplePrizeBalance  decimal.Decimal `json:"simple_prize_balance"`  //会员单日单关剩余赔付额度
	ComplexPrizeBalance decimal.Decimal `json:"complex_prize_balance"` //会员单日串关剩余赔付额度
	*CreditLimit
	*MemberLimit
}

// MemberLimit 现金网会员限额
type MemberLimit struct {
	MatchCompLimit      decimal.Decimal `json:"match_comp_limit"`       //赛事总串注限额
	MatchLevelCompLimit decimal.Decimal `json:"match_level_comp_limit"` //赛事等级串注限额
	MktCompPrizeLimit   decimal.Decimal `json:"mkt_comp_prize_limit"`   //盘口赔付限额
	Limit2              decimal.Decimal `json:"limit2"`                 //2串1限额
	Limit3              decimal.Decimal `json:"limit3"`                 //3串1限额
	Limit4              decimal.Decimal `json:"limit4"`                 //4串1限额
	Limit5              decimal.Decimal `json:"limit5"`                 //5串1限额
	Limit6              decimal.Decimal `json:"limit6"`                 //6串1限额
	Limit7              decimal.Decimal `json:"limit7"`                 //7串1限额
	Limit8              decimal.Decimal `json:"limit8"`                 //8串1限额
	Limit9              decimal.Decimal `json:"limit9"`                 //9串1限额
	Limit10             decimal.Decimal `json:"limit10"`                //10串1限额
}

// CreditLimit 信用网会员限额
type CreditLimit struct {
	CreditSimpleMax         decimal.Decimal `json:"credit_simple_max"`          //信用盘单注最高投注额度
	CreditAgentMatchLimit   string          `json:"credit_agent_match_limit"`   //信用盘代理赛事赔付限额
	CreditAgentMarketLimit  string          `json:"credit_agent_market_limit"`  //信用盘代理玩法赔付限额
	CreditMemberMarketLimit string          `json:"credit_member_market_limit"` //信用盘会员玩法赔付限额
	CreditMemberBetLimit    decimal.Decimal `json:"credit_member_bet_limit"`    //信用盘会员玩法最大投注额
	CreditLimit2            string          `json:"credit_limit_2"`             //信用盘2串1限额
	CreditLimit3            string          `json:"credit_limit_3"`             //信用盘3串1限额
	CreditLimit4            string          `json:"credit_limit_4"`             //信用盘4串1限额
	CreditLimit5            string          `json:"credit_limit_5"`             //信用盘5串1限额
	CreditLimit6            string          `json:"credit_limit_6"`             //信用盘6串1限额
	CreditLimit7            string          `json:"credit_limit_7"`             //信用盘7串1限额
	CreditLimit8            string          `json:"credit_limit_8"`             //信用盘8串1限额
	CreditLimit9            string          `json:"credit_limit_9"`             //信用盘9串1限额
	CreditLimit10           string          `json:"credit_limit_10"`            //信用盘10串1限额
}
type MemberLimitData struct {
	MapData map[string]string
	Limit   MemberLimit
}

var (
	DecimalOne = decimal.NewFromInt(1)
	decimalTwo = decimal.NewFromInt(2)
)

// GetRiskSetting
/**
 * @Description: 读取风控基础配置
 * @Author: wesley
 * @Date: 2020/6/14 14:15
 * @LastEditTime: 2020/6/14 14:15
 * @LastEditors: wesley
 */
func GetRiskSetting(tag int, key, lan string, fields []string) (map[string]decimal.Decimal, error) {

	dataMap := map[string]decimal.Decimal{}

	res, err := mt.ZKRedisCluster.Exists(key).Result()
	if err != nil {
		return nil, errors.New(lang.Text(lan, "errRiskRead"))
	}

	if res == 0 {
		return dataMap, nil
	}

	values, err := mt.ZKRedisCluster.HMGet(key, fields...).Result()
	if err != nil {
		return nil, errors.New(lang.Text(lan, "errRiskRead"))
	}

	for k, v := range values {
		if v == nil {
			continue
		}
		value, ok := v.(string)
		if !ok {
			return nil, errors.New(lang.Text(lan, "errRiskRead"))
		}
		if value == "-1" {
			continue
		}
		v, err := strconv.Atoi(value)
		if err != nil {
			return dataMap, errors.New(lang.Text(lan, "errRiskBasic"))
		}
		dataMap[fields[k]] = decimal.NewFromInt32(int32(v))
	}

	return dataMap, nil
}

type MarketRiskLimit struct {
	MktPrizeStaticProfit map[string]int             // 盘口单注限红
	MktLimitVal          map[string]decimal.Decimal // 盘口赔付值
	MchLimitVal          map[string]decimal.Decimal // 赛事赔付值
	ComplexMaxPrize      decimal.Decimal            // 串关赔付
	RndCompMaxPrize      decimal.Decimal            // 局内串关单注赔付
	RndCompMchMaxPrize   decimal.Decimal            // 局内串关赛事赔付
	MixPrizeLimit        decimal.Decimal            // 复合玩法赛事赔付
	MchCompLimit         decimal.Decimal            // 会员普通赛事赔付限额
}

// RiskMarketPrizeLimitCalc
/**
 * @Description: 计算盘口最小赔付值和单注限红
 * @Author: awen
 * @Date: 2020/7/16
 * @LastEditTime: 2020/7/17
 * @LastEditors: awen
 **/
func RiskMarketPrizeLimitCalc(member fund.Member, marketIDs []string, handicaps utils.HandicapData, stat TheoryPrizeStat, lan string) (MarketRiskLimit, error) {

	var (
		mkt          utils.MarketData
		decimalVal   decimal.Decimal
		ok           bool
		err          error
		complexPrize []decimal.Decimal
	)

	data := MarketRiskLimit{
		MktPrizeStaticProfit: map[string]int{},
		MktLimitVal:          map[string]decimal.Decimal{},
		MchLimitVal:          map[string]decimal.Decimal{},
	}

	// 会员限红设置
	memberLimit, err := GetRiskSetting(0, fmt.Sprintf(RedisUserRisk, member.UID), lan, MemberRiskSettingFields)
	if err != nil {
		return data, err
	}

	// 会员限红设置是否开启
	if status, ok := memberLimit["limit_status"]; ok {
		if status.IsZero() { // 未开启会员限红
			memberLimit = map[string]decimal.Decimal{}
		}
	}

	if mchCompLimit, ok := memberLimit["mch_comp_limit"]; ok {
		data.MchCompLimit = mchCompLimit
	}
	// 单局串关赛事赔付
	for _, mch := range handicaps.Matches {

		//赛事的复合玩法赔付
		data.MixPrizeLimit = decimal.NewFromInt32(int32(mch.MixPrizeLimit))
		//如果限红设置开启
		if decimalVal, ok = memberLimit["mix_mch"]; ok {
			// 会员的局内串关单注赔付不为-1并且小于赛事的局内串关单注赔付
			if !decimalVal.IsNegative() && decimalVal.LessThan(data.MixPrizeLimit) {
				data.MixPrizeLimit = decimalVal
			}
		}

		//赛事的局内串关单注赔付
		data.RndCompMaxPrize = decimal.NewFromInt32(int32(mch.RndComplexPrizeLimit))
		//如果限红设置开启
		if decimalVal, ok = memberLimit["rnd_comp"]; ok {
			// 会员的局内串关单注赔付不为-1并且小于赛事的局内串关单注赔付
			if !decimalVal.IsNegative() && decimalVal.LessThan(data.RndCompMaxPrize) {
				data.RndCompMaxPrize = decimalVal
			}
		}

		//赛事的局内串关赛事赔付
		data.RndCompMchMaxPrize = decimal.NewFromInt32(int32(mch.RndComplexMchPrizeLimit))
		//如果限红设置开启
		if decimalVal, ok = memberLimit["rnd_comp_mch"]; ok {
			// 会员的局内串关赛事赔付不为-1并且小于赛事的局内串关赛事赔付
			if !decimalVal.IsNegative() && decimalVal.LessThan(data.RndCompMchMaxPrize) {
				data.RndCompMchMaxPrize = decimalVal
			}
		}

		if decimalVal, ok = stat.MchRoundTheoryPrize[mch.ID]; ok {
			// 会员局内串关单注最高赔付额 - 会员赛事已用赔付额
			//data.RndCompMaxPrize = data.RndCompMaxPrize.Sub(decimalVal)
			// 会员局内串关赛事最高赔付额 - 会员赛事已用赔付额
			data.RndCompMchMaxPrize = data.RndCompMchMaxPrize.Sub(decimalVal)
		}
		data.MixPrizeLimit = decimal.Min(data.MixPrizeLimit.Sub(stat.MchMixTheoryPrize[mch.ID]), data.RndCompMchMaxPrize)
		//赛事可用赔付
		if _, ok = data.MchLimitVal[mch.ID]; !ok {
			//会员赛事赔付 = 会员赛事赔付（盘口当前设置的参数） - 会员赛事累计预期盈利
			mchLimit := decimal.NewFromInt32(int32(mch.MbMchPrizeLimit))
			if decimalVal, ok = memberLimit["league"]; ok {
				//会员赛事赔付比赛事赔付低
				if !decimalVal.IsNegative() && mchLimit.GreaterThan(decimalVal) {
					mchLimit = decimalVal
				}
			}
			if decimalVal, ok = stat.MchTheoryPrize[mch.ID]; ok {
				//赛事累计预期盈利金额
				mchLimit = mchLimit.Sub(decimalVal)
			}
			data.MchLimitVal[mch.ID] = mchLimit
		}
	}

	for _, mktID := range marketIDs {

		if mkt, ok = handicaps.Markets[mktID]; !ok {
			return data, errors.New(lang.Text(lan, "errVerifyMarket"))
		}
		//单注限红
		data.MktPrizeStaticProfit[mktID] = mkt.PrizeStaticProfit
		// 复合玩法所有子盘口单注赔付限额取小
		if mkt.OptionType == OptionTypeMix {
			mktIds := strings.Split(mkt.SubMktID, ",")
			mixPsf := data.MktPrizeStaticProfit[mktID]
			for _, id := range mktIds {
				mktPsf := handicaps.Markets[id].PrizeStaticProfit
				if mixPsf > mktPsf {
					mixPsf = mktPsf
					data.MktPrizeStaticProfit[mktID] = mktPsf
				}
			}
		}
		if decimalVal, ok = memberLimit["simple_limit"]; ok && !decimalVal.IsNegative() {
			uSimpleLimit := int(decimalVal.IntPart())
			if uSimpleLimit < mkt.PrizeStaticProfit {
				data.MktPrizeStaticProfit[mktID] = uSimpleLimit
			}
		}
		//单注赔付 = 盘口单注赔付和会员单注赔付之间的最低值
		prizeLimit := decimal.NewFromInt32(int32(mkt.PrizeLimit))
		if mkt.OptionType == OptionTypeMix {
			if !data.MixPrizeLimit.IsNegative() && prizeLimit.LessThan(data.MixPrizeLimit) {
				data.MixPrizeLimit = prizeLimit
			}
		}
		if decimalVal, ok = memberLimit["simple"]; ok {
			//会员单注赔付比盘口单注赔付低
			if !decimalVal.IsNegative() && prizeLimit.GreaterThan(decimalVal) {
				prizeLimit = decimalVal
			}
		}

		//会员盘口赔付 = 会员盘口赔付（盘口当前设置的参数）- 会员盘口累计预期盈利
		mktLimit := decimal.NewFromInt32(int32(mkt.MbMktPrizeLimit))
		if decimalVal, ok = memberLimit["handicap"]; ok {
			//会员盘口赔付比盘口赔付低
			if !decimalVal.IsNegative() && mktLimit.GreaterThan(decimalVal) {
				mktLimit = decimalVal
			}
		}
		//盘口累计预期盈利金额
		if mktTp, ok := stat.MktTheoryPrize[mkt.ID]; ok {
			mktLimit = mktLimit.Sub(mktTp)
		}

		//赛事的比赛串关单注赔付
		mchCompPrizeLimit := decimal.NewFromInt32(int32(mkt.MchCompPrizeLimit))
		//如果限红设置开启
		if cmp, ok := memberLimit["mch_comp"]; ok {
			//会员的比赛串关单注赔付不为-1并且小于赛事的比赛串关单注赔付
			if !cmp.IsNegative() && cmp.LessThan(mchCompPrizeLimit) {
				mchCompPrizeLimit = cmp
			}
		}
		complexPrize = append(complexPrize, mchCompPrizeLimit)

		//会员当前盘口的单注、盘口最小赔付值
		data.MktLimitVal[fmt.Sprintf("%s", mkt.ID)] = decimal.Min(prizeLimit, mktLimit)
	}

	//串关最高赔付
	if complexPrize != nil {
		data.ComplexMaxPrize = decimal.Min(complexPrize[0], complexPrize...)
	}

	return data, nil
}

// RiskBetLockCheck
/**
 * @Description: 开启投注检查
 * @Author: wesley
 * @Date: 2020/9/24 17:39
 * @LastEditTime: 2020/9/24 17:39
 * @LastEditors: wesley
 */
func RiskBetLockCheck() (bool, error) {

	value, err := mt.ZKRedisCluster.Get(RedisBetLock).Result()

	if err == redis.Nil {
		return true, nil
	}

	if err != nil {
		return false, err
	}

	if value == "0" {
		return true, nil
	}

	return false, nil
}

// CheckCreditSimpleLimit
/*
* @Description: 单注最大限额校验
* @Author: noah
* @Date: 2021/5/28 19:03
* @LastEditTime: 2021/5/28 19:03
* @LastEditors: noah
 */
func (that *CreditLimit) CheckCreditSimpleLimit(cid, agentID, memberID uint64, matchID, marketID, lan string, originOdd decimal.Decimal,
	handicapInfo utils.HandicapData, amount, rate decimal.Decimal, creditSimpleSum map[string]decimal.Decimal) error {

	odd := originOdd.Sub(DecimalOne)
	key, err := that.GetCreditSimpleLimit(cid, agentID, memberID, matchID, marketID, handicapInfo, rate)
	if err != nil {
		return err
	}

	matchKey := fmt.Sprintf("%s%s", matchID, key)
	if originOdd.GreaterThanOrEqual(decimalTwo) {
		theoryPrize := amount.Mul(odd)
		creditSimpleSum[matchKey] = creditSimpleSum[matchKey].Add(theoryPrize)
		if that.CreditSimpleMax.LessThan(theoryPrize) || that.CreditSimpleMax.LessThan(creditSimpleSum[matchKey]) {
			return errors.New(lang.Text(lan, "msgBetLimit"))
		}

		if that.CreditMemberBetLimit.LessThan(theoryPrize) {
			return errors.New(lang.Text(lan, "msgBetExceedMaxLimit"))
		}

	} else {
		creditSimpleSum[matchKey] = creditSimpleSum[matchKey].Add(amount.Mul(odd))
		if that.CreditSimpleMax.LessThan(amount) || that.CreditSimpleMax.LessThan(creditSimpleSum[matchKey]) {
			return errors.New(lang.Text(lan, "msgBetLimit"))
		}

		if that.CreditMemberBetLimit.LessThan(amount) {
			return errors.New(lang.Text(lan, "msgBetExceedMaxLimit"))
		}

	}
	return nil
}

// CheckCreditComplexLimit
/*
* @Description: 串注限额校验
* @Author: noah
* @Date: 2021/5/28 19:30
* @LastEditTime: 2021/5/28 19:30
* @LastEditors: noah
 */
func (that *CreditLimit) CheckCreditComplexLimit(cid, agentId, memberId uint64, parleyType int, amount, odd, rate decimal.Decimal, creditComplexSum map[string]decimal.Decimal, lan string) error {

	odd = odd.Sub(DecimalOne)
	key := fmt.Sprintf("limit%d", parleyType)
	theoryPrize := amount.Mul(odd)
	creditComplexSum[key] = creditComplexSum[key].Add(theoryPrize)
	complexLimit, err := that.GetCreditComplexLimitMapByKey(cid, agentId, memberId, key, rate)
	if err != nil {
		return err
	}

	if complexLimit.LessThan(theoryPrize) || complexLimit.LessThan(creditComplexSum[key]) {
		return errors.New(lang.Text(lan, "msgBetLimit"))
	}

	return nil
}

// GetCreditComplexLimitMapByKey
/**
* @Description:
* @Author: noah
* @Date: 2021/7/26 13:51
* @LastEditTime:2021/7/26 13:51
* @LastEditors: noah
 */
func (that *CreditLimit) GetCreditComplexLimitMapByKey(cid, agentID, memberId uint64, key string, rate decimal.Decimal) (decimal.Decimal, error) {

	agentComplexLimit, err := that.GetCreditACLimitMap(cid, agentID, rate)
	if err != nil {
		return decimal.Zero, err
	}

	memberComplexLimit, err := that.GetCreditMCLimitMap(cid, memberId, rate)
	if err != nil {
		return decimal.Zero, err
	}

	aLimit, err := decimal.NewFromString(agentComplexLimit[key])
	if err != nil {
		return decimal.Zero, err
	}

	mLimit, err := decimal.NewFromString(memberComplexLimit[key])
	if err != nil {
		return decimal.Zero, err
	}

	return decimal.Min(aLimit, mLimit), nil
}

// GetCreditLimit
/*
* @Description: 获取信用盘赛事限额
* @Author: noah
* @Date: 2021/5/22 19:10
* @LastEditTime: 2021/5/22 19:10
* @LastEditors: noah
 */
func (that *CreditLimit) GetCreditLimit(cid, agentID, memberID uint64, matchID, marketID string, handicapInfo utils.HandicapData, rate decimal.Decimal) error {

	_, err := that.GetCreditSimpleLimit(cid, agentID, memberID, matchID, marketID, handicapInfo, rate)
	if err != nil {
		return err
	}

	err = that.GetCreditComplexLimit(cid, agentID, memberID, rate)
	if err != nil {
		return err
	}

	return nil
}

// GetCreditSimpleLimit
/*
* @Description: 获取信用盘单注限额
* @Author: noah
* @Date: 2021/5/28 17:25
* @LastEditTime: 2021/5/28 17:25
* @LastEditors: noah
 */
func (that *CreditLimit) GetCreditSimpleLimit(cid, agentID, memberID uint64, matchID, marketID string, handicapInfo utils.HandicapData, rate decimal.Decimal) (string, error) {

	var marketerIds []string
	defaultAgentLimit := map[string]string{}
	defaultMemberLimit := map[string]string{}
	creditLevel := uint64(handicapInfo.Matches[matchID].CreditLevel)
	if creditLevel > 6 {
		creditLevel = 0
	}
	gameId, err := strconv.ParseUint(handicapInfo.Matches[matchID].GameID, 10, 64)
	if err != nil {
		AddLog(LogError, LogFlag, cid, fmt.Sprintf("gameId error: %s:", handicapInfo.Matches[matchID].GameID)+err.Error())
		return "", err
	}

	//比赛类型
	category := handicapInfo.Matches[matchID].Category
	//盘口类型
	optionType := handicapInfo.Markets[marketID].OptionType
	//是否初盘,滚球
	isLive := handicapInfo.Matches[matchID].IsLive
	round := handicapInfo.Markets[marketID].Round
	//默认限额key设为其他
	limitKey := OtherEarly
	if isLive == MatchLive {
		limitKey = OtherLive
	}
	//若为玩法冠军盘则设为冠军盘key
	if category == MatchCategoryChampion {
		limitKey = Champion
	} else {
		limitKey = getCreditLimitKey(isLive, round, optionType)
	}
	gameID := uint64(0)
	if _, ok := creditGameIds[gameId]; ok {
		gameID = gameId
	}
	//获取代理相关赛事等级,游戏,限额
	agentLimit, err := redisHMGet(mt.MerchantRedis, fmt.Sprintf(RedisKeyCreditLimit, agentID, creditLevel, gameID), []string{limitKey, MatchLimit})
	if err != nil {
		return limitKey, err
	}

	//如果无法获取代理限额,则获取默认代理限额
	if agentLimit[MatchLimit] == "" || agentLimit[limitKey] == "" || agentLimit[MatchLimit] == "0" || agentLimit[limitKey] == "0" {
		defaultAgentLimit, err = redisHMGet(mt.MerchantRedis, fmt.Sprintf(RedisKeyCreditDefaultAgentLimit, creditLevel, gameID), []string{limitKey, MatchLimit})
		if err != nil {
			return limitKey, err
		}

		if agentLimit[MatchLimit] == "" || agentLimit[MatchLimit] == "0" {
			agentLimit[MatchLimit] = defaultAgentLimit[MatchLimit]
		}
		if agentLimit[limitKey] == "" || agentLimit[limitKey] == "0" {
			agentLimit[limitKey] = defaultAgentLimit[limitKey]
		}
	}
	//获取代理赛事限额
	agentMchLimit, err := decimal.NewFromString(agentLimit[MatchLimit])
	if err != nil {
		AddLog(LogError, LogFlag, cid, fmt.Sprintf("agentMchLimit error: %s:", agentLimit[MatchLimit])+err.Error())
		return limitKey, err
	}

	//获取代理盘口限额
	agentMktLimit, err := decimal.NewFromString(agentLimit[limitKey])
	if err != nil {
		AddLog(LogError, LogFlag, cid, fmt.Sprintf("agentMktLimit error: %s:", agentLimit[limitKey])+err.Error())
		return limitKey, err
	}

	//获取会员相关赛事等级,游戏,限额
	memberBetMaxKey := fmt.Sprintf(MemberBetMax, limitKey)
	memberLimit, err := redisHMGet(mt.MerchantRedis, fmt.Sprintf(RedisKeyCreditMemberLimit, memberID, creditLevel, gameID), []string{limitKey, memberBetMaxKey})
	if err != nil {
		return limitKey, err
	}

	//会员单注最大投注额度
	memberBetMaxStr := memberLimit[memberBetMaxKey]
	if memberBetMaxStr == "" || memberLimit[limitKey] == "" || memberBetMaxStr == "0" || memberLimit[limitKey] == "0" {
		//获取默认会员限额
		defaultMemberLimit, err = redisHMGet(mt.MerchantRedis, fmt.Sprintf(RedisKeyCreditDefaultMemberLimit, creditLevel, gameID), []string{limitKey, memberBetMaxKey})
		if err != nil {
			return limitKey, err
		}

		if defaultMemberLimit[limitKey] == "" || defaultMemberLimit[limitKey] == "0" {
			defaultMemberLimit[limitKey] = mt.Config.Credit.XywMemberQuota
		}
		if memberBetMaxStr == "" || memberBetMaxStr == "0" {
			memberBetMaxStr = defaultMemberLimit[memberBetMaxKey]
		}
		if memberLimit[limitKey] == "" || memberLimit[limitKey] == "0" {
			memberLimit[limitKey] = defaultMemberLimit[limitKey]
		}
	}
	memberBetMax, err := decimal.NewFromString(memberBetMaxStr)
	if err != nil {
		AddLog(LogError, LogFlag, cid, fmt.Sprintf("memberMktLimit error: %s:", limitKey)+err.Error())
		return limitKey, err
	}

	//会员盘口限额,
	memberMktLimit, err := decimal.NewFromString(memberLimit[limitKey])
	if err != nil {
		AddLog(LogError, LogFlag, cid, fmt.Sprintf("memberMktLimit error: %s:", limitKey)+err.Error())
		return limitKey, err
	}

	that.CreditMemberBetLimit = memberBetMax
	//获取该玩法类型下的盘口ID
	for _, mkt := range handicapInfo.Markets {
		//赛事为冠军,所有赛事均添加
		if category == MatchCategoryChampion {
			marketerIds = append(marketerIds, mkt.ID)
			//玩法选项为冠军,含单选,多选
		} else if mkt.OptionType != OptionTypeMix {
			//局数是全局
			if round == 0 {
				switch optionType {
				//输赢,胜平负-全局
				case OptionTypeWinLose, OptionType1X2:
					if (mkt.OptionType == OptionTypeWinLose || mkt.OptionType == OptionType1X2) && mkt.Round == 0 {
						marketerIds = append(marketerIds, mkt.ID)
					}
				//让分玩法-全局
				case OptionTypeHandicap:
					if mkt.OptionType == optionType && mkt.Round == 0 {
						marketerIds = append(marketerIds, mkt.ID)
					}
				//大小玩法-全局
				case OptionTypeOverUnder:
					if mkt.OptionType == optionType && mkt.Round == 0 {
						marketerIds = append(marketerIds, mkt.ID)
					}
				//全局地图比分玩法-全局
				case OptionTypeCorrectScore:
					if mkt.OptionType == optionType && mkt.Round == 0 {
						marketerIds = append(marketerIds, mkt.ID)
					}
				//其他计入其他玩法类
				default:
					//全局地图比分不包含在其他里面
					if mkt.OptionType == OptionTypeCorrectScore && mkt.Round == 0 {
						continue
						//包含 全局是否、全局单双、全局趣味...
					} else if mkt.OptionType != OptionTypeWinLose && mkt.OptionType != OptionType1X2 && mkt.OptionType != OptionTypeHandicap && mkt.OptionType != OptionTypeOverUnder {
						marketerIds = append(marketerIds, mkt.ID)
					}
				}
				//单局全部计入其他玩法
			} else {
				switch optionType {
				//输赢,胜平负-单局
				case OptionTypeWinLose, OptionType1X2:
					if (mkt.OptionType == OptionTypeWinLose || mkt.OptionType == OptionType1X2) && mkt.Round != 0 {
						marketerIds = append(marketerIds, mkt.ID)
					}
				//让分玩法-单局
				case OptionTypeHandicap:
					if mkt.OptionType == optionType && mkt.Round != 0 {
						marketerIds = append(marketerIds, mkt.ID)
					}
				//大小玩法-单局
				case OptionTypeOverUnder:
					if mkt.OptionType == optionType && mkt.Round != 0 {
						marketerIds = append(marketerIds, mkt.ID)
					}
				//其他计入其他玩法类
				default:
					//全局地图比分不包含在其他里面
					if mkt.OptionType == OptionTypeCorrectScore && mkt.Round == 0 {
						continue
						//包含 是否、单双、趣味、单局单双、...
					} else if mkt.OptionType != OptionTypeWinLose && mkt.OptionType != OptionType1X2 && mkt.OptionType != OptionTypeHandicap && mkt.OptionType != OptionTypeOverUnder {
						marketerIds = append(marketerIds, mkt.ID)
					}
				}
			}
		}
	}

	that.CreditSimpleMax = decimal.Zero
	//获取该代理下所有会员关于该赛事的投注限额
	agentMchBetAmountSum, err := getCreditSTPSum("", matchID, fmt.Sprintf("%d", agentID), nil, 0)
	if err != nil {
		return limitKey, err
	}

	//若代理的赛事限额小于等于0,则直接返回单注最大投注限额为0
	agentMchLimit = agentMchLimit.Sub(decimal.NewFromFloat(agentMchBetAmountSum))
	if agentMchLimit.LessThanOrEqual(decimal.Zero) {
		return limitKey, nil
	}

	that.CreditAgentMatchLimit = agentMchLimit.Mul(rate).Floor().String()
	//获取该代理下所有会员关于该赛事的玩法投注限额
	agentMktBetAmountSum, err := getCreditSTPSum("", matchID, fmt.Sprintf("%d", agentID), marketerIds, isLive)
	if err != nil {
		return limitKey, err
	}

	//若代理的赛事玩法的限额小于等于0,则直接返回单注最大投注限额为0
	agentMktLimit = agentMktLimit.Sub(decimal.NewFromFloat(agentMktBetAmountSum))
	if agentMktLimit.LessThanOrEqual(decimal.Zero) {
		return limitKey, nil
	}

	that.CreditAgentMarketLimit = agentMktLimit.Mul(rate).Floor().String()
	//获取会员该类型下的已投注金额
	memberMktAmountSum, err := getCreditSTPSum(fmt.Sprintf("%d", memberID), matchID, "", marketerIds, isLive)
	if err != nil {
		return limitKey, err
	}

	//若会员的赛事玩法限额小于等于0,则直接返回单注最大投注限额为0
	memberMktLimit = memberMktLimit.Sub(decimal.NewFromFloat(memberMktAmountSum))
	if memberMktLimit.LessThanOrEqual(decimal.Zero) {
		return limitKey, nil
	}

	that.CreditMemberMarketLimit = memberMktLimit.Mul(rate).Floor().String()
	//信用盘会员单注最高赔付=(代理最大赛事赔付,代理玩法最大赔付,会员玩法最大赔付)取最小值除以盘口赔率与会员单注最大投注取小值
	that.CreditSimpleMax = decimal.Min(agentMchLimit, agentMktLimit, memberMktLimit).Mul(rate).Floor()
	//当值为负数时,值归0
	if that.CreditSimpleMax.LessThan(decimal.Zero) {
		that.CreditSimpleMax = decimal.Zero
	}
	return limitKey, nil
}

// GetCreditComplexLimit
/*
* @Description:获取信用盘串注限额
* @Author: noah
* @Date: 2021/5/28 17:25
* @LastEditTime: 2021/5/28 17:25
* @LastEditors: noah
 */
func (that *CreditLimit) GetCreditComplexLimit(cid, agentID, memberId uint64, rate decimal.Decimal) error {

	agentComplexLimit, err := that.GetCreditACLimitMap(cid, agentID, rate)
	if err != nil {
		return err
	}

	memberComplexLimit, err := that.GetCreditMCLimitMap(cid, memberId, rate)
	if err != nil {
		return err
	}

	that.CreditLimit2 = calculationComplexLimit(cid, agentComplexLimit["limit2"], memberComplexLimit["limit2"])
	that.CreditLimit3 = calculationComplexLimit(cid, agentComplexLimit["limit3"], memberComplexLimit["limit3"])
	that.CreditLimit4 = calculationComplexLimit(cid, agentComplexLimit["limit4"], memberComplexLimit["limit4"])
	that.CreditLimit5 = calculationComplexLimit(cid, agentComplexLimit["limit5"], memberComplexLimit["limit5"])
	that.CreditLimit6 = calculationComplexLimit(cid, agentComplexLimit["limit6"], memberComplexLimit["limit6"])
	that.CreditLimit7 = calculationComplexLimit(cid, agentComplexLimit["limit7"], memberComplexLimit["limit7"])
	that.CreditLimit8 = calculationComplexLimit(cid, agentComplexLimit["limit8"], memberComplexLimit["limit8"])
	that.CreditLimit9 = calculationComplexLimit(cid, agentComplexLimit["limit9"], memberComplexLimit["limit9"])
	that.CreditLimit10 = calculationComplexLimit(cid, agentComplexLimit["limit10"], memberComplexLimit["limit10"])
	return nil
}

/**
* @Description: 计算并获取代理/会员最小限额
* @Author: noah
* @Date: 2021/7/26 13:52
* @LastEditTime:2021/7/26 13:52
* @LastEditors: noah
 */
func calculationComplexLimit(cid uint64, agentLimit, memberLimit string) string {

	aLimit, err := decimal.NewFromString(agentLimit)
	if err != nil {
		AddLog(LogError, LogFlag, cid, fmt.Sprintf("calculationComplexLimit agentLimit error: %s:", agentLimit)+err.Error())
		return "0"
	}

	mLimit, err := decimal.NewFromString(memberLimit)
	if err != nil {
		AddLog(LogError, LogFlag, cid, fmt.Sprintf("calculationComplexLimit memberLimit error: %s:", memberLimit)+err.Error())
		return "0"
	}
	return decimal.Min(aLimit, mLimit).String()
}

/*
* @Description: 信用盘代理串注计算
* @Author: noah
* @Date: 2021/5/28 21:46
* @LastEditTime: 2021/5/28 21:46
* @LastEditors: noah
 */
func complexLimitCalculate(cid uint64, complexLimit map[string]string, complexBetAmountSumMap map[int]float64, rate decimal.Decimal) error {

	for k, v := range complexBetAmountSumMap {
		key := fmt.Sprintf("limit%d", k)
		if complexLimit[key] == "" {
			complexLimit[key] = "0"
		}
		limit, err := decimal.NewFromString(complexLimit[key])
		if err != nil {
			AddLog(LogError, LogFlag, cid, fmt.Sprintf("limit error: %s:", complexLimit[key])+err.Error())
			return err
		}

		complexLimit[key] = decimal.Max(limit.Sub(decimal.NewFromFloat(v)), decimal.Zero).Mul(rate).String()
	}

	return nil
}

// GetCreditACLimitMap
/*
* @Description:
* @Author: noah
* @Date: 2021/5/28 19:28
* @LastEditTime: 2021/5/28 19:28
* @LastEditors: noah
 */
func (that *CreditLimit) GetCreditACLimitMap(cid, agentID uint64, rate decimal.Decimal) (map[string]string, error) {

	complexLimit, err := redisHMGet(mt.MerchantRedis, fmt.Sprintf(RedisKeyCreditCompLimit, agentID), limitKeys)
	if err != nil {
		return complexLimit, err
	}

	if complexLimit["limit2"] == "" {
		complexLimit, err = redisHMGet(mt.MerchantRedis, RedisKeyCreditDefaultAgentCompLimit, limitKeys)
		if err != nil {
			return complexLimit, err
		}
	}
	ex := g.Ex{
		"bet_time":   g.Op{"gt": helper.GetCreditComplexUpdateTime()},
		"order_type": []int{OrderTypeComplex, OrderTypeRoundComplex, OrderTypeMix},
		"bet_status": []int{BetStatusWaitConfirm, BetStatusWaitSettle, BetStatusWin, BetStatusLose},
		"agent_id":   agentID,
	}
	complexBetAmountSumMap, err := getCompSum(ex)
	if err != nil {
		return complexLimit, err
	}

	err = complexLimitCalculate(cid, complexLimit, complexBetAmountSumMap, rate)
	return complexLimit, err
}

// GetCreditMCLimitMap
/**
* @Description: 获取会员的串注限额
* @Author: noah
* @Date: 2021/7/24 16:21
* @LastEditTime:2021/7/24 16:21
* @LastEditors: noah
 */
func (that *CreditLimit) GetCreditMCLimitMap(cid, memberId uint64, rate decimal.Decimal) (map[string]string, error) {

	complexLimit, err := redisHMGet(mt.MerchantRedis, fmt.Sprintf(RedisKeyCreditMemberCompLimit, memberId), limitKeys)
	if err != nil {
		return complexLimit, err
	}

	if complexLimit["limit2"] == "" {
		complexLimit, err = redisHMGet(mt.MerchantRedis, RedisKeyCreditDefaultMemberCompLimit, limitKeys)
		if err != nil {
			return complexLimit, err
		}
	}
	ex := g.Ex{
		"bet_time":   g.Op{"gt": helper.GetCreditComplexUpdateTime()},
		"order_type": []int{OrderTypeComplex, OrderTypeRoundComplex, OrderTypeMix},
		"bet_status": []int{BetStatusWaitConfirm, BetStatusWaitSettle, BetStatusWin, BetStatusLose},
		"member_id":  memberId,
	}
	complexBetAmountSumMap, err := getCompSum(ex)
	if err != nil {
		return complexLimit, err
	}

	err = complexLimitCalculate(cid, complexLimit, complexBetAmountSumMap, rate)
	return complexLimit, err
}

/*
* @Description: 获取玩法类型key
* @Author: noah
* @Date: 2021/5/22 16:49
* @LastEditTime: 2021/5/22 16:49
* @LastEditors: noah
 */
func getCreditLimitKey(isLive, round, optionType int) string {

	simpleLimit := ""
	//初盘
	if isLive == 1 {
		switch optionType {
		//输赢
		case OptionTypeWinLose, OptionType1X2:
			simpleLimit = AllWinLossEarly
		//让分
		case OptionTypeHandicap:
			simpleLimit = AllHandicapEarly
		//大小
		case OptionTypeOverUnder:
			simpleLimit = AllOverUnderEarly
		//波胆/地图比分
		case OptionTypeCorrectScore:
			simpleLimit = CorrectMapScoreEarly
		default:
			simpleLimit = OtherEarly
		}
		//滚盘
	} else {
		switch optionType {
		//输赢
		case OptionTypeWinLose, OptionType1X2:
			simpleLimit = AllWinLossLive
		//让分
		case OptionTypeHandicap:
			simpleLimit = AllHandicapLive
		//大小
		case OptionTypeOverUnder:
			simpleLimit = AllOverUnderLive
		//波胆/地图比分
		case OptionTypeCorrectScore:
			simpleLimit = CorrectMapScoreLive
		default:
			simpleLimit = OtherLive
		}
	}
	if round != 0 {
		switch simpleLimit {
		case AllWinLossEarly:
			simpleLimit = SingleWinLossEarly
		case AllHandicapEarly:
			simpleLimit = SingleHandicapEarly
		case AllOverUnderEarly:
			simpleLimit = SingleOverUnderEarly
		case AllWinLossLive:
			simpleLimit = SingleWinLossLive
		case AllHandicapLive:
			simpleLimit = SingleHandicapLive
		case AllOverUnderLive:
			simpleLimit = SingleOverUnderLive
		}
	}
	return simpleLimit
}

// GetMemberComplexLimit
/**
* @Description: 获取用户串注限额
* @Author: noah
* @Date: 2021/11/12 12:36
* @LastEditTime:2021/11/12 12:36
* @LastEditors: noah
 */
func (that *MemberLimit) GetMemberComplexLimit(member fund.Member, mchId, mktID, lan string, handicaps utils.HandicapData, sMax, mchCompLimit, rate decimal.Decimal) (map[string]string, error) {

	data := map[string]string{}
	// 获取赛事剩余总限额
	matchLimit, err := getMatchCompLimit(mchId, handicaps)
	if err != nil {
		return nil, err
	}

	var mCompLimit float64
	if !mchCompLimit.IsZero() {
		mCompLimit, _ = mchCompLimit.Float64()
	}
	that.MatchCompLimit = decimal.Max(decimal.NewFromFloat(matchLimit).Mul(rate), decimal.Zero).Floor()
	level := strconv.Itoa(handicaps.Matches[mchId].MatchLevel)
	levelLimit, err := getMatchLevelLimit(member.UID, level, mCompLimit)
	if err != nil {
		return nil, err
	}

	that.MatchLevelCompLimit = decimal.NewFromFloat(levelLimit).Mul(rate).Floor()
	// 获取会员剩余串注额度
	limit, err := getMemberCompUsedLimit(member, lan)
	if err != nil {
		return nil, err
	}

	compPrizeLimit := decimal.NewFromInt32(int32(handicaps.Markets[mktID].MchCompPrizeLimit))
	if !sMax.IsZero() {
		compPrizeLimit = decimal.Min(compPrizeLimit, sMax)
	}
	that.MktCompPrizeLimit = decimal.Max(compPrizeLimit.Mul(rate), decimal.Zero).Floor()
	that.Limit2 = decimal.NewFromFloat(limit["limit2"]).Mul(rate).Floor()
	that.Limit3 = decimal.NewFromFloat(limit["limit3"]).Mul(rate).Floor()
	that.Limit4 = decimal.NewFromFloat(limit["limit4"]).Mul(rate).Floor()
	that.Limit5 = decimal.NewFromFloat(limit["limit5"]).Mul(rate).Floor()
	that.Limit6 = decimal.NewFromFloat(limit["limit6"]).Mul(rate).Floor()
	that.Limit7 = decimal.NewFromFloat(limit["limit7"]).Mul(rate).Floor()
	that.Limit8 = decimal.NewFromFloat(limit["limit8"]).Mul(rate).Floor()
	that.Limit9 = decimal.NewFromFloat(limit["limit9"]).Mul(rate).Floor()
	that.Limit10 = decimal.NewFromFloat(limit["limit10"]).Mul(rate).Floor()

	m, err := helper.StructToMap(that)
	if err != nil {
		return nil, err
	}

	for k, v := range m {
		data[k] = fmt.Sprintf("%v", v)
		if data[k] == "" {
			data[k] = "0"
		}
	}
	data["level"] = level

	return data, nil
}

/**
* @Description: 获取用户已使用串注限额
* @Author: noah
* @Date: 2021/11/12 12:36
* @LastEditTime:2021/11/12 12:36
* @LastEditors: noah
 */
func getMemberCompUsedLimit(m fund.Member, lan string) (map[string]float64, error) {

	data := map[string]float64{}
	// 获取会员已使用限额
	mkey := fmt.Sprintf(RedisKeyMemberCompUsedLimit, m.MerchantID, m.UID, carbon.Now().ToDateString())
	result, err := mt.ZKRedisCluster.Exists(mkey).Result()
	if err != nil {
		return nil, err
	}

	if result == 0 {
		newLimit, err := newMemberCompUsedLimit(m)
		if err != nil {
			return nil, err
		}

		for k, v := range newLimit {
			data[k] = v.(float64)
		}
	} else {
		limits, err := zkRedisHMGet(mt.ZKRedisCluster, mkey, limitKeys)
		if err != nil {
			return nil, err
		}

		for k, v := range limits {
			if v == "" {
				data[k] = 0
				continue
			}
			f, err := strconv.ParseFloat(v, 64)
			if err != nil {
				return nil, err
			}

			data[k] = f
		}
	}

	fields := limitKeys
	fields = append(fields, LimitStatus)
	memberSetLimits, err := zkRedisHMGet(mt.ZKRedisCluster, fmt.Sprintf(RedisUserRisk, m.UID), fields)
	if err != nil && err != redis.Nil {
		return nil, err
	}

	defMemberSetLimits, err := zkRedisHMGet(mt.ZKRedisCluster, RedisBasicSettingsForRisk, limitKeys)
	if err == redis.Nil || defMemberSetLimits["limit2"] == "" || defMemberSetLimits["limit2"] == "-1" {
		return nil, errors.New(lang.Text(lan, "errRiskBasic"))
	} else if err != nil {
		return nil, err
	}

	for _, k := range limitKeys {
		if memberSetLimits[k] == "" || memberSetLimits[k] == "-1" || memberSetLimits[LimitStatus] == "0" || memberSetLimits[LimitStatus] == "" {
			memberSetLimits[k] = defMemberSetLimits[k]
		}
		f, err := strconv.ParseFloat(memberSetLimits[k], 64)
		if err != nil {
			return nil, err
		}

		data[k] = f - data[k]
		if data[k] < 0 {
			data[k] = 0
		}
	}

	return data, nil
}

// NewMemberCompUsedLimit
/**
* @Description:
* @Author: noah
* @Date: 2021/11/4 15:19
* @LastEditTime:2021/11/4 15:19
* @LastEditors: noah
 */
func newMemberCompUsedLimit(m fund.Member) (map[string]interface{}, error) {

	data := map[string]interface{}{}
	for _, key := range limitKeys {
		data[key] = float64(0)
	}
	pipe := mt.ZKRedisCluster.TxPipeline()
	defer pipe.Close()
	// 设置会员今日已使用串注限额
	mkey := fmt.Sprintf(RedisKeyMemberCompUsedLimit, m.MerchantID, m.UID, carbon.Now().ToDateString())
	pipe.HMSet(mkey, data)
	pipe.Expire(mkey, MemberUsedLimitDefaultExpiredTime)
	_, err := pipe.Exec()
	if err != nil {
		return nil, err
	}

	return data, nil
}

// GetMatchCompLimit
/**
* @Description: 获取赛事剩余串注限额
* @Author: noah
* @Date: 2021/11/4 15:18
* @LastEditTime:2021/11/4 15:18
* @LastEditors: noah
 */
func getMatchCompLimit(matchId string, handicaps utils.HandicapData) (float64, error) {

	matchCompMaxLimit := float64(handicaps.Matches[matchId].MchsCompPrizeTotalLimit)
	matchUsedLimit, err := mt.ZKRedisCluster.Get(fmt.Sprintf(RedisKeyMatchCompUsedLimit, matchId)).Float64()
	if err == redis.Nil {
		return matchCompMaxLimit, nil
	} else if err != nil {
		return 0, err
	}

	return matchCompMaxLimit - matchUsedLimit, nil
}

/**
* @Description:获取会员赛事等级已使用限额
* @Author: noah
* @Date: 2021/11/19 18:11
* @LastEditTime:2021/11/19 18:11
* @LastEditors: noah
 */
func getMatchLevelLimit(uid uint64, matchLevel string, mCompLimit float64) (float64, error) {

	matchLevelLimit, err := mt.ZKRedisCluster.HGet(RedisKeyMatchLevelCompLimit, matchLevel).Float64()
	if err == redis.Nil {
		return 0, nil
	} else if err != nil {
		return 0, err
	}

	if mCompLimit != 0 && matchLevelLimit > mCompLimit {
		matchLevelLimit = mCompLimit
	}
	usedLimit, err := mt.ZKRedisCluster.HGet(fmt.Sprintf(RedisKeyLevelUsedLimit, uid), matchLevel).Float64()
	if err == redis.Nil {
		return matchLevelLimit, nil
	} else if err != nil {
		return 0, err
	}

	if matchLevelLimit < usedLimit {
		return 0, nil
	}

	return matchLevelLimit - usedLimit, nil
}

// CompUsedLimitCheck
/**
* @Description:  检查普通赛事串注限额超限
* @Author: noah
* @Date: 2021/11/5 13:53
* @LastEditTime:2021/11/5 13:53
* @LastEditors: noah
 */
func CompUsedLimitCheck(comps []*ComplexBetContent, member fund.Member, handicaps utils.HandicapData, limitVal MarketRiskLimit, compDetailMp map[uint64]map[uint64]g.Record, rate decimal.Decimal, lan string) error {

	compUsedLimitMap := map[string]decimal.Decimal{}
	minLimitMap := map[string]decimal.Decimal{}
	limitMap := map[string]MemberLimitData{}
	mktMaxMap := map[string]decimal.Decimal{}
	levelMap := map[string]decimal.Decimal{}
	levelUsedMap := map[string]decimal.Decimal{}
	parleyType := 0
	checkOdd := decimal.Decimal{}
	if len(comps) > 1 {
		for _, comp := range comps {
			if parleyType < comp.ParleyType && comp.ParleyNum != 1 {
				parleyType = comp.ParleyType
				checkOdd = comp.Odd
			}
		}
	}
	for i := range comps {
		if comps[i].Flags != OrderTypeComplex {
			continue
		}
		pt := comps[i].ParleyType
		if comps[i].ParleyNum != 1 {
			pt = parleyType
		}
		theoryPrize := (comps[i].Odd.Mul(comps[i].Amount)).Sub(comps[i].Amount).Div(rate).Round(3)
		compUsedLimitSum := decimal.Zero
		lenNum := len(comps[i].Data) - 1
		key := fmt.Sprintf("limit%d", comps[i].ParleyType)
		if comps[i].ParleyNum > 1 {
			key = fmt.Sprintf("limit%d", CompsNumMap[comps[i].ParleyNum])
		}
		compUsedLimitMap[key] = compUsedLimitMap[key].Add(theoryPrize)
		orderId := comps[i].OrderId
		// 串注超限判断
		overrunSetting, err := GetOverrunSetting(pt)
		if err != nil {
			return err
		}

		overrunOdd := overrunSetting[fmt.Sprintf(LimitOddStrF, pt)]
		overrunBet := overrunSetting[fmt.Sprintf(LimitBetStrF, pt)]
		overrunTheoryPrize := (overrunBet.Mul(comps[i].Odd)).Sub(overrunBet)
		for j := range comps[i].Data {
			mchId := comps[i].Data[j].MatchID
			mktId := comps[i].Data[j].MarketID
			odId := comps[i].Data[j].OdId
			limitKey := fmt.Sprintf("%s:%s", mchId, mktId)
			level := "0"
			if _, ok := limitMap[limitKey]; !ok {
				sMax := decimal.Decimal{}
				var betMax []decimal.Decimal
				if v, ok := limitVal.MchLimitVal[mchId]; ok {
					betMax = append(betMax, v)
				}
				if v, ok := limitVal.MktLimitVal[mktId]; ok {
					betMax = append(betMax, v)
				}
				if len(betMax) != 0 {
					sMax = decimal.Min(betMax[0], betMax...)
				}
				d := MemberLimitData{}
				m, err := d.Limit.GetMemberComplexLimit(member, mchId, mktId, lan, handicaps, sMax, limitVal.MchCompLimit, rate)
				if err != nil {
					return err
				}

				d.MapData = m
				limitMap[limitKey] = d
			}
			compUsedLimit := comps[i].Data[j].Odd.Div(comps[i].OddSum).Mul(theoryPrize).Round(3)
			if _, ok := compDetailMp[orderId][odId]; ok {
				compDetailMp[orderId][odId]["used_limit"] = compUsedLimit.String()
			}
			// 最后一笔使用预派彩金额-(前几笔赔付限额之和）的剩余值
			// 防止小数点精度问题造成的赔付限额的计算误差
			if lenNum == j {
				compUsedLimit = theoryPrize.Sub(compUsedLimitSum)
			}
			mktMaxMap[limitKey] = mktMaxMap[limitKey].Add(comps[i].Data[j].Odd.Mul(comps[i].Amount).Sub(comps[i].Amount))
			comps[i].Data[j].CompUsedLimit = compUsedLimit
			compUsedLimitSum = compUsedLimitSum.Add(compUsedLimit)
			limit, err := decimal.NewFromString(limitMap[limitKey].MapData[key])
			if err != nil {
				return err
			}

			limit = limit.Div(rate)
			if minLimitMap[key].IsZero() {
				minLimitMap[key] = limit
			}
			if l, ok := limitMap[limitKey].MapData["level"]; ok {
				level = l
				levelUsedMap[level] = levelUsedMap[level].Add(compUsedLimit)
				if _, ok = levelMap[level]; !ok {
					levelLimit, err := decimal.NewFromString(limitMap[limitKey].MapData["match_level_comp_limit"])
					if err != nil {
						return err
					}

					levelMap[level] = levelLimit
				}
			}
			comps[i].Data[j].MatchLevel = level
			minLimitMap[key] = decimal.Min(minLimitMap[key], limit)
			limit = minLimitMap[key]
			mktMin := decimal.Min(limitMap[limitKey].Limit.MatchCompLimit, limitMap[limitKey].Limit.MktCompPrizeLimit)
			// 超限的赔率大于当前赔率
			// 且超限预计赔付小于当前各种赔付判断条件时，跳过校验
			if comps[i].Odd.GreaterThanOrEqual(overrunOdd) && (limit.LessThanOrEqual(overrunTheoryPrize) || mktMin.LessThanOrEqual(overrunTheoryPrize) || levelMap[level].LessThanOrEqual(overrunTheoryPrize)) {
				continue
			}
			// compUsedLimitMap 已使用的串注限额
			// mktMaxMap  盘口最大赔付
			// theoryPrize 预赔付金额
			// levelUsedMap 赛事等级已使用的赔付额度
			// levelMap  当前赛事等级计入赔付额度
			// 已使用限额超限检查
			if compUsedLimitMap[key].GreaterThan(limit) && checkOdd.LessThan(overrunOdd) && !checkOdd.IsZero() {
				return errors.New(lang.Text(lan, "msgSeriesSingleBetLimit"))
			}

			//单次盘口累计赔付超限检查
			if mktMaxMap[limitKey].GreaterThan(mktMin) && checkOdd.LessThan(overrunOdd) && !checkOdd.IsZero() {
				return errors.New(lang.Text(lan, "msgSeriesSingleBetLimit"))
			}

			//盘口赔付超限检查
			if theoryPrize.GreaterThan(mktMin) && checkOdd.LessThan(overrunOdd) && !checkOdd.IsZero() {
				return errors.New(lang.Text(lan, "msgSeriesSingleBetLimit"))
			}

			// 赛事等级超限检查
			if levelUsedMap[level].GreaterThan(levelMap[level]) && checkOdd.LessThan(overrunOdd) && !checkOdd.IsZero() {
				return errors.New(lang.Text(lan, "msgSeriesSingleBetLimit"))
			}
		}
		if comps[i].Odd.GreaterThanOrEqual(overrunOdd) {
			// 判断投注金额是否大于超限投注金额
			if comps[i].Amount.Div(rate).GreaterThan(overrunBet) {
				return errors.New(lang.Text(lan, "msgSeriesSingleBetLimit"))
			}
		}
	}

	return nil
}

// UpdateCompUsedLimit
/**
* @Description:增加已使用串注限额
* @Author: noah
* @Date: 2021/11/5 13:52
* @LastEditTime:2021/11/5 13:52
* @LastEditors: noah
 */
func UpdateCompUsedLimit(ctx *fasthttp.RequestCtx, data []*ComplexBetContent, member fund.Member) {

	pipe := mt.ZKRedisCluster.TxPipeline()
	defer pipe.Close()
	compAllUsedLimit := decimal.Zero
	duplexType := 1
	memberKey := fmt.Sprintf(RedisKeyMemberCompUsedLimit, member.MerchantID, member.UID, carbon.Now().ToDateString())
	for _, i := range data {
		if i.Flags != OrderTypeComplex {
			continue
		}
		for _, j := range i.Data {
			// 赔付占比=X赔率/(X赔率+Y赔率+Z赔率)=1.5/（1.5+2+3）=0.23（四舍五入保留两位小数）
			// 赔付额度=赔付占比*预派彩金额
			compUsedLimit := j.CompUsedLimit
			d, err := strconv.ParseFloat(compUsedLimit.String(), 64)
			if err != nil {
				zlog.Error(ctx, "djGame", "", fmt.Sprintf("update comp used limit err, uid:%d,error:[%s]%s",
					member.UID, compUsedLimit, "cannot transform float64"), ctx.ID(), member.MerchantID)
				continue
			}
			// 更新会员串注已使用额度
			mchKey := fmt.Sprintf(RedisKeyMatchCompUsedLimit, j.MatchID)
			pipe.IncrByFloat(mchKey, d)
			mLevelKey := fmt.Sprintf(RedisKeyLevelUsedLimit, member.UID)
			pipe.HIncrByFloat(mLevelKey, j.MatchLevel, d)
			// 复式串注会员串注已使用限额增加-跳过
			if i.ParleyNum > 1 {
				if i.ParleyType > duplexType {
					duplexType = i.ParleyType
				}
				compAllUsedLimit = compAllUsedLimit.Add(j.CompUsedLimit)
				continue
			}
			pipe.HIncrByFloat(memberKey, fmt.Sprintf("limit%d", i.ParleyType), d)
		}
	}
	// 复式串注扣减串注限额
	if duplexType > 1 {
		d, err := strconv.ParseFloat(compAllUsedLimit.String(), 64)
		if err != nil {
			zlog.Error(ctx, "djGame", "", fmt.Sprintf("update comp used limit err, uid:%d,error:[%s]%s",
				member.UID, compAllUsedLimit, "cannot transform float64"), ctx.ID(), member.MerchantID)
			return
		}

		pipe.HIncrByFloat(memberKey, fmt.Sprintf("limit%d", duplexType), d)
	}
	_, err := pipe.Exec()
	if err != nil {
		zlog.Error(ctx, "djGame", "", fmt.Sprintf("update comp used limit err, uid:%d,error:%s",
			member.UID, err.Error()), ctx.ID(), member.MerchantID)
	}
}

// GetMemberDailyTotal
/**
* @Description: 获取当日会员可用派彩金额
* @Author: noah
* @Date: 2022/2/5 19:47
* @LastEditTime:2022/2/5 19:47
* @LastEditors: noah
 */
func GetMemberDailyTotal(merchantId, uid uint64) (map[string]decimal.Decimal, error) {

	timeStr := carbon.Now().ToDateString()
	key := fmt.Sprintf(RedisKeyMemberDailyTotal, merchantId, uid, timeStr)
	data := map[string]decimal.Decimal{}
	exists, err := ZKRedisKeyExists(key)
	if err != nil {
		return data, err
	}

	if !exists {
		values, err := CreateMemberDailyTotal(merchantId, uid)
		if err != nil {
			return data, err
		}

		for k, v := range values {
			balance, err := decimal.NewFromString(v.(string))
			if err != nil {
				return nil, err
			}

			data[k] = balance
		}

		return data, nil
	}

	result, err := mt.ZKRedisCluster.HMGet(key, MemberDailyTotalFields...).Result()
	if err != nil {
		return data, err
	}

	for i, item := range result {
		data[MemberDailyTotalFields[i]] = decimal.Zero
		v, ok := item.(string)
		if !ok {
			continue
		}
		balance, err := decimal.NewFromString(v)
		if err != nil {
			return nil, err
		}

		data[MemberDailyTotalFields[i]] = balance
	}

	return data, nil
}

// CreateMemberDailyTotal
/**
* @Description: 创建每日统计
* @Author: noah
* @Date: 2022/2/6 13:14
* @LastEditTime:2022/2/6 13:14
* @LastEditors: noah
 */
func CreateMemberDailyTotal(merchantId, uid uint64) (map[string]interface{}, error) {

	values := map[string]interface{}{}
	result, err := mt.ZKRedisCluster.HMGet(RedisBasicSettingsForRisk, MemberDailyTotalFields...).Result()
	if err != nil {
		return values, err
	}

	for i, item := range result {
		if item == nil {
			item = "0"
		}
		values[MemberDailyTotalFields[i]] = item
	}
	timeStr := carbon.Now().ToDateString()
	key := fmt.Sprintf(RedisKeyMemberDailyTotal, merchantId, uid, timeStr)
	err = mt.ZKRedisCluster.HMSet(key, values).Err()
	if err != nil {
		return values, err
	}

	return values, mt.ZKRedisCluster.Expire(key, OneDay).Err()
}

// DeductionMemberDailyTotal
/**
* @Description: 扣减会员单日限额
* @Author: noah
* @Date: 2022/2/6 13:26
* @LastEditTime:2022/2/6 13:26
* @LastEditors: noah
 */
func DeductionMemberDailyTotal(merchantId, uid uint64, types int, amount float64) error {

	timeStr := carbon.Now().ToDateString()
	key := fmt.Sprintf(RedisKeyMemberDailyTotal, merchantId, uid, timeStr)
	switch types {
	case SingleRiskPrizeTotalType:
		return mt.ZKRedisCluster.HIncrByFloat(key, MemberSinglePrizeTotal, -amount).Err()

	case ComplexRiskPrizeTotalType:
		return mt.ZKRedisCluster.HIncrByFloat(key, MemberComplexPrizeTotal, -amount).Err()
	}

	return nil
}

// GetOverrunSetting
/**
* @Description: 获取超限数据
* @Author: noah
* @Date: 2022/2/6 13:17
* @LastEditTime:2022/2/6 13:17
* @LastEditors: noah
 */
func GetOverrunSetting(limit int) (map[string]decimal.Decimal, error) {

	data := map[string]decimal.Decimal{}
	files := OverrunLimitKeys
	if limit != 0 {
		files = []string{fmt.Sprintf(LimitOddStrF, limit), fmt.Sprintf(LimitBetStrF, limit)}
	}
	result, err := mt.ZKRedisCluster.HMGet(RedisBasicSettingsForRisk, files...).Result()
	if err != nil {
		return data, err
	}

	for i, item := range result {
		data[files[i]] = decimal.Zero
		amount, ok := item.(string)
		if !ok {
			continue
		}

		s, err := decimal.NewFromString(amount)
		if err != nil {
			fmt.Println(err.Error())
			continue
		}

		data[files[i]] = s
	}

	return data, err
}

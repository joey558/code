package model

import (
	"game/mRejson"
)

/*
* @Description: 代理获取
* @Author: noah
* @Date: 2021/5/29 11:18
* @LastEditTime: 2021/5/29 11:18
* @LastEditors: noah
 */
func GetAgent(id uint64) (mRejson.AgentCache, error) {
	return mRejson.GetAgent(mt.MerchantRedis, id)
}

type AgentLimit struct {
	ID                   string `db:"id" json:"id"`                                           // id
	AgentID              string `db:"agent_id" json:"agent_id"`                               // 代理ID
	GameID               string `db:"game_id" json:"game_id"`                                 // 游戏ID，其他游戏:0
	TourLv               int    `db:"tour_lv" json:"tour_lv"`                                 // 联赛等级，其他联赛等级:0
	MatchLimit           string `db:"match_limit" json:"match_limit"`                         // 赛事限额
	OtherEarly           string `db:"other_early" json:"other_early"`                         // 其他玩法-早盘限额
	OtherLive            string `db:"other_live" json:"other_live"`                           // 其他玩法-滚球限额
	Champion             string `db:"champion" json:"champion"`                               // 冠军玩法限额
	AllWinLossEarly      string `db:"all_win_loss_early"  json:"all_win_loss_early"`          // 全局输赢-早盘
	SingleWinLossEarly   string `db:"single_win_loss_early"  json:"single_win_loss_early"`    // 单局输赢-早盘
	AllWinLossLive       string `db:"all_win_loss_live"  json:"all_win_loss_live"`            // 全局输赢-滚盘
	SingleWinLossLive    string `db:"single_win_loss_live" json:"single_win_loss_live"`       // 单局输赢-滚盘
	AllHandicapEarly     string `db:"all_handicap_early"  json:"all_handicap_early"`          // 全局让分-早盘
	SingleHandicapEarly  string `db:"single_handicap_early" json:"single_handicap_early"`     // 单局让分-早盘
	AllHandicapLive      string `db:"all_handicap_live" json:"all_handicap_live" `            // 全局让分-滚盘
	SingleHandicapLive   string `db:"single_handicap_live"  json:"single_handicap_live"`      // 单局让分-滚盘
	AllOverUnderEarly    string `db:"all_over_under_early" json:"all_over_under_early"`       // 全局大小-早盘
	SingleOverUnderEarly string `db:"single_over_under_early" json:"single_over_under_early"` // 单局大小-早盘
	AllOverUnderLive     string `db:"all_over_under_live"  json:"all_over_under_live"`        // 全局大小-滚盘
	SingleOverUnderLive  string `db:"single_over_under_live"  json:"single_over_under_live"`  // 单局大小-滚盘
	CorrectMapScoreEarly string `db:"correct_map_score_early" json:"correct_map_score_early"` // 全局地图正确比分-早盘
	CorrectMapScoreLive  string `db:"correct_map_score_live" json:"correct_map_score_live"`   // 全局地图正确比分大小-滚盘
	UpdateAt             int64  `db:"update_at" json:"update_at"`                             // 更新时间
	UpdateId             int64  `db:"update_at" json:"update_id"`                             // 更新人ID
	UpdateAccount        int64  `db:"update_at" json:"update_account"`                        // 更新人
}

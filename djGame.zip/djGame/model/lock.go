package model

import (
	"errors"
	"fmt"
	"time"
)

var (
	// The maximum duration to lock a key, Default: 10s
	LockTimeout time.Duration = 10 * time.Second
	// The maximum duration to wait to get the lock, Default: 0s, do not wait
	WaitTimeout time.Duration
	// The maximum wait retry time to get the lock again, Default: 100ms
	WaitRetry time.Duration = 100 * time.Millisecond
)

const (
	UserBetRedisKey       = "UserBetLock:"
	defaultRedisKeyPrefix = "rlock:"
)

func Lock(key string, ttl time.Duration) error {

	ok, err := mt.MerchantRedis.SetNX(key, "1", ttl).Result()
	if err != nil || !ok {
		if err != nil {
			AddLog(LogError, LogFlag, key, "get lock error: %s", err.Error())
		} else {
			AddLog(LogError, LogFlag, key, "get lock failed")
		}
		return errors.New(fmt.Sprintf("get lock failed"))
	}

	return nil
}

func UnLock(key string) {

	mt.MerchantRedis.Unlink(key)
}

// 检查总控redisKey是否存在
func ZKRedisKeyExists(key string) (bool, error) {

	count, err := mt.ZKRedisCluster.Exists(key).Result()
	if err != nil {
		return false, err
	}

	return count > 0, nil
}

// 检查商户redisKey是否存在
func RedisKeyExists(key string) (bool, error) {

	count, err := mt.MerchantRedis.Exists(key).Result()
	if err != nil {
		return false, err
	}

	return count > 0, nil
}

package model

import (
	"fmt"
	"game/helper"
	"game/lang"
	"game/utils"
	"github.com/coocood/freecache"
	"github.com/go-redis/redis/v7"
	"github.com/scylladb/go-set"
	"github.com/scylladb/go-set/strset"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"
)

type CacheRefreshFunc func(key string) bool

type IdxCache struct {
	Key         string        //key
	RefreshTime time.Duration //数据刷新时间
	//RefreshFunc CacheRefreshFunc //数据刷新函数
}

type CacheData struct {
	PoolSize      int      `json:"pool_size"`       //协程池大小
	FilterGame    sync.Map `json:"filter_game"`     //商户过滤游戏集合
	LiveMatch     sync.Map `json:"live_match"`      //滚球赛事列表
	LiveMarketIds sync.Map `json:"live_market_ids"` //滚球赛事盘口ID集合
	EarlyMatch    sync.Map `json:"early_match"`     //早盘赛事列表
	Nav           sync.Map `json:"nav"`             //游戏列表
	Recommend     sync.Map `json:"recommend"`       //推荐赛事列表
	Stat          sync.Map `json:"stat"`            //赛事计数列表
	Notice        sync.Map `json:"notice"`          //公告
	//HotMchMarket  map[string]interface{} `json:"hot_mch_market"`  //热门赛事盘口数据

	GameName       *freecache.Cache `json:"game_name"`       //游戏多语言中文名
	TournamentName *freecache.Cache `json:"tournament_name"` //联赛多语言名
	OddTypeName    *freecache.Cache `json:"odd_type_name"`   //玩法多语言名
	VirtualName    *freecache.Cache `json:"virtual_name"`    //虚拟体育多语言名
}

type RamCaCheCheck struct {
	PoolSize      int                                `json:"pool_size"`
	FilterGames   map[uint64][]string                `json:"filter_games"`
	LiveMatches   map[string][]utils.GameIndex       `json:"live_matches"`
	EarlyMatches  map[string][]utils.GameIndex       `json:"early_matches"`
	Recommend     map[string][]utils.GameIndex       `json:"recommend"`
	Nav           map[string][]GameNav               `json:"nav"`
	Notice        map[string]NoticeData              `json:"notice"`
	Stat          map[string]utils.MatchCountStat    `json:"stat"`
	HotMchMarket  map[string]map[string]utils.Market `json:"hot_mch_market"`
	LiveMarketIds map[string]map[string][]string     `json:"live_market_ids"`
	I18nNames     map[string]string                  `json:"i18n_names"`
}

var (
	keyLock  = sync.Map{} //key伪锁
	HotGames = map[string]string{
		"257154660915053": "LOL",
		"257289795134339": "DOTA2",
		"257561197207055": "KoG",
		"257578064923863": "CS:GO",
	} //热门游戏
	HotMatchIds []string //热门赛事id[推荐赛事前10条]
)

func RefreshRamData(key string) bool {

	var (
		res bool
		err error
	)
	keyCols := strings.Split(key, "-")
	prefixKey := keyCols[0]
	switch prefixKey {
	case "filterGame": //商户禁用游戏数据
		if len(keyCols) < 2 {
			fmt.Printf("RefreshRamData filterGame key[%s] length error\n", key)
			return false
		}
		merchantID, err := strconv.ParseUint(keyCols[1], 10, 64)
		if err != nil {
			fmt.Printf("RefreshRamData filterGame merchantID error:%s\n", err.Error())
			return false
		}

		res, err = SetMerchantFilterGames(merchantID)
		if err != nil {
			fmt.Printf("RefreshRamData filterGame SetMerchantFilterGames error:%s\n", err.Error())
			return false
		}
	case "live", "early": //首页赛事数据
		if len(keyCols) < 2 {
			fmt.Printf("RefreshRamData mch key[%s] length error\n", key)
			return false
		}

		flag := 0
		if prefixKey == "live" {
			flag = 3
		} else if prefixKey == "early" {
			flag = 2
		} else {
			fmt.Println("未支持内存数据，key:", key)
			return false
		}

		res, err = SetGameIndex(keyCols[1], flag, time.Now())
		if err != nil {
			fmt.Printf("RefreshRamData mch SetGameIndex error:%s\n", err.Error())
			return false
		}

	case "nav": //游戏导航栏数据
		res, err = NavCacheSet()
		if err != nil {
			fmt.Printf("RefreshRamData nav NavCacheSet error:%s\n", err.Error())
			return false
		}

	case "recommend": //推荐赛事
		res, err = RecommendCacheSet()
		if err != nil {
			fmt.Printf("RefreshRamData recommend RecommendCacheSet error:%s\n", err.Error())
			return false
		}

	case "notice": //公告
		if len(keyCols) < 2 {
			fmt.Printf("RefreshRamData notice key[%s] length error\n", key)
			return false
		}

		res, err = NoticeCacheSet(keyCols[1])
		if err != nil {
			fmt.Printf("RefreshRamData notice NoticeCacheSet error:%s\n", err.Error())
			return false
		}

	case "stat": //赛事计数
		res, err = MatchStatisticsSet()
		if err != nil {
			fmt.Printf("RefreshRamData stat MatchStatisticsSet error:%s\n", err.Error())
			return false
		}
	case "timer": //赛事计时器
		err := LoadTimers()
		if err != nil {
			fmt.Printf("RefreshRamData stat MatchTimers error:%s\n", err.Error())
			return false
		}
		res = true

	default:
		fmt.Println("未支持内存数据，key:", key)
	}

	return res
}

// 首页所有赛事数据缓存设置
func SetGameIndex(gameId string, flag int, now time.Time) (bool, error) {

	idxMatches, err := idxMatchDataLoad(NewFilterGames, gameId, flag, 0, 20, now, lang.CN)
	if err != nil {
		return false, err
	}

	idxMatchRamLoad(flag, gameId, idxMatches)

	return true, nil
}

//首页赛事列表数据加载
func idxMatchRamLoad(flag int, gameId string, idxMatches []utils.GameIndex) {

	if flag == 2 { //早盘赛事
		mt.ramCacheData.EarlyMatch.Store(fmt.Sprintf("early-%s", gameId), idxMatches)
	} else if flag == 3 { //滚球赛事
		mt.ramCacheData.LiveMatch.Store(fmt.Sprintf("live-%s", gameId), idxMatches)
		mpGameLiveMatches := map[string][]utils.GameIndex{}
		for _, mch := range idxMatches {
			//热门游戏滚球赛事列表
			liveFilterRecMatch(idxMatches)

			if _, ok := HotGames[mch.GameID]; ok {
				mpGameLiveMatches[mch.GameID] = append(mpGameLiveMatches[mch.GameID], mch)
			}

			mt.ramCacheData.LiveMarketIds.Store(mch.ID, mch.MktIDs)
		}

		for gameId, _ := range HotGames {
			//无可用赛事设置为空，避免内存数据不更新
			if _, ok := mpGameLiveMatches[gameId]; !ok {
				mpGameLiveMatches[gameId] = []utils.GameIndex{}
			}
		}

		for gameID, mchDatas := range mpGameLiveMatches {
			mt.ramCacheData.LiveMatch.Store(fmt.Sprintf("live-%s", gameID), mchDatas)
		}
	}
}

func liveFilterRecMatch(idxMatches []utils.GameIndex) {

	var recMatch []utils.GameIndex
	for _, mch := range idxMatches {
		//推荐赛事
		if mch.Rec > 0 {
			recMatch = append(recMatch, mch)
		}
	}

	if len(recMatch) > 0 {
		sort.Slice(recMatch, func(i, j int) bool {
			return recMatch[i].Rec > recMatch[j].Rec
		})

		if len(recMatch) > 20 {
			recMatch = recMatch[0:20]
		}
	}

	mt.ramCacheData.Recommend.Store("recommend", recMatch)

}

// 首页游戏菜单栏数据缓存设置
func NavCacheSet() (bool, error) {

	var (
		nav  []GameNav
		data []*redis.SliceCmd
	)

	pipe := mt.ZKRedisCluster.Pipeline()
	defer pipe.Close()

	mpNameI18nCmds := map[string]*redis.SliceCmd{}
	for _, id := range mt.Config.GameIDs {
		if utils.CheckSportsGameID(id) {
			continue
		}
		key := fmt.Sprintf("gnav:%s", id)
		val := pipe.HMGet(key, "id", "short_name", "cn_name", "en_name", "status", "count", "sort_code")
		data = append(data, val)

		mpNameI18nCmds[id] = pipe.HMGet(fmt.Sprintf(RedisLangGame, id), Languages...)
	}

	_, err := pipe.Exec()
	if err != nil && err != redis.Nil {
		return false, err
	}

	for _, value := range data {

		res, err := value.Result()
		if err != nil {
			return false, err
		}

		if res[0] == nil { // 对应游戏id的记录不存在
			continue
		}

		id := getHashValue(res[0])
		nameMap := map[string]string{}
		if nameCmd, ok := mpNameI18nCmds[id]; ok {
			nameVals, err := nameCmd.Result()
			if err != nil {
				continue
			}

			for i, nv := range nameVals {
				nameMap[Languages[i]] = getHashValue(nv)
			}
		}
		n := GameNav{
			ID: id,
			//ShortName: getHashValue(res[1]),
			//CnName:    getHashValue(res[2]),
			//EnName:    getHashValue(res[3]),
			Status:   getHashValue(res[4]),
			Count:    getHashValue(res[5]),
			SortCode: getHashValue(res[6]),
			NameMap:  nameMap,
		}
		nav = append(nav, n)
	}

	mt.ramCacheData.Nav.Store("nav", nav)
	return true, nil
}

// 首页推荐赛事列表数据缓存设置
func RecommendCacheSet() (bool, error) {

	key := "mchRecommend"
	opt := redis.ZRangeBy{
		Min:    "1",
		Max:    "+inf",
		Offset: 0,
		Count:  20, // 默认最多取20个推荐赛事
	}

	mchIDs, err := mt.ZKRedisCluster.ZRangeByScore(key, &opt).Result()
	if err != nil {
		return false, err
	}

	if len(mchIDs) == 0 {
		return true, nil
	}

	filterGames := set.NewStringSet()
	data, err := utils.MatchIndexGet(mt.ZKRedisCluster, mchIDs, filterGames)
	if err != nil {
		return false, err
	}

	recommendMatches, err := idxMatchFormat(NewFilterGames, data, lang.CN)
	if err != nil {
		return false, err
	}

	mt.ramCacheData.Recommend.Store("recommend", recommendMatches)
	return true, nil
}

//公告缓存第一页的数据
func NoticeCacheSet(lan string) (bool, error) {

	now := time.Now()
	y, m, d := now.Date()
	today := time.Date(y, m, d, 0, 0, 0, 0, now.Location())

	data := NoticeData{}
	opt := redis.ZRangeBy{ // 只显示1个月内公告
		Min:    fmt.Sprintf("%d", today.AddDate(0, -1, 0).Unix()),
		Max:    "+inf",
		Offset: 0,
		Count:  10,
	}
	pipe := mt.ZKRedisCluster.Pipeline()
	defer pipe.Close()

	key := fmt.Sprintf(redisNoticeList, lan)
	listCmd := pipe.ZRevRangeByScore(key, &opt)
	countCmd := pipe.ZCount(key, opt.Min, opt.Max)
	_, err := pipe.Exec()
	if err != nil {
		return false, err
	}

	list, err := listCmd.Result()
	if err != nil {
		return false, err
	}

	for _, sv := range list {
		noticeValue := Notice{}
		err = helper.JsonUnmarshalFromString(sv, &noticeValue)
		if err != nil {
			fmt.Println("NoticeList JsonUnmarshalFromString error:", err.Error())
			continue
		}

		data.D = append(data.D, noticeValue)
	}

	data.T = countCmd.Val()

	mt.ramCacheData.Notice.Store(fmt.Sprintf("notice-%s", lan), data)
	return true, nil
}

/**
* @Description: 赛事统计内存设置
* @Author:  awen
* @Date: 2021-10-30 19:35
* @LastEditTime: 2021-10-30 19:35
* @LastEditors: awen
 */
func MatchStatisticsSet() (bool, error) {

	filterGames := strset.New()
	data, err := utils.GameNavMatchCountGet(mt.ZKRedisCluster, nil, filterGames, time.Now())
	if err != nil {
		return false, err
	}

	mt.ramCacheData.Stat.Store("stat", data)
	return true, nil
}

func GetCacheDataMap(key string) RamCaCheCheck {

	data := RamCaCheCheck{
		PoolSize:      mt.idxCachePool.Running(),
		FilterGames:   map[uint64][]string{},
		LiveMatches:   map[string][]utils.GameIndex{},
		EarlyMatches:  map[string][]utils.GameIndex{},
		Recommend:     map[string][]utils.GameIndex{},
		Notice:        map[string]NoticeData{},
		Stat:          map[string]utils.MatchCountStat{},
		Nav:           map[string][]GameNav{},
		HotMchMarket:  map[string]map[string]utils.Market{},
		LiveMarketIds: map[string]map[string][]string{},
	}

	for k, v := range MerchantFilterGame {
		data.FilterGames[k] = v.List()
	}

	mt.ramCacheData.LiveMatch.Range(func(key, value interface{}) bool {
		data.LiveMatches[key.(string)] = value.([]utils.GameIndex)
		return true
	})

	mt.ramCacheData.EarlyMatch.Range(func(key, value interface{}) bool {
		data.EarlyMatches[key.(string)] = value.([]utils.GameIndex)
		return true
	})

	mt.ramCacheData.LiveMarketIds.Range(func(key, value interface{}) bool {
		data.LiveMarketIds[key.(string)] = value.(map[string][]string)
		return true
	})

	mt.ramCacheData.Recommend.Range(func(key, value interface{}) bool {
		data.Recommend[key.(string)] = value.([]utils.GameIndex)
		return true
	})

	mt.ramCacheData.Stat.Range(func(key, value interface{}) bool {
		data.Stat[key.(string)] = value.(utils.MatchCountStat)
		return true
	})

	mt.ramCacheData.Nav.Range(func(key, value interface{}) bool {
		data.Nav[key.(string)] = value.([]GameNav)
		return true
	})

	mt.ramCacheData.Notice.Range(func(key, value interface{}) bool {
		data.Notice[key.(string)] = value.(NoticeData)
		return true
	})

	return data
}

func UpdateHotMatchSize(n int) {
	mt.hotMchSize = n
}

package model

import (
	"fmt"
	"game/utils"
	mqtt "github.com/eclipse/paho.mqtt.golang"
)


const (
	mqttBalanceFormat = `{"uid":"%d","account":"%s","balance":"%s"}`
)

// 盘口单注注单投注成功后推送更新盘口注单统计数据通知
func MqttPushMarketOrderBet(matchID, marketID string) {

	payload := fmt.Sprintf(mqttMarketOrderBet, matchID, marketID)
	key := fmt.Sprintf(topicMarketOrderBet, matchID)
	_ = utils.MQTTNotify(mt.Notify, key, utils.QoSAtMostOnce, payload)
}

// 单注和串注注单投注成功后推送实时注单刷新通知
func MqttPushOrderRefresh(orderType int) {

	payload := fmt.Sprintf(mqttOrderRefresh, orderType)
	_ = utils.MQTTNotify(mt.Notify, topicOrderRefresh, utils.QoSAtMostOnce, payload)
}

/**
 * @Description: mqtt推送信用用户当前可用额度
 * @Author: awen
 * @Date: 2020/05/14 14:29
 * @LastEditTime: 2020/05/14 14:29
 * @LastEditors: awen
 */
func mqttPushCreditBalance(cli mqtt.Client, uid uint64, memberAccount string, balance string) error {

	payload := fmt.Sprintf(mqttBalanceFormat, uid, memberAccount, balance)
	key := fmt.Sprintf("/member/balance/%d", uid)

	if token := cli.Publish(key, utils.QoSAtMostOnce, false, payload); token.Wait() && token.Error() != nil {
		return token.Error()
	}

	return nil
}
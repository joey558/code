package model

import (
	"fmt"
	"game/mRejson"
	"game/utils"
	"game/wallet"
	g "github.com/doug-martin/goqu/v9"
	"github.com/go-redis/redis/v7"
	"github.com/scylladb/go-set"
	"github.com/scylladb/go-set/strset"
)

const (
	TblMerchant = "tbl_merchant"
)

type Merchant struct {
	ID            uint64 `json:"id" db:"id"`                         //商户id
	ParentId      uint64 `json:"parent_id" db:"parent_id"`           //父商户id
	ParentAccount string `json:"parent_account" db:"parent_account"` //父商户账号
	Account       string `json:"account" db:"account"`               //商户账号
	Status        uint8  `json:"status" db:"status"`                 //商户状态(1：开启，0：关闭)
	MType         int    `json:"m_type" db:"m_type"`                 //商户类型(0：普通，1：信用)
	SecretKey     string `json:"secret_key" db:"secret_key"`         //秘钥
}

func MerchantCheck(member wallet.Member) (bool, error) {

	m, err := mRejson.Get(mt.MerchantRedis, member.MerchantID)
	if err != nil {
		return false, err
	}

	if m.Status == 0 {
		return false, nil
	}

	return true, nil
}

func MerchantFindOne(id uint64) (mRejson.MCache, error) {

	return mRejson.Get(mt.MerchantRedis, id)
}

func MerchantListDB(ex g.Ex) ([]Merchant, error) {

	var data []Merchant
	query, _, _ := dialect.Select(clMerchant...).From(TblMerchant).Where(ex).ToSQL()
	err := mt.MerchantSlaveDB.Select(&data, query)
	if err != nil {
		return data, err
	}

	return data, nil
}

func InitMerchantFilterGame() {

	MerchantFilterGame = map[uint64]*strset.Set{}
	merchants, err := MerchantListDB(g.Ex{"status": 1})
	if err != nil {
		fmt.Printf("InitMerchantFilterGame MerchantListDB error:%s\n", err.Error())
		return
	}

	mpStrSliceCmd := map[uint64]*redis.StringSliceCmd{}
	pipe := mt.ZKRedisCluster.Pipeline()
	for _, m := range merchants {
		mpStrSliceCmd[m.ID] = pipe.SMembers(fmt.Sprintf(utils.RedisMerchantFilterGame, m.ID))
	}

	_, err = pipe.Exec()
	if err != nil {
		fmt.Printf("InitMerchantFilterGame pipe exec error:%s\n", err.Error())
		return
	}

	var gmIds []string
	for merchID, cmd := range mpStrSliceCmd {
		gmIds, err = cmd.Result()
		if err != nil || len(gmIds) == 0 {
			continue
		}

		gameSet := set.NewStringSet(gmIds...)
		MerchantFilterGame[merchID] = gameSet
	}

	fmt.Println("MerchantFilterGames load success!")
}
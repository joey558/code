#! /bin/bash

PROJECT="djGame"
BRANCH="uat"
ETCDS="34.92.193.98:2379,34.92.58.208:2379"
CFG_PATH="/dj/uat/merchant/bob.json"

git fetch
git checkout $BRANCH
git pull
git submodule init
git submodule update
go build -o $PROJECT

pkill $PROJECT
mkdir log 2>/dev/null
chmod +x $PROJECT
nohup ./$PROJECT $ETCDS $CFG_PATH es 1>>log/a.log 2>>log/a.log 2>&1 &
#nohup ./$PROJECT $ETCDS $CFG_PATH mysql 1>>log/a.log 2>>log/a.log 2>&1 &
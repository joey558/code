#! /bin/bash

DIR=$(dirname $(readlink -f $0))
PROJECT="djGame"
BRANCH="new_dev"
ETCDS="34.92.193.98:2379,34.92.58.208:2379"
CFG_PATH="/dj/dev/merchant/new_bob.json"

git fetch
git checkout $BRANCH
git pull
git submodule init
git submodule update
GitReversion=`git rev-parse HEAD`
BuildTime=`date +'%Y.%m.%d.%H%M%S'`
BuildGoVersion=`go version`
go build -ldflags "-X main.gitReversion=${GitReversion}  -X 'main.buildTime=${BuildTime}' -X 'main.buildGoVersion=${BuildGoVersion}'" -o $PROJECT

pkill $PROJECT
nohup ${DIR}/$PROJECT $ETCDS $CFG_PATH es > ${DIR}/log/a.log 2>&1 &
#nohup ${DIR}/$PROJECT $ETCDS $CFG_PATH mysql > ${DIR}/log/a.log 2>&1 &
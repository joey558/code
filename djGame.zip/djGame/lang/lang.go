package lang

const (
	CN = "cn" //简体中文
	ZH = "zh" //繁体中文
	EN = "en" //英文
	VI = "vi" //越南文
	TH = "th" //泰语
	ML = "ml" //马来文
)

func Text(lang, key string) string {
	switch lang {
	case CN:
		return langCN[key]
	case ZH:
		return langZH[key]
	case VI:
		return langVI[key]
	case TH:
		return langTH[key]
	case ML:
		return langML[key]
	default:
		return langEN[key]
	}
}

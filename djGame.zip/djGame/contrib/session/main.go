package session

import (
	"errors"

	// "log"
	"fmt"
	"github.com/go-redis/redis/v7"
	"github.com/valyala/fasthttp"
)

var (
	client *redis.Client
)

const (
	RedisUuid       = "token:TI%d" // 用户token key
	RedisSessionKey = "token:%s"   // 用户session key
)

func New(reddb *redis.Client) {
	client = reddb
}

func Set(ctx *fasthttp.RequestCtx, value []byte, uid uint64) (string, error) {

	uuid := fmt.Sprintf(RedisUuid, uid)
	token := fmt.Sprintf("%d", Cputicks())
	key := fmt.Sprintf(RedisSessionKey, token)

	val := client.Get(uuid).Val()
	pipe := client.TxPipeline()

	defer pipe.Close()

	if len(val) > 0 {
		//同一个用户，一个时间段，只能登录一个
		pipe.Unlink(fmt.Sprintf(RedisSessionKey, val))
	}
	pipe.Set(uuid, token, -1)
	pipe.SetNX(key, value, defaultGCLifetime)

	_, err := pipe.Exec()

	return token, err
}

func Destroy(ctx *fasthttp.RequestCtx) {

	key := string(ctx.Request.Header.Peek("token"))
	if len(key) == 0 {
		return
	}
	client.Unlink(fmt.Sprintf(RedisSessionKey, key))
	// cookie.Delete(ctx, defaultSessionKeyName)
}

func Get(ctx *fasthttp.RequestCtx) ([]byte, error) {

	key := string(ctx.Request.Header.Peek("token"))
	if len(key) == 0 {
		return nil, errors.New("header missing token")
	}

	val, err := client.Get(fmt.Sprintf(RedisSessionKey, key)).Bytes()
	if err == redis.Nil {
		return nil, fmt.Errorf("session:%s missing in the redis", key)
	} else if err != nil {
		return nil, err
	} else {
		return val, nil
	}
}

func Update(value []byte, uid uint64) bool {

	uuid := fmt.Sprintf(RedisUuid, uid)

	val := client.Get(uuid).Val()
	pipe := client.TxPipeline()
	defer pipe.Close()

	if len(val) == 0 {
		return false
	}

	key := fmt.Sprintf(RedisSessionKey, val)
	pipe.Unlink(key)
	pipe.SetNX(key, value, defaultGCLifetime)

	_, err := pipe.Exec()
	if err != nil {
		return false
	}
	return true
}

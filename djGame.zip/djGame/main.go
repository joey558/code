package main

import (
	"fmt"
	"log"
	"os"
	"os/signal"
	"strings"
	"time"

	"game/contrib/apollo"
	"game/middleware"
	"game/model"
	"game/router"

	_ "github.com/go-sql-driver/mysql"
	"github.com/valyala/fasthttp"
)

var (
	gitReversion   = ""
	buildTime      = ""
	buildGoVersion = ""
)

func main() {

	argc := len(os.Args)
	if argc != 4 {
		fmt.Printf("%s <etcds> <cfgPath> mysql|es \n", os.Args[0])
		return
	}

	etcds := os.Args[1]
	cfgPath := os.Args[2]
	cfg := model.Conf{}
	endpoints := strings.Split(etcds, ",")
	apollo.New(endpoints)
	_ = apollo.Parse(cfgPath, &cfg)
	apollo.Close()
	model.Constructor(cfg)

	b := router.BuildInfo{
		GitReversion:   gitReversion,
		BuildTime:      buildTime,
		BuildGoVersion: buildGoVersion,
	}
	app := router.SetupRouter(b)
	srv := &fasthttp.Server{
		Handler:            middleware.Use(app.Handler),
		ReadTimeout:        5 * time.Second,
		WriteTimeout:       10 * time.Second,
		Name:               "djGame",
		MaxRequestBodySize: 51 * 1024 * 1024,
	}
	// 监听服务
	go func() {
		fmt.Println("djGame running", cfg.Game.Addr)
		if err := srv.ListenAndServe(cfg.Game.Addr); err != nil {
			log.Fatalf("Error in ListenAndServe: %s", err)
		}
	}()

	// 监听退出
	quit := make(chan os.Signal, 1)
	signal.Notify(quit, os.Interrupt)
	<-quit
	fmt.Println("进程退出")
	err := model.ServerStop(srv)
	if err != nil {
		fmt.Println(err.Error())
	}
}

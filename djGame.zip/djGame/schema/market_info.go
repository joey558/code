package schema

type Odd struct {
	ID       uint64 `db:"id" json:"id"`
	IsWinner int    `db:"is_winner" json:"is_winner"`
	MarketID uint64 `db:"market_id" json:"market_id"`
	MatchID  uint64 `db:"match_id" json:"match_id"`
	Name     string `db:"name" json:"name"`
	Odd      string `db:"odd" json:"odd"`
	OrgOdd   string `db:"org_odd" json:"org_odd"`
	Round    int    `db:"round" json:"round"`
	SortID   int    `db:"sort_id" json:"sort_id"`
	Visible  int    `db:"visible" json:"visible"`
}

type Match struct {
	AdminVideoURL       string `db:"admin_video_url" json:"admin_video_url"`
	AutoClosedTime      int    `db:"auto_closed_time" json:"auto_closed_time"`
	BetDelayTime        int    `db:"bet_delay_time" json:"bet_delay_time"`
	Bo                  int    `db:"bo" json:"bo"`
	Category            int    `db:"category" json:"category"`
	CloseTime           int    `db:"close_time" json:"close_time"`
	CreateByID          uint64 `db:"create_by_id" json:"create_by_id"`
	CreateByName        string `db:"create_by_name" json:"create_by_name"`
	CreateTime          int    `db:"create_time" json:"create_time"`
	EndTime             int    `db:"end_time" json:"end_time"`
	GameID              uint64 `db:"game_id" json:"game_id"`
	ID                  uint64 `db:"id" json:"id"`
	IsLive              int    `db:"is_live" json:"is_live"`
	IsPassOff           int    `db:"is_pass_off" json:"is_pass_off"`
	LiveSupport         int    `db:"live_support" json:"live_support"`
	MatchLevel          int    `db:"match_level" json:"match_level"`
	MatchTeam           string `db:"match_team" json:"match_team"`
	Score               string `db:"score" json:"score"`
	StartTime           int    `db:"start_time" json:"start_time"`
	Status              int    `db:"status" json:"status"`
	Suspended           int    `db:"suspended" json:"suspended"`
	Title               string `db:"title" json:"title"`
	TournamentID        uint64 `db:"tournament_id" json:"tournament_id"`
	TournamentShortName string `db:"tournament_short_name" json:"tournament_short_name"`
	UpdateByID          uint64 `db:"update_by_id" json:"update_by_id"`
	UpdateByName        string `db:"update_by_name" json:"update_by_name"`
	UpdateTime          int    `db:"update_time" json:"update_time"`
	UserVideoURL        string `db:"user_video_url" json:"user_video_url"`
	Visible             int    `db:"visible" json:"visible"`
}

type Market struct {
	BonusProportion int     `db:"bonus_proportion" json:"bonus_proportion"`
	CloseTime       int     `db:"close_time" json:"close_time"`
	CnName          string  `db:"cn_name" json:"cn_name"`
	CreateByID      uint64  `db:"create_by_id" json:"create_by_id"`
	CreateByName    string  `db:"create_by_name" json:"create_by_name"`
	CreateTime      int     `db:"create_time" json:"create_time"`
	EnName          string  `db:"en_name" json:"en_name"`
	ID              uint64  `db:"id" json:"id"`
	IsDefault       int     `db:"is_default" json:"is_default"`
	IsInputReject   int     `db:"is_input_reject" json:"is_input_reject"`
	IsReopen        int     `db:"is_reopen" json:"is_reopen"`
	IsSettleReject  int     `db:"is_settle_reject" json:"is_settle_reject"`
	MatchID         uint64  `db:"match_id" json:"match_id"`
	MaxBonusTotal   string  `db:"max_bonus_total" json:"max_bonus_total"`
	OddTypeID       uint64  `db:"odd_type_id" json:"odd_type_id"`
	OptionType      int     `db:"option_type" json:"option_type"`
	Remark          string  `db:"remark" json:"remark"`
	ReturnRate      float64 `db:"return_rate" json:"return_rate"`
	Round           int     `db:"round" json:"round"`
	SettleCount     int     `db:"settle_count" json:"settle_count"`
	SingleMaxBonus  string  `db:"single_max_bonus" json:"single_max_bonus"`
	SortCode        int     `db:"sort_code" json:"sort_code"`
	Status          int     `db:"status" json:"status"`
	Suspended       int     `db:"suspended" json:"suspended"`
	UpdateByID      uint64  `db:"update_by_id" json:"update_by_id"`
	UpdateByName    string  `db:"update_by_name" json:"update_by_name"`
	UpdateTime      int     `db:"update_time" json:"update_time"`
	Visible         int     `db:"visible" json:"visible"`
	PrizeLimit      int     `db:"prize_limit" json:"prize_limit"`               // 风控单注限红
	MbMktPrizeLimit int     `db:"mb_mkt_prize_limit" json:"mb_mkt_prize_limit"` // 风控会员盘口限红
	MbMchPrizeLimit int     `db:"mb_mch_prize_limit" json:"mb_mch_prize_limit"` // 会员赛事限红
}

// getHandicapInfo 请求结构体
type HandicapReq struct {
	MatchID  []string `json:"match"`
	MarketID []string `json:"market"`
	OddID    []string `json:"odd"`
}

// getHandicapInfo 返回结构体
type HandicapResp struct {
	Odds    map[string]Odd    `json:"Odds"`
	Matchs  map[string]Match  `json:"Matchs"`
	Markets map[string]Market `json:"Markets"`
}

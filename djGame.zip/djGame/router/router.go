package router

import (
	"fmt"
	"runtime/debug"
	"strconv"
	"time"

	"github.com/valyala/fasthttp/pprofhandler"

	"game/controller"

	"github.com/buaazp/fasthttprouter"
	"github.com/valyala/fasthttp"
)

var (
	apiTimeoutMsg = `{"status": "false","data":"服务器响应超时，请稍后重试"}`
	apiTimeout    = time.Second * 300
	router        *fasthttprouter.Router
	buildInfo     BuildInfo
	//systemTime 响应json bytes 数组, 0-25 为 `{"status":"true","data":"` 25-34 为10位时间戳，35-36 为"}
	systemTimeResp = []byte{123, 34, 115, 116, 97, 116, 117, 115, 34, 58, 34, 116, 114, 117, 101, 34, 44, 34, 100, 97, 116, 97, 34, 58, 34, 49, 54, 52, 57, 54, 54, 48, 50, 52, 52, 34, 125}
)

type BuildInfo struct {
	GitReversion   string
	BuildTime      string
	BuildGoVersion string
}

func apiServerPanic(ctx *fasthttp.RequestCtx, rcv interface{}) {

	err := rcv.(error)
	fmt.Println(err)
	debug.PrintStack()

	if r := recover(); r != nil {
		fmt.Println("recovered failed", r)
	}

	ctx.SetStatusCode(500)
	return
}

func Version(ctx *fasthttp.RequestCtx) {

	ctx.SetContentType("text/html; charset=utf-8")
	fmt.Fprintf(ctx, "djGame<br />Git reversion = %s<br />Build Time = %s<br />Go version = %s<br />System Time = %s<br />",
		buildInfo.GitReversion, buildInfo.BuildTime, buildInfo.BuildGoVersion, ctx.Time())

	//ctx.Request.Header.VisitAll(func (key, value []byte) {
	//	fmt.Fprintf(ctx, "%s: %s<br/>", string(key), string(value))
	//})
}
func GetSystemTime(ctx *fasthttp.RequestCtx) {
	nowUxStr := strconv.FormatInt(time.Now().Unix(), 10)
	for i, bit := range []byte(nowUxStr) {
		systemTimeResp[i+25] = bit
	}
	ctx.SetBody(systemTimeResp)
}

// SetupRouter 设置路由列表
func SetupRouter(b BuildInfo) *fasthttprouter.Router {

	router = fasthttprouter.New()
	router.PanicHandler = apiServerPanic

	memberCtl := new(controller.MemberController)
	betOrderCtl := new(controller.BetOrderController)
	limitBetCtl := new(controller.LimitBetController)

	matchCtl := new(controller.MatchController)
	gameCtl := new(controller.GameController)
	noticeCtl := new(controller.NoticeController)
	virtualCtl := new(controller.VirtualController)

	// 版本号
	buildInfo = b
	get("/game/version", Version)
	// 性能测试
	get("/debug/pprof/", pprofhandler.PprofHandler)
	get("/debug/pprof/block", pprofhandler.PprofHandler)
	get("/debug/pprof/allocs", pprofhandler.PprofHandler)
	get("/debug/pprof/cmdline", pprofhandler.PprofHandler)
	get("/debug/pprof/goroutine", pprofhandler.PprofHandler)
	get("/debug/pprof/heap", pprofhandler.PprofHandler)
	get("/debug/pprof/profile", pprofhandler.PprofHandler)
	get("/debug/pprof/trace", pprofhandler.PprofHandler)
	get("/debug/pprof/threadcreate", pprofhandler.PprofHandler)

	// 注单管理-用户投注
	post("/game/bet", betOrderCtl.Bet)

	// 用户主页-游戏列表
	get("/game/nav", gameCtl.Nav)
	// 用户主页-联赛列表
	get("/game/tour", gameCtl.Tour)
	// 用户主页-联赛列表-虚拟体育
	get("/game/sports/tour", gameCtl.SportsTour)
	//公告
	get("/game/notice", noticeCtl.List)
	//用户 前台首页数据展示(赛事列表)
	get("/game/index", matchCtl.Index)
	//用户 前台首页数据展示(赛事列表)-虚拟体育
	get("/game/sports/index", matchCtl.SportsIndex)
	//用户 前台首页数据展示(赛果列表)-虚拟体育
	get("/game/sports/indexResult", matchCtl.SportsIndexResult)
	//用户 前台首页数据展示(当前指定批次的赛果)-虚拟体育
	get("/game/sports/batchNoResult", matchCtl.SportsBatchNoResult)
	//推荐赛事
	get("/game/recommend", matchCtl.Recommend)
	// 操盘管理-操盘主页-赛事获取计时器信息
	get("/game/getTimer", matchCtl.GetTimer)
	// 用户前端赛事计数
	get("/game/stat", matchCtl.MatchStat)
	//用户 前台盘口详情展示(盘口列表)
	get("/game/view", matchCtl.View)
	//用户 前台盘口详情展示(盘口列表)-虚拟体育
	get("/game/sports/view", matchCtl.SportsView)
	// 用户首次登录新上版本时 弹出引导页
	get("/game/userver", gameCtl.UserVer)
	//【B端旗舰店】首页-热门推荐
	get("/game/obRecommend", matchCtl.ObRecommend)

	//获取游戏名称
	post("/game/name", gameCtl.GetName)
	//获取联赛名称
	post("/game/tourName", gameCtl.GetTourName)

	// 注单管理-用户注单历史
	get("/game/orderList", betOrderCtl.List)
	// 余额
	get("/game/balance", memberCtl.Balance)
	// 账变记录
	get("/game/fundList", memberCtl.FundList)
	// 赛事管理-获取用户限额
	post("/game/bet/quota", limitBetCtl.SurplusQuota)
	//会员管理-设置用户赔率变动方式
	get("/game/odd/updateType", memberCtl.OddUpdateTypeSet)
	//id查询赛事列表
	post("/game/matchList", matchCtl.MatchList)
	// 获取主播盘小局开始时间和游戏截图
	post("/game/anchorInfo", matchCtl.AnchorInfo)
	//获取冠军赛战队
	post("/game/team", matchCtl.GetTeam)
	//获取当前服务器时间
	get("/game/systemTime", GetSystemTime)
	//前端功能统计
	post("/game/statistics", memberCtl.FrontStatistics)
	//获取有视频源的赛事列表
	get("/game/getVideoList", matchCtl.GetVideoList)
	//获取所有内存数据
	get("/game/checkCacheData", gameCtl.CheckCacheData)
	//修改热门赛事内存化最大数
	post("/game/hotMatchSet", gameCtl.HotMatchDataSizeSet)
	//获取今天最大派彩金额
	get("/game/member/prize", memberCtl.TodayMaxPrize)
	//会员自定义默认语言
	get("/game/langSet", memberCtl.LangSet)
	//获取串注超限设置
	get("/game/parlay/settings", limitBetCtl.GetOverrunSetting)
	//获取节庆图片
	get("/game/festival", memberCtl.GetFestival)
	// 获取一般联赛积分榜
	get("/game/commonScore", matchCtl.CommonScore)
	// 获取小组赛积分榜
	get("/game/groupScore", matchCtl.GroupScore)
	// 获取淘汰赛积分榜
	get("/game/disuseScore", matchCtl.DisuseScore)

	//
	get("/game/virtualRpl", virtualCtl.VideoRpl)
	return router
}

// get is a shortcut for router.GET(path string, handle fasthttp.RequestHandler)
func get(path string, handle fasthttp.RequestHandler) {
	router.GET(path, fasthttp.TimeoutHandler(handle, apiTimeout, apiTimeoutMsg))
}

// head is a shortcut for router.HEAD(path string, handle fasthttp.RequestHandler)
func head(path string, handle fasthttp.RequestHandler) {
	router.HEAD(path, fasthttp.TimeoutHandler(handle, apiTimeout, apiTimeoutMsg))
}

// options is a shortcut for router.OPTIONS(path string, handle fasthttp.RequestHandler)
func options(path string, handle fasthttp.RequestHandler) {
	router.OPTIONS(path, fasthttp.TimeoutHandler(handle, apiTimeout, apiTimeoutMsg))
}

// post is a shortcut for router.POST(path string, handle fasthttp.RequestHandler)
func post(path string, handle fasthttp.RequestHandler) {
	router.POST(path, fasthttp.TimeoutHandler(handle, apiTimeout, apiTimeoutMsg))
}

// put is a shortcut for router.PUT(path string, handle fasthttp.RequestHandler)
func put(path string, handle fasthttp.RequestHandler) {
	router.PUT(path, fasthttp.TimeoutHandler(handle, apiTimeout, apiTimeoutMsg))
}

// patch is a shortcut for router.PATCH(path string, handle fasthttp.RequestHandler)
func patch(path string, handle fasthttp.RequestHandler) {
	router.PATCH(path, fasthttp.TimeoutHandler(handle, apiTimeout, apiTimeoutMsg))
}

// delete is a shortcut for router.DELETE(path string, handle fasthttp.RequestHandler)
func delete(path string, handle fasthttp.RequestHandler) {
	router.DELETE(path, fasthttp.TimeoutHandler(handle, apiTimeout, apiTimeoutMsg))
}

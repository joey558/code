package utils

import (
	"fmt"
	mqtt "github.com/eclipse/paho.mqtt.golang"
	errs "github.com/pkg/errors"
)

// mqtt 服务质量参数
const (
	QoSAtMostOnce  = 0 // 最多一次
	QoSAtLeastOnce = 1 // 最少一次
	QoSAlwaysOnce  = 2 // 只一次
)

func MQTTNotify(cli mqtt.Client, topic string, qos byte, data interface{}) error {

	var (
		payload interface{}
		size    int
	)
	switch data.(type) {
	case string:
		payload = data
		size = len(data.(string))
	case []byte:
		payload = data
		size = len(data.([]byte))
	default:
		marshal, err := json.Marshal(&data)
		if err != nil {
			return err
		}
		payload = marshal
		size = len(marshal)
	}

	if size > 10240 { // > 1K
		Logger.Info(fmt.Sprintf("[MQTTNotify] large payload. cli:%v, topic:%s, payload:%s\n", cli, topic, payload))
	}

	if token := cli.Publish(topic, qos, false, payload); token.Wait() && token.Error() != nil {
		return errs.WithStack(token.Error())
	}

	return nil
}

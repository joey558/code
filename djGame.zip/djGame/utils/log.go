package utils

import (
	"go.uber.org/zap"
	"go.uber.org/zap/zapcore"
	"os"
)

var (
	Logger *zap.Logger
)

func init() {
	Logger = NewLogger()
}
func InitLogger(l *zap.Logger) {
	Logger = l
}

// NewLogger 日志写入控制台
func NewLogger() *zap.Logger {
	// 打印控制台
	writer := zapcore.AddSync(os.Stdout)
	// 格式相关的配置
	encoderConfig := zap.NewProductionEncoderConfig()
	encoderConfig.EncodeLevel = zapcore.CapitalLevelEncoder // 日志级别使用大写显示
	encoder := zapcore.NewJSONEncoder(encoderConfig)
	core := zapcore.NewCore(encoder, writer, zapcore.InfoLevel)
	return zap.New(core,
		zap.AddCaller()) //添加输出代码位置
}

package utils

import (
	"fmt"
	g "github.com/doug-martin/goqu/v9"
	"github.com/go-redis/redis/v7"
	"github.com/jmoiron/sqlx"
	errs "github.com/pkg/errors"
	"github.com/scylladb/go-set/strset"
	"github.com/shopspring/decimal"
	"strconv"
	"strings"
)

//副玩法调赔参数
type SlaveAdjustOddParam struct {
	MasterOdd         decimal.Decimal //主盘口赔率
	MasterMinInterval decimal.Decimal //主盘口区间最小值
	SlaveMinInterval  decimal.Decimal //副盘口区间最小值
	MasterCoefficient decimal.Decimal //主玩法变赔系数
	SlaveCoefficient  decimal.Decimal //副玩法变赔系数
}

const (
	TblOddLinkageProgram      = "tbl_odd_linkage_program"       // 赔率联动方案表
	TblOddLinkageProgramParam = "tbl_odd_linkage_program_param" // 赔率联动方案参数设置表
)

// 赔率联动方案表
type OddLinkageProgram struct {
	ID              string                   `db:"id" json:"id"`                                 // 赔率联动方案id
	ProgramName     string                   `db:"program_name" json:"program_name"`             // 方案名称
	GameID          string                   `db:"game_id" json:"game_id"`                       // 游戏id
	GameName        string                   `db:"game_name" json:"game_name"`                   // 游戏简称
	MatchLevel      string                   `db:"match_level" json:"match_level"`               // 赛事等级
	Rule            int                      `db:"rule" json:"rule"`                             // 规则：1-主从 2-固定
	MasterOddTypeID string                   `db:"master_odd_type_id" json:"master_odd_type_id"` // 主玩法id
	OddTypeID       string                   `db:"odd_type_id" json:"odd_type_id"`               // 副玩法id
	ParamType       int                      `db:"param_type" json:"param_type"`                 // 参数类型 1-胜率 2-区间
	MatchID         string                   `db:"match_id" json:"match_id"`                     // 赛事ID
	MarketID        string                   `db:"market_id" json:"market_id"`                   // 盘口ID
	Round           int                      `db:"round" json:"round"`                           // 第几局 0-全局 1-第一局 2-第二局 ... 100-上半场
	CreateTime      int64                    `db:"create_time" json:"create_time"`               // 创建时间
	CreateByID      uint64                   `db:"create_by_id" json:"create_by_id" `            // 创建人ID
	CreateByName    string                   `db:"create_by_name" json:"create_by_name"`         // 创建人名称
	OddLinkage      int                      `db:"-" json:"odd_linkage"`                         // 盘口赔率联动开关状态
	ProgramParams   []OddLinkageProgramParam `db:"-" json:"program_params"`                      // 赔率联动方案参数
}

// 赔率联动方案参数设置表
type OddLinkageProgramParam struct {
	ID                 string `db:"id" json:"id"`                                     // ID
	ProgramID          string `db:"program_id" json:"program_id"`                     // 赔率联动方案id
	Tag                int    `db:"tag" json:"tag"`                                   // 参数标签 1-区间参数 2-附加赔率 3-双倍返还率 4-固定赔率
	MasterCoefficient  string `db:"master_coefficient" json:"master_coefficient"`     // 主玩法变赔系数
	MinMasterLowOdd    string `db:"min_master_low_odd" json:"min_master_low_odd"`     // 主玩法低赔区间-最低
	MaxMasterLowOdd    string `db:"max_master_low_odd" json:"max_master_low_odd"`     // 主玩法低赔区间-最高
	SlaveCoefficient   string `db:"slave_coefficient" json:"slave_coefficient"`       // 副玩法变赔系数
	MinSlaveLowOdd     string `db:"min_slave_low_odd" json:"min_slave_low_odd"`       // 副玩法低赔区间-最低
	MaxSlaveLowOdd     string `db:"max_slave_low_odd" json:"max_slave_low_odd"`       // 副玩法低赔区间-最高
	SlaveAdditionalVal string `db:"slave_additional_val" json:"slave_additional_val"` // 副玩法低赔选项附加赔率值
	OddOptionName      string `db:"odd_option_name" json:"odd_option_name"`           // 玩法投注项名
	OddOptionValue     string `db:"odd_option_value" json:"odd_option_value"`         // 玩法投注项固定赔率
}

// 盘口赔率联动参数设置表
type MarketOddLinkageParam struct {
	ID                 string `db:"id" json:"id"`                                     // ID
	MatchID            string `db:"match_id" json:"match_id"`                         // 赛事ID
	MarketID           string `db:"market_id" json:"market_id"`                       // 盘口ID
	ParamType          int    `db:"param_type" json:"param_type"`                     // 参数类型 1-胜率 2-区间
	Tag                int    `db:"tag" json:"tag"`                                   // 参数标签 1-区间参数 2-附加赔率 3-双倍返还率 4-固定赔率
	MasterCoefficient  string `db:"master_coefficient" json:"master_coefficient"`     // 主玩法变赔系数
	MinMasterLowOdd    string `db:"min_master_low_odd" json:"min_master_low_odd"`     // 主玩法低赔区间-最低
	MaxMasterLowOdd    string `db:"max_master_low_odd" json:"max_master_low_odd"`     // 主玩法低赔区间-最高
	SlaveCoefficient   string `db:"slave_coefficient" json:"slave_coefficient"`       // 副玩法变赔系数
	MinSlaveLowOdd     string `db:"min_slave_low_odd" json:"min_slave_low_odd"`       // 副玩法低赔区间-最低
	MaxSlaveLowOdd     string `db:"max_slave_low_odd" json:"max_slave_low_odd"`       // 副玩法低赔区间-最高
	SlaveAdditionalVal string `db:"slave_additional_val" json:"slave_additional_val"` // 副玩法低赔选项附加赔率值
	SlaveOptionOdd     string `db:"odd_option_name" json:"odd_option_name"`           // 副玩法对应选项赔率
	CreateTime         int64  `db:"create_time" json:"create_time"`                   // 创建时间
	CreateByID         uint64 `db:"create_by_id" json:"create_by_id" `                // 创建人ID
	CreateByName       string `db:"create_by_name" json:"create_by_name"`             // 创建人名称
}

//赔率联动参数
type OddLinkageParam struct {
	MatchID         string //赛事ID
	MarketID        string //盘口ID
	MasterOddTypeID string //主玩法ID
	OptionType      int    //选项类型
	MatchLevel      int    //赛事等级
	Round           int    //第几局
}

//调配赔率联动参数
type OddUpdateLinkage struct {
	ID     string          `json:"id"`
	Name   string          `json:"name"`
	SortID int             `json:"sort_id"`
	Odd    decimal.Decimal `json:"odd"` //新赔率
	//OldOdd decimal.Decimal `json:"old_odd"` //原赔率
}

// 副玩法选项新旧赔率值
type SlaveOddTypeOdds struct {
	ID           string  `json:"id"`
	MatchID      string  `json:"match_id"`
	MarketID     string  `json:"market_id"`
	MarketCnName string  `json:"market_cn_name"`
	MarketEnName string  `json:"market_en_name"`
	ReturnRate   float64 `json:"return_rate"`
	OddName      string  `json:"odd_name"`
	Round        int     `json:"round"`
	Name         string  `json:"name"`
	OldOdd       string  `json:"old_odd"`
	Odd          string  `json:"odd"`
	IsDefault    int     `json:"is_default"`
}

//赔率联动-区间参数公式
func IntervalFormula(param *SlaveAdjustOddParam) decimal.Decimal {
	//跳赔倍数：(主赔率当前值-主区间最小值)/主玩法变赔系数 （取整）
	beatMultiple := param.MasterOdd.Sub(param.MasterMinInterval).Div(param.MasterCoefficient).IntPart()

	//副盘口赔率=副盘口区间最小值+(跳赔倍数x副玩法变赔系数)
	return param.SlaveMinInterval.Add(decimal.NewFromInt(beatMultiple).Mul(param.SlaveCoefficient))
}

//两项盘根据其中一个选项的赔率和返还率计算另一个选项的赔率
func OddWithReturnRate(odd, returnRate decimal.Decimal) decimal.Decimal {

	//两项盘赔率计算公式：选项1赔率 = 返还率 * 选项2赔率 / (选项2赔率 - 返还率)
	return returnRate.Mul(odd).Div(odd.Sub(returnRate))
}

//根据投注项赔率计算盘口返还率
func MarketReturnRate(odds []decimal.Decimal) float64 {

	rate := float64(0)
	def := decimal.NewFromInt(1)
	totalOddsRate := decimal.Zero
	for _, odd := range odds {
		totalOddsRate = totalOddsRate.Add(def.Div(odd))
	}

	//盘口返还率 = 1/ (1 / 选项1赔率+1 / 选项2赔率 + ……1 / 选项N赔率)
	rate, _ = def.Div(totalOddsRate).Mul(decimal.NewFromInt(100)).Truncate(1).Float64()
	return rate
}

/*
* @Description: 获取赔率联动列表
* @Author: awen
* @Date: 2021-11-08 13:23
* @LastEditTime: 2021-11-08 13:23
* @LastEditors: awen
 */
func OddLinkageFindAll(db *sqlx.DB, ex g.Ex, mchLevel int) ([]OddLinkageProgram, error) {

	var (
		data       []OddLinkageProgram
		programs   []OddLinkageProgram
		programIds []string
	)

	query, _, _ := dialect.From(TblOddLinkageProgram).Select(colOddLinkageProgram...).Where(ex).ToSQL()
	err := db.Select(&programs, query)
	if err != nil {
		return data, err
	}

	for _, program := range programs {
		//根据赛事等级过滤（盘口赔率联动参数设置无需判断赛事等级）
		if program.MarketID != "0" || checkProgramMatchLevel(mchLevel, program.MatchLevel) {
			data = append(data, program)
			programIds = append(programIds, program.ID)
		}
	}

	if len(programIds) > 0 {
		programParams, err := OddLinkageParamFindAll(db, g.Ex{"program_id": programIds})
		if err != nil {
			return data, err
		}

		mpProgramParams := map[string][]OddLinkageProgramParam{}
		for _, param := range programParams {
			mpProgramParams[param.ProgramID] = append(mpProgramParams[param.ProgramID], param)
		}

		for i, program := range data {
			data[i].ProgramParams = mpProgramParams[program.ID]
		}
	}

	return data, err
}

//检查赔率联动方案的赛事等级是否包含当前赛事的赛事等级
func checkProgramMatchLevel(mchLevel int, programLevels string) bool {

	levels := strings.Split(programLevels, ",")
	for _, level := range levels {
		lvl, err := strconv.Atoi(level)
		if err != nil {
			return false
		}

		if lvl == mchLevel {
			return true
		}
	}

	return false
}

/*
* @Description: 获取赔率联动参数列表
* @Author: awen
* @Date: 2021-11-08 13:26
* @LastEditTime: 2021-11-08 13:26
* @LastEditors: awen
 */
func OddLinkageParamFindAll(db *sqlx.DB, ex g.Ex) ([]OddLinkageProgramParam, error) {

	var data []OddLinkageProgramParam

	query, _, _ := dialect.From(TblOddLinkageProgramParam).Select(colOddLinkageProgramParam...).Where(ex).ToSQL()
	err := db.Select(&data, query)
	if err != nil {
		return data, err
	}

	return data, nil
}

/*
* @Description: 单个主盘口调赔时，副玩法盘口赔率联动
* @Author: awen
* @Date: 2021-11-14 14:05
* @LastEditTime: 2021-11-14 14:05
* @LastEditors: awen
 */
func SingleOddUpdateLinkage(db *sqlx.DB, pool *redis.ClusterClient, p *OddLinkageParam, masterOddUpdate []OddUpdateLinkage, isTest int) ([]SlaveOddTypeOdds, error) {

	if len(masterOddUpdate) != 2 {
		return nil, nil
	}

	var data []SlaveOddTypeOdds
	if p.OptionType != OptionTypeWinLose {
		return data, nil
	}

	oddTypeLinkagePrograms, err := OddLinkageFindAll(db, g.Ex{"master_odd_type_id": p.MasterOddTypeID, "rule": OddLinkageRuleMasterSlave}, p.MatchLevel)
	if err != nil {
		return nil, err
	}

	//无适配的赔率联动方案
	if len(oddTypeLinkagePrograms) == 0 {
		return nil, nil
	}

	//副玩法赔率联动参数map
	mpOddTypeProgram := map[string]OddLinkageProgram{}
	oddTypeIds := strset.New()
	for _, program := range oddTypeLinkagePrograms {
		//map不存在就新增，已存在则判断是否为盘口的参数设置，是则覆盖
		if _, ok := mpOddTypeProgram[program.OddTypeID]; !ok {
			mpOddTypeProgram[program.OddTypeID] = program
		} else {
			if program.MatchID == p.MatchID && program.Round == p.Round {
				mpOddTypeProgram[program.OddTypeID] = program
			}
		}
		oddTypeIds.Add(program.OddTypeID)
	}

	slaveMarkets, err := MarketListDB(db, g.Ex{"match_id": p.MatchID, "odd_type_id": oddTypeIds.List()})
	if err != nil {
		return data, err
	}

	//副玩法盘口（1个副玩法只会关联到1个盘口，要么是全局要么与主玩法同局）
	marketIds := strset.New()
	marketIds.Add(p.MarketID)
	mpOddTypeMkt := map[string]MarketData{}
	for _, slaveMkt := range slaveMarkets {
		if slaveMkt.Round == 0 || slaveMkt.Round == p.Round {
			marketIds.Add(slaveMkt.ID)
			mpOddTypeMkt[slaveMkt.OddTypeID] = slaveMkt
		}
	}

	slaveOdds, err := OddListDB(db, g.Ex{"market_id": marketIds.List()})
	if err != nil {
		return nil, err
	}

	mpMarketOdds := map[string][]Odd{}
	for _, odd := range slaveOdds {
		mpMarketOdds[odd.MarketID] = append(mpMarketOdds[odd.MarketID], odd)
		if odd.MarketID != p.MarketID {
			continue
		}
		//设置主盘口投注项序号
		for i, v := range masterOddUpdate {
			if v.ID != odd.ID {
				continue
			}
			v.SortID = odd.SortID
			masterOddUpdate[i] = v
		}
	}

	//主盘口低配值和低配选项序号
	masterLowOdd := masterOddUpdate[0].Odd
	masterLowSortID := masterOddUpdate[0].SortID
	if masterLowOdd.GreaterThan(masterOddUpdate[1].Odd) {
		masterLowOdd = masterOddUpdate[1].Odd
		masterLowSortID = masterOddUpdate[1].SortID
	}

	var (
		minMasterLowOdd, maxMasterLowOdd decimal.Decimal //主盘口低赔区间最小值和最大值
		slaveOddId                       string          //副盘口对应选项id
		slaveAnotherId                   string          //副盘口另一个选项id
		slavePreOdd                      string          //副盘口对应选项原赔率
		slaveOdd                         decimal.Decimal //副盘口对应选项赔率
		slaveAnotherOdd                  decimal.Decimal //副盘口另一个选项赔率
		slaveMktOdds                     []Odd           //副盘口的投注项
		slaveDoubleReturnRate            decimal.Decimal //副盘口双倍返还率
		ok                               bool
	)
	for k, v := range mpOddTypeProgram {
		if v.Rule != OddLinkageRuleMasterSlave {
			continue
		}

		//无匹配的副玩法盘口或副玩法盘口未开启赔率赔率联动，则跳过
		if _, ok = mpOddTypeMkt[k]; !ok || mpOddTypeMkt[k].OddLinkage != 1 {
			continue
		}

		switch v.ParamType {
		case OddLinkageParamTypeWinRateOrDouble: //胜率
		case OddLinkageParamTypeRangeOrFixed: //区间
			if slaveMktOdds, ok = mpMarketOdds[mpOddTypeMkt[k].ID]; ok {
				if len(slaveMktOdds) != 2 {
					continue
				}

				for _, slaveMktOdd := range slaveMktOdds {
					if slaveMktOdd.SortID == masterLowSortID {
						slaveOdd, _ = decimal.NewFromString(slaveMktOdd.Odd)
						slaveOddId = slaveMktOdd.ID
						slavePreOdd = slaveMktOdd.Odd
					} else {
						slaveAnotherId = slaveMktOdd.ID
						slaveAnotherOdd, _ = decimal.NewFromString(slaveMktOdd.Odd)
					}
				}
			}

			//副玩法盘口2倍返还率
			slaveDoubleReturnRate = decimal.NewFromFloat(mpOddTypeMkt[k].ReturnRate * 2).Div(Decimal100)
			//副玩法盘口对应选项超过2倍返还率不进行赔率联动
			if slaveOdd.GreaterThan(slaveDoubleReturnRate) {
				continue
			}

			//让分和大小选项类型盘口，目前没有序号，无法匹配选项
			if slaveAnotherId == "" {
				continue
			}

			for _, param := range v.ProgramParams {
				minMasterLowOdd, _ = decimal.NewFromString(param.MinMasterLowOdd)
				maxMasterLowOdd, _ = decimal.NewFromString(param.MaxMasterLowOdd)
				if masterLowOdd.LessThan(minMasterLowOdd) || masterLowOdd.GreaterThan(maxMasterLowOdd) {
					continue
				}

				if param.Tag == OddLinkageTagRange { //区间参数
					masterCoefficient, _ := decimal.NewFromString(param.MasterCoefficient)
					slaveCoefficient, _ := decimal.NewFromString(param.SlaveCoefficient)
					minSlaveLowOdd, _ := decimal.NewFromString(param.MinSlaveLowOdd)
					maxSlaveLowOdd, _ := decimal.NewFromString(param.MaxSlaveLowOdd)
					slaveAdjustParam := &SlaveAdjustOddParam{
						MasterOdd:         masterLowOdd,
						MasterMinInterval: minMasterLowOdd,
						MasterCoefficient: masterCoefficient,
						SlaveMinInterval:  minSlaveLowOdd,
						SlaveCoefficient:  slaveCoefficient,
					}
					slaveOdd = IntervalFormula(slaveAdjustParam)
					if slaveOdd.GreaterThan(maxSlaveLowOdd) {
						slaveOdd = maxSlaveLowOdd
					}
					break
				} else if param.Tag == OddLinkageTagAdditional { //附加赔率
					additionalVal, _ := decimal.NewFromString(param.SlaveAdditionalVal)
					slaveOdd = masterLowOdd.Add(additionalVal)
					break
				} else if param.Tag == OddLinkageTagDouble { //双倍返还率
					slaveOdd = slaveDoubleReturnRate
					break
				} else if param.Tag == OddLinkageTagFixed { //固定赔率
					slaveOdd, _ = decimal.NewFromString(param.OddOptionValue)
					break
				} else {
					return data, errs.Errorf("odd linkage program param tag[%d] error", param.Tag)
				}
			}

			//副盘口赔率不可超过双倍返还率
			if slaveOdd.GreaterThan(slaveDoubleReturnRate) {
				continue
			}

			if slavePreOdd != TrimDecimal(slaveOdd) {
				for _, v := range slaveMktOdds {
					if v.ID == slaveOddId {
						data = append(data, SlaveOddTypeOdds{
							ID:           slaveOddId,
							MarketID:     v.MarketID,
							MarketCnName: mpOddTypeMkt[k].CnName,
							Round:        mpOddTypeMkt[k].Round,
							ReturnRate:   mpOddTypeMkt[k].ReturnRate,
							OddName:      v.Name,
							OldOdd:       v.Odd,
							Odd:          TrimDecimal(slaveOdd),
						})
					} else {
						//计算另一个投注项的赔率
						newSlaveAnotherOdd := OddWithReturnRate(slaveOdd, decimal.NewFromFloat(mpOddTypeMkt[k].ReturnRate).Div(Decimal100))
						data = append(data, SlaveOddTypeOdds{
							ID:           slaveAnotherId,
							MarketID:     v.MarketID,
							MarketCnName: mpOddTypeMkt[k].CnName,
							Round:        mpOddTypeMkt[k].Round,
							ReturnRate:   mpOddTypeMkt[k].ReturnRate,
							OddName:      v.Name,
							OldOdd:       TrimDecimal(slaveAnotherOdd),
							Odd:          TrimDecimal(newSlaveAnotherOdd),
						})
					}
				}
			}

		default:
			return data, errs.Errorf("odd linkage program paramType[%d] error", v.ParamType)
		}
	}

	if len(data) > 0 {
		err = OddLinkageSlaveUpdate(db, pool, p.MatchID, data, isTest)
	}

	return data, err
}

//赔率联动更新副盘口赔率
func OddLinkageSlaveUpdate(db *sqlx.DB, pool *redis.ClusterClient, matchID string, oddUpdates []SlaveOddTypeOdds, isTest int) error {

	strSQL := ""
	for i := range oddUpdates {
		query, _, _ := dialect.Update(TblOdds).Set(g.Record{"odd": oddUpdates[i].Odd}).Where(g.Ex{"id": oddUpdates[i].ID}).ToSQL()
		strSQL = strSQL + query + ";"
	}

	dbConn, err := db.Begin()
	if err != nil {
		return err
	}

	if len(strSQL) > 0 {
		_, err = dbConn.Exec(strSQL)
		if err != nil {
			_ = dbConn.Rollback()
			return err
		}
	}

	// 更新副盘口缓存
	pipe := pool.Pipeline()
	for _, v := range oddUpdates {
		path := fmt.Sprintf(JPathOddField, v.ID, "odd")
		idxPath := fmt.Sprintf(JPathIdxOddField, v.ID, "odd")
		MarketCacheSet(pipe, matchID, v.MarketID, path, v.Odd, v.IsDefault == 1, idxPath, isTest)
	}
	_, err = pipe.Exec()
	if err != nil {
		_ = dbConn.Rollback()
		return err
	}

	return dbConn.Commit()
}

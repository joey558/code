package helper

import (
	"errors"
	"reflect"
	"strings"

	"github.com/buger/jsonparser"
	jsoniter "github.com/json-iterator/go"
)

var cjson = jsoniter.ConfigCompatibleWithStandardLibrary

func JsonEncode(v interface{}) ([]byte, error) {

	return cjson.Marshal(v)
}

func JsonDecode(v string) (map[string]interface{}, error) {

	reader := strings.NewReader(v)
	decoder := cjson.NewDecoder(reader)
	params := make(map[string]interface{})
	err := decoder.Decode(&params)

	return params, err

}

func JsonMarshalEx(v interface{}) []byte {

	data, _ := cjson.Marshal(v)
	return data
}

func JsonMarshal(v interface{}) ([]byte, error) {

	return cjson.Marshal(v)
}

func JsonUnmarshal(data []byte, v interface{}) error {
	return cjson.Unmarshal(data, v)
}

func JsonUnmarshalFromString(data string, v interface{}) error {
	return cjson.UnmarshalFromString(data, v)
}

func MarshalToString(v interface{}) (string, error) {
	return cjson.MarshalToString(v)
}

func GetValueByKeyFromJson(data []byte, key string) string {

	return cjson.Get(data, key).ToString()
}
func JsonGetBoolean(data []byte, keys ...string) (val bool, err error) {

	return jsonparser.GetBoolean(data, keys...)
}

func JsonGetString(data []byte, keys ...string) (val string, err error) {

	return jsonparser.GetString(data, keys...)
}

func JsonGetByte(data []byte, keys ...string) (value []byte, dataType jsonparser.ValueType, offset int, err error) {
	return jsonparser.Get(data, keys...)
}

func JsonGetInt(data []byte, keys ...string) (val int64, err error) {

	return jsonparser.GetInt(data, keys...)
}

func JsonGetFloat(data []byte, keys ...string) (val float64, err error) {

	return jsonparser.GetFloat(data, keys...)
}

func JsonGetToBool(data []byte, path ...interface{}) bool {

	return jsoniter.Get(data, path...).ToBool()
}

func JsonGetToString(data []byte, path ...interface{}) string {

	return jsoniter.Get(data, path...).ToString()
}

func JsonGetUnsafeString(data []byte, keys ...string) (val string, err error) {

	return jsonparser.GetUnsafeString(data, keys...)
}

// StructToMap
/**
* @Description: 结构体转Map
* @Author: noah
* @Date: 2021/7/26 14:24
* @LastEditTime:2021/7/26 14:24
* @LastEditors: noah
 */
func StructToMap(in interface{}) (map[string]interface{}, error) {
	out := map[string]interface{}{}

	v := reflect.ValueOf(in)
	if v.Kind() == reflect.Ptr {
		v = v.Elem()
	}

	if v.Kind() != reflect.Struct {
		return nil, errors.New("data is not struct")
	}

	t := v.Type()
	for i := 0; i < v.NumField(); i++ {
		fi := t.Field(i)
		if tagValue := fi.Tag.Get("json"); tagValue != "" {
			out[tagValue] = v.Field(i).Interface()
		}
	}
	return out, nil
}

//手动从[]interface{} 拼接json 数组
func JsonSplicing(data interface{}) string {

	itfSli := data.([]interface{})
	b := strings.Builder{}
	b.WriteString(`[`)
	for i, itf := range itfSli {
		b.WriteString(itf.(string))
		if i < len(itfSli)-1 {
			b.WriteString(",")
		}
	}
	b.WriteString(`]`)
	return b.String()
}
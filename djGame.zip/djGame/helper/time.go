package helper

import (
	"fmt"
	"github.com/golang-module/carbon"
	"github.com/valyala/fasthttp"
	"time"
)

func GetDailyTimeBegin(ctx *fasthttp.RequestCtx, n int) string {

	year, month, day := ctx.Time().AddDate(0, 0, n).Date()

	ts := time.Date(year, month, day, 0, 0, 0, 0, ctx.Time().Location()).Unix()

	return fmt.Sprintf("%d", ts)
}

func GetDailyTimeEnd(ctx *fasthttp.RequestCtx, n int) string {

	year, month, day := ctx.Time().AddDate(0, 0, n).Date()

	ts := time.Date(year, month, day, 23, 59, 59, 0, ctx.Time().Location()).Unix()

	return fmt.Sprintf("%d", ts)
}

func DailyEndTime(ctx *fasthttp.RequestCtx, n int) time.Time {

	year, month, day := ctx.Time().AddDate(0, 0, n).Date()

	end := time.Date(year, month, day, 23, 59, 59, 0, ctx.Time().Location())

	return end
}

// GetCreditComplexUpdateTime
/*
* @Description: 获取上次更新时间
* @Author: noah
* @Date: 2021/5/29 13:56
* @LastEditTime: 2021/5/29 13:56
* @LastEditors: noah
 */
func GetCreditComplexUpdateTime() int64 {
	t := time.Now()
	t1 := time.Date(t.Year(), t.Month(), t.Day(), 12, 0, 0, 0, t.Location())
	if t.After(t1) {
		return t1.UnixNano() / 1e6
	} else {
		return t1.AddDate(0, 0, -1).UnixNano() / 1e6
	}
}

// GetStartOfDayUnix
/*
* @Description: 获取今日开始时间秒数
* @Author: noah
* @Date: 2021/5/29 13:56
* @LastEditTime: 2021/5/29 13:56
* @LastEditors: noah
 */
func GetStartOfDayUnix() int64 {
	return carbon.Parse(carbon.Now().ToDateTimeString()).StartOfDay().ToTimestamp()
}

// GetEndOfDayUnix
/*
* @Description: 获取今日结束时间秒数
* @Author: noah
* @Date: 2021/5/29 13:56
* @LastEditTime: 2021/5/29 13:56
* @LastEditors: noah
 */
func GetEndOfDayUnix() int64 {
	return carbon.Parse(carbon.Now().ToDateTimeString()).EndOfDay().ToTimestamp()
}

// GetDiffInSecondsUnix
/*
* @Description: 获取此刻与今日结束相差时间秒数
* @Author: noah
* @Date: 2021/5/29 13:56
* @LastEditTime: 2021/5/29 13:56
* @LastEditors: noah
 */
func GetDiffInSecondsUnix() int64 {
	return GetEndOfDayUnix() - time.Now().Unix()
}

// GetDiffInSecondsTime
/*
* @Description: 获取此刻与今日结束相差时间
* @Author: noah
* @Date: 2021/5/29 13:56
* @LastEditTime: 2021/5/29 13:56
* @LastEditors: noah
 */
func GetDiffInSecondsTime() time.Duration {
	return time.Duration(GetDiffInSecondsUnix())
}

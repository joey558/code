package helper

import (
	"time"

	"github.com/valyala/fasthttp"
)

func Cputicks() (t uint64)

func HttpDoTimeout(requestBody []byte, method string, requestURI string, headers map[string]string, timeout time.Duration) ([]byte, int, error) {

	req := fasthttp.AcquireRequest()
	resp := fasthttp.AcquireResponse()

	defer func() {
		fasthttp.ReleaseResponse(resp)
		fasthttp.ReleaseRequest(req)
	}()

	req.SetRequestURI(requestURI)
	req.Header.SetMethod(method)

	switch method {
	case "POST":
		req.SetBody(requestBody)
	}

	if headers != nil {
		for k, v := range headers {
			req.Header.Set(k, v)
		}
	}

	// time.Second * 30
	fc := &fasthttp.Client{}
	err := fc.DoTimeout(req, resp, timeout)

	var respBytes []byte
	statusCode := 0
	if err == nil {
		respBytes = append(respBytes, resp.Body()...)
		statusCode = resp.StatusCode()
	}

	return respBytes, statusCode, err
}

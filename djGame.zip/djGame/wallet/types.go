package wallet

import "github.com/shopspring/decimal"

func Cputicks() (t uint64)

var DeciAlertAmount = decimal.NewFromInt32(5000)

//1-资金转入 2-资金转出 3-投注 4-派奖 5-取消注单 6-拒绝注单 7-撤单 8-撤销派奖 9-投注失败 10-走水退款 11-输半退款 12-活动奖励
const (
	TransIn             int = 1
	TransOut            int = 2
	TransBet            int = 3
	TransBetPrize       int = 4
	TransBetCancel      int = 5
	TransBetRefuse      int = 6
	TransBetUndo        int = 7
	TransBetPrizeDeduct int = 8
	TransBetFail        int = 9
	TransDrawRefund     int = 10
	TransLoseHalf       int = 11
	TransActivityAward  int = 12
)

//操作钱的方式 1加钱2扣钱
const (
	AddAmount int = 1
	SubAmount int = 2
)

const (
	CreditAddAmount       = "1" // 加款(取消/拒绝/撤单)
	CreditDeductionAmount = "2" // 扣款
	CreditBetPrize        = "3" // 派彩
	CreditPrizeDeduct     = "4" // 赛果回退
)

const RedisKeyMemberWallet = "W:%d" // 会员余额缓存

const (
	mqttBalanceFormat    = `{"uid":"%d","account":"%s","balance":"%s"}`
	mqttGrandPrizeFormat = `{"payload":"%s"}`
)

type Member struct {
	UID                   uint64 `db:"uid" json:"uid"`
	ParentMerchantID      uint64 `db:"parent_merchant_id" json:"parent_merchant_id" `
	ParentMerchantAccount string `db:"parent_merchant_account" json:"parent_merchant_account" `
	MerchantID            uint64 `db:"merchant_id" json:"merchant_id" `
	MerchantAccount       string `db:"merchant_account" json:"merchant_account" `
	Account               string `db:"account" json:"account" `
	Password              string `db:"password" json:"password"`
	TopMerchantId         uint64 `db:"top_merchant_id" json:"top_merchant_id"`           //顶层商户ID
	TopMerchantAccount    string `db:"top_merchant_account" json:"top_merchant_account"` //顶层商户账户名
	SortLevel             string `db:"sort_level" json:"sort_level"`                     //商户排序层级
	Deph                  uint64 `db:"deph" json:"deph"`                                 //商户层深
	RegisterTime          uint32 `db:"register_time" json:"register_time" `
	LastLoginTime         uint32 `db:"last_login_time" json:"last_login_time" `
	LastLoginIp           uint32 `db:"last_login_ip" json:"last_login_ip" `
	Tester                uint8  `db:"tester" json:"tester" `
	Status                uint8  `db:"status" json:"status" `
	LimitStatus           uint8  `db:"limit_status" json:"limit_status" `
	OnlineStatus          uint8  `db:"online_status" json:"online_status" `
	OddUpdateType         uint8  `db:"odd_update_type" json:"odd_update_type" `
	AgentID               uint64 `db:"agent_id" json:"agent_id"`           //直属代理ID(信用会员)
	AgentAccount          string `db:"agent_account" json:"agent_account"` //直属代理账号(信用会员)
	Lang                  string `db:"-" json:"lang"`                      //会员自选语言
	CurrencyCode          int    `db:"currency_code" json:"currency_code"` //币种编码
}

//会员钱包结构体
type MemberBalance struct {
	UID     uint64 `db:"uid"`     //会员id
	Balance string `db:"balance"` //余额
}

//金流结构体
type Transaction struct {
	ID                    uint64  `db:"id"`                      //id
	BetOrderID            uint64  `db:"bet_order_id"`            //注单id
	OrderNo               string  `db:"order_no"`                //订单号(商户转账流水号和本平台注单ID)
	MemberID              uint64  `db:"member_id"`               //会员id
	MemberAccount         string  `db:"member_account"`          //会员账号
	MerchantID            uint64  `db:"merchant_id"`             //商户id
	MerchantAccount       string  `db:"merchant_account"`        //商户账号
	ParentMerchantID      uint64  `db:"parent_merchant_id"`      //父商户id
	ParentMerchantAccount string  `db:"parent_merchant_account"` //父商户账号
	TopMerchantId         uint64  `db:"top_merchant_id"`         //顶层商户ID
	TopMerchantAccount    string  `db:"top_merchant_account"`    //顶层商户账户名
	SortLevel             string  `db:"sort_level"`              //商户排序层级
	Deph                  uint64  `db:"deph"`                    //商户层深
	TradeType             uint8   `db:"trade_type"`              //账变类型
	Amount                string  `db:"amount"`                  //金额
	BalanceBefore         string  `db:"balance_before"`          //账变前余额
	BalanceAfter          string  `db:"balance_after"`           //账变后余额
	CreatedTime           int64   `db:"created_time"`            //创建时间
	Tester                uint8   `db:"tester"`                  //是否测试
	AgentID               uint64  `db:"agent_id"`                //直属代理ID
	AgentAccount          string  `db:"agent_account"`           //直属代理账号
	CurrencyCode          int     `db:"currency_code"`           //币种编码
	ExchangeRate          float64 `db:"exchange_rate"`           //汇率
}

// 充正记录结构体
type ImpactRecord struct {
	ID                    uint64  `db:"id"`                      // 冲正ID
	TransactionID         uint64  `db:"transaction_id"`          // 流水单号
	ParentMerchantID      uint64  `db:"parent_merchant_id"`      // 父商户ID
	ParentMerchantAccount string  `db:"parent_merchant_account"` // 父商户账号
	MerchantID            uint64  `db:"merchant_id"`             // 商户ID
	MerchantAccount       string  `db:"merchant_account"`        // 商户账号
	MemberID              uint64  `db:"member_id"`               // 会员ID
	MemberAccount         string  `db:"member_account"`          // 会员账号
	TopMerchantId         uint64  `db:"top_merchant_id"`         // 顶层商户ID
	TopMerchantAccount    string  `db:"top_merchant_account"`    // 顶层商户账户名
	SortLevel             string  `db:"sort_level"`              // 商户排序层级
	Deph                  uint64  `db:"deph"`                    // 商户层深
	BeforeAmount          string  `db:"before_amount"`           // 帐变前金额
	AfterAmount           string  `db:"after_amount"`            // 帐变后金额
	ImpactAmount          string  `db:"impact_amount"`           // 冲正金额
	CreatedTime           int64   `db:"created_time"`            // 转账时间
	CurrencyCode          int     `db:"currency_code"`           //币种编码
	ExchangeRate          float64 `db:"exchange_rate"`           //汇率
}

//坏账结构体
type BadDebtRecord struct {
	ID                    uint64  `db:"id"`                      // 坏账ID
	BetOrderID            uint64  `db:"bet_order_id"`            // 注单编号
	ParentMerchantID      uint64  `db:"parent_merchant_id"`      // 父商户ID
	ParentMerchantAccount string  `db:"parent_merchant_account"` // 父商户账号
	TopMerchantId         uint64  `db:"top_merchant_id"`         // 顶层商户ID
	TopMerchantAccount    string  `db:"top_merchant_account"`    // 顶层商户账户名
	SortLevel             string  `db:"sort_level"`              // 商户排序层级
	Deph                  uint64  `db:"deph"`                    // 商户层深
	MerchantID            uint64  `db:"merchant_id"`             // 商户ID
	MerchantAccount       string  `db:"merchant_account"`        // 商户账号
	MemberID              uint64  `db:"member_id"`               // 会员ID
	MemberAccount         string  `db:"member_account"`          // 会员账号
	BeforeAmount          string  `db:"before_amount"`           // 帐变前金额
	AfterAmount           string  `db:"after_amount"`            // 帐变后金额
	ReceivableAmount      string  `db:"receivable_amount"`       // 应收金额
	ReceivedAmount        string  `db:"received_amount"`         // 已收金额
	UncollectedAmount     string  `db:"uncollected_amount"`      // 未收金额
	OrderType             uint8   `db:"order_type"`              // 注单类型 1 单注 2串注
	Ty                    uint8   `db:"ty"`                      // 类型 1 坏账 2 扣回
	CreatedTime           int64   `db:"created_time"`            // 回退时间
	CurrencyCode          int     `db:"currency_code"`           //币种编码
	ExchangeRate          float64 `db:"exchange_rate"`           //汇率
}

package wallet

import (
	"bytes"
	"database/sql"
	"errors"
	"fmt"
	mqtt "github.com/eclipse/paho.mqtt.golang"
	"github.com/shopspring/decimal"
	"github.com/valyala/fasthttp"
	"net/http"
	"strings"
	"time"
)

//金流: 操作钱包余额类型
var creditFundTypes = map[int]string{
	TransIn:             "",
	TransOut:            "",
	TransBet:            CreditDeductionAmount,
	TransBetPrize:       CreditBetPrize,
	TransBetCancel:      CreditAddAmount,
	TransBetRefuse:      CreditAddAmount,
	TransBetUndo:        CreditAddAmount,
	TransBetPrizeDeduct: CreditPrizeDeduct,
	TransBetFail:        CreditAddAmount,
}

var (
	XywHost        string
	XywHttpTimeout time.Duration
	XywSecretKey   string
	XywRetryNum    = 5
)

/**
 * @Description:获取信用网中心钱包剩余额度
 * @Author: awen
 * @Date: 2021/05/14 16:06
 * @LastEditTime: 2021/05/14 16:06
 * @LastEditors: awen
 */
func GetCreditBalance(username string) (string, error) {

	balance := "0.00"

	param := new(fasthttp.Args)
	param.Add("username", username)
	param.Add("time", fmt.Sprintf("%d", time.Now().Unix()))
	param.Add("key", XywSecretKey)
	param.Sort(bytes.Compare)
	str := GetMD5Hash(param.String())
	param.Add("sign", str)
	param.Del("key")

	resp, err := HttpPostHelper(XywHost+"/api/finance/credit/obdj/v1/getBalance", param.QueryString())
	if err != nil {
		return balance, err
	}

	if resp.Data == "" {
		return balance, nil
	}
	balance = resp.Data

	return balance, nil
}

/**
* @Description: 批量获取信用会员余额
* @Author: noah
* @Date: 2021/8/18 15:06
* @LastEditTime:2021/8/18 15:06
* @LastEditors: noah
 */
func GetCreditBalanceAll(usernames []string) (map[string]string, error) {

	username := strings.Join(usernames, ",")
	requ := new(fasthttp.Args)
	requ.Add("username", username)
	requ.Add("time", fmt.Sprintf("%d", time.Now().Unix()))
	requ.Sort(bytes.Compare)
	str := GetMD5Hash(requ.String())
	requ.Add("sign", str)
	url := XywSecretKey + "/api/finance/credit/obdj/v1/getBatchBalance"
	headers := map[string]string{
		"Content-Type": "application/x-www-form-urlencoded",
	}
	resp, status, err := httpDoTimeout(requ.QueryString(), fasthttp.MethodPost, url, headers, XywHttpTimeout)
	if err != nil {
		return nil, err
	}

	if status != http.StatusOK {
		return nil, errors.New("未正确获取信息")
	}

	data := RespModelList{}
	err = JsonUnmarshal(resp, &data)
	if err != nil {
		return nil, err
	}

	return data.Data, nil
}

/**
 * @Description:信用网会员钱包余额是否充足
 * @Author: awen
 * @Date: 2021/05/14 16:21
 * @LastEditTime: 2021/05/14 16:21
 * @LastEditors: awen
 */
func CreditBalanceIsEnough(username string, amount decimal.Decimal) (string, bool) {

	balanceVal, err := GetCreditBalance(username)
	if err != nil {
		return balanceVal, false
	}

	balance, err := decimal.NewFromString(balanceVal)
	if err != nil {
		return "0.00", false
	}

	if balance.Sub(amount).IsNegative() {
		return balance.String(), false
	}

	return balance.String(), true
}

/**
 * @Description:信用网中心钱包加/扣款
 * @Author: awen
 * @Date: 2021/05/14 16:21
 * @LastEditTime: 2021/05/14 16:21
 * @LastEditors: awen
 */
func CreditBalanceAddDeduction(username, sToken, orderID string, amount decimal.Decimal, transType int) (decimal.Decimal, bool, string) {

	opType := creditFundTypes[transType]
	if opType == "" {
		return decimal.Zero, false, "transaction type error"
	}
	balanceStr, err := GetCreditBalance(username)
	if err != nil {
		return decimal.Zero, false, err.Error()
	}

	balance, err := decimal.NewFromString(balanceStr)
	if err != nil {
		return decimal.Zero, false, err.Error()
	}

	data := new(fasthttp.Args)
	data.Add("username", username)
	data.Add("type", opType)
	data.Add("amount", amount.String())
	data.Add("orderId", orderID)
	data.Add("time", fmt.Sprintf("%d", time.Now().Unix()))
	data.Add("key", XywSecretKey)
	data.Add("stoken", sToken)
	data.Sort(bytes.Compare)
	str := GetMD5Hash(data.String())
	data.Add("sign", str)
	data.Del("key")

	var (
		i    int                 //中心钱包接口超时重试次数
		resp BetConfirmRespModel //中心钱包加扣款接口返回参数
	)
	// 非投注扣款操作中心钱包接口超时则重试
	for {
		resp, err = httpBetConfirmHelper(XywHost+"/api/finance/credit/obdj/v1/betConfirm", data.QueryString())
		if err == nil {
			break
		}

		if opType == CreditDeductionAmount && err == fasthttp.ErrTimeout {
			break
		}
		i++
		if i == XywRetryNum {
			break
		}
	}

	if err != nil {
		return decimal.Zero, false, err.Error()
	}

	if resp.Status == "false" {
		return balance, true, resp.Data
	}

	// 重置参数，验证响应签名是否合法
	data.Reset()
	data.Add("status", resp.Status)
	data.Add("data", resp.Data)
	data.Add("time", resp.Time)
	data.Add("key", XywSecretKey)
	data.Sort(bytes.Compare)
	sign := GetMD5Hash(data.String())
	if resp.Signature != sign {
		fmt.Printf("credit sign:%s | params:%s | md5Hash: %s \n", resp.Signature, data.String(), sign)
		return balance, false, "非法签名"
	}

	return balance, true, ""
}

//信用注单只插入账变，不派彩不扣款
func CreditTransfer(dbTx *sql.Tx, cli mqtt.Client, trans Transaction, amount decimal.Decimal, transType int, sToken string) error {

	balance, res, msg := CreditBalanceAddDeduction(trans.MemberAccount, sToken, trans.OrderNo, amount, transType)
	if !res {
		return errors.New(msg)
	}
	var balanceAfter decimal.Decimal
	amountType := balanceFundTypes[transType]
	if amountType == AddAmount {
		balanceAfter = balance.Add(amount)
	} else {
		balanceAfter = balance.Sub(amount)
	}

	trans.ID = GenId()
	trans.Amount = amount.String()
	trans.BalanceBefore = balance.String()
	trans.BalanceAfter = balanceAfter.String()
	trans.TradeType = uint8(transType)

	//增加账变
	query, _, _ := dialect.Insert("tbl_member_transaction").Rows(trans).ToSQL()
	fmt.Println(query)
	_, err := dbTx.Exec(query)
	if err != nil {
		return err
	}

	go mqttPushBalance(cli, trans.MemberID, trans.MemberAccount, trans.BalanceAfter)

	return nil
}

//操作中心钱包（投注专用），事务方式写入账变记录。 传入金额,无论加减钱都传正值
func TxCreditTransfer(dbConn *sql.Tx, cli mqtt.Client, param map[string]interface{}, balance, amount decimal.Decimal, tradeType int) error {

	var (
		ok                    bool
		orderNo               string //注单id
		memberID              uint64 //会员id
		memberAccount         string //会员账号
		merchantID            uint64 //商户id
		merchantAccount       string //商户账号
		parentMerchantId      uint64 //父商户id
		parentMerchantAccount string //父商户账号
		topMerchantId         uint64 //顶层商户ID
		topMerchantAccount    string //顶层商户账户名
		sortLevel             string //商户排序层级
		deph                  uint64 //商户层深
		tester                uint8  //是否测试
		agentID               uint64 //直属代理ID
		agentAccount          string //直属代理账号
	)

	if orderNo, ok = param["order_no"].(string); !ok {
		return errors.New("order_no参数错误")
	}
	if memberID, ok = param["member_id"].(uint64); !ok {
		return errors.New("member_id参数错误")
	}
	if memberAccount, ok = param["member_account"].(string); !ok {
		return errors.New("member_account参数错误")
	}
	if merchantID, ok = param["merchant_id"].(uint64); !ok {
		return errors.New("merchant_id参数错误")
	}
	if merchantAccount, ok = param["merchant_account"].(string); !ok {
		return errors.New("merchant_account参数错误")
	}
	if parentMerchantId, ok = param["parent_merchant_id"].(uint64); !ok {
		return errors.New("parent_merchant_id参数错误")
	}
	if parentMerchantAccount, ok = param["parent_merchant_account"].(string); !ok {
		return errors.New("parent_merchant_account参数错误")
	}
	if topMerchantId, ok = param["top_merchant_id"].(uint64); !ok {
		return errors.New("top_merchant_id参数错误")
	}
	if topMerchantAccount, ok = param["top_merchant_account"].(string); !ok {
		return errors.New("top_merchant_account参数错误")
	}
	if sortLevel, ok = param["sort_level"].(string); !ok {
		return errors.New("sort_level参数错误")
	}
	if deph, ok = param["deph"].(uint64); !ok {
		return errors.New("deph参数错误")
	}
	if tester, ok = param["tester"].(uint8); !ok {
		return errors.New("tester参数错误")
	}

	if agentID, ok = param["agent_id"].(uint64); !ok {
		return errors.New("agent_id参数错误")
	}
	if agentAccount, ok = param["agent_account"].(string); !ok {
		return errors.New("agent_account参数错误")
	}

	if tradeType > TransBetPrizeDeduct {
		return errors.New("tradeType参数错误")
	}

	var balanceAfter decimal.Decimal
	amountType := balanceFundTypes[tradeType]
	if amountType == AddAmount {
		balanceAfter = balance.Add(amount)
	} else {
		balanceAfter = balance.Sub(amount)
	}

	transID := GenId()
	trans := Transaction{
		BalanceBefore:         balance.String(),
		ID:                    transID,
		OrderNo:               orderNo,
		MemberID:              memberID,
		MemberAccount:         memberAccount,
		MerchantID:            merchantID,
		MerchantAccount:       merchantAccount,
		ParentMerchantID:      parentMerchantId,
		ParentMerchantAccount: parentMerchantAccount,
		TopMerchantId:         topMerchantId,
		TopMerchantAccount:    topMerchantAccount,
		SortLevel:             sortLevel,
		Deph:                  deph,
		TradeType:             uint8(tradeType),
		Amount:                amount.String(),
		CreatedTime:           time.Now().UnixNano() / 1e6,
		Tester:                tester,
		BalanceAfter:          balanceAfter.String(),
		AgentID:               agentID,
		AgentAccount:          agentAccount,
	}

	//增加账变
	query, _, _ := dialect.Insert("tbl_member_transaction").Rows(trans).ToSQL()
	fmt.Println(query)
	_, err := dbConn.Exec(query)
	if err != nil {
		return err
	}

	// 余额推送
	go mqttPushBalance(cli, memberID, memberAccount, balanceAfter.String())

	return nil
}

func GetBalanceResult(orderID string, transType int) (bool, error) {

	opType := creditFundTypes[transType]
	if opType == "" {
		return false, errors.New("transaction type error")
	}
	param := new(fasthttp.Args)
	param.Add("orderId", orderID)
	param.Add("type", opType)
	param.Add("time", fmt.Sprintf("%d", time.Now().Unix()))
	param.Add("key", XywSecretKey)
	param.Sort(bytes.Compare)
	str := GetMD5Hash(param.String())
	param.Add("sign", str)
	param.Del("key")

	resp, err := HttpPostHelper(XywHost+"/api/finance/credit/obdj/v1/getDeductionStatus", param.QueryString())
	if err != nil {
		return false, err
	}

	if resp.Status == "false" || resp.Data != "2" {
		return false, nil
	}

	return true, nil
}

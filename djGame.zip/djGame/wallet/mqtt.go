package wallet

import (
	"fmt"
	mqtt "github.com/eclipse/paho.mqtt.golang"
)

/**
 * @Description: mqtt推送用户当前余额
 * @Author: wesley
 * @Date: 2020/6/14 14:31
 * @LastEditTime: 2020/6/14 14:31
 * @LastEditors: wesley
 */
func mqttPushBalance(cli mqtt.Client, uid uint64, memberAccount string, balance string) {

	payload := fmt.Sprintf(mqttBalanceFormat, uid, memberAccount, balance)
	key := fmt.Sprintf("/member/balance/%d", uid)

	if token := cli.Publish(key, 0, false, payload); token.Wait() && token.Error() != nil {
		fmt.Printf("mqttPushBalance uid[%d] balance[%s] error:%s\n", uid, balance, token.Error())
	}
}

/**
 * @Description: mqtt推送单笔中奖金额大于5000的消息
 * @Author: awen
 * @Date: 2022-01-17 13:53
 * @LastEditTime: 2022-01-17 13:53
 * @LastEditors: awen
 */
func mqttPushGrandPrize(cli mqtt.Client, uid uint64, prize string) {

	key := fmt.Sprintf("/member/prize/%d", uid)
	payload := fmt.Sprintf(mqttGrandPrizeFormat, prize)

	if token := cli.Publish(key, 0, false, payload); token.Wait() && token.Error() != nil {
		fmt.Printf("mqttPushGrandPrize uid[%d] prize[%s] error:%s\n", uid, prize, token.Error())
	}
}
